#ifndef _SYS_FCNTL_H_
#define _SYS_FCNTL_H_
#include <sys/_default_fcntl.h>
#endif
