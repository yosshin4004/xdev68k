* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___mulsi3				*	.globl	__mulsi3
	.align	2					*	.align	2
	.globl	___mulvsi3				*	.globl	__mulvsi3
							*	.hidden	__mulvsi3
							*	.type	__mulvsi3, @function
___mulvsi3:						*__mulvsi3:
	movem.l d3/d4/d5/d6,-(sp)			*	movem.l #7680,-(%sp)
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	move.l 24(sp),d1				*	move.l 24(%sp),%d1
	move.l d0,d3					*	move.l %d0,%d3
	swap d3						*	swap %d3
	ext.l d3					*	ext.l %d3
	move.w d0,d5					*	move.w %d0,%d5
	moveq #15,d2					*	moveq #15,%d2
	asr.w d2,d5					*	asr.w %d2,%d5
	move.l d1,d4					*	move.l %d1,%d4
	swap d4						*	swap %d4
	ext.l d4					*	ext.l %d4
	move.w d1,d2					*	move.w %d1,%d2
	moveq #15,d6					*	moveq #15,%d6
	asr.w d6,d2					*	asr.w %d6,%d2
	cmp.w d5,d3					*	cmp.w %d5,%d3
	jbne _?L4					*	jne .L4
	cmp.w d2,d4					*	cmp.w %d2,%d4
	jbne _?L5					*	jne .L5
	muls.w d1,d0					*	muls.w %d1,%d0
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L4:							*.L4:
	cmp.w d2,d4					*	cmp.w %d2,%d4
	jbne _?L7					*	jne .L7
	move.l d0,a0					*	move.l %d0,%a0
	move.w d1,d4					*	move.w %d1,%d4
_?L6:							*.L6:
	move.w d0,d5					*	move.w %d0,%d5
	mulu.w d1,d5					*	mulu.w %d1,%d5
	move.w d4,d2					*	move.w %d4,%d2
	mulu.w d3,d2					*	mulu.w %d3,%d2
	tst.w d3					*	tst.w %d3
	jbge _?L8					*	jge .L8
	move.l d4,d3					*	move.l %d4,%d3
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	sub.l d3,d2					*	sub.l %d3,%d2
_?L8:							*.L8:
	tst.w d4					*	tst.w %d4
	jbge _?L9					*	jge .L9
	sub.l a0,d2					*	sub.l %a0,%d2
_?L9:							*.L9:
	move.l d5,d3					*	move.l %d5,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	add.l d3,d2					*	add.l %d3,%d2
	move.l d2,d3					*	move.l %d2,%d3
	swap d3						*	swap %d3
	ext.l d3					*	ext.l %d3
	move.w d2,d4					*	move.w %d2,%d4
	moveq #15,d6					*	moveq #15,%d6
	asr.w d6,d4					*	asr.w %d6,%d4
	cmp.w d4,d3					*	cmp.w %d4,%d3
	jbne _?L10					*	jne .L10
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	move.l d2,d0					*	move.l %d2,%d0
	or.w d5,d0					*	or.w %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L5:							*.L5:
	move.l d1,a0					*	move.l %d1,%a0
	move.w d4,d3					*	move.w %d4,%d3
	move.w d0,d4					*	move.w %d0,%d4
	jbra _?L6					*	jra .L6
_?L7:							*.L7:
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	move.w d3,d1					*	move.w %d3,%d1
	addq.w #1,d1					*	addq.w #1,%d1
	cmp.w #1,d1					*	cmp.w #1,%d1
	jbhi _?L13					*	jhi .L13
	move.w d4,d1					*	move.w %d4,%d1
	addq.w #1,d1					*	addq.w #1,%d1
	cmp.w #1,d1					*	cmp.w #1,%d1
	jbhi _?L13					*	jhi .L13
	cmp.w d3,d4					*	cmp.w %d3,%d4
	jbne _?L11					*	jne .L11
	tst.l d0					*	tst.l %d0
	jbgt _?L1					*	jgt .L1
_?L13:							*.L13:
	trap #7						*	trap #7
_?L11:							*.L11:
	tst.l d0					*	tst.l %d0
	jbge _?L13					*	jge .L13
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L10:							*.L10:
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	addq.l #8,sp					*	addq.l #8,%sp
	trap #7						*	trap #7
							*	.size	__mulvsi3, .-__mulvsi3
							*	.ident	"GCC: (GNU) 13.4.0"
