* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___ltxf2				*	.globl	__ltxf2
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixxfdi				*	.globl	__fixxfdi
							*	.hidden	__fixxfdi
							*	.type	__fixxfdi, @function
___fixxfdi:						*__fixxfdi:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d3				*	move.l 16(%sp),%d3
	move.l 20(sp),d4				*	move.l 20(%sp),%d4
	move.l 24(sp),d5				*	move.l 24(%sp),%d5
	move.l _?LC0+8,-(sp)				*	move.l .LC0+8,-(%sp)
	move.l _?LC0+4,-(sp)				*	move.l .LC0+4,-(%sp)
	move.l _?LC0,-(sp)				*	move.l .LC0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___ltxf2					*	jsr __ltxf2
	lea (24,sp),sp					*	lea (24,%sp),%sp
	tst.l d0					*	tst.l %d0
	jblt _?L8					*	jlt .L8
	move.l d3,16(sp)				*	move.l %d3,16(%sp)
	move.l d4,20(sp)				*	move.l %d4,20(%sp)
	move.l d5,24(sp)				*	move.l %d5,24(%sp)
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	jbra ___fixunsxfdi				*	jra __fixunsxfdi
_?L8:							*.L8:
	move.l d3,d0					*	move.l %d3,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l d4,d1					*	move.l %d4,%d1
	move.l d5,d2					*	move.l %d5,%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___fixunsxfdi				*	jsr __fixunsxfdi
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	lea (12,sp),sp					*	lea (12,%sp),%sp
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
							*	.size	__fixxfdi, .-__fixxfdi
							*	.ident	"GCC: (GNU) 13.4.0"
