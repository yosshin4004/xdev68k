* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___udivsi3				*	.globl	__udivsi3
	.globl	___mulsi3				*	.globl	__mulsi3
	.globl	___umodsi3				*	.globl	__umodsi3
	.align	2					*	.align	2
	.globl	___umoddi3				*	.globl	__umoddi3
							*	.hidden	__umoddi3
							*	.type	__umoddi3, @function
___umoddi3:						*__umoddi3:
	lea (-20,sp),sp					*	lea (-20,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 60(sp),d0				*	move.l 60(%sp),%d0
	move.l 64(sp),d1				*	move.l 64(%sp),%d1
	move.l 68(sp),d2				*	move.l 68(%sp),%d2
	move.l 72(sp),d5				*	move.l 72(%sp),%d5
	move.l d1,d3					*	move.l %d1,%d3
	move.l d0,a0					*	move.l %d0,%a0
	move.l d0,a5					*	move.l %d0,%a5
	tst.l d2					*	tst.l %d2
	jbne _?L2					*	jne .L2
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbcc _?L3					*	jcc .L3
	cmp.l #65535,d5					*	cmp.l #65535,%d5
	jbls _?L42					*	jls .L42
	cmp.l #16777215,d5				*	cmp.l #16777215,%d5
	jbhi _?L30					*	jhi .L30
	moveq #16,d2					*	moveq #16,%d2
_?L5:							*.L5:
	move.l d5,d4					*	move.l %d5,%d4
	lsr.l d2,d4					*	lsr.l %d2,%d4
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d4.l),d4				*	move.b (%a0,%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d4,d2					*	add.l %d4,%d2
	moveq #32,d4					*	moveq #32,%d4
	sub.l d2,d4					*	sub.l %d2,%d4
	moveq #32,d6					*	moveq #32,%d6
	cmp.l d2,d6					*	cmp.l %d2,%d6
	jbeq _?L6					*	jeq .L6
	lsl.l d4,d5					*	lsl.l %d4,%d5
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l d1,d3					*	move.l %d1,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	or.l d0,d3					*	or.l %d0,%d3
	move.l d3,a5					*	move.l %d3,%a5
	move.l d1,d3					*	move.l %d1,%d3
	lsl.l d4,d3					*	lsl.l %d4,%d3
_?L6:							*.L6:
	move.l d5,d6					*	move.l %d5,%d6
	clr.w d6					*	clr.w %d6
	swap d6						*	swap %d6
	move.l d5,d7					*	move.l %d5,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d3,d1					*	move.l %d3,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcc _?L7					*	jcc .L7
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L7					*	jcs .L7
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L43					*	jcs .L43
_?L7:							*.L7:
	move.l d1,a5					*	move.l %d1,%a5
	sub.l a6,a5					*	sub.l %a6,%a5
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d7,(sp)					*	move.l %d7,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d7					*	move.l %d0,%d7
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d3,d1					*	or.w %d3,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L8					*	jcc .L8
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L8					*	jcs .L8
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L8					*	jcc .L8
	add.l d5,d1					*	add.l %d5,%d1
_?L8:							*.L8:
	sub.l d7,d1					*	sub.l %d7,%d1
	moveq #0,d0					*	moveq #0,%d0
	lsr.l d4,d1					*	lsr.l %d4,%d1
_?L19:							*.L19:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L2:							*.L2:
	move.l d1,d4					*	move.l %d1,%d4
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L19					*	jcs .L19
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbls _?L44					*	jls .L44
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L32					*	jhi .L32
	moveq #16,d3					*	moveq #16,%d3
_?L22:							*.L22:
	move.l d2,d6					*	move.l %d2,%d6
	lsr.l d3,d6					*	lsr.l %d3,%d6
	lea ___clz_tab,a1				*	lea __clz_tab,%a1
	move.b (a1,d6.l),d6				*	move.b (%a1,%d6.l),%d6
	and.l #255,d6					*	and.l #255,%d6
	move.l d6,a1					*	move.l %d6,%a1
	add.l d3,a1					*	add.l %d3,%a1
	move.w #32,a6					*	move.w #32,%a6
	sub.l a1,a6					*	sub.l %a1,%a6
	moveq #32,d3					*	moveq #32,%d3
	cmp.l a1,d3					*	cmp.l %a1,%d3
	jbne _?L23					*	jne .L23
_?L46:							*.L46:
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbhi _?L24					*	jhi .L24
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L25					*	jcs .L25
_?L24:							*.L24:
	move.l d1,d4					*	move.l %d1,%d4
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d5,d4					*	sub.l %d5,%d4
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,a0					*	move.l %d0,%a0
_?L25:							*.L25:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d4,d1					*	move.l %d4,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L3:							*.L3:
	tst.l d5					*	tst.l %d5
	jbeq _?L31					*	jeq .L31
	cmp.l #65535,d5					*	cmp.l #65535,%d5
	jbhi _?L11					*	jhi .L11
	cmp.l #255,d5					*	cmp.l #255,%d5
	shi d4						*	shi %d4
	ext.w d4					*	ext.w %d4
	ext.l d4					*	ext.l %d4
	neg.l d4					*	neg.l %d4
	lsl.l #3,d4					*	lsl.l #3,%d4
	move.l d5,d2					*	move.l %d5,%d2
	lsr.l d4,d2					*	lsr.l %d4,%d2
_?L10:							*.L10:
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d2.l),d2				*	move.b (%a0,%d2.l),%d2
	and.l #255,d2					*	and.l #255,%d2
	add.l d4,d2					*	add.l %d4,%d2
	moveq #32,d4					*	moveq #32,%d4
	sub.l d2,d4					*	sub.l %d2,%d4
	moveq #32,d6					*	moveq #32,%d6
	cmp.l d2,d6					*	cmp.l %d2,%d6
	jbne _?L13					*	jne .L13
_?L48:							*.L48:
	move.l d0,d7					*	move.l %d0,%d7
	sub.l d5,d7					*	sub.l %d5,%d7
	move.l d5,d6					*	move.l %d5,%d6
	clr.w d6					*	clr.w %d6
	swap d6						*	swap %d6
	move.l d5,d0					*	move.l %d5,%d0
	and.l #65535,d0					*	and.l #65535,%d0
	move.l d0,a5					*	move.l %d0,%a5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
_?L14:							*.L14:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a5,(sp)					*	move.l %a5,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d3,d1					*	move.l %d3,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcc _?L17					*	jcc .L17
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L17					*	jcs .L17
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L45					*	jcs .L45
_?L17:							*.L17:
	move.l d1,d7					*	move.l %d1,%d7
	sub.l a6,d7					*	sub.l %a6,%d7
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a5,(sp)					*	move.l %a5,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a4					*	move.l %d0,%a4
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d3,d1					*	or.w %d3,%d1
	cmp.l a4,d1					*	cmp.l %a4,%d1
	jbcc _?L18					*	jcc .L18
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L18					*	jcs .L18
	cmp.l a4,d1					*	cmp.l %a4,%d1
	jbcc _?L18					*	jcc .L18
	add.l d5,d1					*	add.l %d5,%d1
_?L18:							*.L18:
	sub.l a4,d1					*	sub.l %a4,%d1
	moveq #0,d0					*	moveq #0,%d0
	lsr.l d4,d1					*	lsr.l %d4,%d1
	jbra _?L19					*	jra .L19
_?L42:							*.L42:
	cmp.l #255,d5					*	cmp.l #255,%d5
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	jbra _?L5					*	jra .L5
_?L44:							*.L44:
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d3						*	shi %d3
	ext.w d3					*	ext.w %d3
	ext.l d3					*	ext.l %d3
	neg.l d3					*	neg.l %d3
	lsl.l #3,d3					*	lsl.l #3,%d3
	move.l d2,d6					*	move.l %d2,%d6
	lsr.l d3,d6					*	lsr.l %d3,%d6
	lea ___clz_tab,a1				*	lea __clz_tab,%a1
	move.b (a1,d6.l),d6				*	move.b (%a1,%d6.l),%d6
	and.l #255,d6					*	and.l #255,%d6
	move.l d6,a1					*	move.l %d6,%a1
	add.l d3,a1					*	add.l %d3,%a1
	move.w #32,a6					*	move.w #32,%a6
	sub.l a1,a6					*	sub.l %a1,%a6
	moveq #32,d3					*	moveq #32,%d3
	cmp.l a1,d3					*	cmp.l %a1,%d3
	jbeq _?L46					*	jeq .L46
_?L23:							*.L23:
	move.l a6,d6					*	move.l %a6,%d6
	lsl.l d6,d2					*	lsl.l %d6,%d2
	move.l d5,d7					*	move.l %d5,%d7
	move.l a1,d3					*	move.l %a1,%d3
	lsr.l d3,d7					*	lsr.l %d3,%d7
	or.l d2,d7					*	or.l %d2,%d7
	lsl.l d6,d5					*	lsl.l %d6,%d5
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d3,d2					*	lsr.l %d3,%d2
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d1,d4					*	move.l %d1,%d4
	lsr.l d3,d4					*	lsr.l %d3,%d4
	or.l d0,d4					*	or.l %d0,%d4
	lsl.l d6,d1					*	lsl.l %d6,%d1
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l d7,d6					*	move.l %d7,%d6
	clr.w d6					*	clr.w %d6
	swap d6						*	swap %d6
	move.l d6,a5					*	move.l %d6,%a5
	move.l d7,d6					*	move.l %d7,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d2,56(sp)				*	move.l %d2,56(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l 52(sp),d2				*	move.l 52(%sp),%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d4,d2					*	move.l %d4,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d0,d2					*	or.l %d0,%d2
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 40(sp),a1				*	move.l 40(%sp),%a1
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbcc _?L26					*	jcc .L26
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d7,d2					*	add.l %d7,%d2
	cmp.l d7,d2					*	cmp.l %d7,%d2
	jbcs _?L34					*	jcs .L34
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbcc _?L34					*	jcc .L34
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d7,d2					*	add.l %d7,%d2
_?L26:							*.L26:
	sub.l d1,d2					*	sub.l %d1,%d2
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d2,56(sp)				*	move.l %d2,56(%sp)
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a4					*	move.l %d0,%a4
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l 52(sp),d2				*	move.l 52(%sp),%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d4,d0					*	or.w %d4,%d0
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l 40(sp),a1				*	move.l 40(%sp),%a1
	cmp.l a4,d0					*	cmp.l %a4,%d0
	jbcc _?L27					*	jcc .L27
	move.l d1,a0					*	move.l %d1,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d7,d0					*	add.l %d7,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcs _?L36					*	jcs .L36
	cmp.l a4,d0					*	cmp.l %a4,%d0
	jbcc _?L36					*	jcc .L36
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d7,d0					*	add.l %d7,%d0
_?L27:							*.L27:
	move.l d0,a0					*	move.l %d0,%a0
	sub.l a4,a0					*	sub.l %a4,%a0
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	or.l d1,d3					*	or.l %d1,%d3
	move.l d3,a3					*	move.l %d3,%a3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	a3,d0					*	move.l	%a3,%d0
	move.l	d5,d1					*	move.l	%d5,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a4					*	move.l	%d2,%a4
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a3					*	move.l	%d0,%a3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a3,d3					*	move.l %a3,%d3
	move.l a4,d2					*	move.l %a4,%d2
	cmp.l a0,a3					*	cmp.l %a0,%a3
	jbhi _?L28					*	jhi .L28
	jbeq _?L47					*	jeq .L47
_?L29:							*.L29:
	move.l a0,d0					*	move.l %a0,%d0
	move.l 52(sp),d6				*	move.l 52(%sp),%d6
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d6					*	sub.l %d2,%d6
	subx.l d3,d0					*	subx.l %d3,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	move.l a1,d2					*	move.l %a1,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l a6,d3					*	move.l %a6,%d3
	lsr.l d3,d6					*	lsr.l %d3,%d6
	lsr.l d3,d0					*	lsr.l %d3,%d0
	or.l d6,d1					*	or.l %d6,%d1
_?L49:							*.L49:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L31:							*.L31:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d4					*	moveq #0,%d4
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d2.l),d2				*	move.b (%a0,%d2.l),%d2
	and.l #255,d2					*	and.l #255,%d2
	add.l d4,d2					*	add.l %d4,%d2
	moveq #32,d4					*	moveq #32,%d4
	sub.l d2,d4					*	sub.l %d2,%d4
	moveq #32,d6					*	moveq #32,%d6
	cmp.l d2,d6					*	cmp.l %d2,%d6
	jbeq _?L48					*	jeq .L48
_?L13:							*.L13:
	lsl.l d4,d5					*	lsl.l %d4,%d5
	move.l d0,d3					*	move.l %d0,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	move.l d3,a1					*	move.l %d3,%a1
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l d1,d7					*	move.l %d1,%d7
	lsr.l d2,d7					*	lsr.l %d2,%d7
	or.l d0,d7					*	or.l %d0,%d7
	move.l d1,d3					*	move.l %d1,%d3
	lsl.l d4,d3					*	lsl.l %d4,%d3
	move.l d5,d6					*	move.l %d5,%d6
	clr.w d6					*	clr.w %d6
	swap d6						*	swap %d6
	move.l d5,d0					*	move.l %d5,%d0
	and.l #65535,d0					*	and.l #65535,%d0
	move.l d0,a5					*	move.l %d0,%a5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d7,d1					*	move.l %d7,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcc _?L15					*	jcc .L15
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L15					*	jcs .L15
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcc _?L15					*	jcc .L15
	add.l d5,d1					*	add.l %d5,%d1
_?L15:							*.L15:
	sub.l a6,d1					*	sub.l %a6,%d1
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a5,(sp)					*	move.l %a5,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d7,d0					*	or.w %d7,%d0
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a6,d0					*	cmp.l %a6,%d0
	jbcc _?L16					*	jcc .L16
	add.l d5,d0					*	add.l %d5,%d0
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbcs _?L16					*	jcs .L16
	cmp.l a6,d0					*	cmp.l %a6,%d0
	jbcc _?L16					*	jcc .L16
	add.l d5,d0					*	add.l %d5,%d0
_?L16:							*.L16:
	move.l d0,d7					*	move.l %d0,%d7
	sub.l a6,d7					*	sub.l %a6,%d7
	jbra _?L14					*	jra .L14
_?L47:							*.L47:
	cmp.l 52(sp),a4					*	cmp.l 52(%sp),%a4
	jbls _?L29					*	jls .L29
_?L28:							*.L28:
	move.l a3,d3					*	move.l %a3,%d3
	move.l a4,d2					*	move.l %a4,%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d5,d2					*	sub.l %d5,%d2
	subx.l d7,d3					*	subx.l %d7,%d3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a0,d0					*	move.l %a0,%d0
	move.l 52(sp),d6				*	move.l 52(%sp),%d6
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d6					*	sub.l %d2,%d6
	subx.l d3,d0					*	subx.l %d3,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	move.l a1,d2					*	move.l %a1,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l a6,d3					*	move.l %a6,%d3
	lsr.l d3,d6					*	lsr.l %d3,%d6
	lsr.l d3,d0					*	lsr.l %d3,%d0
	or.l d6,d1					*	or.l %d6,%d1
	jbra _?L49					*	jra .L49
_?L11:							*.L11:
	move.l d5,d2					*	move.l %d5,%d2
	cmp.l #16777215,d5				*	cmp.l #16777215,%d5
	jbhi _?L12					*	jhi .L12
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	moveq #16,d4					*	moveq #16,%d4
	jbra _?L10					*	jra .L10
_?L30:							*.L30:
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L5					*	jra .L5
_?L32:							*.L32:
	moveq #24,d3					*	moveq #24,%d3
	jbra _?L22					*	jra .L22
_?L36:							*.L36:
	move.l a0,d1					*	move.l %a0,%d1
	jbra _?L27					*	jra .L27
_?L34:							*.L34:
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L26					*	jra .L26
_?L45:							*.L45:
	add.l d5,d1					*	add.l %d5,%d1
	jbra _?L17					*	jra .L17
_?L43:							*.L43:
	add.l d5,d1					*	add.l %d5,%d1
	jbra _?L7					*	jra .L7
_?L12:							*.L12:
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	lsr.w #8,d2					*	lsr.w #8,%d2
	moveq #24,d4					*	moveq #24,%d4
	jbra _?L10					*	jra .L10
							*	.size	__umoddi3, .-__umoddi3
							*	.ident	"GCC: (GNU) 13.4.0"
