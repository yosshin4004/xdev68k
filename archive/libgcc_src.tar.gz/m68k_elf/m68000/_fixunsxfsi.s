* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___gexf2				*	.globl	__gexf2
	.globl	___subxf3				*	.globl	__subxf3
	.globl	___fixxfsi				*	.globl	__fixxfsi
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	1075707904				*	.long	1075707904
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsxfsi				*	.globl	__fixunsxfsi
							*	.hidden	__fixunsxfsi
							*	.type	__fixunsxfsi, @function
___fixunsxfsi:						*__fixunsxfsi:
	movem.l d3/d4/d5/a4/a5/a6,-(sp)			*	movem.l #7182,-(%sp)
	move.l 28(sp),d3				*	move.l 28(%sp),%d3
	move.l 32(sp),d4				*	move.l 32(%sp),%d4
	move.l 36(sp),d5				*	move.l 36(%sp),%d5
	move.l _?LC0,a4					*	move.l .LC0,%a4
	move.l _?LC0+4,a5				*	move.l .LC0+4,%a5
	move.l _?LC0+8,a6				*	move.l .LC0+8,%a6
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___gexf2					*	jsr __gexf2
	lea (24,sp),sp					*	lea (24,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbge _?L9					*	jge .L9
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___fixxfsi					*	jsr __fixxfsi
	lea (12,sp),sp					*	lea (12,%sp),%sp
	movem.l (sp)+,d3/d4/d5/a4/a5/a6			*	movem.l (%sp)+,#28728
	rts						*	rts
_?L9:							*.L9:
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___subxf3					*	jsr __subxf3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___fixxfsi					*	jsr __fixxfsi
	lea (12,sp),sp					*	lea (12,%sp),%sp
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	movem.l (sp)+,d3/d4/d5/a4/a5/a6			*	movem.l (%sp)+,#28728
	rts						*	rts
							*	.size	__fixunsxfsi, .-__fixunsxfsi
							*	.ident	"GCC: (GNU) 13.4.0"
