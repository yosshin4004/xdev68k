* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___muldi3				*	.globl	__muldi3
	.align	2					*	.align	2
	.globl	___mulvdi3				*	.globl	__mulvdi3
							*	.hidden	__mulvdi3
							*	.type	__mulvdi3, @function
___mulvdi3:						*__mulvdi3:
	lea (-20,sp),sp					*	lea (-20,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 60(sp),d6				*	move.l 60(%sp),%d6
	move.l 64(sp),d7				*	move.l 64(%sp),%d7
	move.l 68(sp),d4				*	move.l 68(%sp),%d4
	move.l 72(sp),d5				*	move.l 72(%sp),%d5
	move.l d6,d3					*	move.l %d6,%d3
	move.l d5,a6					*	move.l %d5,%a6
	move.l d5,d0					*	move.l %d5,%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	move.l d4,a3					*	move.l %d4,%a3
	move.l d7,d1					*	move.l %d7,%d1
	add.l d1,d1					*	add.l %d1,%d1
	subx.l d1,d1					*	subx.l %d1,%d1
	cmp.l d1,d3					*	cmp.l %d1,%d3
	jbne _?L2					*	jne .L2
	cmp.l d0,a3					*	cmp.l %d0,%a3
	jbne _?L3					*	jne .L3
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	smi d0						*	smi %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	smi d1						*	smi %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr ___muldi3					*	jsr __muldi3
	lea (16,sp),sp					*	lea (16,%sp),%sp
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L2:							*.L2:
	cmp.l d0,a3					*	cmp.l %d0,%a3
	jbne _?L9					*	jne .L9
	sub.l a4,a4					*	sub.l %a4,%a4
	sub.l a5,a5					*	sub.l %a5,%a5
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	lea ___muldi3,a3				*	lea __muldi3,%a3
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a0,56(sp)				*	move.l %a0,56(%sp)
	move.l a1,52(sp)				*	move.l %a1,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,a2					*	move.l %d0,%a2
	move.l a2,d0					*	move.l %a2,%d0
	tst.l d3					*	tst.l %d3
	jblt _?L25					*	jlt .L25
	cmp.w #0,a6					*	cmp.w #0,%a6
	jblt _?L26					*	jlt .L26
_?L11:							*.L11:
	move.l 48(sp),a1				*	move.l 48(%sp),%a1
	sub.l a0,a0					*	sub.l %a0,%a0
	move.l a0,d2					*	move.l %a0,%d2
	add.l a1,d1					*	add.l %a1,%d1
	addx.l d2,d0					*	addx.l %d2,%d0
	move.l d1,d2					*	move.l %d1,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbne _?L8					*	jne .L8
	move.l d1,d0					*	move.l %d1,%d0
	move.l 52(sp),d1				*	move.l 52(%sp),%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L3:							*.L3:
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	lea ___muldi3,a6				*	lea __muldi3,%a6
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,60(sp)				*	move.l %d7,60(%sp)
	move.l a0,56(sp)				*	move.l %a0,56(%sp)
	move.l d7,52(sp)				*	move.l %d7,52(%sp)
	jbsr (a6)					*	jsr (%a6)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	move.l 40(sp),a0				*	move.l 40(%sp),%a0
	move.l 36(sp),a1				*	move.l 36(%sp),%a1
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	jbsr (a6)					*	jsr (%a6)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,a1					*	move.l %d0,%a1
	move.l a1,d0					*	move.l %a1,%d0
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	cmp.w #0,a3					*	cmp.w #0,%a3
	jblt _?L27					*	jlt .L27
	tst.l d2					*	tst.l %d2
	jblt _?L28					*	jlt .L28
_?L6:							*.L6:
	move.l d3,a5					*	move.l %d3,%a5
	sub.l a4,a4					*	sub.l %a4,%a4
	move.l a4,d2					*	move.l %a4,%d2
	add.l a5,d1					*	add.l %a5,%d1
	addx.l d2,d0					*	addx.l %d2,%d0
	move.l d1,d2					*	move.l %d1,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbne _?L8					*	jne .L8
	move.l d1,d0					*	move.l %d1,%d0
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L28:							*.L28:
	sub.l d5,d1					*	sub.l %d5,%d1
	subx.l d4,d0					*	subx.l %d4,%d0
	jbra _?L6					*	jra .L6
_?L27:							*.L27:
	sub.l d7,a1					*	sub.l %d7,%a1
	move.l a1,d0					*	move.l %a1,%d0
	tst.l d2					*	tst.l %d2
	jbge _?L6					*	jge .L6
	jbra _?L28					*	jra .L28
_?L26:							*.L26:
	sub.l d7,d1					*	sub.l %d7,%d1
	subx.l d6,d0					*	subx.l %d6,%d0
	jbra _?L11					*	jra .L11
_?L25:							*.L25:
	move.l a2,d3					*	move.l %a2,%d3
	sub.l d5,d3					*	sub.l %d5,%d3
	move.l d3,d0					*	move.l %d3,%d0
	cmp.w #0,a6					*	cmp.w #0,%a6
	jbge _?L11					*	jge .L11
	jbra _?L26					*	jra .L26
_?L9:							*.L9:
	tst.l d3					*	tst.l %d3
	jblt _?L13					*	jlt .L13
	cmp.w #0,a3					*	cmp.w #0,%a3
	jblt _?L14					*	jlt .L14
	move.l d6,d0					*	move.l %d6,%d0
	or.l d4,d0					*	or.l %d4,%d0
	jbne _?L8					*	jne .L8
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldi3					*	jsr __muldi3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbge _?L1					*	jge .L1
_?L8:							*.L8:
	trap #7						*	trap #7
_?L13:							*.L13:
	cmp.w #0,a3					*	cmp.w #0,%a3
	jblt _?L16					*	jlt .L16
	addq.l #1,d3					*	addq.l #1,%d3
	jbne _?L8					*	jne .L8
	cmp.w #0,a3					*	cmp.w #0,%a3
	jbne _?L8					*	jne .L8
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldi3					*	jsr __muldi3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	sub.l d5,d0					*	sub.l %d5,%d0
	jbpl _?L8					*	jpl .L8
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L14:							*.L14:
	tst.l d3					*	tst.l %d3
	jbne _?L8					*	jne .L8
	moveq #-1,d0					*	moveq #-1,%d0
	cmp.l a3,d0					*	cmp.l %a3,%d0
	jbne _?L8					*	jne .L8
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldi3					*	jsr __muldi3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	sub.l d7,d0					*	sub.l %d7,%d0
	jbpl _?L8					*	jpl .L8
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L16:							*.L16:
	move.l d6,d0					*	move.l %d6,%d0
	and.l d4,d0					*	and.l %d4,%d0
	addq.l #1,d0					*	addq.l #1,%d0
	jbne _?L8					*	jne .L8
	move.l d7,d0					*	move.l %d7,%d0
	or.l d5,d0					*	or.l %d5,%d0
	jbeq _?L8					*	jeq .L8
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldi3					*	jsr __muldi3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	sub.l d7,d0					*	sub.l %d7,%d0
	sub.l d5,d0					*	sub.l %d5,%d0
	jbmi _?L8					*	jmi .L8
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
							*	.size	__mulvdi3, .-__mulvdi3
							*	.ident	"GCC: (GNU) 13.4.0"
