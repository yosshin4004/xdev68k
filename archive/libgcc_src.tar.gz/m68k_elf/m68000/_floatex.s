* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 228 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| This is an attempt at a decent floating point (single, double and
							*| extended double) code for the GNU C compiler. It should be easy to
							*| adapt to other compilers (but beware of the local labels!).
							*
							*| Starting date: 21 October, 1990
							*
							*| It is convenient to introduce the notation (s,e,f) for a floating point
							*| number, where s=sign, e=exponent, f=fraction. We will call a floating
							*| point number fpn to abbreviate, independently of the precision.
							*| Let MAX_EXP be in each case the maximum exponent (255 for floats, 1023
							*| for doubles and 16383 for long doubles). We then have the following
							*| different cases:
							*| 1. Normalized fpns have 0 < e < MAX_EXP. They correspond to
							*| (-1)^s x 1.f x 2^(e-bias-1).
							*| 2. Denormalized fpns have e=0. They correspond to numbers of the form
							*| (-1)^s x 0.f x 2^(-bias).
							*| 3. +/-INFINITY have e=MAX_EXP, f=0.
							*| 4. Quiet NaN (Not a Number) have all bits set.
							*| 5. Signaling NaN (Not a Number) have s=0, e=MAX_EXP, f=1.
							*
							*|=============================================================================
							*| exceptions
							*|=============================================================================
							*
							*| This is the floating point condition code register (_fpCCR):
							*|
							*| struct {
							*| short _exception_bits;
							*| short _trap_enable_bits;
							*| short _sticky_bits;
							*| short _rounding_mode;
							*| short _format;
							*| short _last_operation;
							*| union {
							*| float sf;
							*| double df;
							*| } _operand1;
							*| union {
							*| float sf;
							*| double df;
							*| } _operand2;
							*| } _fpCCR;
							*
 .data							* .data
 .even							* .even
							*
 .globl __fpCCR						* .globl _fpCCR
							*
__fpCCR:						*_fpCCR:
___exception_bits:					*__exception_bits:
 .dc.w 0						* .word 0
___trap_enable_bits:					*__trap_enable_bits:
 .dc.w 0						* .word 0
___sticky_bits:						*__sticky_bits:
 .dc.w 0						* .word 0
___rounding_mode:					*__rounding_mode:
 .dc.w ROUND_TO_NEAREST					* .word ROUND_TO_NEAREST
___format:						*__format:
 .dc.w NIL						* .word NIL
___last_operation:					*__last_operation:
 .dc.w NOOP						* .word NOOP
___operand1:						*__operand1:
 .dc.l 0						* .long 0
 .dc.l 0						* .long 0
___operand2:						*__operand2:
 .dc.l 0						* .long 0
 .dc.l 0						* .long 0
							*
							*| Offsets:
EBITS = ___exception_bits-__fpCCR			*EBITS = __exception_bits - _fpCCR
TRAPE = ___trap_enable_bits-__fpCCR			*TRAPE = __trap_enable_bits - _fpCCR
STICK = ___sticky_bits-__fpCCR				*STICK = __sticky_bits - _fpCCR
ROUND = ___rounding_mode-__fpCCR			*ROUND = __rounding_mode - _fpCCR
FORMT = ___format-__fpCCR				*FORMT = __format - _fpCCR
LASTO = ___last_operation-__fpCCR			*LASTO = __last_operation - _fpCCR
OPER1 = ___operand1-__fpCCR				*OPER1 = __operand1 - _fpCCR
OPER2 = ___operand2-__fpCCR				*OPER2 = __operand2 - _fpCCR
							*
							*| The following exception types are supported:
INEXACT_RESULT = 0x0001					*INEXACT_RESULT = 0x0001
UNDERFLOW = 0x0002					*UNDERFLOW = 0x0002
OVERFLOW = 0x0004					*OVERFLOW = 0x0004
DIVIDE_BY_ZERO = 0x0008					*DIVIDE_BY_ZERO = 0x0008
INVALID_OPERATION = 0x0010				*INVALID_OPERATION = 0x0010
							*
							*| The allowed rounding modes are:
UNKNOWN = -1						*UNKNOWN = -1
ROUND_TO_NEAREST = 0					*ROUND_TO_NEAREST = 0 | round result to nearest representable value
ROUND_TO_ZERO = 1					*ROUND_TO_ZERO = 1 | round result towards zero
ROUND_TO_PLUS = 2					*ROUND_TO_PLUS = 2 | round result towards plus infinity
ROUND_TO_MINUS = 3					*ROUND_TO_MINUS = 3 | round result towards minus infinity
							*
							*| The allowed values of format are:
NIL = 0							*NIL = 0
SINGLE_FLOAT = 1					*SINGLE_FLOAT = 1
DOUBLE_FLOAT = 2					*DOUBLE_FLOAT = 2
LONG_FLOAT = 3						*LONG_FLOAT = 3
							*
							*| The allowed values for the last operation are:
NOOP = 0						*NOOP = 0
ADD = 1							*ADD = 1
MULTIPLY = 2						*MULTIPLY = 2
DIVIDE = 3						*DIVIDE = 3
NEGATE = 4						*NEGATE = 4
COMPARE = 5						*COMPARE = 5
EXTENDSFDF = 6						*EXTENDSFDF = 6
TRUNCDFSF = 7						*TRUNCDFSF = 7
							*
							*|=============================================================================
							*| __clear_sticky_bits
							*|=============================================================================
							*
							*| The sticky bits are normally not cleared (thus the name), whereas the
							*| exception type and exception value reflect the last computation.
							*| This routine is provided to clear them (you can also write to _fpCCR,
							*| since it is globally visible).
							*
 .globl ___clear_sticky_bit				* .globl __clear_sticky_bit
							*
 .text							* .text
 .even							* .even
							*
							*| void __clear_sticky_bits(void);
___clear_sticky_bit:					*__clear_sticky_bit:
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
							*
 move.w #0,STICK(a0)					* movew #0,%a0@(STICK)
							*
							*
							*
 rts							* rts
							*
							*|=============================================================================
							*| $_exception_handler
							*|=============================================================================
							*
 .globl _$_exception_handler				* .globl $_exception_handler
							*
 .text							* .text
 .even							* .even
							*
							*| This is the common exit point if an exception occurs.
							*| NOTE: it is NOT callable from C!
							*| It expects the exception type in %d7, the format (SINGLE_FLOAT,
							*| DOUBLE_FLOAT or LONG_FLOAT) in %d6, and the last operation code in %d5.
							*| It sets the corresponding exception and sticky bits, and the format.
							*| Depending on the format if fills the corresponding slots for the
							*| operands which produced the exception (all this information is provided
							*| so if you write your own exception handlers you have enough information
							*| to deal with the problem).
							*| Then checks to see if the corresponding exception is trap-enabled,
							*| in which case it pushes the address of _fpCCR and traps through
							*| trap FPTRAP (15 for the moment).
							*
FPTRAP = 15						*FPTRAP = 15
							*
_$_exception_handler:					*$_exception_handler:
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w d7,EBITS(a0)					* movew %d7,%a0@(EBITS) | set __exception_bits
							*
 or.w d7,STICK(a0)					* orw %d7,%a0@(STICK) | and __sticky_bits
							*
							*
							*
							*
							*
 move.w d6,FORMT(a0)					* movew %d6,%a0@(FORMT) | and __format
 move.w d5,LASTO(a0)					* movew %d5,%a0@(LASTO) | and __last_operation
							*
							*| Now put the operands in place:
							*
 cmp.w #SINGLE_FLOAT,d6					* cmpw #SINGLE_FLOAT,%d6
							*
							*
							*
 beq 1f							* beq 1f
 move.l 8(a6),OPER1(a0)					* movel %a6@(8),%a0@(OPER1)
 move.l 12(a6),OPER1+4(a0)				* movel %a6@(12),%a0@(OPER1+4)
 move.l 16(a6),OPER2(a0)				* movel %a6@(16),%a0@(OPER2)
 move.l 20(a6),OPER2+4(a0)				* movel %a6@(20),%a0@(OPER2+4)
 bra 2f							* bra 2f
1: move.l 8(a6),OPER1(a0)				*1: movel %a6@(8),%a0@(OPER1)
 move.l 12(a6),OPER2(a0)				* movel %a6@(12),%a0@(OPER2)
2:							*2:
							*| And check whether the exception is trap-enabled:
							*
 and.w TRAPE(a0),d7					* andw %a0@(TRAPE),%d7 | is exception trap-enabled?
							*
							*
							*
							*
							*
 beq 1f							* beq 1f | no, exit
 PICPEA __fpCCR,a1					* PICPEA _fpCCR,%a1 | yes, push address of _fpCCR
 trap #FPTRAP						* trap #FPTRAP | and trap
							*
1: movem.l (sp)+,d2-d7					*1: moveml %sp@+,%d2-%d7 | restore data registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 | and return
 rts							* rts
							*# 3930 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
