* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clzdi2				*	.globl	__clzdi2
							*	.hidden	__clzdi2
							*	.type	__clzdi2, @function
___clzdi2:						*__clzdi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	tst.l d0					*	tst.l %d0
	jbeq _?L2					*	jeq .L2
	move.l d0,d1					*	move.l %d0,%d1
	sub.l a0,a0					*	sub.l %a0,%a0
_?L3:							*.L3:
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbhi _?L4					*	jhi .L4
	cmp.l #255,d1					*	cmp.l #255,%d1
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	moveq #32,d0					*	moveq #32,%d0
	sub.l d2,d0					*	sub.l %d2,%d0
	lsr.l d2,d1					*	lsr.l %d2,%d1
	lea ___clz_tab,a1				*	lea __clz_tab,%a1
	move.b (a1,d1.l),d1				*	move.b (%a1,%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L4:							*.L4:
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbhi _?L6					*	jhi .L6
	moveq #16,d0					*	moveq #16,%d0
	moveq #16,d2					*	moveq #16,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	lea ___clz_tab,a1				*	lea __clz_tab,%a1
	move.b (a1,d1.l),d1				*	move.b (%a1,%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L2:							*.L2:
	move.w #32,a0					*	move.w #32,%a0
	jbra _?L3					*	jra .L3
_?L6:							*.L6:
	moveq #8,d0					*	moveq #8,%d0
	moveq #24,d2					*	moveq #24,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	lea ___clz_tab,a1				*	lea __clz_tab,%a1
	move.b (a1,d1.l),d1				*	move.b (%a1,%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
							*	.size	__clzdi2, .-__clzdi2
							*	.ident	"GCC: (GNU) 13.4.0"
