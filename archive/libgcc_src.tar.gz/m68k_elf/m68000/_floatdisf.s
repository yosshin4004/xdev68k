* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___floatsidf				*	.globl	__floatsidf
	.globl	___muldf3				*	.globl	__muldf3
	.globl	___floatunsidf				*	.globl	__floatunsidf
	.globl	___adddf3				*	.globl	__adddf3
	.globl	___truncdfsf2				*	.globl	__truncdfsf2
	.align	2					*	.align	2
	.globl	___floatdisf				*	.globl	__floatdisf
							*	.hidden	__floatdisf
							*	.type	__floatdisf, @function
___floatdisf:						*__floatdisf:
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 24(sp),d6				*	move.l 24(%sp),%d6
	move.l 28(sp),d7				*	move.l 28(%sp),%d7
	move.l #2097151,d0				*	move.l #2097151,%d0
	moveq #-1,d1					*	moveq #-1,%d1
	add.l d7,d1					*	add.l %d7,%d1
	addx.l d6,d0					*	addx.l %d6,%d0
	move.l #4194303,d2				*	move.l #4194303,%d2
	moveq #-2,d3					*	moveq #-2,%d3
	sub.l d1,d3					*	sub.l %d1,%d3
	subx.l d0,d2					*	subx.l %d0,%d2
	jbcc _?L2					*	jcc .L2
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	move.l d7,d1					*	move.l %d7,%d1
	and.l #2047,d1					*	and.l #2047,%d1
	move.l d0,d3					*	move.l %d0,%d3
	or.l d1,d3					*	or.l %d1,%d3
	jbeq _?L2					*	jeq .L2
	move.l d7,d0					*	move.l %d7,%d0
	and.w #63488,d0					*	and.w #63488,%d0
	move.l d0,d7					*	move.l %d0,%d7
	or.w #2048,d7					*	or.w #2048,%d7
_?L2:							*.L2:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr ___floatsidf				*	jsr __floatsidf
	clr.l (sp)					*	clr.l (%sp)
	move.l #1106247680,-(sp)			*	move.l #1106247680,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldf3					*	jsr __muldf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr ___floatunsidf				*	jsr __floatunsidf
	move.l d5,(sp)					*	move.l %d5,(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___adddf3					*	jsr __adddf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___truncdfsf2				*	jsr __truncdfsf2
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
							*	.size	__floatdisf, .-__floatdisf
							*	.ident	"GCC: (GNU) 13.4.0"
