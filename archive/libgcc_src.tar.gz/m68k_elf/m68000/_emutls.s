* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"emutls.c"				*	.file	"emutls.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___emutls_get_address			*	.globl	__emutls_get_address
							*	.hidden	__emutls_get_address
							*	.type	__emutls_get_address, @function
___emutls_get_address:					*__emutls_get_address:
	movem.l d3/a3/a4,-(sp)				*	movem.l #4120,-(%sp)
	move.l 16(sp),a3				*	move.l 16(%sp),%a3
	move.l 8(a3),d3					*	move.l 8(%a3),%d3
	jbeq _?L14					*	jeq .L14
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/a3/a4				*	movem.l (%sp)+,#6152
	rts						*	rts
_?L14:							*.L14:
	move.l 4(a3),d3					*	move.l 4(%a3),%d3
	move.l (a3),a4					*	move.l (%a3),%a4
	moveq #4,d0					*	moveq #4,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcs _?L3					*	jcs .L3
	pea 4(a4)					*	pea 4(%a4)
	jbsr _malloc					*	jsr malloc
	move.l d0,a0					*	move.l %d0,%a0
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L6					*	jeq .L6
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #4,d3					*	addq.l #4,%d3
_?L5:							*.L5:
	move.l 12(a3),d0				*	move.l 12(%a3),%d0
	jbeq _?L7					*	jeq .L7
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d3,8(a3)					*	move.l %d3,8(%a3)
_?L15:							*.L15:
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/a3/a4				*	movem.l (%sp)+,#6152
	rts						*	rts
_?L3:							*.L3:
	pea 3(a4,d3.l)					*	pea 3(%a4,%d3.l)
	jbsr _malloc					*	jsr malloc
	move.l d0,a0					*	move.l %d0,%a0
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L6					*	jeq .L6
	lea 3(a0,d3.l),a1				*	lea 3(%a0,%d3.l),%a1
	move.l a1,d0					*	move.l %a1,%d0
	neg.l d3					*	neg.l %d3
	and.l d0,d3					*	and.l %d0,%d3
	move.l d3,a1					*	move.l %d3,%a1
	move.l a0,-4(a1)				*	move.l %a0,-4(%a1)
	jbra _?L5					*	jra .L5
_?L7:							*.L7:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _memset					*	jsr memset
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d3,8(a3)					*	move.l %d3,8(%a3)
	jbra _?L15					*	jra .L15
_?L6:							*.L6:
	trap #7						*	trap #7
							*	.size	__emutls_get_address, .-__emutls_get_address
	.align	2					*	.align	2
	.globl	___emutls_register_common		*	.globl	__emutls_register_common
							*	.hidden	__emutls_register_common
							*	.type	__emutls_register_common, @function
___emutls_register_common:				*__emutls_register_common:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	move.l 12(sp),d1				*	move.l 12(%sp),%d1
	cmp.l (a0),d0					*	cmp.l (%a0),%d0
	jbls _?L17					*	jls .L17
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 12(a0)					*	clr.l 12(%a0)
_?L17:							*.L17:
	cmp.l 4(a0),d1					*	cmp.l 4(%a0),%d1
	jbls _?L18					*	jls .L18
	move.l d1,4(a0)					*	move.l %d1,4(%a0)
_?L18:							*.L18:
	tst.l 16(sp)					*	tst.l 16(%sp)
	jbeq _?L16					*	jeq .L16
	cmp.l (a0),d0					*	cmp.l (%a0),%d0
	jbeq _?L25					*	jeq .L25
_?L16:							*.L16:
	rts						*	rts
_?L25:							*.L25:
	move.l 16(sp),12(a0)				*	move.l 16(%sp),12(%a0)
	rts						*	rts
							*	.size	__emutls_register_common, .-__emutls_register_common
							*	.ident	"GCC: (GNU) 13.4.0"
