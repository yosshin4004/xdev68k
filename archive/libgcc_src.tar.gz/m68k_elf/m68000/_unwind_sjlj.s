* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"unwind-sjlj.c"				*	.file	"unwind-sjlj.c"
	.text						*	.text
							*	.ident	"GCC: (GNU) 13.4.0"
