* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___negvdi2				*	.globl	__negvdi2
							*	.hidden	__negvdi2
							*	.type	__negvdi2, @function
___negvdi2:						*__negvdi2:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d2				*	move.l 16(%sp),%d2
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	move.l #-2147483648,d4				*	move.l #-2147483648,%d4
	clr.l d5					*	clr.l %d5
	sub.l d3,d5					*	sub.l %d3,%d5
	subx.l d2,d4					*	subx.l %d2,%d4
	jbeq _?L8					*	jeq .L8
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L8:							*.L8:
	trap #7						*	trap #7
							*	.size	__negvdi2, .-__negvdi2
							*	.ident	"GCC: (GNU) 13.4.0"
