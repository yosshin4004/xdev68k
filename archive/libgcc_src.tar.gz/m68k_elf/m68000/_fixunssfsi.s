* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___gesf2				*	.globl	__gesf2
	.globl	___subsf3				*	.globl	__subsf3
	.globl	___fixsfsi				*	.globl	__fixsfsi
	.align	2					*	.align	2
	.globl	___fixunssfsi				*	.globl	__fixunssfsi
							*	.hidden	__fixunssfsi
							*	.type	__fixunssfsi, @function
___fixunssfsi:						*__fixunssfsi:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d3				*	move.l 12(%sp),%d3
	move.l #0x4f000000,d4				*	move.l #0x4f000000,%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___gesf2					*	jsr __gesf2
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbge _?L9					*	jge .L9
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___fixsfsi					*	jsr __fixsfsi
	addq.l #4,sp					*	addq.l #4,%sp
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L9:							*.L9:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___subsf3					*	jsr __subsf3
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,(sp)					*	move.l %d0,(%sp)
	jbsr ___fixsfsi					*	jsr __fixsfsi
	addq.l #4,sp					*	addq.l #4,%sp
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
							*	.size	__fixunssfsi, .-__fixunssfsi
							*	.ident	"GCC: (GNU) 13.4.0"
