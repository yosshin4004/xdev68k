* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"crtstuff.c"				*	.file	"crtstuff.c"
	.text						*	.text
							*	.section	.ctors,"aw"
	.align	2					*	.align	2
							*	.type	__CTOR_LIST__, @object
___CTOR_LIST__:						*__CTOR_LIST__:
	.dc.l	-1					*	.long	-1
							*	.section	.dtors,"aw"
	.align	2					*	.align	2
							*	.type	__DTOR_LIST__, @object
___DTOR_LIST__:						*__DTOR_LIST__:
	.dc.l	-1					*	.long	-1
							*	.section	.eh_frame,"a"
	.align	2					*	.align	2
							*	.type	__EH_FRAME_BEGIN__, @object
___EH_FRAME_BEGIN__:					*__EH_FRAME_BEGIN__:
							*	.section	.tm_clone_table,"aw"
	.align	2					*	.align	2
							*	.type	__TMC_LIST__, @object
___TMC_LIST__:						*__TMC_LIST__:
	.text						*	.text
	.align	2					*	.align	2
							*	.type	deregister_tm_clones, @function
_deregister_tm_clones:					*deregister_tm_clones:
	move.l #___TMC_END__,d0				*	move.l #__TMC_END__,%d0
	cmp.l #___TMC_LIST__,d0				*	cmp.l #__TMC_LIST__,%d0
	jbeq _?L1					*	jeq .L1
	lea __ITM_deregisterTMCloneTable,a0		*	lea _ITM_deregisterTMCloneTable,%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L1					*	jeq .L1
	pea ___TMC_LIST__				*	pea __TMC_LIST__
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
_?L1:							*.L1:
	rts						*	rts
	.align	2					*	.align	2
							*	.type	register_tm_clones, @function
_register_tm_clones:					*register_tm_clones:
	move.l #___TMC_END__,d0				*	move.l #__TMC_END__,%d0
	sub.l #___TMC_LIST__,d0				*	sub.l #__TMC_LIST__,%d0
	move.l d0,d1					*	move.l %d0,%d1
	asr.l #2,d1					*	asr.l #2,%d1
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	add.l d1,d0					*	add.l %d1,%d0
	asr.l #1,d0					*	asr.l #1,%d0
	jbeq _?L11					*	jeq .L11
	lea __ITM_registerTMCloneTable,a0		*	lea _ITM_registerTMCloneTable,%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L11					*	jeq .L11
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	pea ___TMC_LIST__				*	pea __TMC_LIST__
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
_?L11:							*.L11:
	rts						*	rts
							*	.hidden	__dso_handle
	.globl	___dso_handle				*	.globl	__dso_handle
	.data						*	.data
	.align	2					*	.align	2
							*	.type	__dso_handle, @object
___dso_handle:						*__dso_handle:
	.ds.b	4					*	.zero	4
	.text						*	.text
	.align	2					*	.align	2
							*	.type	__do_global_dtors_aux, @function
___do_global_dtors_aux:					*__do_global_dtors_aux:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	tst.b (_completed?2).l				*	tst.b (completed.2).l
	jbne _?L21					*	jne .L21
	lea ___DTOR_LIST__,a3				*	lea __DTOR_LIST__,%a3
	move.l (_dtor_idx?1),d0				*	move.l (dtor_idx.1),%d0
	move.l #___DTOR_END__,d3			*	move.l #__DTOR_END__,%d3
	sub.l #___DTOR_LIST__,d3			*	sub.l #__DTOR_LIST__,%d3
	asr.l #2,d3					*	asr.l #2,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	cmp.l d0,d3					*	cmp.l %d0,%d3
	jbls _?L23					*	jls .L23
_?L24:							*.L24:
	addq.l #1,d0					*	addq.l #1,%d0
	move.l d0,(_dtor_idx?1)				*	move.l %d0,(dtor_idx.1)
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a3,d0.l),a0				*	move.l (%a3,%d0.l),%a0
	jbsr (a0)					*	jsr (%a0)
	move.l (_dtor_idx?1),d0				*	move.l (dtor_idx.1),%d0
	cmp.l d0,d3					*	cmp.l %d0,%d3
	jbhi _?L24					*	jhi .L24
_?L23:							*.L23:
	jbsr _deregister_tm_clones			*	jsr deregister_tm_clones
	lea ___deregister_frame_info,a0			*	lea __deregister_frame_info,%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L25					*	jeq .L25
	pea ___EH_FRAME_BEGIN__				*	pea __EH_FRAME_BEGIN__
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
_?L25:							*.L25:
	move.b #1,(_completed?2)			*	move.b #1,(completed.2)
_?L21:							*.L21:
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
	.align	2					*	.align	2
							*	.type	call___do_global_dtors_aux, @function
_call___do_global_dtors_aux:				*call___do_global_dtors_aux:
* APP ON (APP) asm_mode=gas				*#APP
							*| 443 "build_gcc/src/gcc-13.4.0/libgcc/crtstuff.c" 1
							*		.section	.fini
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	jbsr ___do_global_dtors_aux			*	jsr __do_global_dtors_aux
* APP ON (APP) asm_mode=gas				*#APP
							*| 443 "build_gcc/src/gcc-13.4.0/libgcc/crtstuff.c" 1
		.text					*		.text
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	rts						*	rts
	.align	2					*	.align	2
							*	.type	frame_dummy, @function
_frame_dummy:						*frame_dummy:
	lea ___register_frame_info,a0			*	lea __register_frame_info,%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L35					*	jeq .L35
	pea (_object?0)					*	pea (object.0)
	pea ___EH_FRAME_BEGIN__				*	pea __EH_FRAME_BEGIN__
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
_?L35:							*.L35:
	jbra _register_tm_clones			*	jra register_tm_clones
	.align	2					*	.align	2
							*	.type	call_frame_dummy, @function
_call_frame_dummy:					*call_frame_dummy:
* APP ON (APP) asm_mode=gas				*#APP
							*| 496 "build_gcc/src/gcc-13.4.0/libgcc/crtstuff.c" 1
							*		.section	.init
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	jbsr _frame_dummy				*	jsr frame_dummy
* APP ON (APP) asm_mode=gas				*#APP
							*| 496 "build_gcc/src/gcc-13.4.0/libgcc/crtstuff.c" 1
		.text					*		.text
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	rts						*	rts
							*	.local	completed.2
	.comm	_completed?2,1				*	.comm	completed.2,1,1
							*	.local	dtor_idx.1
	.align 2	* workaround for 3 args .comm directive.
	.comm	_dtor_idx?1,4				*	.comm	dtor_idx.1,4,2
							*	.local	object.0
	.align 2	* workaround for 3 args .comm directive.
	.comm	_object?0,24				*	.comm	object.0,24,2
	.globl	___register_frame_info			*	.weak	__register_frame_info
	.globl	___deregister_frame_info		*	.weak	__deregister_frame_info
	.globl	__ITM_registerTMCloneTable		*	.weak	_ITM_registerTMCloneTable
	.globl	__ITM_deregisterTMCloneTable		*	.weak	_ITM_deregisterTMCloneTable
							*	.hidden	__DTOR_END__
							*	.hidden	__TMC_END__
							*	.ident	"GCC: (GNU) 13.4.0"
