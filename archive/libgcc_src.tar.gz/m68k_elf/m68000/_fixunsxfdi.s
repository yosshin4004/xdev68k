* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___ltxf2				*	.globl	__ltxf2
	.globl	___mulxf3				*	.globl	__mulxf3
	.globl	___fixunsxfsi				*	.globl	__fixunsxfsi
	.globl	___floatundixf				*	.globl	__floatundixf
	.globl	___subxf3				*	.globl	__subxf3
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC1:							*.LC1:
	.dc.l	1071579136				*	.long	1071579136
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsxfdi				*	.globl	__fixunsxfdi
							*	.hidden	__fixunsxfdi
							*	.type	__fixunsxfdi, @function
___fixunsxfdi:						*__fixunsxfdi:
	lea (-20,sp),sp					*	lea (-20,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 60(sp),d3				*	move.l 60(%sp),%d3
	move.l 64(sp),d4				*	move.l 64(%sp),%d4
	move.l 68(sp),d5				*	move.l 68(%sp),%d5
	move.l _?LC0,a4					*	move.l .LC0,%a4
	move.l _?LC0+4,a5				*	move.l .LC0+4,%a5
	move.l _?LC0+8,a6				*	move.l .LC0+8,%a6
	lea ___ltxf2,a3					*	lea __ltxf2,%a3
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	tst.l d0					*	tst.l %d0
	jblt _?L5					*	jlt .L5
	move.l _?LC1+8,-(sp)				*	move.l .LC1+8,-(%sp)
	move.l _?LC1+4,-(sp)				*	move.l .LC1+4,-(%sp)
	move.l _?LC1,-(sp)				*	move.l .LC1,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___mulxf3					*	jsr __mulxf3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	lea ___fixunsxfsi,a0				*	lea __fixunsxfsi,%a0
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a0,48(sp)				*	move.l %a0,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,d6					*	move.l %d0,%d6
	moveq #0,d7					*	moveq #0,%d7
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___floatundixf				*	jsr __floatundixf
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___subxf3					*	jsr __subxf3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.l d1,d4					*	move.l %d1,%d4
	move.l d2,d5					*	move.l %d2,%d5
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	tst.l d0					*	tst.l %d0
	jblt _?L10					*	jlt .L10
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,44(sp)				*	move.l %d0,44(%sp)
	clr.l 40(sp)					*	clr.l 40(%sp)
	move.l 40(sp),d0				*	move.l 40(%sp),%d0
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	add.l d7,d1					*	add.l %d7,%d1
	addx.l d6,d0					*	addx.l %d6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L10:							*.L10:
	move.l d3,d0					*	move.l %d3,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l d4,d1					*	move.l %d4,%d1
	move.l d5,d2					*	move.l %d5,%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	clr.l 48(sp)					*	clr.l 48(%sp)
	move.l d6,d0					*	move.l %d6,%d0
	move.l d7,d1					*	move.l %d7,%d1
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	sub.l 52(sp),d1					*	sub.l 52(%sp),%d1
	subx.l d2,d0					*	subx.l %d2,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L5:							*.L5:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
							*	.size	__fixunsxfdi, .-__fixunsxfdi
							*	.ident	"GCC: (GNU) 13.4.0"
