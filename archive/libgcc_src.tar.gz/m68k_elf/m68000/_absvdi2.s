* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___absvdi2				*	.globl	__absvdi2
							*	.hidden	__absvdi2
							*	.type	__absvdi2, @function
___absvdi2:						*__absvdi2:
	movem.l d3/d4/d5/d6,-(sp)			*	movem.l #7680,-(%sp)
	move.l 20(sp),d2				*	move.l 20(%sp),%d2
	move.l 24(sp),d3				*	move.l 24(%sp),%d3
	move.l d2,d6					*	move.l %d2,%d6
	add.l d6,d6					*	add.l %d6,%d6
	subx.l d6,d6					*	subx.l %d6,%d6
	move.l d6,d1					*	move.l %d6,%d1
	smi d0						*	smi %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	add.l d3,d5					*	add.l %d3,%d5
	addx.l d2,d4					*	addx.l %d2,%d4
	move.l d0,d3					*	move.l %d0,%d3
	eor.l d2,d3					*	eor.l %d2,%d3
	eor.l d4,d2					*	eor.l %d4,%d2
	not.l d3					*	not.l %d3
	and.l d3,d2					*	and.l %d3,%d2
	jbmi _?L8					*	jmi .L8
	eor.l d4,d0					*	eor.l %d4,%d0
	move.l d6,d1					*	move.l %d6,%d1
	eor.l d5,d1					*	eor.l %d5,%d1
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L8:							*.L8:
	trap #7						*	trap #7
							*	.size	__absvdi2, .-__absvdi2
							*	.ident	"GCC: (GNU) 13.4.0"
