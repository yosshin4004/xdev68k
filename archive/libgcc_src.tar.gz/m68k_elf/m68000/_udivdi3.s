* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___udivsi3				*	.globl	__udivsi3
	.globl	___mulsi3				*	.globl	__mulsi3
	.globl	___umodsi3				*	.globl	__umodsi3
	.align	2					*	.align	2
	.globl	___udivdi3				*	.globl	__udivdi3
							*	.hidden	__udivdi3
							*	.type	__udivdi3, @function
___udivdi3:						*__udivdi3:
	lea (-16,sp),sp					*	lea (-16,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 56(sp),d0				*	move.l 56(%sp),%d0
	move.l 60(sp),d7				*	move.l 60(%sp),%d7
	move.l 64(sp),d1				*	move.l 64(%sp),%d1
	move.l 68(sp),d6				*	move.l 68(%sp),%d6
	move.l d7,d4					*	move.l %d7,%d4
	move.l d0,a3					*	move.l %d0,%a3
	tst.l d1					*	tst.l %d1
	jbne _?L2					*	jne .L2
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcc _?L3					*	jcc .L3
	cmp.l #65535,d6					*	cmp.l #65535,%d6
	jbls _?L54					*	jls .L54
	cmp.l #16777215,d6				*	cmp.l #16777215,%d6
	jbhi _?L27					*	jhi .L27
	moveq #16,d1					*	moveq #16,%d1
_?L5:							*.L5:
	move.l d6,d2					*	move.l %d6,%d2
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d2.l),d2				*	move.b (%a0,%d2.l),%d2
	and.l #255,d2					*	and.l #255,%d2
	add.l d2,d1					*	add.l %d2,%d1
	moveq #32,d2					*	moveq #32,%d2
	sub.l d1,d2					*	sub.l %d1,%d2
	moveq #32,d3					*	moveq #32,%d3
	cmp.l d1,d3					*	cmp.l %d1,%d3
	jbeq _?L6					*	jeq .L6
	lsl.l d2,d6					*	lsl.l %d2,%d6
	lsl.l d2,d0					*	lsl.l %d2,%d0
	move.l d7,d3					*	move.l %d7,%d3
	lsr.l d1,d3					*	lsr.l %d1,%d3
	or.l d0,d3					*	or.l %d0,%d3
	move.l d3,a3					*	move.l %d3,%a3
	move.l d7,d4					*	move.l %d7,%d4
	lsl.l d2,d4					*	lsl.l %d2,%d4
_?L6:							*.L6:
	move.l d6,d5					*	move.l %d6,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	move.l d6,d7					*	move.l %d6,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d4,d1					*	move.l %d4,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcc _?L7					*	jcc .L7
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d1					*	add.l %d6,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L29					*	jcs .L29
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcc _?L29					*	jcc .L29
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d6,d1					*	add.l %d6,%d1
_?L7:							*.L7:
	move.l d1,a3					*	move.l %d1,%a3
	sub.l a6,a3					*	sub.l %a6,%a3
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d7					*	move.l %d0,%d7
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d4,d1					*	or.w %d4,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L8					*	jcc .L8
	move.l a6,d0					*	move.l %a6,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d1					*	add.l %d6,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L31					*	jcs .L31
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L31					*	jcc .L31
	subq.l #2,a6					*	subq.l #2,%a6
_?L8:							*.L8:
	move.l d3,d1					*	move.l %d3,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a6,d4					*	move.l %a6,%d4
	or.l d4,d1					*	or.l %d4,%d1
	moveq #0,d5					*	moveq #0,%d5
_?L9:							*.L9:
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L2:							*.L2:
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcc _?L55					*	jcc .L55
_?L43:							*.L43:
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d5					*	moveq #0,%d5
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L3:							*.L3:
	tst.l d6					*	tst.l %d6
	jbeq _?L32					*	jeq .L32
	cmp.l #65535,d6					*	cmp.l #65535,%d6
	jbhi _?L11					*	jhi .L11
	cmp.l #255,d6					*	cmp.l #255,%d6
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	move.l d6,d1					*	move.l %d6,%d1
	lsr.l d2,d1					*	lsr.l %d2,%d1
_?L10:							*.L10:
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d1.l),d1				*	move.b (%a0,%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	add.l d2,d1					*	add.l %d2,%d1
	moveq #32,d2					*	moveq #32,%d2
	sub.l d1,d2					*	sub.l %d1,%d2
	moveq #32,d3					*	moveq #32,%d3
	cmp.l d1,d3					*	cmp.l %d1,%d3
	jbne _?L13					*	jne .L13
_?L58:							*.L58:
	move.l d0,a6					*	move.l %d0,%a6
	sub.l d6,a6					*	sub.l %d6,%a6
	move.l d6,d0					*	move.l %d6,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d0,a3					*	move.l %d0,%a3
	move.l d6,d7					*	move.l %d6,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	moveq #1,d5					*	moveq #1,%d5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
_?L14:							*.L14:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d4,d1					*	move.l %d4,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L17					*	jcc .L17
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d1					*	add.l %d6,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L38					*	jcs .L38
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L38					*	jcc .L38
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d6,d1					*	add.l %d6,%d1
_?L17:							*.L17:
	sub.l a1,d1					*	sub.l %a1,%d1
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d7					*	move.l %d0,%d7
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d4,d1					*	or.w %d4,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L18					*	jcc .L18
	move.l a6,d0					*	move.l %a6,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d1					*	add.l %d6,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L40					*	jcs .L40
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L40					*	jcc .L40
	subq.l #2,a6					*	subq.l #2,%a6
_?L18:							*.L18:
	move.l d3,d1					*	move.l %d3,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a6,d2					*	move.l %a6,%d2
	or.l d2,d1					*	or.l %d2,%d1
_?L59:							*.L59:
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L55:							*.L55:
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbls _?L56					*	jls .L56
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbhi _?L42					*	jhi .L42
	moveq #16,d2					*	moveq #16,%d2
_?L20:							*.L20:
	move.l d1,d3					*	move.l %d1,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d3.l),d3				*	move.b (%a0,%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	add.l d2,d3					*	add.l %d2,%d3
	move.w #32,a3					*	move.w #32,%a3
	sub.l d3,a3					*	sub.l %d3,%a3
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbne _?L21					*	jne .L21
_?L57:							*.L57:
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbhi _?L22					*	jhi .L22
	cmp.l d6,d7					*	cmp.l %d6,%d7
	jbcs _?L43					*	jcs .L43
_?L22:							*.L22:
	moveq #1,d1					*	moveq #1,%d1
	moveq #0,d5					*	moveq #0,%d5
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L56:							*.L56:
	cmp.l #255,d1					*	cmp.l #255,%d1
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	move.l d1,d3					*	move.l %d1,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d3.l),d3				*	move.b (%a0,%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	add.l d2,d3					*	add.l %d2,%d3
	move.w #32,a3					*	move.w #32,%a3
	sub.l d3,a3					*	sub.l %d3,%a3
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbeq _?L57					*	jeq .L57
_?L21:							*.L21:
	move.l a3,d2					*	move.l %a3,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d6,d2					*	move.l %d6,%d2
	lsr.l d3,d2					*	lsr.l %d3,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l a3,d4					*	move.l %a3,%d4
	lsl.l d4,d6					*	lsl.l %d4,%d6
	move.l d6,48(sp)				*	move.l %d6,48(%sp)
	move.l d0,d1					*	move.l %d0,%d1
	lsr.l d3,d1					*	lsr.l %d3,%d1
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l d7,d5					*	move.l %d7,%d5
	lsr.l d3,d5					*	lsr.l %d3,%d5
	or.l d0,d5					*	or.l %d0,%d5
	move.l d2,d4					*	move.l %d2,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	move.l d2,d0					*	move.l %d2,%d0
	and.l #65535,d0					*	and.l #65535,%d0
	move.l d0,a6					*	move.l %d0,%a6
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	move.l d2,52(sp)				*	move.l %d2,52(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d6					*	move.l %d0,%d6
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d5,d1					*	move.l %d5,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcc _?L23					*	jcc .L23
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d2,d1					*	add.l %d2,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L45					*	jcs .L45
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcc _?L45					*	jcc .L45
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d2,d1					*	add.l %d2,%d1
_?L23:							*.L23:
	sub.l d6,d1					*	sub.l %d6,%d1
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	move.l d2,52(sp)				*	move.l %d2,52(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d6					*	move.l %d0,%d6
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a5					*	move.l %d0,%a5
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d5,d1					*	or.w %d5,%d1
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	cmp.l a5,d1					*	cmp.l %a5,%d1
	jbcc _?L24					*	jcc .L24
	move.l d6,d0					*	move.l %d6,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d2,d1					*	add.l %d2,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L47					*	jcs .L47
	cmp.l a5,d1					*	cmp.l %a5,%d1
	jbcc _?L47					*	jcc .L47
	subq.l #2,d6					*	subq.l #2,%d6
	add.l d2,d1					*	add.l %d2,%d1
_?L24:							*.L24:
	move.l d1,a0					*	move.l %d1,%a0
	sub.l a5,a0					*	sub.l %a5,%a0
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	move.l d3,d5					*	move.l %d3,%d5
	or.l d6,d5					*	or.l %d6,%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	d5,d0					*	move.l	%d5,%d0
	move.l	48(sp),d1				*	move.l	48(%sp),%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a1					*	move.l	%d2,%a1
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,d6					*	move.l	%d0,%d6
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	cmp.l a0,d6					*	cmp.l %a0,%d6
	jbhi _?L25					*	jhi .L25
	jbeq _?L26					*	jeq .L26
_?L51:							*.L51:
	move.l d5,d1					*	move.l %d5,%d1
	moveq #0,d5					*	moveq #0,%d5
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L54:							*.L54:
	cmp.l #255,d6					*	cmp.l #255,%d6
	shi d1						*	shi %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	jbra _?L5					*	jra .L5
_?L32:							*.L32:
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d2					*	moveq #0,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d1.l),d1				*	move.b (%a0,%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	add.l d2,d1					*	add.l %d2,%d1
	moveq #32,d2					*	moveq #32,%d2
	sub.l d1,d2					*	sub.l %d1,%d2
	moveq #32,d3					*	moveq #32,%d3
	cmp.l d1,d3					*	cmp.l %d1,%d3
	jbeq _?L58					*	jeq .L58
_?L13:							*.L13:
	lsl.l d2,d6					*	lsl.l %d2,%d6
	move.l d0,d3					*	move.l %d0,%d3
	lsr.l d1,d3					*	lsr.l %d1,%d3
	move.l d3,a6					*	move.l %d3,%a6
	lsl.l d2,d0					*	lsl.l %d2,%d0
	move.l d7,d3					*	move.l %d7,%d3
	lsr.l d1,d3					*	lsr.l %d1,%d3
	or.l d0,d3					*	or.l %d0,%d3
	move.l d7,d4					*	move.l %d7,%d4
	lsl.l d2,d4					*	lsl.l %d2,%d4
	move.l d6,d0					*	move.l %d6,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d0,a3					*	move.l %d0,%a3
	move.l d6,d7					*	move.l %d6,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d5					*	move.l %d0,%d5
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d3,d1					*	move.l %d3,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L15					*	jcc .L15
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d1					*	add.l %d6,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L34					*	jcs .L34
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L34					*	jcc .L34
	subq.l #2,d5					*	subq.l #2,%d5
	add.l d6,d1					*	add.l %d6,%d1
_?L15:							*.L15:
	move.l d1,a6					*	move.l %d1,%a6
	sub.l a1,a6					*	sub.l %a1,%a6
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d3,d0					*	or.w %d3,%d0
	move.l 40(sp),d1				*	move.l 40(%sp),%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d0					*	cmp.l %a1,%d0
	jbcc _?L16					*	jcc .L16
	move.l d1,d2					*	move.l %d1,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L36					*	jcs .L36
	cmp.l a1,d0					*	cmp.l %a1,%d0
	jbcc _?L36					*	jcc .L36
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d6,d0					*	add.l %d6,%d0
_?L16:							*.L16:
	move.l d0,a6					*	move.l %d0,%a6
	sub.l a1,a6					*	sub.l %a1,%a6
	swap d5						*	swap %d5
	clr.w d5					*	clr.w %d5
	or.l d1,d5					*	or.l %d1,%d5
	jbra _?L14					*	jra .L14
_?L38:							*.L38:
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L17					*	jra .L17
_?L40:							*.L40:
	move.l d0,a6					*	move.l %d0,%a6
	move.l d3,d1					*	move.l %d3,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a6,d2					*	move.l %a6,%d2
	or.l d2,d1					*	or.l %d2,%d1
	jbra _?L59					*	jra .L59
_?L29:							*.L29:
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L7					*	jra .L7
_?L31:							*.L31:
	move.l d0,a6					*	move.l %d0,%a6
	move.l d3,d1					*	move.l %d3,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a6,d4					*	move.l %a6,%d4
	or.l d4,d1					*	or.l %d4,%d1
	moveq #0,d5					*	moveq #0,%d5
	jbra _?L9					*	jra .L9
_?L26:							*.L26:
	move.l a3,d1					*	move.l %a3,%d1
	lsl.l d1,d7					*	lsl.l %d1,%d7
	cmp.l d7,a1					*	cmp.l %d7,%a1
	jbls _?L51					*	jls .L51
_?L25:							*.L25:
	move.l d5,d1					*	move.l %d5,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	moveq #0,d5					*	moveq #0,%d5
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L11:							*.L11:
	move.l d6,d1					*	move.l %d6,%d1
	cmp.l #16777215,d6				*	cmp.l #16777215,%d6
	jbhi _?L12					*	jhi .L12
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	moveq #16,d2					*	moveq #16,%d2
	jbra _?L10					*	jra .L10
_?L42:							*.L42:
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L20					*	jra .L20
_?L27:							*.L27:
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L5					*	jra .L5
_?L36:							*.L36:
	move.l d2,d1					*	move.l %d2,%d1
	move.l d0,a6					*	move.l %d0,%a6
	sub.l a1,a6					*	sub.l %a1,%a6
	swap d5						*	swap %d5
	clr.w d5					*	clr.w %d5
	or.l d1,d5					*	or.l %d1,%d5
	jbra _?L14					*	jra .L14
_?L47:							*.L47:
	move.l d0,d6					*	move.l %d0,%d6
	jbra _?L24					*	jra .L24
_?L34:							*.L34:
	move.l d0,d5					*	move.l %d0,%d5
	jbra _?L15					*	jra .L15
_?L45:							*.L45:
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L23					*	jra .L23
_?L12:							*.L12:
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	lsr.w #8,d1					*	lsr.w #8,%d1
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L10					*	jra .L10
							*	.size	__udivdi3, .-__udivdi3
							*	.ident	"GCC: (GNU) 13.4.0"
