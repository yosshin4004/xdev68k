* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___floatunsixf				*	.globl	__floatunsixf
	.globl	___mulxf3				*	.globl	__mulxf3
	.globl	___addxf3				*	.globl	__addxf3
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	1075773440				*	.long	1075773440
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___floatundixf				*	.globl	__floatundixf
							*	.hidden	__floatundixf
							*	.type	__floatundixf, @function
___floatundixf:						*__floatundixf:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	lea ___floatunsixf,a3				*	lea __floatunsixf,%a3
	move.l 20(sp),-(sp)				*	move.l 20(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l _?LC0+8,-(sp)				*	move.l .LC0+8,-(%sp)
	move.l _?LC0+4,-(sp)				*	move.l .LC0+4,-(%sp)
	move.l _?LC0,-(sp)				*	move.l .LC0,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___mulxf3					*	jsr __mulxf3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.l d1,d4					*	move.l %d1,%d4
	move.l d2,d5					*	move.l %d2,%d5
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___addxf3					*	jsr __addxf3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	rts						*	rts
							*	.size	__floatundixf, .-__floatundixf
							*	.ident	"GCC: (GNU) 13.4.0"
