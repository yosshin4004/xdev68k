* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___ltsf2				*	.globl	__ltsf2
	.align	2					*	.align	2
	.globl	___fixsfdi				*	.globl	__fixsfdi
							*	.hidden	__fixsfdi
							*	.type	__fixsfdi, @function
___fixsfdi:						*__fixsfdi:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 8(sp),d3					*	move.l 8(%sp),%d3
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___ltsf2					*	jsr __ltsf2
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jblt _?L8					*	jlt .L8
	move.l d3,8(sp)					*	move.l %d3,8(%sp)
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	jbra ___fixunssfdi				*	jra __fixunssfdi
_?L8:							*.L8:
	add.l #-2147483648,d3				*	add.l #-2147483648,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr ___fixunssfdi				*	jsr __fixunssfdi
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	addq.l #4,sp					*	addq.l #4,%sp
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	rts						*	rts
							*	.size	__fixsfdi, .-__fixsfdi
							*	.ident	"GCC: (GNU) 13.4.0"
