* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___udivsi3				*	.globl	__udivsi3
	.globl	___mulsi3				*	.globl	__mulsi3
	.globl	___umodsi3				*	.globl	__umodsi3
	.align	2					*	.align	2
	.globl	___divmoddi4				*	.globl	__divmoddi4
							*	.hidden	__divmoddi4
							*	.type	__divmoddi4, @function
___divmoddi4:						*__divmoddi4:
	lea (-32,sp),sp					*	lea (-32,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 72(sp),d2				*	move.l 72(%sp),%d2
	move.l 76(sp),d3				*	move.l 76(%sp),%d3
	move.l 80(sp),d4				*	move.l 80(%sp),%d4
	move.l 84(sp),d5				*	move.l 84(%sp),%d5
	move.l d2,d0					*	move.l %d2,%d0
	jbmi _?L67					*	jmi .L67
	clr.l 48(sp)					*	clr.l 48(%sp)
_?L2:							*.L2:
	move.l d4,d7					*	move.l %d4,%d7
	jbmi _?L68					*	jmi .L68
	move.l 48(sp),52(sp)				*	move.l 48(%sp),52(%sp)
_?L3:							*.L3:
	move.l d5,d6					*	move.l %d5,%d6
	move.l d3,d5					*	move.l %d3,%d5
	move.l d0,a6					*	move.l %d0,%a6
	tst.l d7					*	tst.l %d7
	jbne _?L4					*	jne .L4
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcc _?L5					*	jcc .L5
	cmp.l #65535,d6					*	cmp.l #65535,%d6
	jbls _?L69					*	jls .L69
	cmp.l #16777215,d6				*	cmp.l #16777215,%d6
	jbhi _?L36					*	jhi .L36
	moveq #16,d2					*	moveq #16,%d2
_?L7:							*.L7:
	move.l d6,d3					*	move.l %d6,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d3.l),d3				*	move.b (%a0,%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	add.l d3,d2					*	add.l %d3,%d2
	moveq #32,d7					*	moveq #32,%d7
	sub.l d2,d7					*	sub.l %d2,%d7
	moveq #32,d3					*	moveq #32,%d3
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbeq _?L8					*	jeq .L8
	lsl.l d7,d6					*	lsl.l %d7,%d6
	move.l d0,d3					*	move.l %d0,%d3
	lsl.l d7,d3					*	lsl.l %d7,%d3
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l d2,d0					*	lsr.l %d2,%d0
	or.l d3,d0					*	or.l %d3,%d0
	move.l d0,a6					*	move.l %d0,%a6
	lsl.l d7,d5					*	lsl.l %d7,%d5
_?L8:							*.L8:
	move.l d6,d4					*	move.l %d6,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	move.l d6,d0					*	move.l %d6,%d0
	and.l #65535,d0					*	and.l #65535,%d0
	move.l d0,a5					*	move.l %d0,%a5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	move.l d5,d0					*	move.l %d5,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	or.l d2,d0					*	or.l %d2,%d0
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d0					*	cmp.l %a1,%d0
	jbcc _?L9					*	jcc .L9
	move.l d3,d2					*	move.l %d3,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L38					*	jcs .L38
	cmp.l a1,d0					*	cmp.l %a1,%d0
	jbcc _?L38					*	jcc .L38
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d6,d0					*	add.l %d6,%d0
_?L9:							*.L9:
	move.l d0,a6					*	move.l %d0,%a6
	sub.l a1,a6					*	sub.l %a1,%a6
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a4					*	move.l %d0,%a4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.w d5,d2					*	or.w %d5,%d2
	move.l 40(sp),d1				*	move.l 40(%sp),%d1
	cmp.l a4,d2					*	cmp.l %a4,%d2
	jbcc _?L10					*	jcc .L10
	move.l d1,d0					*	move.l %d1,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d2					*	add.l %d6,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L40					*	jcs .L40
	cmp.l a4,d2					*	cmp.l %a4,%d2
	jbcc _?L40					*	jcc .L40
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d6,d2					*	add.l %d6,%d2
_?L10:							*.L10:
	sub.l a4,d2					*	sub.l %a4,%d2
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	or.l d1,d3					*	or.l %d1,%d3
	move.l d3,a0					*	move.l %d3,%a0
	sub.l a6,a6					*	sub.l %a6,%a6
_?L11:							*.L11:
	moveq #0,d4					*	moveq #0,%d4
	move.l d2,d5					*	move.l %d2,%d5
	lsr.l d7,d5					*	lsr.l %d7,%d5
_?L21:							*.L21:
	move.l a6,d0					*	move.l %a6,%d0
	move.l a0,d1					*	move.l %a0,%d1
	tst.l 52(sp)					*	tst.l 52(%sp)
	jbeq _?L32					*	jeq .L32
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
_?L32:							*.L32:
	tst.l 48(sp)					*	tst.l 48(%sp)
	jbeq _?L33					*	jeq .L33
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
_?L33:							*.L33:
	move.l 88(sp),a0				*	move.l 88(%sp),%a0
	move.l d4,(a0)					*	move.l %d4,(%a0)
	move.l d5,4(a0)					*	move.l %d5,4(%a0)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (32,sp),sp					*	lea (32,%sp),%sp
	rts						*	rts
_?L4:							*.L4:
	move.l d3,a1					*	move.l %d3,%a1
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcc _?L22					*	jcc .L22
	move.l d0,d4					*	move.l %d0,%d4
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L21					*	jra .L21
_?L22:							*.L22:
	cmp.l #65535,d7					*	cmp.l #65535,%d7
	jbls _?L70					*	jls .L70
	cmp.l #16777215,d7				*	cmp.l #16777215,%d7
	jbhi _?L50					*	jhi .L50
	moveq #16,d2					*	moveq #16,%d2
_?L24:							*.L24:
	move.l d7,d3					*	move.l %d7,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d3.l),d3				*	move.b (%a0,%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	move.l d3,a5					*	move.l %d3,%a5
	add.l d2,a5					*	add.l %d2,%a5
	move.w #32,a6					*	move.w #32,%a6
	sub.l a5,a6					*	sub.l %a5,%a6
	moveq #32,d3					*	moveq #32,%d3
	cmp.l a5,d3					*	cmp.l %a5,%d3
	jbne _?L25					*	jne .L25
_?L72:							*.L72:
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbhi _?L26					*	jhi .L26
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbcs _?L51					*	jcs .L51
_?L26:							*.L26:
	move.l d0,d3					*	move.l %d0,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d6,d5					*	sub.l %d6,%d5
	subx.l d7,d3					*	subx.l %d7,%d3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d5,a1					*	move.l %d5,%a1
	move.l d3,d0					*	move.l %d3,%d0
	move.w #1,a0					*	move.w #1,%a0
	move.l d0,d4					*	move.l %d0,%d4
	move.l a1,d5					*	move.l %a1,%d5
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L21					*	jra .L21
_?L5:							*.L5:
	tst.l d6					*	tst.l %d6
	jbeq _?L41					*	jeq .L41
	cmp.l #65535,d6					*	cmp.l #65535,%d6
	jbhi _?L13					*	jhi .L13
	cmp.l #255,d6					*	cmp.l #255,%d6
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	move.l d6,d3					*	move.l %d6,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
_?L12:							*.L12:
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d4					*	moveq #0,%d4
	move.b (a0,d3.l),d4				*	move.b (%a0,%d3.l),%d4
	add.l d2,d4					*	add.l %d2,%d4
	moveq #32,d7					*	moveq #32,%d7
	sub.l d4,d7					*	sub.l %d4,%d7
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbne _?L15					*	jne .L15
_?L71:							*.L71:
	move.l d0,d3					*	move.l %d0,%d3
	sub.l d6,d3					*	sub.l %d6,%d3
	move.l d6,d2					*	move.l %d6,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	move.l d2,a5					*	move.l %d2,%a5
	move.l d6,d1					*	move.l %d6,%d1
	and.l #65535,d1					*	and.l #65535,%d1
	move.l d1,56(sp)				*	move.l %d1,56(%sp)
	move.w #1,a6					*	move.w #1,%a6
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
_?L16:							*.L16:
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l 56(sp),-(sp)				*	move.l 56(%sp),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d5,d3					*	move.l %d5,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	or.l d0,d3					*	or.l %d0,%d3
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d3					*	cmp.l %a1,%d3
	jbcc _?L19					*	jcc .L19
	move.l d4,d0					*	move.l %d4,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d3					*	add.l %d6,%d3
	cmp.l d6,d3					*	cmp.l %d6,%d3
	jbcs _?L47					*	jcs .L47
	cmp.l a1,d3					*	cmp.l %a1,%d3
	jbcc _?L47					*	jcc .L47
	subq.l #2,d4					*	subq.l #2,%d4
	add.l d6,d3					*	add.l %d6,%d3
_?L19:							*.L19:
	sub.l a1,d3					*	sub.l %a1,%d3
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l 56(sp),-(sp)				*	move.l 56(%sp),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a4					*	move.l %d0,%a4
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	or.w d5,d3					*	or.w %d5,%d3
	move.l 40(sp),d1				*	move.l 40(%sp),%d1
	cmp.l a4,d3					*	cmp.l %a4,%d3
	jbcc _?L20					*	jcc .L20
	move.l d1,d0					*	move.l %d1,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d3					*	add.l %d6,%d3
	cmp.l d6,d3					*	cmp.l %d6,%d3
	jbcs _?L49					*	jcs .L49
	cmp.l a4,d3					*	cmp.l %a4,%d3
	jbcc _?L49					*	jcc .L49
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d6,d3					*	add.l %d6,%d3
_?L20:							*.L20:
	move.l d3,d2					*	move.l %d3,%d2
	sub.l a4,d2					*	sub.l %a4,%d2
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.l d1,d4					*	or.l %d1,%d4
	move.l d4,a0					*	move.l %d4,%a0
_?L74:							*.L74:
	moveq #0,d4					*	moveq #0,%d4
	move.l d2,d5					*	move.l %d2,%d5
	lsr.l d7,d5					*	lsr.l %d7,%d5
	jbra _?L21					*	jra .L21
_?L68:							*.L68:
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	not.l d1					*	not.l %d1
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
	move.l d4,d7					*	move.l %d4,%d7
	jbra _?L3					*	jra .L3
_?L67:							*.L67:
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
	move.l d2,d0					*	move.l %d2,%d0
	moveq #-1,d1					*	moveq #-1,%d1
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	jbra _?L2					*	jra .L2
_?L69:							*.L69:
	cmp.l #255,d6					*	cmp.l #255,%d6
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	jbra _?L7					*	jra .L7
_?L41:							*.L41:
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d2					*	moveq #0,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d4					*	moveq #0,%d4
	move.b (a0,d3.l),d4				*	move.b (%a0,%d3.l),%d4
	add.l d2,d4					*	add.l %d2,%d4
	moveq #32,d7					*	moveq #32,%d7
	sub.l d4,d7					*	sub.l %d4,%d7
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbeq _?L71					*	jeq .L71
_?L15:							*.L15:
	lsl.l d7,d6					*	lsl.l %d7,%d6
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d4,d2					*	lsr.l %d4,%d2
	lsl.l d7,d0					*	lsl.l %d7,%d0
	move.l d5,d3					*	move.l %d5,%d3
	lsr.l d4,d3					*	lsr.l %d4,%d3
	or.l d0,d3					*	or.l %d0,%d3
	lsl.l d7,d5					*	lsl.l %d7,%d5
	move.l d6,d0					*	move.l %d6,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d0,a5					*	move.l %d0,%a5
	move.l d6,d1					*	move.l %d6,%d1
	and.l #65535,d1					*	and.l #65535,%d1
	move.l d1,56(sp)				*	move.l %d1,56(%sp)
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d2,52(sp)				*	move.l %d2,52(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d4					*	move.l %d0,%d4
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l 60(sp),-(sp)				*	move.l 60(%sp),-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	move.l d3,d0					*	move.l %d3,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	or.l d2,d0					*	or.l %d2,%d0
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a6,d0					*	cmp.l %a6,%d0
	jbcc _?L17					*	jcc .L17
	move.l d4,d2					*	move.l %d4,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L43					*	jcs .L43
	cmp.l a6,d0					*	cmp.l %a6,%d0
	jbcc _?L43					*	jcc .L43
	subq.l #2,d4					*	subq.l #2,%d4
	add.l d6,d0					*	add.l %d6,%d0
_?L17:							*.L17:
	move.l d0,a2					*	move.l %d0,%a2
	sub.l a6,a2					*	sub.l %a6,%a2
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a2,-(sp)					*	move.l %a2,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	move.l a2,52(sp)				*	move.l %a2,52(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l 60(sp),-(sp)				*	move.l 60(%sp),-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l 48(sp),a2				*	move.l 48(%sp),%a2
	move.l a2,-(sp)					*	move.l %a2,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d3,d0					*	or.w %d3,%d0
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d0					*	cmp.l %a1,%d0
	jbcc _?L18					*	jcc .L18
	move.l a6,d3					*	move.l %a6,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L45					*	jcs .L45
	cmp.l a1,d0					*	cmp.l %a1,%d0
	jbcc _?L45					*	jcc .L45
	subq.l #2,a6					*	subq.l #2,%a6
	add.l d6,d0					*	add.l %d6,%d0
_?L18:							*.L18:
	move.l d0,d3					*	move.l %d0,%d3
	sub.l a1,d3					*	sub.l %a1,%d3
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	move.l a6,d2					*	move.l %a6,%d2
	or.l d4,d2					*	or.l %d4,%d2
	move.l d2,a6					*	move.l %d2,%a6
	jbra _?L16					*	jra .L16
_?L70:							*.L70:
	cmp.l #255,d7					*	cmp.l #255,%d7
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	move.l d7,d3					*	move.l %d7,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d3.l),d3				*	move.b (%a0,%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	move.l d3,a5					*	move.l %d3,%a5
	add.l d2,a5					*	add.l %d2,%a5
	move.w #32,a6					*	move.w #32,%a6
	sub.l a5,a6					*	sub.l %a5,%a6
	moveq #32,d3					*	moveq #32,%d3
	cmp.l a5,d3					*	cmp.l %a5,%d3
	jbeq _?L72					*	jeq .L72
_?L25:							*.L25:
	move.l a6,d1					*	move.l %a6,%d1
	lsl.l d1,d7					*	lsl.l %d1,%d7
	move.l d6,d2					*	move.l %d6,%d2
	move.l a5,d3					*	move.l %a5,%d3
	lsr.l d3,d2					*	lsr.l %d3,%d2
	or.l d2,d7					*	or.l %d2,%d7
	lsl.l d1,d6					*	lsl.l %d1,%d6
	move.l d6,56(sp)				*	move.l %d6,56(%sp)
	move.l d0,d1					*	move.l %d0,%d1
	lsr.l d3,d1					*	lsr.l %d3,%d1
	move.l d0,d3					*	move.l %d0,%d3
	move.l a6,d2					*	move.l %a6,%d2
	lsl.l d2,d3					*	lsl.l %d2,%d3
	move.l d5,d0					*	move.l %d5,%d0
	move.l a5,d2					*	move.l %a5,%d2
	lsr.l d2,d0					*	lsr.l %d2,%d0
	or.l d3,d0					*	or.l %d3,%d0
	move.l d0,60(sp)				*	move.l %d0,60(%sp)
	move.l a6,d3					*	move.l %a6,%d3
	lsl.l d3,d5					*	lsl.l %d3,%d5
	move.l d5,64(sp)				*	move.l %d5,64(%sp)
	move.l d7,d3					*	move.l %d7,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	move.l d7,d5					*	move.l %d7,%d5
	and.l #65535,d5					*	and.l #65535,%d5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d4					*	move.l %d0,%d4
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l 60(sp),d1				*	move.l 60(%sp),%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 44(sp),a1				*	move.l 44(%sp),%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L28					*	jcc .L28
	move.l d4,d0					*	move.l %d4,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d7,d1					*	add.l %d7,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcs _?L53					*	jcs .L53
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L53					*	jcc .L53
	subq.l #2,d4					*	subq.l #2,%d4
	add.l d7,d1					*	add.l %d7,%d1
_?L28:							*.L28:
	sub.l a1,d1					*	sub.l %a1,%d1
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d5					*	move.l %d0,%d5
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w 62(sp),d0					*	or.w 62(%sp),%d0
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbcc _?L29					*	jcc .L29
	move.l d2,d1					*	move.l %d2,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	add.l d7,d0					*	add.l %d7,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcs _?L55					*	jcs .L55
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbcc _?L55					*	jcc .L55
	subq.l #2,d2					*	subq.l #2,%d2
	add.l d7,d0					*	add.l %d7,%d0
_?L29:							*.L29:
	move.l d0,a1					*	move.l %d0,%a1
	sub.l d5,a1					*	sub.l %d5,%a1
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.l d2,d4					*	or.l %d2,%d4
	move.l d4,a0					*	move.l %d4,%a0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	a0,d0					*	move.l	%a0,%d0
	move.l	56(sp),d1				*	move.l	56(%sp),%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a2					*	move.l	%d2,%a2
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,d5					*	move.l	%d0,%d5
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d5,d2					*	move.l %d5,%d2
	move.l a2,d3					*	move.l %a2,%d3
	cmp.l a1,d5					*	cmp.l %a1,%d5
	jbhi _?L30					*	jhi .L30
	jbeq _?L73					*	jeq .L73
_?L31:							*.L31:
	move.l a1,d0					*	move.l %a1,%d0
	move.l 64(sp),d1				*	move.l 64(%sp),%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d1					*	sub.l %d3,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d2					*	move.l %d0,%d2
	move.l a5,d3					*	move.l %a5,%d3
	lsl.l d3,d2					*	lsl.l %d3,%d2
	move.l a6,d3					*	move.l %a6,%d3
	lsr.l d3,d1					*	lsr.l %d3,%d1
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d3,d4					*	lsr.l %d3,%d4
	move.l d2,d5					*	move.l %d2,%d5
	or.l d1,d5					*	or.l %d1,%d5
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L21					*	jra .L21
_?L38:							*.L38:
	move.l d2,d3					*	move.l %d2,%d3
	jbra _?L9					*	jra .L9
_?L40:							*.L40:
	move.l d0,d1					*	move.l %d0,%d1
	sub.l a4,d2					*	sub.l %a4,%d2
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	or.l d1,d3					*	or.l %d1,%d3
	move.l d3,a0					*	move.l %d3,%a0
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L11					*	jra .L11
_?L47:							*.L47:
	move.l d0,d4					*	move.l %d0,%d4
	jbra _?L19					*	jra .L19
_?L49:							*.L49:
	move.l d0,d1					*	move.l %d0,%d1
	move.l d3,d2					*	move.l %d3,%d2
	sub.l a4,d2					*	sub.l %a4,%d2
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.l d1,d4					*	or.l %d1,%d4
	move.l d4,a0					*	move.l %d4,%a0
	jbra _?L74					*	jra .L74
_?L73:							*.L73:
	cmp.l 64(sp),a2					*	cmp.l 64(%sp),%a2
	jbls _?L31					*	jls .L31
_?L30:							*.L30:
	subq.l #1,a0					*	subq.l #1,%a0
	move.l a2,d3					*	move.l %a2,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l 56(sp),d3					*	sub.l 56(%sp),%d3
	subx.l d7,d5					*	subx.l %d7,%d5
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d5,d2					*	move.l %d5,%d2
	move.l a1,d0					*	move.l %a1,%d0
	move.l 64(sp),d1				*	move.l 64(%sp),%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d1					*	sub.l %d3,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d2					*	move.l %d0,%d2
	move.l a5,d3					*	move.l %a5,%d3
	lsl.l d3,d2					*	lsl.l %d3,%d2
	move.l a6,d3					*	move.l %a6,%d3
	lsr.l d3,d1					*	lsr.l %d3,%d1
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d3,d4					*	lsr.l %d3,%d4
	move.l d2,d5					*	move.l %d2,%d5
	or.l d1,d5					*	or.l %d1,%d5
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L21					*	jra .L21
_?L50:							*.L50:
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L24					*	jra .L24
_?L36:							*.L36:
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L7					*	jra .L7
_?L13:							*.L13:
	move.l d6,d3					*	move.l %d6,%d3
	cmp.l #16777215,d6				*	cmp.l #16777215,%d6
	jbhi _?L14					*	jhi .L14
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	moveq #16,d2					*	moveq #16,%d2
	jbra _?L12					*	jra .L12
_?L45:							*.L45:
	move.l d3,a6					*	move.l %d3,%a6
	move.l d0,d3					*	move.l %d0,%d3
	sub.l a1,d3					*	sub.l %a1,%d3
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	move.l a6,d2					*	move.l %a6,%d2
	or.l d4,d2					*	or.l %d4,%d2
	move.l d2,a6					*	move.l %d2,%a6
	jbra _?L16					*	jra .L16
_?L55:							*.L55:
	move.l d1,d2					*	move.l %d1,%d2
	jbra _?L29					*	jra .L29
_?L43:							*.L43:
	move.l d2,d4					*	move.l %d2,%d4
	jbra _?L17					*	jra .L17
_?L53:							*.L53:
	move.l d0,d4					*	move.l %d0,%d4
	jbra _?L28					*	jra .L28
_?L51:							*.L51:
	sub.l a0,a0					*	sub.l %a0,%a0
	move.l d0,d4					*	move.l %d0,%d4
	move.l a1,d5					*	move.l %a1,%d5
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L21					*	jra .L21
_?L14:							*.L14:
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	lsr.w #8,d3					*	lsr.w #8,%d3
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L12					*	jra .L12
							*	.size	__divmoddi4, .-__divmoddi4
							*	.ident	"GCC: (GNU) 13.4.0"
