* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___udivsi3				*	.globl	__udivsi3
	.globl	___mulsi3				*	.globl	__mulsi3
	.globl	___umodsi3				*	.globl	__umodsi3
	.align	2					*	.align	2
	.globl	___udivmoddi4				*	.globl	__udivmoddi4
							*	.hidden	__udivmoddi4
							*	.type	__udivmoddi4, @function
___udivmoddi4:						*__udivmoddi4:
	lea (-20,sp),sp					*	lea (-20,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 60(sp),d0				*	move.l 60(%sp),%d0
	move.l 64(sp),d2				*	move.l 64(%sp),%d2
	move.l 68(sp),d4				*	move.l 68(%sp),%d4
	move.l 72(sp),d3				*	move.l 72(%sp),%d3
	move.l d3,d6					*	move.l %d3,%d6
	move.l d2,d7					*	move.l %d2,%d7
	move.l d0,a6					*	move.l %d0,%a6
	tst.l d4					*	tst.l %d4
	jbne _?L2					*	jne .L2
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L3					*	jcc .L3
	cmp.l #65535,d3					*	cmp.l #65535,%d3
	jbls _?L63					*	jls .L63
	cmp.l #16777215,d3				*	cmp.l #16777215,%d3
	jbhi _?L33					*	jhi .L33
	moveq #16,d4					*	moveq #16,%d4
_?L5:							*.L5:
	move.l d3,d5					*	move.l %d3,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d5.l),d5				*	move.b (%a0,%d5.l),%d5
	and.l #255,d5					*	and.l #255,%d5
	add.l d5,d4					*	add.l %d5,%d4
	moveq #32,d1					*	moveq #32,%d1
	sub.l d4,d1					*	sub.l %d4,%d1
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbeq _?L6					*	jeq .L6
	move.l d3,d6					*	move.l %d3,%d6
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	lsl.l d1,d6					*	lsl.l %d1,%d6
	lsl.l d1,d0					*	lsl.l %d1,%d0
	move.l d2,d3					*	move.l %d2,%d3
	lsr.l d4,d3					*	lsr.l %d4,%d3
	or.l d0,d3					*	or.l %d0,%d3
	move.l d3,a6					*	move.l %d3,%a6
	move.l d2,d7					*	move.l %d2,%d7
	lsl.l d1,d7					*	lsl.l %d1,%d7
_?L6:							*.L6:
	move.l d6,d3					*	move.l %d6,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	move.l d6,d4					*	move.l %d6,%d4
	and.l #65535,d4					*	and.l #65535,%d4
	lea ___udivsi3,a3				*	lea __udivsi3,%a3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d5					*	move.l %d0,%d5
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l d0,44(sp)				*	move.l %d0,44(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d7,d2					*	move.l %d7,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d0,d2					*	or.l %d0,%d2
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbcc _?L7					*	jcc .L7
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d2					*	add.l %d6,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L35					*	jcs .L35
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbcc _?L35					*	jcc .L35
	subq.l #2,d5					*	subq.l #2,%d5
	add.l d6,d2					*	add.l %d6,%d2
_?L7:							*.L7:
	sub.l a0,d2					*	sub.l %a0,%d2
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d2,48(sp)				*	move.l %d2,48(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.w d7,d2					*	or.w %d7,%d2
	cmp.l d4,d2					*	cmp.l %d4,%d2
	jbcc _?L8					*	jcc .L8
	move.l a6,d0					*	move.l %a6,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d2					*	add.l %d6,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L37					*	jcs .L37
	cmp.l d4,d2					*	cmp.l %d4,%d2
	jbcc _?L37					*	jcc .L37
	subq.l #2,a6					*	subq.l #2,%a6
	add.l d6,d2					*	add.l %d6,%d2
_?L8:							*.L8:
	sub.l d4,d2					*	sub.l %d4,%d2
	move.l d5,d1					*	move.l %d5,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a6,d3					*	move.l %a6,%d3
	or.l d3,d1					*	or.l %d3,%d1
	sub.l a6,a6					*	sub.l %a6,%a6
_?L9:							*.L9:
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbeq _?L20					*	jeq .L20
	move.l 48(sp),d4				*	move.l 48(%sp),%d4
	lsr.l d4,d2					*	lsr.l %d4,%d2
	move.l 76(sp),a0				*	move.l 76(%sp),%a0
	clr.l (a0)					*	clr.l (%a0)
	move.l d2,4(a0)					*	move.l %d2,4(%a0)
_?L20:							*.L20:
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L2:							*.L2:
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcc _?L22					*	jcc .L22
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbeq _?L47					*	jeq .L47
	move.l 76(sp),a0				*	move.l 76(%sp),%a0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l d2,4(a0)					*	move.l %d2,4(%a0)
	moveq #0,d1					*	moveq #0,%d1
	sub.l a6,a6					*	sub.l %a6,%a6
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L22:							*.L22:
	cmp.l #65535,d4					*	cmp.l #65535,%d4
	jbls _?L64					*	jls .L64
	cmp.l #16777215,d4				*	cmp.l #16777215,%d4
	jbhi _?L48					*	jhi .L48
	moveq #16,d1					*	moveq #16,%d1
_?L24:							*.L24:
	move.l d4,d5					*	move.l %d4,%d5
	lsr.l d1,d5					*	lsr.l %d1,%d5
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d5.l),d5				*	move.b (%a0,%d5.l),%d5
	and.l #255,d5					*	and.l #255,%d5
	move.l d5,a0					*	move.l %d5,%a0
	add.l d1,a0					*	add.l %d1,%a0
	moveq #32,d6					*	moveq #32,%d6
	sub.l a0,d6					*	sub.l %a0,%d6
	moveq #32,d1					*	moveq #32,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbne _?L25					*	jne .L25
_?L65:							*.L65:
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbhi _?L26					*	jhi .L26
	cmp.l d3,d2					*	cmp.l %d3,%d2
	jbcs _?L49					*	jcs .L49
_?L26:							*.L26:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d2					*	sub.l %d3,%d2
	subx.l d4,d0					*	subx.l %d4,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,a6					*	move.l %d0,%a6
	move.l d2,d7					*	move.l %d2,%d7
	moveq #1,d1					*	moveq #1,%d1
_?L27:							*.L27:
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbeq _?L50					*	jeq .L50
	move.l 76(sp),a0				*	move.l 76(%sp),%a0
	move.l a6,(a0)					*	move.l %a6,(%a0)
	move.l d7,4(a0)					*	move.l %d7,4(%a0)
	sub.l a6,a6					*	sub.l %a6,%a6
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L3:							*.L3:
	tst.l d3					*	tst.l %d3
	jbeq _?L38					*	jeq .L38
	cmp.l #65535,d3					*	cmp.l #65535,%d3
	jbhi _?L11					*	jhi .L11
	cmp.l #255,d3					*	cmp.l #255,%d3
	shi d5						*	shi %d5
	ext.w d5					*	ext.w %d5
	ext.l d5					*	ext.l %d5
	neg.l d5					*	neg.l %d5
	lsl.l #3,d5					*	lsl.l #3,%d5
	move.l d3,d4					*	move.l %d3,%d4
	lsr.l d5,d4					*	lsr.l %d5,%d4
_?L10:							*.L10:
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d4.l),d4				*	move.b (%a0,%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d5,d4					*	add.l %d5,%d4
	moveq #32,d1					*	moveq #32,%d1
	sub.l d4,d1					*	sub.l %d4,%d1
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbne _?L13					*	jne .L13
_?L67:							*.L67:
	move.l d0,a0					*	move.l %d0,%a0
	sub.l d3,a0					*	sub.l %d3,%a0
	move.l d3,d5					*	move.l %d3,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	and.l #65535,d3					*	and.l #65535,%d3
	move.w #1,a6					*	move.w #1,%a6
	lea ___udivsi3,a3				*	lea __udivsi3,%a3
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
_?L14:							*.L14:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l 40(sp),a0				*	move.l 40(%sp),%a0
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d7,d2					*	move.l %d7,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d0,d2					*	or.l %d0,%d2
	move.l 44(sp),a2				*	move.l 44(%sp),%a2
	cmp.l a2,d2					*	cmp.l %a2,%d2
	jbcc _?L17					*	jcc .L17
	move.l d4,d0					*	move.l %d4,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d2					*	add.l %d6,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L44					*	jcs .L44
	cmp.l a2,d2					*	cmp.l %a2,%d2
	jbcc _?L44					*	jcc .L44
	subq.l #2,d4					*	subq.l #2,%d4
	add.l d6,d2					*	add.l %d6,%d2
_?L17:							*.L17:
	sub.l a2,d2					*	sub.l %a2,%d2
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d2,48(sp)				*	move.l %d2,48(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a3					*	move.l %d0,%a3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.w d7,d2					*	or.w %d7,%d2
	cmp.l d3,d2					*	cmp.l %d3,%d2
	jbcc _?L18					*	jcc .L18
	move.l a3,d0					*	move.l %a3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d6,d2					*	add.l %d6,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L46					*	jcs .L46
	cmp.l d3,d2					*	cmp.l %d3,%d2
	jbcc _?L46					*	jcc .L46
	subq.l #2,a3					*	subq.l #2,%a3
	add.l d6,d2					*	add.l %d6,%d2
_?L18:							*.L18:
	sub.l d3,d2					*	sub.l %d3,%d2
	move.l d4,d1					*	move.l %d4,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a3,d3					*	move.l %a3,%d3
	or.l d3,d1					*	or.l %d3,%d1
	jbra _?L9					*	jra .L9
_?L64:							*.L64:
	cmp.l #255,d4					*	cmp.l #255,%d4
	shi d1						*	shi %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d4,d5					*	move.l %d4,%d5
	lsr.l d1,d5					*	lsr.l %d1,%d5
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d5.l),d5				*	move.b (%a0,%d5.l),%d5
	and.l #255,d5					*	and.l #255,%d5
	move.l d5,a0					*	move.l %d5,%a0
	add.l d1,a0					*	add.l %d1,%a0
	moveq #32,d6					*	moveq #32,%d6
	sub.l a0,d6					*	sub.l %a0,%d6
	moveq #32,d1					*	moveq #32,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbeq _?L65					*	jeq .L65
_?L25:							*.L25:
	lsl.l d6,d4					*	lsl.l %d6,%d4
	move.l d3,d5					*	move.l %d3,%d5
	move.l a0,d1					*	move.l %a0,%d1
	lsr.l d1,d5					*	lsr.l %d1,%d5
	or.l d4,d5					*	or.l %d4,%d5
	lsl.l d6,d3					*	lsl.l %d6,%d3
	move.l d3,48(sp)				*	move.l %d3,48(%sp)
	move.l d0,d1					*	move.l %d0,%d1
	move.l a0,d3					*	move.l %a0,%d3
	lsr.l d3,d1					*	lsr.l %d3,%d1
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d2,d4					*	move.l %d2,%d4
	lsr.l d3,d4					*	lsr.l %d3,%d4
	or.l d0,d4					*	or.l %d0,%d4
	lsl.l d6,d2					*	lsl.l %d6,%d2
	move.l d2,52(sp)				*	move.l %d2,52(%sp)
	move.l d5,d7					*	move.l %d5,%d7
	clr.w d7					*	clr.w %d7
	swap d7						*	swap %d7
	move.l d5,d0					*	move.l %d5,%d0
	and.l #65535,d0					*	and.l #65535,%d0
	move.l d0,a6					*	move.l %d0,%a6
	lea ___udivsi3,a3				*	lea __udivsi3,%a3
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d4,d1					*	move.l %d4,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 40(sp),d2				*	move.l 40(%sp),%d2
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L28					*	jcc .L28
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L52					*	jcs .L52
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L52					*	jcc .L52
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d5,d1					*	add.l %d5,%d1
_?L28:							*.L28:
	sub.l d2,d1					*	sub.l %d2,%d1
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a5					*	move.l %d0,%a5
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d4,d0					*	or.w %d4,%d0
	move.l 40(sp),d2				*	move.l 40(%sp),%d2
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l a5,d0					*	cmp.l %a5,%d0
	jbcc _?L29					*	jcc .L29
	move.l d2,d1					*	move.l %d2,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	add.l d5,d0					*	add.l %d5,%d0
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbcs _?L54					*	jcs .L54
	cmp.l a5,d0					*	cmp.l %a5,%d0
	jbcc _?L54					*	jcc .L54
	subq.l #2,d2					*	subq.l #2,%d2
	add.l d5,d0					*	add.l %d5,%d0
_?L29:							*.L29:
	move.l d0,a1					*	move.l %d0,%a1
	sub.l a5,a1					*	sub.l %a5,%a1
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	move.l d3,d7					*	move.l %d3,%d7
	or.l d2,d7					*	or.l %d2,%d7
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	d7,d0					*	move.l	%d7,%d0
	move.l	48(sp),d1				*	move.l	48(%sp),%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a2					*	move.l	%d2,%a2
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a4					*	move.l	%d0,%a4
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a4,d3					*	move.l %a4,%d3
	move.l a2,d4					*	move.l %a2,%d4
	cmp.l a1,a4					*	cmp.l %a1,%a4
	jbhi _?L30					*	jhi .L30
	jbeq _?L66					*	jeq .L66
_?L31:							*.L31:
	move.l d7,d1					*	move.l %d7,%d1
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbeq _?L50					*	jeq .L50
	move.l a1,d0					*	move.l %a1,%d0
	move.l 52(sp),d2				*	move.l 52(%sp),%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d4,d2					*	sub.l %d4,%d2
	subx.l d3,d0					*	subx.l %d3,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d3					*	move.l %d0,%d3
	move.l a0,d4					*	move.l %a0,%d4
	lsl.l d4,d3					*	lsl.l %d4,%d3
	lsr.l d6,d2					*	lsr.l %d6,%d2
	lsr.l d6,d0					*	lsr.l %d6,%d0
	move.l 76(sp),a0				*	move.l 76(%sp),%a0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	or.l d2,d3					*	or.l %d2,%d3
	move.l d3,4(a0)					*	move.l %d3,4(%a0)
_?L50:							*.L50:
	sub.l a6,a6					*	sub.l %a6,%a6
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L63:							*.L63:
	cmp.l #255,d3					*	cmp.l #255,%d3
	shi d4						*	shi %d4
	ext.w d4					*	ext.w %d4
	ext.l d4					*	ext.l %d4
	neg.l d4					*	neg.l %d4
	lsl.l #3,d4					*	lsl.l #3,%d4
	jbra _?L5					*	jra .L5
_?L38:							*.L38:
	moveq #0,d4					*	moveq #0,%d4
	moveq #0,d5					*	moveq #0,%d5
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d4.l),d4				*	move.b (%a0,%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d5,d4					*	add.l %d5,%d4
	moveq #32,d1					*	moveq #32,%d1
	sub.l d4,d1					*	sub.l %d4,%d1
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbeq _?L67					*	jeq .L67
_?L13:							*.L13:
	move.l d3,d6					*	move.l %d3,%d6
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	lsl.l d1,d6					*	lsl.l %d1,%d6
	move.l d0,d1					*	move.l %d0,%d1
	lsr.l d4,d1					*	lsr.l %d4,%d1
	move.l 48(sp),d3				*	move.l 48(%sp),%d3
	lsl.l d3,d0					*	lsl.l %d3,%d0
	move.l d2,d3					*	move.l %d2,%d3
	lsr.l d4,d3					*	lsr.l %d4,%d3
	or.l d0,d3					*	or.l %d0,%d3
	move.l d3,52(sp)				*	move.l %d3,52(%sp)
	move.l d2,d7					*	move.l %d2,%d7
	move.l 48(sp),d4				*	move.l 48(%sp),%d4
	lsl.l d4,d7					*	lsl.l %d4,%d7
	move.l d6,d5					*	move.l %d6,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	move.l d6,d3					*	move.l %d6,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	lea ___udivsi3,a3				*	lea __udivsi3,%a3
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d4					*	move.l %d0,%d4
	lea ___mulsi3,a5				*	lea __mulsi3,%a5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	lea ___umodsi3,a4				*	lea __umodsi3,%a4
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l 52(sp),d0				*	move.l 52(%sp),%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	or.l d1,d0					*	or.l %d1,%d0
	cmp.l a6,d0					*	cmp.l %a6,%d0
	jbcc _?L15					*	jcc .L15
	move.l d4,a0					*	move.l %d4,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L40					*	jcs .L40
	cmp.l a6,d0					*	cmp.l %a6,%d0
	jbcc _?L40					*	jcc .L40
	subq.l #2,d4					*	subq.l #2,%d4
	add.l d6,d0					*	add.l %d6,%d0
_?L15:							*.L15:
	move.l d0,a0					*	move.l %d0,%a0
	sub.l a6,a0					*	sub.l %a6,%a0
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l 40(sp),a0				*	move.l 40(%sp),%a0
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w 54(sp),d0					*	or.w 54(%sp),%d0
	move.l 44(sp),a2				*	move.l 44(%sp),%a2
	cmp.l a2,d0					*	cmp.l %a2,%d0
	jbcc _?L16					*	jcc .L16
	lea (-1,a6),a0					*	lea (-1,%a6),%a0
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L42					*	jcs .L42
	cmp.l a2,d0					*	cmp.l %a2,%d0
	jbcc _?L42					*	jcc .L42
	subq.l #2,a6					*	subq.l #2,%a6
	add.l d6,d0					*	add.l %d6,%d0
_?L16:							*.L16:
	move.l d0,a0					*	move.l %d0,%a0
	sub.l a2,a0					*	sub.l %a2,%a0
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	move.l a6,d0					*	move.l %a6,%d0
	or.l d4,d0					*	or.l %d4,%d0
	move.l d0,a6					*	move.l %d0,%a6
	jbra _?L14					*	jra .L14
_?L47:							*.L47:
	moveq #0,d1					*	moveq #0,%d1
	sub.l a6,a6					*	sub.l %a6,%a6
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L35:							*.L35:
	move.l d0,d5					*	move.l %d0,%d5
	jbra _?L7					*	jra .L7
_?L37:							*.L37:
	move.l d0,a6					*	move.l %d0,%a6
	sub.l d4,d2					*	sub.l %d4,%d2
	move.l d5,d1					*	move.l %d5,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a6,d3					*	move.l %a6,%d3
	or.l d3,d1					*	or.l %d3,%d1
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L9					*	jra .L9
_?L44:							*.L44:
	move.l d0,d4					*	move.l %d0,%d4
	jbra _?L17					*	jra .L17
_?L46:							*.L46:
	move.l d0,a3					*	move.l %d0,%a3
	sub.l d3,d2					*	sub.l %d3,%d2
	move.l d4,d1					*	move.l %d4,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l a3,d3					*	move.l %a3,%d3
	or.l d3,d1					*	or.l %d3,%d1
	jbra _?L9					*	jra .L9
_?L66:							*.L66:
	cmp.l 52(sp),a2					*	cmp.l 52(%sp),%a2
	jbls _?L31					*	jls .L31
_?L30:							*.L30:
	subq.l #1,d7					*	subq.l #1,%d7
	move.l a4,d3					*	move.l %a4,%d3
	move.l a2,d4					*	move.l %a2,%d4
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l 48(sp),d4					*	sub.l 48(%sp),%d4
	subx.l d5,d3					*	subx.l %d5,%d3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	jbra _?L31					*	jra .L31
_?L11:							*.L11:
	move.l d3,d4					*	move.l %d3,%d4
	cmp.l #16777215,d3				*	cmp.l #16777215,%d3
	jbhi _?L12					*	jhi .L12
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	moveq #16,d5					*	moveq #16,%d5
	jbra _?L10					*	jra .L10
_?L33:							*.L33:
	moveq #24,d4					*	moveq #24,%d4
	jbra _?L5					*	jra .L5
_?L48:							*.L48:
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L24					*	jra .L24
_?L42:							*.L42:
	move.l a0,a6					*	move.l %a0,%a6
	move.l d0,a0					*	move.l %d0,%a0
	sub.l a2,a0					*	sub.l %a2,%a0
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	move.l a6,d0					*	move.l %a6,%d0
	or.l d4,d0					*	or.l %d4,%d0
	move.l d0,a6					*	move.l %d0,%a6
	jbra _?L14					*	jra .L14
_?L40:							*.L40:
	move.l a0,d4					*	move.l %a0,%d4
	jbra _?L15					*	jra .L15
_?L54:							*.L54:
	move.l d1,d2					*	move.l %d1,%d2
	jbra _?L29					*	jra .L29
_?L52:							*.L52:
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L28					*	jra .L28
_?L49:							*.L49:
	moveq #0,d1					*	moveq #0,%d1
	jbra _?L27					*	jra .L27
_?L12:							*.L12:
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	lsr.w #8,d4					*	lsr.w #8,%d4
	moveq #24,d5					*	moveq #24,%d5
	jbra _?L10					*	jra .L10
							*	.size	__udivmoddi4, .-__udivmoddi4
							*	.ident	"GCC: (GNU) 13.4.0"
