* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___extendsfdf2				*	.globl	__extendsfdf2
	.globl	___muldf3				*	.globl	__muldf3
	.globl	___fixunsdfsi				*	.globl	__fixunsdfsi
	.globl	___floatunsidf				*	.globl	__floatunsidf
	.globl	___subdf3				*	.globl	__subdf3
	.align	2					*	.align	2
	.globl	___fixunssfdi				*	.globl	__fixunssfdi
							*	.hidden	__fixunssfdi
							*	.type	__fixunssfdi, @function
___fixunssfdi:						*__fixunssfdi:
	movem.l d3/d4/d5/a3/a4,-(sp)			*	movem.l #7192,-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr ___extendsfdf2				*	jsr __extendsfdf2
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	lea ___muldf3,a4				*	lea __muldf3,%a4
	clr.l (sp)					*	clr.l (%sp)
	move.l #1039138816,-(sp)			*	move.l #1039138816,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	lea ___fixunsdfsi,a3				*	lea __fixunsdfsi,%a3
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___floatunsidf				*	jsr __floatunsidf
	clr.l (sp)					*	clr.l (%sp)
	move.l #1106247680,-(sp)			*	move.l #1106247680,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___subdf3					*	jsr __subdf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/d4/d5/a3/a4			*	movem.l (%sp)+,#6200
	rts						*	rts
							*	.size	__fixunssfdi, .-__fixunssfdi
							*	.ident	"GCC: (GNU) 13.4.0"
