* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___muldf3				*	.globl	__muldf3
	.globl	___divdf3				*	.globl	__divdf3
	.align	2					*	.align	2
	.globl	___powidf2				*	.globl	__powidf2
							*	.hidden	__powidf2
							*	.type	__powidf2, @function
___powidf2:						*__powidf2:
	movem.l d3/d4/d5/d6/d7/a3/a4,-(sp)		*	movem.l #7960,-(%sp)
	move.l 32(sp),d6				*	move.l 32(%sp),%d6
	move.l 36(sp),d7				*	move.l 36(%sp),%d7
	move.l 40(sp),a4				*	move.l 40(%sp),%a4
	move.l a4,d3					*	move.l %a4,%d3
	jbmi _?L18					*	jmi .L18
_?L2:							*.L2:
	btst #0,d3					*	btst #0,%d3
	jbeq _?L8					*	jeq .L8
	move.l d6,d4					*	move.l %d6,%d4
	move.l d7,d5					*	move.l %d7,%d5
_?L3:							*.L3:
	lsr.l #1,d3					*	lsr.l #1,%d3
	jbeq _?L4					*	jeq .L4
	lea ___muldf3,a3				*	lea __muldf3,%a3
_?L6:							*.L6:
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d6					*	move.l %d0,%d6
	move.l d1,d7					*	move.l %d1,%d7
	btst #0,d3					*	btst #0,%d3
	jbeq _?L5					*	jeq .L5
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
_?L5:							*.L5:
	lsr.l #1,d3					*	lsr.l #1,%d3
	jbne _?L6					*	jne .L6
_?L4:							*.L4:
	cmp.w #0,a4					*	cmp.w #0,%a4
	jblt _?L19					*	jlt .L19
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4		*	movem.l (%sp)+,#6392
	rts						*	rts
_?L8:							*.L8:
	move.l #1072693248,d4				*	move.l #1072693248,%d4
	clr.l d5					*	clr.l %d5
	jbra _?L3					*	jra .L3
_?L19:							*.L19:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l #1072693248,-(sp)			*	move.l #1072693248,-(%sp)
	jbsr ___divdf3					*	jsr __divdf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4		*	movem.l (%sp)+,#6392
	rts						*	rts
_?L18:							*.L18:
	neg.l d3					*	neg.l %d3
	jbra _?L2					*	jra .L2
							*	.size	__powidf2, .-__powidf2
							*	.ident	"GCC: (GNU) 13.4.0"
