* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___mulxf3				*	.globl	__mulxf3
	.globl	___divxf3				*	.globl	__divxf3
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	1073676288				*	.long	1073676288
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___powixf2				*	.globl	__powixf2
							*	.hidden	__powixf2
							*	.type	__powixf2, @function
___powixf2:						*__powixf2:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),a4				*	move.l 40(%sp),%a4
	move.l 44(sp),a5				*	move.l 44(%sp),%a5
	move.l 48(sp),a6				*	move.l 48(%sp),%a6
	move.l 52(sp),d7				*	move.l 52(%sp),%d7
	move.l d7,d3					*	move.l %d7,%d3
	jbmi _?L18					*	jmi .L18
_?L2:							*.L2:
	btst #0,d3					*	btst #0,%d3
	jbeq _?L8					*	jeq .L8
	move.l a4,d4					*	move.l %a4,%d4
	move.l a5,d5					*	move.l %a5,%d5
	move.l a6,d6					*	move.l %a6,%d6
_?L3:							*.L3:
	lsr.l #1,d3					*	lsr.l #1,%d3
	jbeq _?L4					*	jeq .L4
	lea ___mulxf3,a3				*	lea __mulxf3,%a3
_?L6:							*.L6:
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l d0,a4					*	move.l %d0,%a4
	move.l d1,a5					*	move.l %d1,%a5
	move.l d2,a6					*	move.l %d2,%a6
	btst #0,d3					*	btst #0,%d3
	jbeq _?L5					*	jeq .L5
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l d2,d6					*	move.l %d2,%d6
_?L5:							*.L5:
	lsr.l #1,d3					*	lsr.l #1,%d3
	jbne _?L6					*	jne .L6
_?L4:							*.L4:
	tst.l d7					*	tst.l %d7
	jblt _?L19					*	jlt .L19
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	move.l d6,d2					*	move.l %d6,%d2
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L8:							*.L8:
	move.l _?LC0,d4					*	move.l .LC0,%d4
	move.l _?LC0+4,d5				*	move.l .LC0+4,%d5
	move.l _?LC0+8,d6				*	move.l .LC0+8,%d6
	jbra _?L3					*	jra .L3
_?L19:							*.L19:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l _?LC0+8,-(sp)				*	move.l .LC0+8,-(%sp)
	move.l _?LC0+4,-(sp)				*	move.l .LC0+4,-(%sp)
	move.l _?LC0,-(sp)				*	move.l .LC0,-(%sp)
	jbsr ___divxf3					*	jsr __divxf3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l d2,d6					*	move.l %d2,%d6
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	move.l d6,d2					*	move.l %d6,%d2
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L18:							*.L18:
	neg.l d3					*	neg.l %d3
	jbra _?L2					*	jra .L2
							*	.size	__powixf2, .-__powixf2
							*	.ident	"GCC: (GNU) 13.4.0"
