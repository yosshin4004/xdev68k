* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___udivsi3				*	.globl	__udivsi3
	.globl	___mulsi3				*	.globl	__mulsi3
	.globl	___umodsi3				*	.globl	__umodsi3
	.align	2					*	.align	2
	.globl	___moddi3				*	.globl	__moddi3
							*	.hidden	__moddi3
							*	.type	__moddi3, @function
___moddi3:						*__moddi3:
	lea (-24,sp),sp					*	lea (-24,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 64(sp),d4				*	move.l 64(%sp),%d4
	move.l 68(sp),d5				*	move.l 68(%sp),%d5
	move.l 72(sp),a0				*	move.l 72(%sp),%a0
	move.l 76(sp),a1				*	move.l 76(%sp),%a1
	move.l d4,d2					*	move.l %d4,%d2
	jbmi _?L49					*	jmi .L49
	moveq #0,d6					*	moveq #0,%d6
	move.l a0,d0					*	move.l %a0,%d0
	jbmi _?L50					*	jmi .L50
_?L3:							*.L3:
	move.l a1,a6					*	move.l %a1,%a6
	move.l d5,d3					*	move.l %d5,%d3
	move.l d2,a5					*	move.l %d2,%a5
	tst.l d0					*	tst.l %d0
	jbne _?L4					*	jne .L4
	cmp.l a1,d2					*	cmp.l %a1,%d2
	jbcc _?L5					*	jcc .L5
	cmp.l #65535,a1					*	cmp.l #65535,%a1
	jbls _?L51					*	jls .L51
	cmp.l #16777215,a1				*	cmp.l #16777215,%a1
	jbhi _?L34					*	jhi .L34
	moveq #16,d0					*	moveq #16,%d0
_?L7:							*.L7:
	move.l a6,d1					*	move.l %a6,%d1
	lsr.l d0,d1					*	lsr.l %d0,%d1
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d1.l),d1				*	move.b (%a0,%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d0					*	add.l %d1,%d0
	moveq #32,d4					*	moveq #32,%d4
	sub.l d0,d4					*	sub.l %d0,%d4
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L8					*	jeq .L8
	move.l a6,d1					*	move.l %a6,%d1
	lsl.l d4,d1					*	lsl.l %d4,%d1
	move.l d1,a6					*	move.l %d1,%a6
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l d0,d1					*	lsr.l %d0,%d1
	or.l d2,d1					*	or.l %d2,%d1
	move.l d1,a5					*	move.l %d1,%a5
	lsl.l d4,d3					*	lsl.l %d4,%d3
_?L8:							*.L8:
	move.l a6,d5					*	move.l %a6,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	move.l a6,d7					*	move.l %a6,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d3,d1					*	move.l %d3,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 40(sp),a1				*	move.l 40(%sp),%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L9					*	jcc .L9
	add.l a6,d1					*	add.l %a6,%d1
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L9					*	jcs .L9
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcs _?L52					*	jcs .L52
_?L9:							*.L9:
	move.l d1,a5					*	move.l %d1,%a5
	sub.l a1,a5					*	sub.l %a1,%a5
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d7,(sp)					*	move.l %d7,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d7					*	move.l %d0,%d7
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d3,d1					*	or.w %d3,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L10					*	jcc .L10
	add.l a6,d1					*	add.l %a6,%d1
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L10					*	jcs .L10
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcc _?L10					*	jcc .L10
	add.l a6,d1					*	add.l %a6,%d1
_?L10:							*.L10:
	sub.l d7,d1					*	sub.l %d7,%d1
	sub.l a0,a0					*	sub.l %a0,%a0
	lsr.l d4,d1					*	lsr.l %d4,%d1
	move.l d1,a1					*	move.l %d1,%a1
_?L21:							*.L21:
	tst.l d6					*	tst.l %d6
	jbeq _?L1					*	jeq .L1
	exg d0,a1					*	exg %d0,%a1
	neg.l d0					*	neg.l %d0
	exg d0,a1					*	exg %d0,%a1
	exg d0,a0					*	exg %d0,%a0
	negx.l d0					*	negx.l %d0
	exg d0,a0					*	exg %d0,%a0
_?L1:							*.L1:
	move.l a0,d0					*	move.l %a0,%d0
	move.l a1,d1					*	move.l %a1,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (24,sp),sp					*	lea (24,%sp),%sp
	rts						*	rts
_?L4:							*.L4:
	move.l d5,d7					*	move.l %d5,%d7
	cmp.l d0,d2					*	cmp.l %d0,%d2
	jbcc _?L22					*	jcc .L22
	move.l d2,a0					*	move.l %d2,%a0
	move.l d5,a1					*	move.l %d5,%a1
	jbra _?L21					*	jra .L21
_?L50:							*.L50:
	exg d0,a1					*	exg %d0,%a1
	neg.l d0					*	neg.l %d0
	exg d0,a1					*	exg %d0,%a1
	exg d0,a0					*	exg %d0,%a0
	negx.l d0					*	negx.l %d0
	exg d0,a0					*	exg %d0,%a0
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L3					*	jra .L3
_?L22:							*.L22:
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbls _?L53					*	jls .L53
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbhi _?L36					*	jhi .L36
	moveq #16,d1					*	moveq #16,%d1
_?L24:							*.L24:
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d4.l),d4				*	move.b (%a0,%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	move.l d4,a1					*	move.l %d4,%a1
	add.l d1,a1					*	add.l %d1,%a1
	moveq #32,d5					*	moveq #32,%d5
	sub.l a1,d5					*	sub.l %a1,%d5
	moveq #32,d1					*	moveq #32,%d1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbne _?L25					*	jne .L25
_?L55:							*.L55:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	jbhi _?L26					*	jhi .L26
	cmp.l a6,d3					*	cmp.l %a6,%d3
	jbcs _?L27					*	jcs .L27
_?L26:							*.L26:
	move.l d3,d7					*	move.l %d3,%d7
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a6,d7					*	sub.l %a6,%d7
	subx.l d0,d2					*	subx.l %d0,%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
_?L27:							*.L27:
	move.l d2,a0					*	move.l %d2,%a0
	move.l d7,a1					*	move.l %d7,%a1
	jbra _?L21					*	jra .L21
_?L5:							*.L5:
	cmp.w #0,a1					*	cmp.w #0,%a1
	jbeq _?L35					*	jeq .L35
	cmp.l #65535,a1					*	cmp.l #65535,%a1
	jbhi _?L13					*	jhi .L13
	cmp.w #255,a1					*	cmp.w #255,%a1
	shi d1						*	shi %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l a1,d0					*	move.l %a1,%d0
	lsr.l d1,d0					*	lsr.l %d1,%d0
_?L12:							*.L12:
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d0.l),d0				*	move.b (%a0,%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l d1,d0					*	add.l %d1,%d0
	moveq #32,d4					*	moveq #32,%d4
	sub.l d0,d4					*	sub.l %d0,%d4
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L15					*	jne .L15
_?L57:							*.L57:
	move.l d2,a5					*	move.l %d2,%a5
	sub.l a6,a5					*	sub.l %a6,%a5
	move.l a6,d7					*	move.l %a6,%d7
	clr.w d7					*	clr.w %d7
	swap d7						*	swap %d7
	move.l a6,d5					*	move.l %a6,%d5
	and.l #65535,d5					*	and.l #65535,%d5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
_?L16:							*.L16:
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d5,(sp)					*	move.l %d5,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,48(sp)				*	move.l %d0,48(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d3,d1					*	move.l %d3,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 40(sp),a1				*	move.l 40(%sp),%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcc _?L19					*	jcc .L19
	add.l a6,d1					*	add.l %a6,%d1
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L19					*	jcs .L19
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcs _?L54					*	jcs .L54
_?L19:							*.L19:
	move.l d1,a5					*	move.l %d1,%a5
	sub.l a1,a5					*	sub.l %a1,%a5
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d5,(sp)					*	move.l %d5,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d5					*	move.l %d0,%d5
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d3,d1					*	or.w %d3,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcc _?L20					*	jcc .L20
	add.l a6,d1					*	add.l %a6,%d1
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L20					*	jcs .L20
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcc _?L20					*	jcc .L20
	add.l a6,d1					*	add.l %a6,%d1
_?L20:							*.L20:
	sub.l d5,d1					*	sub.l %d5,%d1
	sub.l a0,a0					*	sub.l %a0,%a0
	lsr.l d4,d1					*	lsr.l %d4,%d1
	move.l d1,a1					*	move.l %d1,%a1
	jbra _?L21					*	jra .L21
_?L49:							*.L49:
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
	move.l d4,d2					*	move.l %d4,%d2
	moveq #-1,d6					*	moveq #-1,%d6
	move.l a0,d0					*	move.l %a0,%d0
	jbpl _?L3					*	jpl .L3
	jbra _?L50					*	jra .L50
_?L51:							*.L51:
	cmp.w #255,a1					*	cmp.w #255,%a1
	shi d0						*	shi %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	lsl.l #3,d0					*	lsl.l #3,%d0
	jbra _?L7					*	jra .L7
_?L53:							*.L53:
	cmp.l #255,d0					*	cmp.l #255,%d0
	shi d1						*	shi %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d4.l),d4				*	move.b (%a0,%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	move.l d4,a1					*	move.l %d4,%a1
	add.l d1,a1					*	add.l %d1,%a1
	moveq #32,d5					*	moveq #32,%d5
	sub.l a1,d5					*	sub.l %a1,%d5
	moveq #32,d1					*	moveq #32,%d1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbeq _?L55					*	jeq .L55
_?L25:							*.L25:
	lsl.l d5,d0					*	lsl.l %d5,%d0
	move.l a6,d7					*	move.l %a6,%d7
	move.l a1,d1					*	move.l %a1,%d1
	lsr.l d1,d7					*	lsr.l %d1,%d7
	or.l d0,d7					*	or.l %d0,%d7
	move.l a6,d0					*	move.l %a6,%d0
	lsl.l d5,d0					*	lsl.l %d5,%d0
	move.l d0,a6					*	move.l %d0,%a6
	move.l d2,d1					*	move.l %d2,%d1
	move.l a1,d0					*	move.l %a1,%d0
	lsr.l d0,d1					*	lsr.l %d0,%d1
	lsl.l d5,d2					*	lsl.l %d5,%d2
	move.l d3,d4					*	move.l %d3,%d4
	lsr.l d0,d4					*	lsr.l %d0,%d4
	or.l d2,d4					*	or.l %d2,%d4
	lsl.l d5,d3					*	lsl.l %d5,%d3
	move.l d3,56(sp)				*	move.l %d3,56(%sp)
	move.l d7,d3					*	move.l %d7,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	move.l d3,a5					*	move.l %d3,%a5
	move.l d7,d3					*	move.l %d7,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	move.l d3,52(sp)				*	move.l %d3,52(%sp)
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l 56(sp),-(sp)				*	move.l 56(%sp),-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,56(sp)				*	move.l %d0,56(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d4,d1					*	move.l %d4,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 40(sp),a1				*	move.l 40(%sp),%a1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L28					*	jcc .L28
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d7,d1					*	add.l %d7,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbcs _?L38					*	jcs .L38
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L38					*	jcc .L38
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d7,d1					*	add.l %d7,%d1
_?L28:							*.L28:
	sub.l d2,d1					*	sub.l %d2,%d1
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d1,52(sp)				*	move.l %d1,52(%sp)
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l 56(sp),-(sp)				*	move.l 56(%sp),-(%sp)
	move.l d0,56(sp)				*	move.l %d0,56(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,a4					*	move.l %d0,%a4
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d4,d0					*	or.w %d4,%d0
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l 40(sp),a1				*	move.l 40(%sp),%a1
	cmp.l a4,d0					*	cmp.l %a4,%d0
	jbcc _?L29					*	jcc .L29
	move.l d2,d1					*	move.l %d2,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	add.l d7,d0					*	add.l %d7,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcs _?L40					*	jcs .L40
	cmp.l a4,d0					*	cmp.l %a4,%d0
	jbcc _?L40					*	jcc .L40
	subq.l #2,d2					*	subq.l #2,%d2
	add.l d7,d0					*	add.l %d7,%d0
_?L29:							*.L29:
	move.l d0,a3					*	move.l %d0,%a3
	sub.l a4,a3					*	sub.l %a4,%a3
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	or.l d2,d3					*	or.l %d2,%d3
	move.l d3,a0					*	move.l %d3,%a0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	a0,d0					*	move.l	%a0,%d0
	move.l	a6,d1					*	move.l	%a6,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a4					*	move.l	%d2,%a4
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a0					*	move.l	%d0,%a0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a0,d2					*	move.l %a0,%d2
	move.l a4,d3					*	move.l %a4,%d3
	cmp.l a3,a0					*	cmp.l %a3,%a0
	jbhi _?L30					*	jhi .L30
	jbeq _?L56					*	jeq .L56
_?L31:							*.L31:
	move.l a3,d0					*	move.l %a3,%d0
	move.l 56(sp),d1				*	move.l 56(%sp),%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d1					*	sub.l %d3,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d2					*	move.l %d0,%d2
	move.l a1,d3					*	move.l %a1,%d3
	lsl.l d3,d2					*	lsl.l %d3,%d2
	lsr.l d5,d1					*	lsr.l %d5,%d1
	lsr.l d5,d0					*	lsr.l %d5,%d0
	move.l d0,a0					*	move.l %d0,%a0
	or.l d1,d2					*	or.l %d1,%d2
	move.l d2,a1					*	move.l %d2,%a1
	jbra _?L21					*	jra .L21
_?L35:							*.L35:
	moveq #0,d0					*	moveq #0,%d0
	moveq #0,d1					*	moveq #0,%d1
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	move.b (a0,d0.l),d0				*	move.b (%a0,%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l d1,d0					*	add.l %d1,%d0
	moveq #32,d4					*	moveq #32,%d4
	sub.l d0,d4					*	sub.l %d0,%d4
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L57					*	jeq .L57
_?L15:							*.L15:
	move.l a6,d1					*	move.l %a6,%d1
	lsl.l d4,d1					*	lsl.l %d4,%d1
	move.l d1,a6					*	move.l %d1,%a6
	move.l d2,d1					*	move.l %d2,%d1
	lsr.l d0,d1					*	lsr.l %d0,%d1
	move.l d1,a5					*	move.l %d1,%a5
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d3,d5					*	move.l %d3,%d5
	lsr.l d0,d5					*	lsr.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	move.l d5,52(sp)				*	move.l %d5,52(%sp)
	lsl.l d4,d3					*	lsl.l %d4,%d3
	move.l a6,d7					*	move.l %a6,%d7
	clr.w d7					*	clr.w %d7
	swap d7						*	swap %d7
	move.l a6,d5					*	move.l %a6,%d5
	and.l #65535,d5					*	and.l #65535,%d5
	lea ___udivsi3,a0				*	lea __udivsi3,%a0
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	lea ___umodsi3,a3				*	lea __umodsi3,%a3
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,56(sp)				*	move.l %d0,56(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l 52(sp),d1				*	move.l 52(%sp),%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L17					*	jcc .L17
	add.l a6,d1					*	add.l %a6,%d1
	cmp.l a6,d1					*	cmp.l %a6,%d1
	jbcs _?L17					*	jcs .L17
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L17					*	jcc .L17
	add.l a6,d1					*	add.l %a6,%d1
_?L17:							*.L17:
	move.l d1,a5					*	move.l %d1,%a5
	sub.l d2,a5					*	sub.l %d2,%a5
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,44(sp)				*	move.l %a0,44(%sp)
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d5,(sp)					*	move.l %d5,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,52(sp)				*	move.l %d0,52(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.w 54(sp),d2					*	or.w 54(%sp),%d2
	move.l 44(sp),d1				*	move.l 44(%sp),%d1
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbcc _?L18					*	jcc .L18
	add.l a6,d2					*	add.l %a6,%d2
	cmp.l a6,d2					*	cmp.l %a6,%d2
	jbcs _?L18					*	jcs .L18
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbcc _?L18					*	jcc .L18
	add.l a6,d2					*	add.l %a6,%d2
_?L18:							*.L18:
	move.l d2,a5					*	move.l %d2,%a5
	sub.l d1,a5					*	sub.l %d1,%a5
	jbra _?L16					*	jra .L16
_?L56:							*.L56:
	cmp.l 56(sp),a4					*	cmp.l 56(%sp),%a4
	jbls _?L31					*	jls .L31
_?L30:							*.L30:
	move.l a0,d2					*	move.l %a0,%d2
	move.l a4,d0					*	move.l %a4,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a6,d0					*	sub.l %a6,%d0
	subx.l d7,d2					*	subx.l %d7,%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d3					*	move.l %d0,%d3
	move.l a3,d0					*	move.l %a3,%d0
	move.l 56(sp),d1				*	move.l 56(%sp),%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d1					*	sub.l %d3,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d2					*	move.l %d0,%d2
	move.l a1,d3					*	move.l %a1,%d3
	lsl.l d3,d2					*	lsl.l %d3,%d2
	lsr.l d5,d1					*	lsr.l %d5,%d1
	lsr.l d5,d0					*	lsr.l %d5,%d0
	move.l d0,a0					*	move.l %d0,%a0
	or.l d1,d2					*	or.l %d1,%d2
	move.l d2,a1					*	move.l %d2,%a1
	jbra _?L21					*	jra .L21
_?L13:							*.L13:
	move.l a1,d0					*	move.l %a1,%d0
	cmp.l #16777215,a1				*	cmp.l #16777215,%a1
	jbhi _?L14					*	jhi .L14
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	moveq #16,d1					*	moveq #16,%d1
	jbra _?L12					*	jra .L12
_?L34:							*.L34:
	moveq #24,d0					*	moveq #24,%d0
	jbra _?L7					*	jra .L7
_?L36:							*.L36:
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L24					*	jra .L24
_?L40:							*.L40:
	move.l d1,d2					*	move.l %d1,%d2
	jbra _?L29					*	jra .L29
_?L38:							*.L38:
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L28					*	jra .L28
_?L54:							*.L54:
	add.l a6,d1					*	add.l %a6,%d1
	jbra _?L19					*	jra .L19
_?L52:							*.L52:
	add.l a6,d1					*	add.l %a6,%d1
	jbra _?L9					*	jra .L9
_?L14:							*.L14:
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	lsr.w #8,d0					*	lsr.w #8,%d0
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L12					*	jra .L12
							*	.size	__moddi3, .-__moddi3
							*	.ident	"GCC: (GNU) 13.4.0"
