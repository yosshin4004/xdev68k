* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___negvsi2				*	.globl	__negvsi2
							*	.hidden	__negvsi2
							*	.type	__negvsi2, @function
___negvsi2:						*__negvsi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	cmp.l #-2147483648,d1				*	cmp.l #-2147483648,%d1
	jbeq _?L7					*	jeq .L7
	rts						*	rts
_?L7:							*.L7:
	trap #7						*	trap #7
							*	.size	__negvsi2, .-__negvsi2
							*	.ident	"GCC: (GNU) 13.4.0"
