* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___ltdf2				*	.globl	__ltdf2
	.align	2					*	.align	2
	.globl	___fixdfdi				*	.globl	__fixdfdi
							*	.hidden	__fixdfdi
							*	.type	__fixdfdi, @function
___fixdfdi:						*__fixdfdi:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l 12(sp),d4				*	move.l 12(%sp),%d4
	move.l 16(sp),d5				*	move.l 16(%sp),%d5
	clr.l -(sp)					*	clr.l -(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___ltdf2					*	jsr __ltdf2
	lea (16,sp),sp					*	lea (16,%sp),%sp
	tst.l d0					*	tst.l %d0
	jblt _?L8					*	jlt .L8
	move.l d4,12(sp)				*	move.l %d4,12(%sp)
	move.l d5,16(sp)				*	move.l %d5,16(%sp)
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	move.l (sp)+,d5					*	move.l (%sp)+,%d5
	jbra ___fixunsdfdi				*	jra __fixunsdfdi
_?L8:							*.L8:
	move.l d4,d0					*	move.l %d4,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___fixunsdfdi				*	jsr __fixunsdfdi
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	addq.l #8,sp					*	addq.l #8,%sp
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	move.l (sp)+,d5					*	move.l (%sp)+,%d5
	rts						*	rts
							*	.size	__fixdfdi, .-__fixdfdi
							*	.ident	"GCC: (GNU) 13.4.0"
