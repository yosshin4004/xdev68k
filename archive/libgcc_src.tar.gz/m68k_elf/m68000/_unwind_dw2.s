* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"unwind-dw2.c"				*	.file	"unwind-dw2.c"
	.text						*	.text
	.align	2					*	.align	2
							*	.type	uw_install_context_1, @function
_uw_install_context_1:					*uw_install_context_1:
	subq.l #8,sp					*	subq.l #8,%sp
	movem.l d3/d4/a3/a4,-(sp)			*	movem.l #6168,-(%sp)
	move.l 28(sp),a4				*	move.l 28(%sp),%a4
	move.l 32(sp),a3				*	move.l 32(%sp),%a3
	move.l 128(a3),d0				*	move.l 128(%a3),%d0
	and.l #1073741824,d0				*	and.l #1073741824,%d0
	jbeq _?L2					*	jeq .L2
	tst.b 155(a3)					*	tst.b 155(%a3)
	jbne _?L3					*	jne .L3
_?L2:							*.L2:
	tst.l 60(a3)					*	tst.l 60(%a3)
	jbeq _?L37					*	jeq .L37
_?L3:							*.L3:
	moveq #115,d4					*	moveq #115,%d4
	not.b d4					*	not.b %d4
	moveq #0,d3					*	moveq #0,%d3
_?L9:							*.L9:
	move.l d3,d0					*	move.l %d3,%d0
	add.l d3,d0					*	add.l %d3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a4,d0.l),a0				*	move.l (%a4,%d0.l),%a0
	move.l (a3,d0.l),d0				*	move.l (%a3,%d0.l),%d0
	tst.b (a4,d4.l)					*	tst.b (%a4,%d4.l)
	jbne _?L4					*	jne .L4
	tst.b (a3,d4.l)					*	tst.b (%a3,%d4.l)
	jbeq _?L7					*	jeq .L7
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L8					*	jeq .L8
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	cmp.b #4,(a1,d3.l)				*	cmp.b #4,(%a1,%d3.l)
	jbne _?L4					*	jne .L4
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.b 20(sp),(a0)+				*	move.b 20(%sp),(%a0)+
	move.b 21(sp),(a0)+				*	move.b 21(%sp),(%a0)+
	move.b 22(sp),(a0)+				*	move.b 22(%sp),(%a0)+
	move.b 23(sp),(a0)				*	move.b 23(%sp),(%a0)
_?L8:							*.L8:
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #1,d4					*	addq.l #1,%d4
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbne _?L9					*	jne .L9
_?L39:							*.L39:
	moveq #0,d0					*	moveq #0,%d0
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L10					*	jeq .L10
	tst.b 155(a4)					*	tst.b 155(%a4)
	jbne _?L1					*	jne .L1
_?L10:							*.L10:
	tst.l 60(a4)					*	tst.l 60(%a4)
	jbeq _?L38					*	jeq .L38
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/a3/a4			*	movem.l (%sp)+,#6168
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
_?L7:							*.L7:
	tst.l d0					*	tst.l %d0
	jbeq _?L8					*	jeq .L8
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L8					*	jeq .L8
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbeq _?L8					*	jeq .L8
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1,d3.l),d1				*	move.b (%a1,%d3.l),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	lea (12,sp),sp					*	lea (12,%sp),%sp
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #1,d4					*	addq.l #1,%d4
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbne _?L9					*	jne .L9
	jbra _?L39					*	jra .L39
_?L37:							*.L37:
	move.l 104(a3),d1				*	move.l 104(%a3),%d1
	cmp.b #4,_dwarf_reg_size_table+15.l		*	cmp.b #4,dwarf_reg_size_table+15.l
	jbne _?L4					*	jne .L4
	move.l d1,16(sp)				*	move.l %d1,16(%sp)
	tst.l d0					*	tst.l %d0
	jbeq _?L6					*	jeq .L6
	clr.b 155(a3)					*	clr.b 155(%a3)
_?L6:							*.L6:
	moveq #16,d0					*	moveq #16,%d0
	add.l sp,d0					*	add.l %sp,%d0
	move.l d0,60(a3)				*	move.l %d0,60(%a3)
	moveq #115,d4					*	moveq #115,%d4
	not.b d4					*	not.b %d4
	moveq #0,d3					*	moveq #0,%d3
	jbra _?L9					*	jra .L9
_?L38:							*.L38:
	move.b _dwarf_reg_size_table+15,d0		*	move.b dwarf_reg_size_table+15,%d0
	move.l 60(a3),a0				*	move.l 60(%a3),%a0
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L12					*	jeq .L12
	tst.b 155(a3)					*	tst.b 155(%a3)
	jbne _?L13					*	jne .L13
_?L12:							*.L12:
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbne _?L4					*	jne .L4
	move.l (a0),a0					*	move.l (%a0),%a0
_?L13:							*.L13:
	sub.l 104(a4),a0				*	sub.l 104(%a4),%a0
	move.l a0,d0					*	move.l %a0,%d0
	add.l 136(a3),d0				*	add.l 136(%a3),%d0
	movem.l (sp)+,d3/d4/a3/a4			*	movem.l (%sp)+,#6168
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
_?L4:							*.L4:
	trap #7						*	trap #7
							*	.size	uw_install_context_1, .-uw_install_context_1
	.align	2					*	.align	2
							*	.type	read_encoded_value, @function
_read_encoded_value:					*read_encoded_value:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	move.l 24(sp),a1				*	move.l 24(%sp),%a1
	move.b d0,d3					*	move.b %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L41					*	jeq .L41
	move.b d0,d2					*	move.b %d0,%d2
	and.b #112,d2					*	and.b #112,%d2
	cmp.b #48,d2					*	cmp.b #48,%d2
	jbeq _?L42					*	jeq .L42
	jbhi _?L43					*	jhi .L43
	cmp.b #32,d2					*	cmp.b #32,%d2
	jbne _?L80					*	jne .L80
	move.l 16(sp),a0				*	move.l 16(%sp),%a0
	move.l 116(a0),a2				*	move.l 116(%a0),%a2
_?L45:							*.L45:
	cmp.b #80,d3					*	cmp.b #80,%d3
	jbeq _?L81					*	jeq .L81
_?L47:							*.L47:
	and.b #15,d0					*	and.b #15,%d0
	cmp.b #12,d0					*	cmp.b #12,%d0
	jbhi _?L41					*	jhi .L41
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w _?L50(pc,d0.l),d0			*	move.w .L50(%pc,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&13
_?L50:							*.L50:
	.dc.w _?L51-_?L50				*	.word .L51-.L50
	.dc.w _?L63-_?L50				*	.word .L63-.L50
	.dc.w _?L56-_?L50				*	.word .L56-.L50
	.dc.w _?L51-_?L50				*	.word .L51-.L50
	.dc.w _?L49-_?L50				*	.word .L49-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L64-_?L50				*	.word .L64-.L50
	.dc.w _?L52-_?L50				*	.word .L52-.L50
	.dc.w _?L51-_?L50				*	.word .L51-.L50
	.dc.w _?L49-_?L50				*	.word .L49-.L50
_?L43:							*.L43:
	cmp.b #64,d2					*	cmp.b #64,%d2
	jbne _?L82					*	jne .L82
	move.l 16(sp),a0				*	move.l 16(%sp),%a0
	move.l 124(a0),a2				*	move.l 124(%a0),%a2
	cmp.b #80,d3					*	cmp.b #80,%d3
	jbne _?L47					*	jne .L47
_?L81:							*.L81:
	lea (3,a1),a0					*	lea (3,%a1),%a0
	move.l a0,d0					*	move.l %a0,%d0
	moveq #-4,d1					*	moveq #-4,%d1
	and.l d1,d0					*	and.l %d1,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.l (a0)+,d1					*	move.l (%a0)+,%d1
_?L48:							*.L48:
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L51:							*.L51:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.w #8,d1					*	lsl.w #8,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 3(a1),d1					*	or.b 3(%a1),%d1
	lea (4,a1),a0					*	lea (4,%a1),%a0
_?L59:							*.L59:
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
_?L60:							*.L60:
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbeq _?L83					*	jeq .L83
_?L61:							*.L61:
	add.l a2,d1					*	add.l %a2,%d1
	tst.b d3					*	tst.b %d3
	jbge _?L48					*	jge .L48
	move.l d1,a1					*	move.l %d1,%a1
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L80:							*.L80:
	cmp.b #32,d2					*	cmp.b #32,%d2
	jbhi _?L41					*	jhi .L41
	sub.l a2,a2					*	sub.l %a2,%a2
	jbra _?L45					*	jra .L45
_?L83:							*.L83:
	move.l a1,a2					*	move.l %a1,%a2
	jbra _?L61					*	jra .L61
_?L49:							*.L49:
	moveq #0,d1					*	moveq #0,%d1
	move.b 4(a1),d1					*	move.b 4(%a1),%d1
	lsl.w #8,d1					*	lsl.w #8,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 5(a1),d0					*	move.b 5(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 6(a1),d1					*	move.b 6(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 7(a1),d1					*	or.b 7(%a1),%d1
	lea (8,a1),a0					*	lea (8,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
	jbra _?L60					*	jra .L60
_?L82:							*.L82:
	sub.l a2,a2					*	sub.l %a2,%a2
	cmp.b #80,d2					*	cmp.b #80,%d2
	jbeq _?L45					*	jeq .L45
_?L41:							*.L41:
	trap #7						*	trap #7
_?L52:							*.L52:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	ext.l d1					*	ext.l %d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
	jbra _?L60					*	jra .L60
_?L56:							*.L56:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
	jbra _?L60					*	jra .L60
_?L63:							*.L63:
	move.l a1,a0					*	move.l %a1,%a0
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d4					*	moveq #0,%d4
_?L57:							*.L57:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jbge _?L59					*	jge .L59
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L57					*	jlt .L57
	jbra _?L59					*	jra .L59
_?L64:							*.L64:
	move.l a1,a0					*	move.l %a1,%a0
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d4					*	moveq #0,%d4
_?L53:							*.L53:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L53					*	jlt .L53
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L59					*	jcs .L59
	btst #6,d5					*	btst #6,%d5
	jbeq _?L59					*	jeq .L59
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbne _?L61					*	jne .L61
	jbra _?L83					*	jra .L83
_?L42:							*.L42:
	move.l 16(sp),a0				*	move.l 16(%sp),%a0
	move.l 120(a0),a2				*	move.l 120(%a0),%a2
	jbra _?L45					*	jra .L45
							*	.size	read_encoded_value, .-read_encoded_value
	.globl	___divsi3				*	.globl	__divsi3
	.globl	___umodsi3				*	.globl	__umodsi3
	.globl	___mulsi3				*	.globl	__mulsi3
	.align	2					*	.align	2
							*	.type	execute_stack_op, @function
_execute_stack_op:					*execute_stack_op:
	link.w a6,#-264					*	link.w %fp,#-264
	movem.l d3/d4/d5/d6/a3/a4/a5,-(sp)		*	movem.l #7708,-(%sp)
	move.l 8(a6),a1					*	move.l 8(%fp),%a1
	move.l 12(a6),d4				*	move.l 12(%fp),%d4
	move.l 16(a6),a4				*	move.l 16(%fp),%a4
	move.l 20(a6),-256(a6)				*	move.l 20(%fp),-256(%fp)
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbls _?L167					*	jls .L167
	moveq #1,d5					*	moveq #1,%d5
	move.l #_?L90,a5				*	move.l #.L90,%a5
	move.l #_?L103,a3				*	move.l #.L103,%a3
_?L166:							*.L166:
	move.l a1,-264(a6)				*	move.l %a1,-264(%fp)
	move.l a1,a0					*	move.l %a1,%a0
	addq.l #1,-264(a6)				*	addq.l #1,-264(%fp)
	move.b (a0)+,d1					*	move.b (%a0)+,%d1
	cmp.b #22,d1					*	cmp.b #22,%d1
	jbhi _?L86					*	jhi .L86
	cmp.b #2,d1					*	cmp.b #2,%d1
	jbls _?L88					*	jls .L88
	subq.b #3,d1					*	subq.b #3,%d1
	cmp.b #19,d1					*	cmp.b #19,%d1
	jbhi _?L88					*	jhi .L88
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w (a3,d1.l),d0				*	move.w (%a3,%d1.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&20
_?L103:							*.L103:
	.dc.w _?L112-_?L103				*	.word .L112-.L103
	.dc.w _?L88-_?L103				*	.word .L88-.L103
	.dc.w _?L88-_?L103				*	.word .L88-.L103
	.dc.w _?L118-_?L103				*	.word .L118-.L103
	.dc.w _?L88-_?L103				*	.word .L88-.L103
	.dc.w _?L117-_?L103				*	.word .L117-.L103
	.dc.w _?L116-_?L103				*	.word .L116-.L103
	.dc.w _?L115-_?L103				*	.word .L115-.L103
	.dc.w _?L114-_?L103				*	.word .L114-.L103
	.dc.w _?L112-_?L103				*	.word .L112-.L103
	.dc.w _?L112-_?L103				*	.word .L112-.L103
	.dc.w _?L110-_?L103				*	.word .L110-.L103
	.dc.w _?L110-_?L103				*	.word .L110-.L103
	.dc.w _?L171-_?L103				*	.word .L171-.L103
	.dc.w _?L172-_?L103				*	.word .L172-.L103
	.dc.w _?L107-_?L103				*	.word .L107-.L103
	.dc.w _?L106-_?L103				*	.word .L106-.L103
	.dc.w _?L105-_?L103				*	.word .L105-.L103
	.dc.w _?L104-_?L103				*	.word .L104-.L103
	.dc.w _?L102-_?L103				*	.word .L102-.L103
_?L112:							*.L112:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 3(a1),d0					*	move.b 3(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 4(a1),d0					*	or.b 4(%a1),%d0
	addq.l #5,a1					*	addq.l #5,%a1
	move.l d5,d3					*	move.l %d5,%d3
_?L125:							*.L125:
	moveq #63,d1					*	moveq #63,%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcs _?L88					*	jcs .L88
	move.l d3,d5					*	move.l %d3,%d5
	addq.l #1,d5					*	addq.l #1,%d5
	add.l d3,d3					*	add.l %d3,%d3
	add.l d3,d3					*	add.l %d3,%d3
	lea (a6,d3.l),a0				*	lea (%fp,%d3.l),%a0
	move.l d0,-256(a0)				*	move.l %d0,-256(%a0)
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L166					*	jcs .L166
_?L233:							*.L233:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	subq.l #1,d5					*	subq.l #1,%d5
	add.l d5,d5					*	add.l %d5,%d5
	add.l d5,d5					*	add.l %d5,%d5
	lea (a6,d5.l),a0				*	lea (%fp,%d5.l),%a0
	move.l -256(a0),d0				*	move.l -256(%a0),%d0
	movem.l -292(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -292(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L110:							*.L110:
	moveq #0,d0					*	moveq #0,%d0
	move.b 5(a1),d0					*	move.b 5(%a1),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 6(a1),d1					*	move.b 6(%a1),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 7(a1),d0					*	move.b 7(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 8(a1),d0					*	or.b 8(%a1),%d0
	lea (9,a1),a1					*	lea (9,%a1),%a1
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L86:							*.L86:
	cmp.b #-106,d1					*	cmp.b #-106,%d1
	jbhi _?L120					*	jhi .L120
	cmp.b #35,d1					*	cmp.b #35,%d1
	jbls _?L232					*	jls .L232
	moveq #0,d3					*	moveq #0,%d3
	move.b d1,d3					*	move.b %d1,%d3
	move.b d1,d0					*	move.b %d1,%d0
	add.b #-36,d0					*	add.b #-36,%d0
	cmp.b #114,d0					*	cmp.b #114,%d0
	jbhi _?L88					*	jhi .L88
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w (a5,d0.l),d0				*	move.w (%a5,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&115
_?L90:							*.L90:
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L99-_?L90				*	.word .L99-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L97-_?L90				*	.word .L97-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L169-_?L90				*	.word .L169-.L90
	.dc.w _?L88-_?L90				*	.word .L88-.L90
	.dc.w _?L170-_?L90				*	.word .L170-.L90
	.dc.w _?L88-_?L90				*	.word .L88-.L90
	.dc.w _?L91-_?L90				*	.word .L91-.L90
	.dc.w _?L88-_?L90				*	.word .L88-.L90
	.dc.w _?L229-_?L90				*	.word .L229-.L90
_?L168:							*.L168:
	moveq #0,d0					*	moveq #0,%d0
	moveq #0,d2					*	moveq #0,%d2
_?L94:							*.L94:
	move.l -264(a6),a0				*	move.l -264(%fp),%a0
	addq.l #1,-264(a6)				*	addq.l #1,-264(%fp)
	move.b (a0)+,d6					*	move.b (%a0)+,%d6
	moveq #127,d1					*	moveq #127,%d1
	and.l d6,d1					*	and.l %d6,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d6					*	tst.b %d6
	jblt _?L94					*	jlt .L94
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L130					*	jcs .L130
	btst #6,d6					*	btst #6,%d6
	jbeq _?L130					*	jeq .L130
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
_?L130:							*.L130:
	move.w #-112,a0					*	move.w #-112,%a0
	add.l d3,a0					*	add.l %d3,%a0
	moveq #25,d1					*	moveq #25,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbcs _?L88					*	jcs .L88
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.b (a1,a0.l),d2				*	move.b (%a1,%a0.l),%d2
	move.l a0,d1					*	move.l %a0,%d1
	add.l a0,d1					*	add.l %a0,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l (a4,d1.l),a1				*	move.l (%a4,%d1.l),%a1
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L131					*	jeq .L131
	lea (a4,a0.l),a0				*	lea (%a4,%a0.l),%a0
	tst.b 140(a0)					*	tst.b 140(%a0)
	jbeq _?L131					*	jeq .L131
	move.l a1,d1					*	move.l %a1,%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L106:							*.L106:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	subq.l #1,d5					*	subq.l #1,%d5
_?L229:							*.L229:
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
_?L234:							*.L234:
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L166					*	jcs .L166
	jbra _?L233					*	jra .L233
_?L232:							*.L232:
	move.b d1,d2					*	move.b %d1,%d2
	add.b #-23,d2					*	add.b #-23,%d2
	and.l #255,d2					*	and.l #255,%d2
	moveq #1,d0					*	moveq #1,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	move.l d0,d2					*	move.l %d0,%d2
	and.l #3320,d2					*	and.l #3320,%d2
	jbne _?L98					*	jne .L98
	move.l d0,d3					*	move.l %d0,%d3
	and.l #4868,d3					*	and.l #4868,%d3
	jbne _?L100					*	jne .L100
	btst #0,d0					*	btst #0,%d0
	jbeq _?L88					*	jeq .L88
	moveq #2,d0					*	moveq #2,%d0
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbge _?L88					*	jge .L88
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a2				*	lea (%fp,%d0.l),%a2
	lea (-256,a2),a2				*	lea (-256,%a2),%a2
	move.l (a2),d1					*	move.l (%a2),%d1
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #2,d0					*	subq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a1				*	lea (%fp,%d0.l),%a1
	lea (-256,a1),a1				*	lea (-256,%a1),%a1
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #3,d0					*	subq.l #3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	lea (-256,a0),a0				*	lea (-256,%a0),%a0
	move.l (a0),d0					*	move.l (%a0),%d0
	move.l (a1),(a2)				*	move.l (%a1),(%a2)
	move.l d0,(a1)					*	move.l %d0,(%a1)
	move.l d1,(a0)					*	move.l %d1,(%a0)
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L166					*	jcs .L166
	jbra _?L233					*	jra .L233
_?L95:							*.L95:
	move.w #-80,a0					*	move.w #-80,%a0
	add.l d3,a0					*	add.l %d3,%a0
	moveq #25,d0					*	moveq #25,%d0
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbcs _?L88					*	jcs .L88
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.b (a1,a0.l),d1				*	move.b (%a1,%a0.l),%d1
	move.l a0,d0					*	move.l %a0,%d0
	add.l a0,d0					*	add.l %a0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a4,d0.l),a1				*	move.l (%a4,%d0.l),%a1
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L127					*	jeq .L127
	lea (a4,a0.l),a0				*	lea (%a4,%a0.l),%a0
	tst.b 140(a0)					*	tst.b 140(%a0)
	jbeq _?L127					*	jeq .L127
	move.l a1,d0					*	move.l %a1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L96:							*.L96:
	moveq #-48,d0					*	moveq #-48,%d0
	add.l d3,d0					*	add.l %d3,%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L107:							*.L107:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),d0				*	move.l -256(%a0),%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L102:							*.L102:
	moveq #1,d1					*	moveq #1,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbge _?L88					*	jge .L88
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a1				*	lea (%fp,%d0.l),%a1
	lea (-256,a1),a1				*	lea (-256,%a1),%a1
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #2,d0					*	subq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	lea (-256,a0),a0				*	lea (-256,%a0),%a0
	move.l (a0),(a1)				*	move.l (%a0),(%a1)
	move.l d1,(a0)					*	move.l %d1,(%a0)
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L234					*	jra .L234
_?L105:							*.L105:
	moveq #1,d0					*	moveq #1,%d0
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbge _?L88					*	jge .L88
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #2,d0					*	subq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),d0				*	move.l -256(%a0),%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L104:							*.L104:
	move.l a1,d2					*	move.l %a1,%d2
	addq.l #2,d2					*	addq.l #2,%d2
	moveq #0,d1					*	moveq #0,%d1
	move.b 1(a1),d1					*	move.b 1(%a1),%d1
	move.l d5,d0					*	move.l %d5,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jble _?L88					*	jle .L88
	sub.l d1,d0					*	sub.l %d1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),d0				*	move.l -256(%a0),%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l d2,a1					*	move.l %d2,%a1
	jbra _?L125					*	jra .L125
_?L114:							*.L114:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	ext.l d0					*	ext.l %d0
	addq.l #3,a1					*	addq.l #3,%a1
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L115:							*.L115:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	addq.l #3,a1					*	addq.l #3,%a1
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L116:							*.L116:
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	addq.l #2,a1					*	addq.l #2,%a1
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L117:							*.L117:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	addq.l #2,a1					*	addq.l #2,%a1
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L171:							*.L171:
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	moveq #0,d0					*	moveq #0,%d0
	moveq #0,d2					*	moveq #0,%d2
_?L109:							*.L109:
	move.b (a1)+,d3					*	move.b (%a1)+,%d3
	moveq #127,d1					*	moveq #127,%d1
	and.l d3,d1					*	and.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d3					*	tst.b %d3
	jblt _?L109					*	jlt .L109
_?L174:							*.L174:
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L172:							*.L172:
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	moveq #0,d0					*	moveq #0,%d0
	moveq #0,d2					*	moveq #0,%d2
_?L108:							*.L108:
	move.b (a1)+,d3					*	move.b (%a1)+,%d3
	moveq #127,d1					*	moveq #127,%d1
	and.l d3,d1					*	and.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d3					*	tst.b %d3
	jblt _?L108					*	jlt .L108
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L174					*	jcs .L174
	btst #6,d3					*	btst #6,%d3
	jbeq _?L174					*	jeq .L174
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L118:							*.L118:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	move.l d5,d3					*	move.l %d5,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	move.l d3,d0					*	move.l %d3,%d0
	add.l d3,d0					*	add.l %d3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),a0				*	move.l -256(%a0),%a0
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0),d0					*	move.b (%a0),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 1(a0),d1					*	move.b 1(%a0),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 2(a0),d0					*	move.b 2(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 3(a0),d0					*	or.b 3(%a0),%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L98:							*.L98:
	moveq #1,d0					*	moveq #1,%d0
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbge _?L88					*	jge .L88
	move.l d5,d3					*	move.l %d5,%d3
	subq.l #2,d3					*	subq.l #2,%d3
	move.l d3,d0					*	move.l %d3,%d0
	add.l d3,d0					*	add.l %d3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),d0				*	move.l -256(%a0),%d0
	subq.l #1,d5					*	subq.l #1,%d5
	add.l d5,d5					*	add.l %d5,%d5
	add.l d5,d5					*	add.l %d5,%d5
	lea (a6,d5.l),a0				*	lea (%fp,%d5.l),%a0
	move.l -256(a0),d2				*	move.l -256(%a0),%d2
	add.b #-26,d1					*	add.b #-26,%d1
	cmp.b #20,d1					*	cmp.b #20,%d1
	jbhi _?L88					*	jhi .L88
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w _?L149(pc,d1.l),d1			*	move.w .L149(%pc,%d1.l),%d1
	jmp 2(pc,d1.w)					*	jmp %pc@(2,%d1:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&21
_?L149:							*.L149:
	.dc.w _?L165-_?L149				*	.word .L165-.L149
	.dc.w _?L164-_?L149				*	.word .L164-.L149
	.dc.w _?L163-_?L149				*	.word .L163-.L149
	.dc.w _?L162-_?L149				*	.word .L162-.L149
	.dc.w _?L161-_?L149				*	.word .L161-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L160-_?L149				*	.word .L160-.L149
	.dc.w _?L159-_?L149				*	.word .L159-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L158-_?L149				*	.word .L158-.L149
	.dc.w _?L157-_?L149				*	.word .L157-.L149
	.dc.w _?L156-_?L149				*	.word .L156-.L149
	.dc.w _?L155-_?L149				*	.word .L155-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L154-_?L149				*	.word .L154-.L149
	.dc.w _?L153-_?L149				*	.word .L153-.L149
	.dc.w _?L152-_?L149				*	.word .L152-.L149
	.dc.w _?L151-_?L149				*	.word .L151-.L149
	.dc.w _?L150-_?L149				*	.word .L150-.L149
	.dc.w _?L148-_?L149				*	.word .L148-.L149
_?L99:							*.L99:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	subq.l #1,d5					*	subq.l #1,%d5
	lea (3,a1),a2					*	lea (3,%a1),%a2
	move.l d5,d0					*	move.l %d5,%d0
	add.l d5,d0					*	add.l %d5,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	tst.l -256(a0)					*	tst.l -256(%a0)
	jbeq _?L177					*	jeq .L177
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	ext.l d0					*	ext.l %d0
	lea (a2,d0.l),a1				*	lea (%a2,%d0.l),%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L166					*	jcs .L166
	jbra _?L233					*	jra .L233
_?L97:							*.L97:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	ext.l d0					*	ext.l %d0
	lea 3(a1,d0.l),a1				*	lea 3(%a1,%d0.l),%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L166					*	jcs .L166
	jbra _?L233					*	jra .L233
_?L120:							*.L120:
	cmp.b #-15,d1					*	cmp.b #-15,%d1
	jbne _?L88					*	jne .L88
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	pea -260(a6)					*	pea -260(%fp)
	pea 2(a1)					*	pea 2(%a1)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a1					*	move.l %d0,%a1
	move.l -260(a6),d0				*	move.l -260(%fp),%d0
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L177:							*.L177:
	move.l a2,a1					*	move.l %a2,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L166					*	jcs .L166
	jbra _?L233					*	jra .L233
_?L127:							*.L127:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L88					*	jne .L88
	move.l (a1),d0					*	move.l (%a1),%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L131:							*.L131:
	cmp.b #4,d2					*	cmp.b #4,%d2
	jbne _?L88					*	jne .L88
	move.l (a1),d1					*	move.l (%a1),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L167:							*.L167:
	move.l 20(a6),d0				*	move.l 20(%fp),%d0
	movem.l -292(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -292(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L170:							*.L170:
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L92:							*.L92:
	move.b (a1)+,d2					*	move.b (%a1)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L92					*	jlt .L92
	moveq #0,d0					*	moveq #0,%d0
	moveq #0,d2					*	moveq #0,%d2
_?L133:							*.L133:
	move.b (a1)+,d3					*	move.b (%a1)+,%d3
	moveq #127,d1					*	moveq #127,%d1
	and.l d3,d1					*	and.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d3					*	tst.b %d3
	jblt _?L133					*	jlt .L133
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L134					*	jcs .L134
	btst #6,d3					*	btst #6,%d3
	jbeq _?L134					*	jeq .L134
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
_?L134:							*.L134:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jblt _?L88					*	jlt .L88
	lea _dwarf_reg_size_table,a0			*	lea dwarf_reg_size_table,%a0
	move.b (a0,d6.l),d2				*	move.b (%a0,%d6.l),%d2
	move.l d6,d1					*	move.l %d6,%d1
	add.l d6,d1					*	add.l %d6,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l (a4,d1.l),a2				*	move.l (%a4,%d1.l),%a2
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L135					*	jeq .L135
	lea (a4,d6.l),a0				*	lea (%a4,%d6.l),%a0
	tst.b 140(a0)					*	tst.b 140(%a0)
	jbeq _?L135					*	jeq .L135
	move.l a2,d1					*	move.l %a2,%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L169:							*.L169:
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d1					*	moveq #0,%d1
_?L93:							*.L93:
	move.b (a1)+,d2					*	move.b (%a1)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L93					*	jlt .L93
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jblt _?L88					*	jlt .L88
	lea _dwarf_reg_size_table,a0			*	lea dwarf_reg_size_table,%a0
	move.b (a0,d3.l),d1				*	move.b (%a0,%d3.l),%d1
	move.l d3,d0					*	move.l %d3,%d0
	add.l d3,d0					*	add.l %d3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a4,d0.l),a2				*	move.l (%a4,%d0.l),%a2
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L129					*	jeq .L129
	lea (a4,d3.l),a0				*	lea (%a4,%d3.l),%a0
	tst.b 140(a0)					*	tst.b 140(%a0)
	jbeq _?L129					*	jeq .L129
	move.l a2,d0					*	move.l %a2,%d0
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L91:							*.L91:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	move.l d5,d3					*	move.l %d5,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	move.l d3,d0					*	move.l %d3,%d0
	add.l d3,d0					*	add.l %d3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),a0				*	move.l -256(%a0),%a0
	move.l a1,d1					*	move.l %a1,%d1
	addq.l #2,d1					*	addq.l #2,%d1
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbeq _?L235					*	jeq .L235
	jbhi _?L144					*	jhi .L144
	cmp.b #1,d0					*	cmp.b #1,%d0
	jbeq _?L145					*	jeq .L145
	cmp.b #2,d0					*	cmp.b #2,%d0
	jbne _?L88					*	jne .L88
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0),d0					*	move.b (%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 1(a0),d0					*	or.b 1(%a0),%d0
	move.l d1,a1					*	move.l %d1,%a1
	jbra _?L125					*	jra .L125
_?L154:							*.L154:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	seq d0						*	seq %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L153:							*.L153:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	sle d0						*	sle %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L152:							*.L152:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	slt d0						*	slt %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L150:							*.L150:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	sgt d0						*	sgt %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L148:							*.L148:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	sne d0						*	sne %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
_?L228:							*.L228:
	neg.l d0					*	neg.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L158:							*.L158:
	lsl.l d2,d0					*	lsl.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L157:							*.L157:
	lsr.l d2,d0					*	lsr.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L156:							*.L156:
	asr.l d2,d0					*	asr.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L155:							*.L155:
	eor.l d2,d0					*	eor.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L151:							*.L151:
	cmp.l d0,d2					*	cmp.l %d0,%d2
	sge d0						*	sge %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L165:							*.L165:
	and.l d2,d0					*	and.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L164:							*.L164:
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___divsi3					*	jsr __divsi3
	addq.l #8,sp					*	addq.l #8,%sp
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L163:							*.L163:
	sub.l d2,d0					*	sub.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L162:							*.L162:
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___umodsi3					*	jsr __umodsi3
	addq.l #8,sp					*	addq.l #8,%sp
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L161:							*.L161:
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L160:							*.L160:
	or.l d2,d0					*	or.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L159:							*.L159:
	add.l d2,d0					*	add.l %d2,%d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L129:							*.L129:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L88					*	jne .L88
	move.l (a2),d0					*	move.l (%a2),%d0
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L135:							*.L135:
	cmp.b #4,d2					*	cmp.b #4,%d2
	jbne _?L88					*	jne .L88
	move.l (a2),d1					*	move.l (%a2),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	jbra _?L125					*	jra .L125
_?L100:							*.L100:
	tst.l d5					*	tst.l %d5
	jbeq _?L88					*	jeq .L88
	move.l d5,d3					*	move.l %d5,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	move.l d3,d0					*	move.l %d3,%d0
	add.l d3,d0					*	add.l %d3,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	move.l -256(a0),d0				*	move.l -256(%a0),%d0
	add.b #-25,d1					*	add.b #-25,%d1
	cmp.b #10,d1					*	cmp.b #10,%d1
	jbhi _?L88					*	jhi .L88
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w _?L140(pc,d1.l),d1			*	move.w .L140(%pc,%d1.l),%d1
	jmp 2(pc,d1.w)					*	jmp %pc@(2,%d1:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&11
_?L140:							*.L140:
	.dc.w _?L143-_?L140				*	.word .L143-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L228-_?L140				*	.word .L228-.L140
	.dc.w _?L141-_?L140				*	.word .L141-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L175-_?L140				*	.word .L175-.L140
_?L141:							*.L141:
	not.l d0					*	not.l %d0
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L143:							*.L143:
	tst.l d0					*	tst.l %d0
	jblt _?L228					*	jlt .L228
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
	jbra _?L125					*	jra .L125
_?L175:							*.L175:
	moveq #0,d5					*	moveq #0,%d5
	move.l -264(a6),a1				*	move.l -264(%fp),%a1
_?L139:							*.L139:
	move.b (a1)+,d6					*	move.b (%a1)+,%d6
	moveq #127,d1					*	moveq #127,%d1
	and.l d6,d1					*	and.l %d6,%d1
	lsl.l d5,d1					*	lsl.l %d5,%d1
	or.l d1,d2					*	or.l %d1,%d2
	addq.l #7,d5					*	addq.l #7,%d5
	tst.b d6					*	tst.b %d6
	jblt _?L139					*	jlt .L139
	add.l d2,d0					*	add.l %d2,%d0
	jbra _?L125					*	jra .L125
_?L145:							*.L145:
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0),d0					*	move.b (%a0),%d0
	move.l d1,a1					*	move.l %d1,%a1
	jbra _?L125					*	jra .L125
_?L144:							*.L144:
	cmp.b #8,d0					*	cmp.b #8,%d0
	jbne _?L88					*	jne .L88
	moveq #0,d0					*	moveq #0,%d0
	move.b 4(a0),d0					*	move.b 4(%a0),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d2					*	moveq #0,%d2
	move.b 5(a0),d2					*	move.b 5(%a0),%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d0,d2					*	or.l %d0,%d2
	moveq #0,d0					*	moveq #0,%d0
	move.b 6(a0),d0					*	move.b 6(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d2,d0					*	or.l %d2,%d0
	or.b 7(a0),d0					*	or.b 7(%a0),%d0
	move.l d1,a1					*	move.l %d1,%a1
	jbra _?L125					*	jra .L125
_?L235:							*.L235:
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0),d0					*	move.b (%a0),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d2					*	moveq #0,%d2
	move.b 1(a0),d2					*	move.b 1(%a0),%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d0,d2					*	or.l %d0,%d2
	moveq #0,d0					*	moveq #0,%d0
	move.b 2(a0),d0					*	move.b 2(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d2,d0					*	or.l %d2,%d0
	or.b 3(a0),d0					*	or.b 3(%a0),%d0
	move.l d1,a1					*	move.l %d1,%a1
	jbra _?L125					*	jra .L125
_?L88:							*.L88:
	trap #7						*	trap #7
							*	.size	execute_stack_op, .-execute_stack_op
	.align	2					*	.align	2
							*	.type	uw_update_context_1, @function
_uw_update_context_1:					*uw_update_context_1:
	lea (-192,sp),sp				*	lea (-192,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 232(sp),a5				*	move.l 232(%sp),%a5
	move.l 236(sp),a6				*	move.l 236(%sp),%a6
	pea 166.w					*	pea 166.w
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	pea 70(sp)					*	pea 70(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l 202(sp),d0				*	move.l 202(%sp),%d0
	and.l #1073741824,d0				*	and.l #1073741824,%d0
	move.l d0,62(sp)				*	move.l %d0,62(%sp)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	jbeq _?L237					*	jeq .L237
	tst.b 217(sp)					*	tst.b 217(%sp)
	jbne _?L238					*	jne .L238
_?L237:							*.L237:
	tst.l 122(sp)					*	tst.l 122(%sp)
	jbeq _?L299					*	jeq .L299
_?L238:							*.L238:
	move.l 128(a5),46(sp)				*	move.l 128(%a5),46(%sp)
	move.l 46(sp),d1				*	move.l 46(%sp),%d1
	and.l #1073741824,d1				*	and.l #1073741824,%d1
	move.l d1,42(sp)				*	move.l %d1,42(%sp)
	btst #6,46(sp)					*	btst #6,46(%sp)
	jbeq _?L242					*	jeq .L242
	clr.b 155(a5)					*	clr.b 155(%a5)
_?L242:							*.L242:
	clr.l 60(a5)					*	clr.l 60(%a5)
	move.b 130(a6),d0				*	move.b 130(%a6),%d0
	cmp.b #1,d0					*	cmp.b #1,%d0
	jbeq _?L243					*	jeq .L243
	cmp.b #2,d0					*	cmp.b #2,%d0
	jbne _?L291					*	jne .L291
	move.l 144(a6),a0				*	move.l 144(%a6),%a0
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d1					*	moveq #0,%d1
_?L249:							*.L249:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L249					*	jlt .L249
	clr.l -(sp)					*	clr.l -(%sp)
	pea 66(sp)					*	pea 66(%sp)
	pea (a0,d3.l)					*	pea (%a0,%d3.l)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr _execute_stack_op				*	jsr execute_stack_op
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d5					*	move.l %d0,%d5
	move.l #_dwarf_reg_size_table,54(sp)		*	move.l #dwarf_reg_size_table,54(%sp)
	move.l d5,104(a5)				*	move.l %d5,104(%a5)
	lea (104,a6),a3					*	lea (104,%a6),%a3
	lea (140,a5),a4					*	lea (140,%a5),%a4
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.l a6,d6					*	move.l %a6,%d6
	add.l #130,d6					*	add.l #130,%d6
	moveq #0,d4					*	moveq #0,%d4
	move.l #_?L252,d7				*	move.l #.L252,%d7
_?L265:							*.L265:
	move.b (a3)+,d0					*	move.b (%a3)+,%d0
	cmp.b #5,d0					*	cmp.b #5,%d0
	jbhi _?L250					*	jhi .L250
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.w (a0,d7.l),d0				*	move.w (%a0,%d7.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&6
_?L252:							*.L252:
	.dc.w _?L250-_?L252				*	.word .L250-.L252
	.dc.w _?L256-_?L252				*	.word .L256-.L252
	.dc.w _?L255-_?L252				*	.word .L255-.L252
	.dc.w _?L254-_?L252				*	.word .L254-.L252
	.dc.w _?L253-_?L252				*	.word .L253-.L252
	.dc.w _?L251-_?L252				*	.word .L251-.L252
_?L251:							*.L251:
	move.l (a6,d4.l),a0				*	move.l (%a6,%d4.l),%a0
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d1					*	moveq #0,%d1
_?L264:							*.L264:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L264					*	jlt .L264
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	pea 66(sp)					*	pea 66(%sp)
	pea (a0,d3.l)					*	pea (%a0,%d3.l)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a1,54(sp)				*	move.l %a1,54(%sp)
	jbsr _execute_stack_op				*	jsr execute_stack_op
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l 38(sp),a1				*	move.l 38(%sp),%a1
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbhi _?L291					*	jhi .L291
_?L292:							*.L292:
	move.b #1,(a4)					*	move.b #1,(%a4)
_?L293:							*.L293:
	move.l d0,(a5,d4.l)				*	move.l %d0,(%a5,%d4.l)
_?L250:							*.L250:
	addq.l #1,a4					*	addq.l #1,%a4
	addq.l #1,a1					*	addq.l #1,%a1
	addq.l #4,d4					*	addq.l #4,%d4
	cmp.l d6,a3					*	cmp.l %d6,%a3
	jbne _?L265					*	jne .L265
	tst.b 171(a6)					*	tst.b 171(%a6)
	jbeq _?L266					*	jeq .L266
	move.l 46(sp),d0				*	move.l 46(%sp),%d0
	bset #31,d0					*	bset #31,%d0
	move.l d0,128(a5)				*	move.l %d0,128(%a5)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (192,sp),sp					*	lea (192,%sp),%sp
	rts						*	rts
_?L253:							*.L253:
	move.l d5,d0					*	move.l %d5,%d0
	add.l (a6,d4.l),d0				*	add.l (%a6,%d4.l),%d0
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbls _?L292					*	jls .L292
_?L291:							*.L291:
	trap #7						*	trap #7
_?L254:							*.L254:
	move.l (a6,d4.l),a0				*	move.l (%a6,%d4.l),%a0
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d1					*	moveq #0,%d1
_?L262:							*.L262:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L262					*	jlt .L262
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	pea 66(sp)					*	pea 66(%sp)
	pea (a0,d3.l)					*	pea (%a0,%d3.l)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a1,54(sp)				*	move.l %a1,54(%sp)
	jbsr _execute_stack_op				*	jsr execute_stack_op
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l 38(sp),a1				*	move.l 38(%sp),%a1
	tst.l 42(sp)					*	tst.l 42(%sp)
	jbeq _?L293					*	jeq .L293
	clr.b (a4)					*	clr.b (%a4)
_?L300:							*.L300:
	move.l d0,(a5,d4.l)				*	move.l %d0,(%a5,%d4.l)
	jbra _?L250					*	jra .L250
_?L256:							*.L256:
	move.l d5,d0					*	move.l %d5,%d0
	add.l (a6,d4.l),d0				*	add.l (%a6,%d4.l),%d0
	tst.l 42(sp)					*	tst.l 42(%sp)
	jbeq _?L293					*	jeq .L293
	clr.b (a4)					*	clr.b (%a4)
	jbra _?L300					*	jra .L300
_?L255:							*.L255:
	move.l (a6,d4.l),d0				*	move.l (%a6,%d4.l),%d0
	lea (202,sp),a0					*	lea (202,%sp),%a0
	tst.b (a0,d0.l)					*	tst.b (%a0,%d0.l)
	jbne _?L301					*	jne .L301
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (228,sp),a0					*	lea (228,%sp),%a0
	add.l d0,a0					*	add.l %d0,%a0
	move.l -166(a0),d0				*	move.l -166(%a0),%d0
	tst.l 42(sp)					*	tst.l 42(%sp)
	jbeq _?L293					*	jeq .L293
	clr.b (a4)					*	clr.b (%a4)
	jbra _?L300					*	jra .L300
_?L301:							*.L301:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L291					*	jlt .L291
	move.l 54(sp),a0				*	move.l 54(%sp),%a0
	move.b (a0,d0.l),d1				*	move.b (%a0,%d0.l),%d1
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (228,sp),a0					*	lea (228,%sp),%a0
	add.l d0,a0					*	add.l %d0,%a0
	move.l -166(a0),a0				*	move.l -166(%a0),%a0
	tst.l 50(sp)					*	tst.l 50(%sp)
	jbeq _?L259					*	jeq .L259
	move.l a0,d0					*	move.l %a0,%d0
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbls _?L292					*	jls .L292
	jbra _?L291					*	jra .L291
_?L259:							*.L259:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L291					*	jne .L291
	move.l (a0),d0					*	move.l (%a0),%d0
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbls _?L292					*	jls .L292
	jbra _?L291					*	jra .L291
_?L266:							*.L266:
	move.l 46(sp),d0				*	move.l 46(%sp),%d0
	bclr #31,d0					*	bclr #31,%d0
	move.l d0,128(a5)				*	move.l %d0,128(%a5)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (192,sp),sp					*	lea (192,%sp),%sp
	rts						*	rts
_?L243:							*.L243:
	move.l 140(a6),d1				*	move.l 140(%a6),%d1
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jblt _?L291					*	jlt .L291
	move.l d1,d0					*	move.l %d1,%d0
	add.l d1,d0					*	add.l %d1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (228,sp),a0					*	lea (228,%sp),%a0
	add.l d0,a0					*	add.l %d0,%a0
	move.l -166(a0),a0				*	move.l -166(%a0),%a0
	tst.l 50(sp)					*	tst.l 50(%sp)
	jbeq _?L246					*	jeq .L246
	lea (202,sp),a1					*	lea (202,%sp),%a1
	tst.b (a1,d1.l)					*	tst.b (%a1,%d1.l)
	jbne _?L302					*	jne .L302
_?L246:							*.L246:
	move.l #_dwarf_reg_size_table,54(sp)		*	move.l #dwarf_reg_size_table,54(%sp)
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	cmp.b #4,(a1,d1.l)				*	cmp.b #4,(%a1,%d1.l)
	jbne _?L291					*	jne .L291
	move.l (a0),a0					*	move.l (%a0),%a0
	move.l a0,d5					*	move.l %a0,%d5
	add.l 136(a6),d5				*	add.l 136(%a6),%d5
_?L303:							*.L303:
	move.l d5,104(a5)				*	move.l %d5,104(%a5)
	lea (104,a6),a3					*	lea (104,%a6),%a3
	lea (140,a5),a4					*	lea (140,%a5),%a4
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.l a6,d6					*	move.l %a6,%d6
	add.l #130,d6					*	add.l #130,%d6
	moveq #0,d4					*	moveq #0,%d4
	move.l #_?L252,d7				*	move.l #.L252,%d7
	jbra _?L265					*	jra .L265
_?L299:							*.L299:
	move.l 104(a5),d0				*	move.l 104(%a5),%d0
	cmp.b #4,_dwarf_reg_size_table+15.l		*	cmp.b #4,dwarf_reg_size_table+15.l
	jbne _?L291					*	jne .L291
	move.l d0,58(sp)				*	move.l %d0,58(%sp)
	tst.l 50(sp)					*	tst.l 50(%sp)
	jbeq _?L241					*	jeq .L241
	clr.b 217(sp)					*	clr.b 217(%sp)
_?L241:							*.L241:
	moveq #58,d1					*	moveq #58,%d1
	add.l sp,d1					*	add.l %sp,%d1
	move.l d1,122(sp)				*	move.l %d1,122(%sp)
	jbra _?L238					*	jra .L238
_?L302:							*.L302:
	move.l #_dwarf_reg_size_table,54(sp)		*	move.l #dwarf_reg_size_table,54(%sp)
	move.l a0,d5					*	move.l %a0,%d5
	add.l 136(a6),d5				*	add.l 136(%a6),%d5
	jbra _?L303					*	jra .L303
							*	.size	uw_update_context_1, .-uw_update_context_1
	.align	2					*	.align	2
							*	.type	execute_cfa_program_specialized, @function
_execute_cfa_program_specialized:			*execute_cfa_program_specialized:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a1					*	move.l 8(%fp),%a1
	move.l 12(a6),d4				*	move.l 12(%fp),%d4
	move.l 16(a6),a5				*	move.l 16(%fp),%a5
	move.l 20(a6),a4				*	move.l 20(%fp),%a4
	clr.l 132(a4)					*	clr.l 132(%a4)
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbls _?L304					*	jls .L304
	move.l 128(a5),d3				*	move.l 128(%a5),%d3
	add.l d3,d3					*	add.l %d3,%d3
	subx.l d3,d3					*	subx.l %d3,%d3
	neg.l d3					*	neg.l %d3
	add.l 108(a5),d3				*	add.l 108(%a5),%d3
	sub.l a2,a2					*	sub.l %a2,%a2
	move.l #_?L316,a0				*	move.l #.L316,%a0
_?L306:							*.L306:
	move.l 148(a4),d2				*	move.l 148(%a4),%d2
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbls _?L304					*	jls .L304
	move.l a1,a3					*	move.l %a1,%a3
	move.b (a3)+,d1					*	move.b (%a3)+,%d1
	move.b d1,d0					*	move.b %d1,%d0
	and.b #-64,d0					*	and.b #-64,%d0
	cmp.b #64,d0					*	cmp.b #64,%d0
	jbeq _?L444					*	jeq .L444
	cmp.b #-128,d0					*	cmp.b #-128,%d0
	jbeq _?L445					*	jeq .L445
	cmp.b #-64,d0					*	cmp.b #-64,%d0
	jbeq _?L446					*	jeq .L446
	cmp.b #47,d1					*	cmp.b #47,%d1
	jbhi _?L314					*	jhi .L314
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w (a0,d1.l),d0				*	move.w (%a0,%d1.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&48
_?L316:							*.L316:
	.dc.w _?L311-_?L316				*	.word .L311-.L316
	.dc.w _?L339-_?L316				*	.word .L339-.L316
	.dc.w _?L338-_?L316				*	.word .L338-.L316
	.dc.w _?L337-_?L316				*	.word .L337-.L316
	.dc.w _?L336-_?L316				*	.word .L336-.L316
	.dc.w _?L370-_?L316				*	.word .L370-.L316
	.dc.w _?L371-_?L316				*	.word .L371-.L316
	.dc.w _?L372-_?L316				*	.word .L372-.L316
	.dc.w _?L373-_?L316				*	.word .L373-.L316
	.dc.w _?L374-_?L316				*	.word .L374-.L316
	.dc.w _?L330-_?L316				*	.word .L330-.L316
	.dc.w _?L329-_?L316				*	.word .L329-.L316
	.dc.w _?L375-_?L316				*	.word .L375-.L316
	.dc.w _?L376-_?L316				*	.word .L376-.L316
	.dc.w _?L377-_?L316				*	.word .L377-.L316
	.dc.w _?L325-_?L316				*	.word .L325-.L316
	.dc.w _?L378-_?L316				*	.word .L378-.L316
	.dc.w _?L379-_?L316				*	.word .L379-.L316
	.dc.w _?L380-_?L316				*	.word .L380-.L316
	.dc.w _?L381-_?L316				*	.word .L381-.L316
	.dc.w _?L382-_?L316				*	.word .L382-.L316
	.dc.w _?L383-_?L316				*	.word .L383-.L316
	.dc.w _?L384-_?L316				*	.word .L384-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L314-_?L316				*	.word .L314-.L316
	.dc.w _?L311-_?L316				*	.word .L311-.L316
	.dc.w _?L385-_?L316				*	.word .L385-.L316
	.dc.w _?L386-_?L316				*	.word .L386-.L316
_?L444:							*.L444:
	moveq #63,d0					*	moveq #63,%d0
	and.l d0,d1					*	and.l %d0,%d1
	add.l d1,d2					*	add.l %d1,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
_?L311:							*.L311:
	move.l a3,a1					*	move.l %a3,%a1
_?L313:							*.L313:
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
_?L304:							*.L304:
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L446:							*.L446:
	move.b d1,d0					*	move.b %d1,%d0
	and.b #63,d0					*	and.b #63,%d0
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	cmp.b #25,d0					*	cmp.b #25,%d0
	jbhi _?L311					*	jhi .L311
	clr.b 104(a4,d1.l)				*	clr.b 104(%a4,%d1.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L445:							*.L445:
	move.b d1,d7					*	move.b %d1,%d7
	and.b #63,d7					*	and.b #63,%d7
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d2					*	moveq #0,%d2
_?L310:							*.L310:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d6					*	tst.b %d6
	jblt _?L310					*	jlt .L310
	neg.l d5					*	neg.l %d5
	move.l d5,a1					*	move.l %d5,%a1
	add.l d5,a1					*	add.l %d5,%a1
	cmp.b #25,d7					*	cmp.b #25,%d7
	jbhi _?L311					*	jhi .L311
	move.b #1,104(a4,d1.l)				*	move.b #1,104(%a4,%d1.l)
	add.l d1,d1					*	add.l %d1,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l a1,(a4,d1.l)				*	move.l %a1,(%a4,%d1.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L325:							*.L325:
	move.l a3,144(a4)				*	move.l %a3,144(%a4)
	move.b #2,130(a4)				*	move.b #2,130(%a4)
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L350:							*.L350:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L350					*	jlt .L350
_?L430:							*.L430:
	lea (a3,d6.l),a1				*	lea (%a3,%d6.l),%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L339:							*.L339:
	pea -4(a6)					*	pea -4(%fp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a1					*	move.l %d0,%a1
	move.l -4(a6),148(a4)				*	move.l -4(%fp),148(%a4)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L338:							*.L338:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
	addq.l #2,a1					*	addq.l #2,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L337:							*.L337:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
	addq.l #3,a1					*	addq.l #3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L336:							*.L336:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 3(a1),d0					*	move.b 3(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 4(a1),d0					*	or.b 4(%a1),%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
	addq.l #5,a1					*	addq.l #5,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L330:							*.L330:
	cmp.w #0,a2					*	cmp.w #0,%a2
	jbeq _?L347					*	jeq .L347
	move.l a2,d6					*	move.l %a2,%d6
	move.l 132(a2),a2				*	move.l 132(%a2),%a2
	pea 148.w					*	pea 148.w
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a4)				*	move.l %d6,132(%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
_?L450:							*.L450:
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L329:							*.L329:
	move.l 132(a4),d6				*	move.l 132(%a4),%d6
	pea 148.w					*	pea 148.w
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	move.l d6,a1					*	move.l %d6,%a1
	move.l a2,132(a1)				*	move.l %a2,132(%a1)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d6,a2					*	move.l %d6,%a2
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L375:							*.L375:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L328:							*.L328:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L328					*	jlt .L328
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L349:							*.L349:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L349					*	jlt .L349
	move.l d6,136(a4)				*	move.l %d6,136(%a4)
	move.b #1,130(a4)				*	move.b #1,130(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L386:							*.L386:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L315:							*.L315:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L315					*	jlt .L315
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d1					*	moveq #0,%d1
_?L366:							*.L366:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L366					*	jlt .L366
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L311					*	jcs .L311
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	add.l d2,d2					*	add.l %d2,%d2
	add.l d2,d2					*	add.l %d2,%d2
	neg.l d7					*	neg.l %d7
	move.l d7,(a4,d2.l)				*	move.l %d7,(%a4,%d2.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L378:							*.L378:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L324:							*.L324:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L324					*	jlt .L324
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L351					*	jcs .L351
	move.b #3,104(a4,d6.l)				*	move.b #3,104(%a4,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l a3,(a4,d6.l)				*	move.l %a3,(%a4,%d6.l)
_?L351:							*.L351:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L352:							*.L352:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L430					*	jge .L430
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L352					*	jlt .L352
	jbra _?L430					*	jra .L430
_?L379:							*.L379:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L323:							*.L323:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L323					*	jlt .L323
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d1					*	moveq #0,%d1
_?L353:							*.L353:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L353					*	jlt .L353
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L354					*	jcs .L354
	btst #6,d6					*	btst #6,%d6
	jbne _?L447					*	jne .L447
_?L354:							*.L354:
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L311					*	jcs .L311
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	add.l d2,d2					*	add.l %d2,%d2
	add.l d2,d2					*	add.l %d2,%d2
	move.l d7,(a4,d2.l)				*	move.l %d7,(%a4,%d2.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L380:							*.L380:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L322:							*.L322:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L322					*	jlt .L322
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L356:							*.L356:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L356					*	jlt .L356
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L357					*	jcs .L357
	btst #6,d2					*	btst #6,%d2
	jbeq _?L357					*	jeq .L357
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
_?L357:							*.L357:
	move.b #1,130(a4)				*	move.b #1,130(%a4)
_?L431:							*.L431:
	add.l d6,d6					*	add.l %d6,%d6
	neg.l d6					*	neg.l %d6
_?L429:							*.L429:
	move.l d6,136(a4)				*	move.l %d6,136(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L381:							*.L381:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L321:							*.L321:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L321					*	jlt .L321
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L431					*	jcs .L431
	btst #6,d2					*	btst #6,%d2
	jbeq _?L431					*	jeq .L431
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	add.l d6,d6					*	add.l %d6,%d6
	neg.l d6					*	neg.l %d6
	jbra _?L429					*	jra .L429
_?L383:							*.L383:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L319:							*.L319:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L319					*	jlt .L319
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d1					*	moveq #0,%d1
_?L361:							*.L361:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L361					*	jlt .L361
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L362					*	jcs .L362
	btst #6,d6					*	btst #6,%d6
	jbne _?L448					*	jne .L448
_?L362:							*.L362:
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L311					*	jcs .L311
	move.b #4,104(a4,d2.l)				*	move.b #4,104(%a4,%d2.l)
	add.l d2,d2					*	add.l %d2,%d2
	add.l d2,d2					*	add.l %d2,%d2
	move.l d7,(a4,d2.l)				*	move.l %d7,(%a4,%d2.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L382:							*.L382:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L320:							*.L320:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L320					*	jlt .L320
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d1					*	moveq #0,%d1
_?L359:							*.L359:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jbge _?L362					*	jge .L362
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L359					*	jlt .L359
	jbra _?L362					*	jra .L362
_?L384:							*.L384:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L318:							*.L318:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L318					*	jlt .L318
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L364					*	jcs .L364
	move.b #5,104(a4,d6.l)				*	move.b #5,104(%a4,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l a3,(a4,d6.l)				*	move.l %a3,(%a4,%d6.l)
_?L364:							*.L364:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L365:							*.L365:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L430					*	jge .L430
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L365					*	jlt .L365
	jbra _?L430					*	jra .L430
_?L385:							*.L385:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L317:							*.L317:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L317					*	jlt .L317
	move.l d6,136(a5)				*	move.l %d6,136(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L370:							*.L370:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L335:							*.L335:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L335					*	jlt .L335
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d1					*	moveq #0,%d1
_?L340:							*.L340:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jbge _?L354					*	jge .L354
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L340					*	jlt .L340
	jbra _?L354					*	jra .L354
_?L371:							*.L371:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L334:							*.L334:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L334					*	jlt .L334
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L311					*	jcs .L311
	clr.b 104(a4,d6.l)				*	clr.b 104(%a4,%d6.l)
_?L449:							*.L449:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L376:							*.L376:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L327:							*.L327:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L327					*	jlt .L327
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	move.b #1,130(a4)				*	move.b #1,130(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L306					*	jcs .L306
	jbra _?L304					*	jra .L304
_?L377:							*.L377:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L326:							*.L326:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L429					*	jge .L429
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L326					*	jlt .L326
	jbra _?L429					*	jra .L429
_?L372:							*.L372:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L333:							*.L333:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L333					*	jlt .L333
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L311					*	jcs .L311
	move.b #7,104(a4,d6.l)				*	move.b #7,104(%a4,%d6.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L373:							*.L373:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L332:							*.L332:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L332					*	jlt .L332
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L311					*	jcs .L311
	clr.b 104(a4,d6.l)				*	clr.b 104(%a4,%d6.l)
	jbra _?L449					*	jra .L449
_?L374:							*.L374:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L331:							*.L331:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L331					*	jlt .L331
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d1					*	moveq #0,%d1
_?L345:							*.L345:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L345					*	jlt .L345
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L311					*	jcs .L311
	move.b #2,104(a4,d2.l)				*	move.b #2,104(%a4,%d2.l)
	add.l d2,d2					*	add.l %d2,%d2
	add.l d2,d2					*	add.l %d2,%d2
	move.l d7,(a4,d2.l)				*	move.l %d7,(%a4,%d2.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L313					*	jra .L313
_?L448:							*.L448:
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	jbra _?L362					*	jra .L362
_?L447:							*.L447:
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	jbra _?L354					*	jra .L354
_?L347:							*.L347:
	lea (-148,sp),sp				*	lea (-148,%sp),%sp
	move.l sp,d6					*	move.l %sp,%d6
	pea 148.w					*	pea 148.w
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a4)				*	move.l %d6,132(%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	jbra _?L450					*	jra .L450
_?L314:							*.L314:
	trap #7						*	trap #7
							*	.size	execute_cfa_program_specialized, .-execute_cfa_program_specialized
	.align	2					*	.align	2
							*	.type	execute_cfa_program_generic, @function
_execute_cfa_program_generic:				*execute_cfa_program_generic:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a1					*	move.l 8(%fp),%a1
	move.l 12(a6),d4				*	move.l 12(%fp),%d4
	move.l 20(a6),a5				*	move.l 20(%fp),%a5
	clr.l 132(a5)					*	clr.l 132(%a5)
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbls _?L451					*	jls .L451
	move.l 16(a6),a0				*	move.l 16(%fp),%a0
	move.l 128(a0),d3				*	move.l 128(%a0),%d3
	add.l d3,d3					*	add.l %d3,%d3
	subx.l d3,d3					*	subx.l %d3,%d3
	neg.l d3					*	neg.l %d3
	add.l 108(a0),d3				*	add.l 108(%a0),%d3
	clr.l -8(a6)					*	clr.l -8(%fp)
	lea ___mulsi3,a4				*	lea __mulsi3,%a4
_?L453:							*.L453:
	move.l 148(a5),d6				*	move.l 148(%a5),%d6
	cmp.l d6,d3					*	cmp.l %d6,%d3
	jbls _?L451					*	jls .L451
	move.l a1,a3					*	move.l %a1,%a3
	move.b (a3)+,d1					*	move.b (%a3)+,%d1
	move.b d1,d0					*	move.b %d1,%d0
	and.b #-64,d0					*	and.b #-64,%d0
	cmp.b #64,d0					*	cmp.b #64,%d0
	jbeq _?L584					*	jeq .L584
	cmp.b #-128,d0					*	cmp.b #-128,%d0
	jbeq _?L585					*	jeq .L585
	cmp.b #-64,d0					*	cmp.b #-64,%d0
	jbeq _?L586					*	jeq .L586
	cmp.b #47,d1					*	cmp.b #47,%d1
	jbhi _?L462					*	jhi .L462
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w _?L464(pc,d1.l),d0			*	move.w .L464(%pc,%d1.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&48
_?L464:							*.L464:
	.dc.w _?L458-_?L464				*	.word .L458-.L464
	.dc.w _?L487-_?L464				*	.word .L487-.L464
	.dc.w _?L486-_?L464				*	.word .L486-.L464
	.dc.w _?L485-_?L464				*	.word .L485-.L464
	.dc.w _?L484-_?L464				*	.word .L484-.L464
	.dc.w _?L518-_?L464				*	.word .L518-.L464
	.dc.w _?L519-_?L464				*	.word .L519-.L464
	.dc.w _?L520-_?L464				*	.word .L520-.L464
	.dc.w _?L521-_?L464				*	.word .L521-.L464
	.dc.w _?L522-_?L464				*	.word .L522-.L464
	.dc.w _?L478-_?L464				*	.word .L478-.L464
	.dc.w _?L477-_?L464				*	.word .L477-.L464
	.dc.w _?L523-_?L464				*	.word .L523-.L464
	.dc.w _?L524-_?L464				*	.word .L524-.L464
	.dc.w _?L525-_?L464				*	.word .L525-.L464
	.dc.w _?L473-_?L464				*	.word .L473-.L464
	.dc.w _?L526-_?L464				*	.word .L526-.L464
	.dc.w _?L527-_?L464				*	.word .L527-.L464
	.dc.w _?L528-_?L464				*	.word .L528-.L464
	.dc.w _?L529-_?L464				*	.word .L529-.L464
	.dc.w _?L530-_?L464				*	.word .L530-.L464
	.dc.w _?L531-_?L464				*	.word .L531-.L464
	.dc.w _?L532-_?L464				*	.word .L532-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L462-_?L464				*	.word .L462-.L464
	.dc.w _?L458-_?L464				*	.word .L458-.L464
	.dc.w _?L533-_?L464				*	.word .L533-.L464
	.dc.w _?L534-_?L464				*	.word .L534-.L464
_?L584:							*.L584:
	move.l 160(a5),-(sp)				*	move.l 160(%a5),-(%sp)
	moveq #63,d0					*	moveq #63,%d0
	and.l d1,d0					*	and.l %d1,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	add.l d0,d6					*	add.l %d0,%d6
	move.l d6,148(a5)				*	move.l %d6,148(%a5)
_?L458:							*.L458:
	move.l a3,a1					*	move.l %a3,%a1
_?L461:							*.L461:
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
_?L451:							*.L451:
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L586:							*.L586:
	move.b d1,d0					*	move.b %d1,%d0
	and.b #63,d0					*	and.b #63,%d0
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	cmp.b #25,d0					*	cmp.b #25,%d0
	jbhi _?L458					*	jhi .L458
	clr.b 104(a5,d1.l)				*	clr.b 104(%a5,%d1.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L585:							*.L585:
	move.b d1,d6					*	move.b %d1,%d6
	and.b #63,d6					*	and.b #63,%d6
	moveq #63,d5					*	moveq #63,%d5
	and.l d1,d5					*	and.l %d1,%d5
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d2					*	moveq #0,%d2
_?L457:							*.L457:
	move.b (a3)+,d7					*	move.b (%a3)+,%d7
	moveq #127,d0					*	moveq #127,%d0
	and.l d7,d0					*	and.l %d7,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d7					*	tst.b %d7
	jblt _?L457					*	jlt .L457
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #25,d6					*	cmp.b #25,%d6
	jbhi _?L458					*	jhi .L458
	move.b #1,104(a5,d5.l)				*	move.b #1,104(%a5,%d5.l)
	move.l d5,d1					*	move.l %d5,%d1
	add.l d5,d1					*	add.l %d5,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l d0,(a5,d1.l)				*	move.l %d0,(%a5,%d1.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L473:							*.L473:
	move.l a3,144(a5)				*	move.l %a3,144(%a5)
	move.b #2,130(a5)				*	move.b #2,130(%a5)
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L498:							*.L498:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L498					*	jlt .L498
_?L576:							*.L576:
	lea (a3,d6.l),a1				*	lea (%a3,%d6.l),%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L487:							*.L487:
	pea -4(a6)					*	pea -4(%fp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	move.b 168(a5),d0				*	move.b 168(%a5),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l 16(a6),-(sp)				*	move.l 16(%fp),-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a1					*	move.l %d0,%a1
	move.l -4(a6),148(a5)				*	move.l -4(%fp),148(%a5)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L486:							*.L486:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	move.l 160(a5),-(sp)				*	move.l 160(%a5),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a1,-12(a6)				*	move.l %a1,-12(%fp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	add.l d0,d6					*	add.l %d0,%d6
	move.l d6,148(a5)				*	move.l %d6,148(%a5)
	move.l -12(a6),a1				*	move.l -12(%fp),%a1
	addq.l #2,a1					*	addq.l #2,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L485:							*.L485:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	move.l 160(a5),-(sp)				*	move.l 160(%a5),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a1,-12(a6)				*	move.l %a1,-12(%fp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	add.l d0,d6					*	add.l %d0,%d6
	move.l d6,148(a5)				*	move.l %d6,148(%a5)
	move.l -12(a6),a1				*	move.l -12(%fp),%a1
	addq.l #3,a1					*	addq.l #3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L484:							*.L484:
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 3(a1),d0					*	move.b 3(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 4(a1),d0					*	or.b 4(%a1),%d0
	move.l 160(a5),-(sp)				*	move.l 160(%a5),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a1,-12(a6)				*	move.l %a1,-12(%fp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	add.l d0,d6					*	add.l %d0,%d6
	move.l d6,148(a5)				*	move.l %d6,148(%a5)
	move.l -12(a6),a1				*	move.l -12(%fp),%a1
	addq.l #5,a1					*	addq.l #5,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L478:							*.L478:
	tst.l -8(a6)					*	tst.l -8(%fp)
	jbeq _?L495					*	jeq .L495
	move.l -8(a6),d6				*	move.l -8(%fp),%d6
	move.l d6,a0					*	move.l %d6,%a0
	move.l 132(a0),-8(a6)				*	move.l 132(%a0),-8(%fp)
	pea 148.w					*	pea 148.w
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a5)				*	move.l %d6,132(%a5)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
_?L590:							*.L590:
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L477:							*.L477:
	move.l 132(a5),d6				*	move.l 132(%a5),%d6
	pea 148.w					*	pea 148.w
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,a0					*	move.l %d6,%a0
	move.l -8(a6),132(a0)				*	move.l -8(%fp),132(%a0)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d6,-8(a6)				*	move.l %d6,-8(%fp)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L523:							*.L523:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L476:							*.L476:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L476					*	jlt .L476
	move.l d6,140(a5)				*	move.l %d6,140(%a5)
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L497:							*.L497:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L497					*	jlt .L497
	move.l d6,136(a5)				*	move.l %d6,136(%a5)
	move.b #1,130(a5)				*	move.b #1,130(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L534:							*.L534:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L463:							*.L463:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L463					*	jlt .L463
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L514:							*.L514:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L514					*	jlt .L514
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L458					*	jcs .L458
	move.b #1,104(a5,d6.l)				*	move.b #1,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	neg.l d0					*	neg.l %d0
	move.l d0,(a5,d6.l)				*	move.l %d0,(%a5,%d6.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L526:							*.L526:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L472:							*.L472:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L472					*	jlt .L472
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L499					*	jcs .L499
	move.b #3,104(a5,d6.l)				*	move.b #3,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l a3,(a5,d6.l)				*	move.l %a3,(%a5,%d6.l)
_?L499:							*.L499:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L500:							*.L500:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L576					*	jge .L576
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L500					*	jlt .L500
	jbra _?L576					*	jra .L576
_?L527:							*.L527:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L471:							*.L471:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L471					*	jlt .L471
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L501:							*.L501:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L501					*	jlt .L501
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L502					*	jcs .L502
	btst #6,d2					*	btst #6,%d2
	jbeq _?L502					*	jeq .L502
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
_?L502:							*.L502:
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L458					*	jcs .L458
	move.b #1,104(a5,d6.l)				*	move.b #1,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l d0,(a5,d6.l)				*	move.l %d0,(%a5,%d6.l)
_?L588:							*.L588:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L528:							*.L528:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L470:							*.L470:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L470					*	jlt .L470
	move.l d6,140(a5)				*	move.l %d6,140(%a5)
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L504:							*.L504:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L504					*	jlt .L504
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L505					*	jcs .L505
	btst #6,d2					*	btst #6,%d2
	jbeq _?L505					*	jeq .L505
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
_?L505:							*.L505:
	move.b #1,130(a5)				*	move.b #1,130(%a5)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,136(a5)				*	move.l %d0,136(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L529:							*.L529:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L469:							*.L469:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L469					*	jlt .L469
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L506					*	jcs .L506
	btst #6,d2					*	btst #6,%d2
	jbeq _?L506					*	jeq .L506
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
_?L506:							*.L506:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,136(a5)				*	move.l %d0,136(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L531:							*.L531:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L467:							*.L467:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L467					*	jlt .L467
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L509:							*.L509:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L509					*	jlt .L509
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L510					*	jcs .L510
	btst #6,d2					*	btst #6,%d2
	jbeq _?L510					*	jeq .L510
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
_?L510:							*.L510:
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L458					*	jcs .L458
	move.b #4,104(a5,d6.l)				*	move.b #4,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l d0,(a5,d6.l)				*	move.l %d0,(%a5,%d6.l)
_?L587:							*.L587:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L530:							*.L530:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L468:							*.L468:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L468					*	jlt .L468
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L507:							*.L507:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L507					*	jlt .L507
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L458					*	jcs .L458
	move.b #4,104(a5,d6.l)				*	move.b #4,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l d0,(a5,d6.l)				*	move.l %d0,(%a5,%d6.l)
	jbra _?L587					*	jra .L587
_?L532:							*.L532:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L466:							*.L466:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L466					*	jlt .L466
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L512					*	jcs .L512
	move.b #5,104(a5,d6.l)				*	move.b #5,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l a3,(a5,d6.l)				*	move.l %a3,(%a5,%d6.l)
_?L512:							*.L512:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L513:							*.L513:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L576					*	jge .L576
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L513					*	jlt .L513
	jbra _?L576					*	jra .L576
_?L533:							*.L533:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L465:							*.L465:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L465					*	jlt .L465
	move.l 16(a6),a0				*	move.l 16(%fp),%a0
	move.l d6,136(a0)				*	move.l %d6,136(%a0)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L518:							*.L518:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L483:							*.L483:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L483					*	jlt .L483
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L488:							*.L488:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L488					*	jlt .L488
	move.l 156(a5),-(sp)				*	move.l 156(%a5),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr ___mulsi3					*	jsr __mulsi3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L458					*	jcs .L458
	move.b #1,104(a5,d6.l)				*	move.b #1,104(%a5,%d6.l)
	add.l d6,d6					*	add.l %d6,%d6
	add.l d6,d6					*	add.l %d6,%d6
	move.l d0,(a5,d6.l)				*	move.l %d0,(%a5,%d6.l)
	jbra _?L588					*	jra .L588
_?L519:							*.L519:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L482:							*.L482:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L482					*	jlt .L482
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L458					*	jcs .L458
	clr.b 104(a5,d6.l)				*	clr.b 104(%a5,%d6.l)
_?L589:							*.L589:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L524:							*.L524:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L475:							*.L475:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L475					*	jlt .L475
	move.l d6,140(a5)				*	move.l %d6,140(%a5)
	move.b #1,130(a5)				*	move.b #1,130(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L525:							*.L525:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L474:							*.L474:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L474					*	jlt .L474
	move.l d6,136(a5)				*	move.l %d6,136(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L453					*	jhi .L453
	jbra _?L451					*	jra .L451
_?L520:							*.L520:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L481:							*.L481:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L481					*	jlt .L481
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L458					*	jcs .L458
	move.b #7,104(a5,d6.l)				*	move.b #7,104(%a5,%d6.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L521:							*.L521:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d1					*	moveq #0,%d1
_?L480:							*.L480:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L480					*	jlt .L480
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L458					*	jcs .L458
	clr.b 104(a5,d6.l)				*	clr.b 104(%a5,%d6.l)
	jbra _?L589					*	jra .L589
_?L522:							*.L522:
	moveq #0,d2					*	moveq #0,%d2
	moveq #0,d1					*	moveq #0,%d1
_?L479:							*.L479:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L479					*	jlt .L479
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L493:							*.L493:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L493					*	jlt .L493
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L458					*	jcs .L458
	move.b #2,104(a5,d2.l)				*	move.b #2,104(%a5,%d2.l)
	add.l d2,d2					*	add.l %d2,%d2
	add.l d2,d2					*	add.l %d2,%d2
	move.l d5,(a5,d2.l)				*	move.l %d5,(%a5,%d2.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L461					*	jra .L461
_?L495:							*.L495:
	lea (-148,sp),sp				*	lea (-148,%sp),%sp
	move.l sp,d6					*	move.l %sp,%d6
	pea 148.w					*	pea 148.w
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a5)				*	move.l %d6,132(%a5)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L590					*	jra .L590
_?L462:							*.L462:
	trap #7						*	trap #7
							*	.size	execute_cfa_program_generic, .-execute_cfa_program_generic
	.align	2					*	.align	2
							*	.type	uw_frame_state_for, @function
_uw_frame_state_for:					*uw_frame_state_for:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/a3/a4/a5,-(sp)		*	movem.l #7708,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 12(a6),a4				*	move.l 12(%fp),%a4
	pea 72.w					*	pea 72.w
	clr.l -(sp)					*	clr.l -(%sp)
	pea 104(a4)					*	pea 104(%a4)
	jbsr _memset					*	jsr memset
	clr.l 136(a3)					*	clr.l 136(%a3)
	clr.l 112(a3)					*	clr.l 112(%a3)
	move.l 108(a3),a0				*	move.l 108(%a3),%a0
	lea (12,sp),sp					*	lea (12,%sp),%sp
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L594					*	jeq .L594
	pea 116(a3)					*	pea 116(%a3)
	move.l 128(a3),d0				*	move.l 128(%a3),%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	pea -1(a0,d0.l)					*	pea -1(%a0,%d0.l)
	jbsr __Unwind_Find_FDE				*	jsr _Unwind_Find_FDE
	move.l d0,a5					*	move.l %d0,%a5
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L594					*	jeq .L594
	move.l 124(a3),148(a4)				*	move.l 124(%a3),148(%a4)
	lea (4,a5),a0					*	lea (4,%a5),%a0
	sub.l 4(a5),a0					*	sub.l 4(%a5),%a0
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.w #9,a1					*	move.w #9,%a1
	add.l a0,a1					*	add.l %a0,%a1
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l a1,-8(a6)				*	move.l %a1,-8(%fp)
	jbsr _strlen					*	jsr strlen
	addq.l #4,sp					*	addq.l #4,%sp
	move.l -8(a6),a1				*	move.l -8(%fp),%a1
	lea 1(a1,d0.l),a0				*	lea 1(%a1,%d0.l),%a0
	move.l -12(a6),a2				*	move.l -12(%fp),%a2
	cmp.b #101,9(a2)				*	cmp.b #101,9(%a2)
	jbeq _?L659					*	jeq .L659
_?L595:							*.L595:
	move.l -12(a6),a2				*	move.l -12(%fp),%a2
	move.b 8(a2),d2					*	move.b 8(%a2),%d2
	move.b (a0),d0					*	move.b (%a0),%d0
	cmp.b #3,d2					*	cmp.b #3,%d2
	jbhi _?L660					*	jhi .L660
_?L596:							*.L596:
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d0					*	moveq #0,%d0
_?L599:							*.L599:
	move.b (a0)+,d4					*	move.b (%a0)+,%d4
	moveq #127,d1					*	moveq #127,%d1
	and.l d4,d1					*	and.l %d4,%d1
	lsl.l d0,d1					*	lsl.l %d0,%d1
	or.l d1,d3					*	or.l %d1,%d3
	addq.l #7,d0					*	addq.l #7,%d0
	tst.b d4					*	tst.b %d4
	jblt _?L599					*	jlt .L599
	move.l d3,160(a4)				*	move.l %d3,160(%a4)
	moveq #0,d4					*	moveq #0,%d4
	moveq #0,d0					*	moveq #0,%d0
_?L600:							*.L600:
	move.l a0,a2					*	move.l %a0,%a2
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d1					*	moveq #127,%d1
	and.l d5,d1					*	and.l %d5,%d1
	lsl.l d0,d1					*	lsl.l %d0,%d1
	or.l d1,d4					*	or.l %d1,%d4
	addq.l #7,d0					*	addq.l #7,%d0
	tst.b d5					*	tst.b %d5
	jblt _?L600					*	jlt .L600
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L601					*	jcs .L601
	btst #6,d5					*	btst #6,%d5
	jbeq _?L601					*	jeq .L601
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d0,d1					*	lsl.l %d0,%d1
	or.l d1,d4					*	or.l %d1,%d4
_?L601:							*.L601:
	move.l d4,156(a4)				*	move.l %d4,156(%a4)
	moveq #0,d5					*	moveq #0,%d5
	cmp.b #1,d2					*	cmp.b #1,%d2
	jbeq _?L661					*	jeq .L661
	moveq #0,d1					*	moveq #0,%d1
_?L602:							*.L602:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L602					*	jlt .L602
	move.l d5,164(a4)				*	move.l %d5,164(%a4)
	st 169(a4)					*	st 169(%a4)
	move.b (a1),d1					*	move.b (%a1),%d1
	moveq #0,d5					*	moveq #0,%d5
	cmp.b #122,d1					*	cmp.b #122,%d1
	jbeq _?L662					*	jeq .L662
_?L604:							*.L604:
	tst.b d1					*	tst.b %d1
	jbeq _?L663					*	jeq .L663
	addq.l #1,a1					*	addq.l #1,%a1
	move.l #_?L609,d6				*	move.l #.L609,%d6
_?L616:							*.L616:
	add.b #-66,d1					*	add.b #-66,%d1
	cmp.b #17,d1					*	cmp.b #17,%d1
	jbhi _?L607					*	jhi .L607
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l d1,a2					*	move.l %d1,%a2
	move.w (a2,d6.l),d0				*	move.w (%a2,%d6.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&18
_?L609:							*.L609:
	.dc.w _?L614-_?L609				*	.word .L614-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L612-_?L609				*	.word .L612-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L611-_?L609				*	.word .L611-.L609
	.dc.w _?L607-_?L609				*	.word .L607-.L609
	.dc.w _?L610-_?L609				*	.word .L610-.L609
	.dc.w _?L608-_?L609				*	.word .L608-.L609
_?L612:							*.L612:
	move.b (a0)+,169(a4)				*	move.b (%a0)+,169(%a4)
_?L614:							*.L614:
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L616					*	jne .L616
_?L667:							*.L667:
	tst.l d5					*	tst.l %d5
	jbne _?L606					*	jne .L606
	move.l a0,d5					*	move.l %a0,%d5
_?L607:							*.L607:
	tst.l d5					*	tst.l %d5
	jbeq _?L598					*	jeq .L598
_?L606:							*.L606:
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l (a0),d0					*	move.l (%a0),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l a0,d0					*	add.l %a0,%d0
	move.l d0,-12(a6)				*	move.l %d0,-12(%fp)
	addq.l #2,d4					*	addq.l #2,%d4
	jbne _?L617					*	jne .L617
	subq.l #1,d3					*	subq.l #1,%d3
	jbeq _?L664					*	jeq .L664
_?L617:							*.L617:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _execute_cfa_program_generic		*	jsr execute_cfa_program_generic
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L632					*	jeq .L632
_?L669:							*.L669:
	and.b #7,d0					*	and.b #7,%d0
	cmp.b #2,d0					*	cmp.b #2,%d0
	jbeq _?L633					*	jeq .L633
	jbls _?L665					*	jls .L665
	cmp.b #3,d0					*	cmp.b #3,%d0
	jbeq _?L635					*	jeq .L635
	moveq #24,d1					*	moveq #24,%d1
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbne _?L621					*	jne .L621
_?L619:							*.L619:
	add.l a5,d1					*	add.l %a5,%d1
	move.l d1,-12(a6)				*	move.l %d1,-12(%fp)
	tst.b 170(a4)					*	tst.b 170(%a4)
	jbeq _?L622					*	jeq .L622
_?L668:							*.L668:
	moveq #0,d4					*	moveq #0,%d4
	moveq #0,d2					*	moveq #0,%d2
_?L623:							*.L623:
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	addq.l #1,-12(a6)				*	addq.l #1,-12(%fp)
	move.b (a0)+,d3					*	move.b (%a0)+,%d3
	moveq #127,d1					*	moveq #127,%d1
	and.l d3,d1					*	and.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d4					*	or.l %d1,%d4
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d3					*	tst.b %d3
	jblt _?L623					*	jlt .L623
	move.b 169(a4),d0				*	move.b 169(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L625					*	jeq .L625
	pea -4(a6)					*	pea -4(%fp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	and.l #255,d0					*	and.l #255,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l -4(a6),112(a3)				*	move.l -4(%fp),112(%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
_?L625:							*.L625:
	add.l d4,-12(a6)				*	add.l %d4,-12(%fp)
_?L629:							*.L629:
	move.l (a5),d0					*	move.l (%a5),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a5					*	add.l %d0,%a5
	moveq #-2,d0					*	moveq #-2,%d0
	cmp.l 156(a4),d0				*	cmp.l 156(%a4),%d0
	jbne _?L627					*	jne .L627
	moveq #1,d1					*	moveq #1,%d1
	cmp.l 160(a4),d1				*	cmp.l 160(%a4),%d1
	jbeq _?L666					*	jeq .L666
_?L627:							*.L627:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	jbsr _execute_cfa_program_generic		*	jsr execute_cfa_program_generic
	lea (16,sp),sp					*	lea (16,%sp),%sp
	moveq #0,d0					*	moveq #0,%d0
_?L591:							*.L591:
	movem.l -40(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -40(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L659:							*.L659:
	cmp.b #104,10(a2)				*	cmp.b #104,10(%a2)
	jbne _?L595					*	jne .L595
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0),d0					*	move.b (%a0),%d0
	lsl.w #8,d0					*	lsl.w #8,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 1(a0),d1					*	move.b 1(%a0),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 2(a0),d0					*	move.b 2(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 3(a0),d0					*	or.b 3(%a0),%d0
	move.l d0,172(a4)				*	move.l %d0,172(%a4)
	addq.l #4,a0					*	addq.l #4,%a0
	move.w #11,a1					*	move.w #11,%a1
	add.l a2,a1					*	add.l %a2,%a1
	move.l -12(a6),a2				*	move.l -12(%fp),%a2
	move.b 8(a2),d2					*	move.b 8(%a2),%d2
	move.b (a0),d0					*	move.b (%a0),%d0
	cmp.b #3,d2					*	cmp.b #3,%d2
	jbls _?L596					*	jls .L596
	jbra _?L660					*	jra .L660
_?L661:							*.L661:
	move.b (a0),d5					*	move.b (%a0),%d5
	lea (2,a2),a0					*	lea (2,%a2),%a0
	move.l d5,164(a4)				*	move.l %d5,164(%a4)
	st 169(a4)					*	st 169(%a4)
	move.b (a1),d1					*	move.b (%a1),%d1
	moveq #0,d5					*	moveq #0,%d5
	cmp.b #122,d1					*	cmp.b #122,%d1
	jbne _?L604					*	jne .L604
_?L662:							*.L662:
	moveq #0,d1					*	moveq #0,%d1
_?L605:							*.L605:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L605					*	jlt .L605
	add.l a0,d5					*	add.l %a0,%d5
	move.b #1,170(a4)				*	move.b #1,170(%a4)
	move.l a1,d0					*	move.l %a1,%d0
	addq.l #1,d0					*	addq.l #1,%d0
	move.b 1(a1),d1					*	move.b 1(%a1),%d1
	jbeq _?L606					*	jeq .L606
	move.l d0,a1					*	move.l %d0,%a1
	addq.l #1,a1					*	addq.l #1,%a1
	move.l #_?L609,d6				*	move.l #.L609,%d6
	jbra _?L616					*	jra .L616
_?L610:							*.L610:
	move.b (a0)+,168(a4)				*	move.b (%a0)+,168(%a4)
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L616					*	jne .L616
	jbra _?L667					*	jra .L667
_?L611:							*.L611:
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	pea -4(a6)					*	pea -4(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a1,-8(a6)				*	move.l %a1,-8(%fp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a0					*	move.l %d0,%a0
	move.l -4(a6),152(a4)				*	move.l -4(%fp),152(%a4)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l -8(a6),a1				*	move.l -8(%fp),%a1
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L616					*	jne .L616
	jbra _?L667					*	jra .L667
_?L608:							*.L608:
	move.b #1,171(a4)				*	move.b #1,171(%a4)
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L616					*	jne .L616
	jbra _?L667					*	jra .L667
_?L594:							*.L594:
	moveq #5,d0					*	moveq #5,%d0
	movem.l -40(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -40(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L660:							*.L660:
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbeq _?L597					*	jeq .L597
_?L598:							*.L598:
	moveq #3,d0					*	moveq #3,%d0
	movem.l -40(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -40(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L635:							*.L635:
	moveq #16,d1					*	moveq #16,%d1
	add.l a5,d1					*	add.l %a5,%d1
	move.l d1,-12(a6)				*	move.l %d1,-12(%fp)
	tst.b 170(a4)					*	tst.b 170(%a4)
	jbne _?L668					*	jne .L668
_?L622:							*.L622:
	move.b 169(a4),d0				*	move.b 169(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L629					*	jeq .L629
	pea -4(a6)					*	pea -4(%fp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	and.l #255,d0					*	and.l #255,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,-12(a6)				*	move.l %d0,-12(%fp)
	move.l -4(a6),112(a3)				*	move.l -4(%fp),112(%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L629					*	jra .L629
_?L666:							*.L666:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	jbsr _execute_cfa_program_specialized		*	jsr execute_cfa_program_specialized
	lea (16,sp),sp					*	lea (16,%sp),%sp
	moveq #0,d0					*	moveq #0,%d0
	jbra _?L591					*	jra .L591
_?L664:							*.L664:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _execute_cfa_program_specialized		*	jsr execute_cfa_program_specialized
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L669					*	jne .L669
_?L632:							*.L632:
	moveq #8,d1					*	moveq #8,%d1
	jbra _?L619					*	jra .L619
_?L633:							*.L633:
	moveq #12,d1					*	moveq #12,%d1
	jbra _?L619					*	jra .L619
_?L665:							*.L665:
	moveq #16,d1					*	moveq #16,%d1
	tst.b d0					*	tst.b %d0
	jbeq _?L619					*	jeq .L619
_?L621:							*.L621:
	trap #7						*	trap #7
_?L597:							*.L597:
	tst.b 1(a0)					*	tst.b 1(%a0)
	jbne _?L598					*	jne .L598
	addq.l #2,a0					*	addq.l #2,%a0
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d0					*	moveq #0,%d0
	jbra _?L599					*	jra .L599
_?L663:							*.L663:
	move.l a0,d5					*	move.l %a0,%d5
	jbra _?L606					*	jra .L606
							*	.size	uw_frame_state_for, .-uw_frame_state_for
	.align	2					*	.align	2
							*	.type	uw_init_context_1, @function
_uw_init_context_1:					*uw_init_context_1:
	lea (-180,sp),sp				*	lea (-180,%sp),%sp
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 192(sp),a3				*	move.l 192(%sp),%a3
	move.l 188(sp),d3				*	move.l 188(%sp),%d3
	pea 166.w					*	pea 166.w
	clr.l -(sp)					*	clr.l -(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _memset					*	jsr memset
	move.l d3,108(a3)				*	move.l %d3,108(%a3)
	move.l #1073741824,128(a3)			*	move.l #1073741824,128(%a3)
	moveq #24,d3					*	moveq #24,%d3
	add.l sp,d3					*	add.l %sp,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _uw_frame_state_for			*	jsr uw_frame_state_for
	lea (20,sp),sp					*	lea (20,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L673					*	jne .L673
	tst.b _dwarf_reg_size_table.l			*	tst.b dwarf_reg_size_table.l
	jbeq _?L680					*	jeq .L680
_?L672:							*.L672:
	cmp.b #4,_dwarf_reg_size_table+15.l		*	cmp.b #4,dwarf_reg_size_table+15.l
	jbne _?L673					*	jne .L673
	move.l 196(sp),8(sp)				*	move.l 196(%sp),8(%sp)
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L674					*	jeq .L674
	clr.b 155(a3)					*	clr.b 155(%a3)
_?L674:							*.L674:
	moveq #8,d0					*	moveq #8,%d0
	add.l sp,d0					*	add.l %sp,%d0
	move.l d0,60(a3)				*	move.l %d0,60(%a3)
	move.b #1,142(sp)				*	move.b #1,142(%sp)
	moveq #15,d0					*	moveq #15,%d0
	move.l d0,152(sp)				*	move.l %d0,152(%sp)
	clr.l 148(sp)					*	clr.l 148(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _uw_update_context_1			*	jsr uw_update_context_1
	move.l 208(sp),108(a3)				*	move.l 208(%sp),108(%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	lea (180,sp),sp					*	lea (180,%sp),%sp
	rts						*	rts
_?L680:							*.L680:
	move.b #4,_dwarf_reg_size_table			*	move.b #4,dwarf_reg_size_table
	move.b #4,_dwarf_reg_size_table+1		*	move.b #4,dwarf_reg_size_table+1
	move.b #4,_dwarf_reg_size_table+2		*	move.b #4,dwarf_reg_size_table+2
	move.b #4,_dwarf_reg_size_table+3		*	move.b #4,dwarf_reg_size_table+3
	move.b #4,_dwarf_reg_size_table+4		*	move.b #4,dwarf_reg_size_table+4
	move.b #4,_dwarf_reg_size_table+5		*	move.b #4,dwarf_reg_size_table+5
	move.b #4,_dwarf_reg_size_table+6		*	move.b #4,dwarf_reg_size_table+6
	move.b #4,_dwarf_reg_size_table+7		*	move.b #4,dwarf_reg_size_table+7
	move.b #4,_dwarf_reg_size_table+8		*	move.b #4,dwarf_reg_size_table+8
	move.b #4,_dwarf_reg_size_table+9		*	move.b #4,dwarf_reg_size_table+9
	move.b #4,_dwarf_reg_size_table+10		*	move.b #4,dwarf_reg_size_table+10
	move.b #4,_dwarf_reg_size_table+11		*	move.b #4,dwarf_reg_size_table+11
	move.b #4,_dwarf_reg_size_table+12		*	move.b #4,dwarf_reg_size_table+12
	move.b #4,_dwarf_reg_size_table+13		*	move.b #4,dwarf_reg_size_table+13
	move.b #4,_dwarf_reg_size_table+14		*	move.b #4,dwarf_reg_size_table+14
	move.b #4,_dwarf_reg_size_table+15		*	move.b #4,dwarf_reg_size_table+15
	move.b #12,_dwarf_reg_size_table+16		*	move.b #12,dwarf_reg_size_table+16
	move.b #12,_dwarf_reg_size_table+17		*	move.b #12,dwarf_reg_size_table+17
	move.b #12,_dwarf_reg_size_table+18		*	move.b #12,dwarf_reg_size_table+18
	move.b #12,_dwarf_reg_size_table+19		*	move.b #12,dwarf_reg_size_table+19
	move.b #12,_dwarf_reg_size_table+20		*	move.b #12,dwarf_reg_size_table+20
	move.b #12,_dwarf_reg_size_table+21		*	move.b #12,dwarf_reg_size_table+21
	move.b #12,_dwarf_reg_size_table+22		*	move.b #12,dwarf_reg_size_table+22
	move.b #12,_dwarf_reg_size_table+23		*	move.b #12,dwarf_reg_size_table+23
	move.b #4,_dwarf_reg_size_table+24		*	move.b #4,dwarf_reg_size_table+24
	move.b #4,_dwarf_reg_size_table+25		*	move.b #4,dwarf_reg_size_table+25
	jbra _?L672					*	jra .L672
_?L673:							*.L673:
	trap #7						*	trap #7
							*	.size	uw_init_context_1, .-uw_init_context_1
	.align	2					*	.align	2
							*	.type	_Unwind_RaiseException_Phase2, @function
__Unwind_RaiseException_Phase2:				*_Unwind_RaiseException_Phase2:
	lea (-176,sp),sp				*	lea (-176,%sp),%sp
	movem.l d3/d4/d5/a3/a4/a5/a6,-(sp)		*	movem.l #7198,-(%sp)
	move.l 208(sp),a4				*	move.l 208(%sp),%a4
	move.l 212(sp),a3				*	move.l 212(%sp),%a3
	moveq #1,d3					*	moveq #1,%d3
	lea _uw_frame_state_for,a5			*	lea uw_frame_state_for,%a5
	lea _uw_update_context_1,a6			*	lea uw_update_context_1,%a6
	move.l #_dwarf_reg_size_table,d4		*	move.l #dwarf_reg_size_table,%d4
	pea 28(sp)					*	pea 28(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l 128(a3),d1				*	move.l 128(%a3),%d1
	add.l d1,d1					*	add.l %d1,%d1
	subx.l d1,d1					*	subx.l %d1,%d1
	neg.l d1					*	neg.l %d1
	move.l 104(a3),a0				*	move.l 104(%a3),%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.l 16(a4),a0					*	cmp.l 16(%a4),%a0
	jbeq _?L682					*	jeq .L682
_?L702:							*.L702:
	tst.l d0					*	tst.l %d0
	jbne _?L683					*	jne .L683
	move.l 180(sp),a0				*	move.l 180(%sp),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L685					*	jeq .L685
	moveq #2,d0					*	moveq #2,%d0
	moveq #0,d5					*	moveq #0,%d5
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L687					*	jeq .L687
_?L703:							*.L703:
	subq.l #8,d0					*	subq.l #8,%d0
	jbne _?L683					*	jne .L683
	tst.l d5					*	tst.l %d5
	jbne _?L686					*	jne .L686
_?L685:							*.L685:
	pea 28(sp)					*	pea 28(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a6)					*	jsr (%a6)
	move.l 200(sp),d0				*	move.l 200(%sp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	lea (132,sp),a0					*	lea (132,%sp),%a0
	cmp.b #7,(a0,d0.l)				*	cmp.b #7,(%a0,%d0.l)
	jbeq _?L696					*	jeq .L696
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L686					*	jlt .L686
	move.l d4,a0					*	move.l %d4,%a0
	move.b (a0,d0.l),d2				*	move.b (%a0,%d0.l),%d2
	move.l d0,d1					*	move.l %d0,%d1
	add.l d0,d1					*	add.l %d0,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l (a3,d1.l),a0				*	move.l (%a3,%d1.l),%a0
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L690					*	jeq .L690
	lea (a3,d0.l),a1				*	lea (%a3,%d0.l),%a1
	tst.b 140(a1)					*	tst.b 140(%a1)
	jbne _?L691					*	jne .L691
_?L690:							*.L690:
	cmp.b #4,d2					*	cmp.b #4,%d2
	jbne _?L686					*	jne .L686
	move.l (a0),a0					*	move.l (%a0),%a0
_?L691:							*.L691:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d3					*	addq.l #1,%d3
_?L704:							*.L704:
	pea 28(sp)					*	pea 28(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l 128(a3),d1				*	move.l 128(%a3),%d1
	add.l d1,d1					*	add.l %d1,%d1
	subx.l d1,d1					*	subx.l %d1,%d1
	neg.l d1					*	neg.l %d1
	move.l 104(a3),a0				*	move.l 104(%a3),%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.l 16(a4),a0					*	cmp.l 16(%a4),%a0
	jbne _?L702					*	jne .L702
_?L682:							*.L682:
	tst.l d0					*	tst.l %d0
	jbne _?L683					*	jne .L683
	move.l 180(sp),a0				*	move.l 180(%sp),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L686					*	jeq .L686
	moveq #6,d0					*	moveq #6,%d0
	moveq #4,d5					*	moveq #4,%d5
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L703					*	jne .L703
_?L687:							*.L687:
	move.l 216(sp),a0				*	move.l 216(%sp),%a0
	move.l d3,(a0)					*	move.l %d3,(%a0)
	movem.l (sp)+,d3/d4/d5/a3/a4/a5/a6		*	movem.l (%sp)+,#30776
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L696:							*.L696:
	moveq #0,d0					*	moveq #0,%d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d3					*	addq.l #1,%d3
	jbra _?L704					*	jra .L704
_?L683:							*.L683:
	moveq #2,d0					*	moveq #2,%d0
	movem.l (sp)+,d3/d4/d5/a3/a4/a5/a6		*	movem.l (%sp)+,#30776
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L686:							*.L686:
	trap #7						*	trap #7
							*	.size	_Unwind_RaiseException_Phase2, .-_Unwind_RaiseException_Phase2
	.align	2					*	.align	2
							*	.type	_Unwind_ForcedUnwind_Phase2, @function
__Unwind_ForcedUnwind_Phase2:				*_Unwind_ForcedUnwind_Phase2:
	lea (-176,sp),sp				*	lea (-176,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 216(sp),a4				*	move.l 216(%sp),%a4
	move.l 220(sp),a3				*	move.l 220(%sp),%a3
	move.l 12(a4),a6				*	move.l 12(%a4),%a6
	move.l 16(a4),d5				*	move.l 16(%a4),%d5
	moveq #1,d4					*	moveq #1,%d4
	lea _uw_frame_state_for,a5			*	lea uw_frame_state_for,%a5
	move.l #_uw_update_context_1,d6			*	move.l #uw_update_context_1,%d6
	move.l #_dwarf_reg_size_table,d7		*	move.l #dwarf_reg_size_table,%d7
	pea 36(sp)					*	pea 36(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #4,d0					*	moveq #4,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbeq _?L706					*	jeq .L706
_?L736:							*.L736:
	moveq #5,d1					*	moveq #5,%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbeq _?L707					*	jeq .L707
	tst.l d3					*	tst.l %d3
	jbne _?L708					*	jne .L708
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 10.w					*	pea 10.w
	pea 1.w						*	pea 1.w
	jbsr (a6)					*	jsr (%a6)
	lea (28,sp),sp					*	lea (28,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L708					*	jne .L708
_?L709:							*.L709:
	move.l 188(sp),a0				*	move.l 188(%sp),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L715					*	jeq .L715
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 10.w					*	pea 10.w
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	move.l d0,d3					*	move.l %d0,%d3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d0					*	moveq #7,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbeq _?L713					*	jeq .L713
	subq.l #8,d3					*	subq.l #8,%d3
	jbne _?L708					*	jne .L708
_?L715:							*.L715:
	pea 36(sp)					*	pea 36(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	move.l 208(sp),d0				*	move.l 208(%sp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	lea (140,sp),a0					*	lea (140,%sp),%a0
	cmp.b #7,(a0,d0.l)				*	cmp.b #7,(%a0,%d0.l)
	jbne _?L735					*	jne .L735
	moveq #0,d0					*	moveq #0,%d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d4					*	addq.l #1,%d4
_?L737:							*.L737:
	pea 36(sp)					*	pea 36(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #4,d0					*	moveq #4,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbne _?L736					*	jne .L736
_?L706:							*.L706:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 26.w					*	pea 26.w
	pea 1.w						*	pea 1.w
	jbsr (a6)					*	jsr (%a6)
	lea (28,sp),sp					*	lea (28,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L709					*	jeq .L709
_?L708:							*.L708:
	moveq #2,d3					*	moveq #2,%d3
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L735:							*.L735:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L719					*	jlt .L719
	move.l d7,a0					*	move.l %d7,%a0
	move.b (a0,d0.l),d2				*	move.b (%a0,%d0.l),%d2
	move.l d0,d1					*	move.l %d0,%d1
	add.l d0,d1					*	add.l %d0,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l (a3,d1.l),a0				*	move.l (%a3,%d1.l),%a0
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L717					*	jeq .L717
	lea (a3,d0.l),a1				*	lea (%a3,%d0.l),%a1
	tst.b 140(a1)					*	tst.b 140(%a1)
	jbne _?L718					*	jne .L718
_?L717:							*.L717:
	cmp.b #4,d2					*	cmp.b #4,%d2
	jbne _?L719					*	jne .L719
	move.l (a0),a0					*	move.l (%a0),%a0
_?L718:							*.L718:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d4					*	addq.l #1,%d4
	jbra _?L737					*	jra .L737
_?L707:							*.L707:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 26.w					*	pea 26.w
	pea 1.w						*	pea 1.w
	jbsr (a6)					*	jsr (%a6)
	lea (28,sp),sp					*	lea (28,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L708					*	jne .L708
_?L713:							*.L713:
	move.l 224(sp),a0				*	move.l 224(%sp),%a0
	move.l d4,(a0)					*	move.l %d4,(%a0)
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L719:							*.L719:
	trap #7						*	trap #7
							*	.size	_Unwind_ForcedUnwind_Phase2, .-_Unwind_ForcedUnwind_Phase2
	.align	2					*	.align	2
	.globl	__Unwind_GetGR				*	.globl	_Unwind_GetGR
							*	.hidden	_Unwind_GetGR
							*	.type	_Unwind_GetGR, @function
__Unwind_GetGR:						*_Unwind_GetGR:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jblt _?L742					*	jlt .L742
	move.l d1,d0					*	move.l %d1,%d0
	add.l d1,d0					*	add.l %d1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a0,d0.l),a1				*	move.l (%a0,%d0.l),%a1
	btst #6,128(a0)					*	btst #6,128(%a0)
	jbeq _?L740					*	jeq .L740
	add.l d1,a0					*	add.l %d1,%a0
	tst.b 140(a0)					*	tst.b 140(%a0)
	jbne _?L748					*	jne .L748
_?L740:							*.L740:
	lea _dwarf_reg_size_table,a0			*	lea dwarf_reg_size_table,%a0
	cmp.b #4,(a0,d1.l)				*	cmp.b #4,(%a0,%d1.l)
	jbne _?L742					*	jne .L742
	move.l (a1),d0					*	move.l (%a1),%d0
	rts						*	rts
_?L748:							*.L748:
	move.l a1,d0					*	move.l %a1,%d0
	rts						*	rts
_?L742:							*.L742:
	trap #7						*	trap #7
							*	.size	_Unwind_GetGR, .-_Unwind_GetGR
	.align	2					*	.align	2
	.globl	__Unwind_GetCFA				*	.globl	_Unwind_GetCFA
							*	.hidden	_Unwind_GetCFA
							*	.type	_Unwind_GetCFA, @function
__Unwind_GetCFA:					*_Unwind_GetCFA:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 104(a0),d0				*	move.l 104(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetCFA, .-_Unwind_GetCFA
	.align	2					*	.align	2
	.globl	__Unwind_SetGR				*	.globl	_Unwind_SetGR
							*	.hidden	_Unwind_SetGR
							*	.type	_Unwind_SetGR, @function
__Unwind_SetGR:						*_Unwind_SetGR:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L755					*	jlt .L755
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.b (a1,d0.l),d1				*	move.b (%a1,%d0.l),%d1
	btst #6,128(a0)					*	btst #6,128(%a0)
	jbeq _?L753					*	jeq .L753
	lea (a0,d0.l),a1				*	lea (%a0,%d0.l),%a1
	tst.b 140(a1)					*	tst.b 140(%a1)
	jbne _?L761					*	jne .L761
_?L753:							*.L753:
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a0,d0.l),a0				*	move.l (%a0,%d0.l),%a0
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L755					*	jne .L755
	move.l 12(sp),(a0)				*	move.l 12(%sp),(%a0)
	rts						*	rts
_?L761:							*.L761:
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l 12(sp),(a0,d0.l)				*	move.l 12(%sp),(%a0,%d0.l)
	rts						*	rts
_?L755:							*.L755:
	trap #7						*	trap #7
							*	.size	_Unwind_SetGR, .-_Unwind_SetGR
	.align	2					*	.align	2
	.globl	__Unwind_GetIP				*	.globl	_Unwind_GetIP
							*	.hidden	_Unwind_GetIP
							*	.type	_Unwind_GetIP, @function
__Unwind_GetIP:						*_Unwind_GetIP:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 108(a0),d0				*	move.l 108(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetIP, .-_Unwind_GetIP
	.align	2					*	.align	2
	.globl	__Unwind_GetIPInfo			*	.globl	_Unwind_GetIPInfo
							*	.hidden	_Unwind_GetIPInfo
							*	.type	_Unwind_GetIPInfo, @function
__Unwind_GetIPInfo:					*_Unwind_GetIPInfo:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 128(a0),d0				*	move.l 128(%a0),%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	move.l 8(sp),a1					*	move.l 8(%sp),%a1
	move.l d0,(a1)					*	move.l %d0,(%a1)
	move.l 108(a0),d0				*	move.l 108(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetIPInfo, .-_Unwind_GetIPInfo
	.align	2					*	.align	2
	.globl	__Unwind_SetIP				*	.globl	_Unwind_SetIP
							*	.hidden	_Unwind_SetIP
							*	.type	_Unwind_SetIP, @function
__Unwind_SetIP:						*_Unwind_SetIP:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),108(a0)				*	move.l 8(%sp),108(%a0)
	rts						*	rts
							*	.size	_Unwind_SetIP, .-_Unwind_SetIP
	.align	2					*	.align	2
	.globl	__Unwind_GetLanguageSpecificData	*	.globl	_Unwind_GetLanguageSpecificData
							*	.hidden	_Unwind_GetLanguageSpecificData
							*	.type	_Unwind_GetLanguageSpecificData, @function
__Unwind_GetLanguageSpecificData:			*_Unwind_GetLanguageSpecificData:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 112(a0),d0				*	move.l 112(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetLanguageSpecificData, .-_Unwind_GetLanguageSpecificData
	.align	2					*	.align	2
	.globl	__Unwind_GetRegionStart			*	.globl	_Unwind_GetRegionStart
							*	.hidden	_Unwind_GetRegionStart
							*	.type	_Unwind_GetRegionStart, @function
__Unwind_GetRegionStart:				*_Unwind_GetRegionStart:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 124(a0),d0				*	move.l 124(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetRegionStart, .-_Unwind_GetRegionStart
	.align	2					*	.align	2
	.globl	__Unwind_FindEnclosingFunction		*	.globl	_Unwind_FindEnclosingFunction
							*	.hidden	_Unwind_FindEnclosingFunction
							*	.type	_Unwind_FindEnclosingFunction, @function
__Unwind_FindEnclosingFunction:				*_Unwind_FindEnclosingFunction:
	link.w a6,#-12					*	link.w %fp,#-12
	pea -12(a6)					*	pea -12(%fp)
	move.l 8(a6),d0					*	move.l 8(%fp),%d0
	subq.l #1,d0					*	subq.l #1,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr __Unwind_Find_FDE				*	jsr _Unwind_Find_FDE
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L772					*	jeq .L772
	move.l -4(a6),d0				*	move.l -4(%fp),%d0
_?L772:							*.L772:
	unlk a6						*	unlk %fp
	rts						*	rts
							*	.size	_Unwind_FindEnclosingFunction, .-_Unwind_FindEnclosingFunction
	.align	2					*	.align	2
	.globl	__Unwind_GetDataRelBase			*	.globl	_Unwind_GetDataRelBase
							*	.hidden	_Unwind_GetDataRelBase
							*	.type	_Unwind_GetDataRelBase, @function
__Unwind_GetDataRelBase:				*_Unwind_GetDataRelBase:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 120(a0),d0				*	move.l 120(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetDataRelBase, .-_Unwind_GetDataRelBase
	.align	2					*	.align	2
	.globl	__Unwind_GetTextRelBase			*	.globl	_Unwind_GetTextRelBase
							*	.hidden	_Unwind_GetTextRelBase
							*	.type	_Unwind_GetTextRelBase, @function
__Unwind_GetTextRelBase:				*_Unwind_GetTextRelBase:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 116(a0),d0				*	move.l 116(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetTextRelBase, .-_Unwind_GetTextRelBase
	.align	2					*	.align	2
	.globl	___frame_state_for			*	.globl	__frame_state_for
							*	.hidden	__frame_state_for
							*	.type	__frame_state_for, @function
___frame_state_for:					*__frame_state_for:
	lea (-344,sp),sp				*	lea (-344,%sp),%sp
	movem.l d3/a3/a4/a5,-(sp)			*	movem.l #4124,-(%sp)
	move.l 368(sp),a5				*	move.l 368(%sp),%a5
	lea (18,sp),a3					*	lea (18,%sp),%a3
	pea 166.w					*	pea 166.w
	clr.l -(sp)					*	clr.l -(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _memset					*	jsr memset
	move.l #1073741824,158(sp)			*	move.l #1073741824,158(%sp)
	move.l 376(sp),d0				*	move.l 376(%sp),%d0
	addq.l #1,d0					*	addq.l #1,%d0
	move.l d0,138(sp)				*	move.l %d0,138(%sp)
	move.l sp,d3					*	move.l %sp,%d3
	add.l #196,d3					*	add.l #196,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _uw_frame_state_for			*	jsr uw_frame_state_for
	lea (20,sp),sp					*	lea (20,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L789					*	jne .L789
	cmp.b #2,314(sp)				*	cmp.b #2,314(%sp)
	jbeq _?L789					*	jeq .L789
	lea (288,sp),a0					*	lea (288,%sp),%a0
	lea (124,a5),a3					*	lea (124,%a5),%a3
	lea (16,a5),a2					*	lea (16,%a5),%a2
	move.l d3,a1					*	move.l %d3,%a1
	lea (314,sp),a4					*	lea (314,%sp),%a4
_?L787:							*.L787:
	move.b (a0)+,d1					*	move.b (%a0)+,%d1
	move.b d1,(a3)+					*	move.b %d1,(%a3)+
	cmp.b #1,d1					*	cmp.b #1,%d1
	jbeq _?L785					*	jeq .L785
	cmp.b #2,d1					*	cmp.b #2,%d1
	jbeq _?L785					*	jeq .L785
	moveq #0,d1					*	moveq #0,%d1
	move.l d1,(a2)+					*	move.l %d1,(%a2)+
	addq.l #4,a1					*	addq.l #4,%a1
	cmp.l a0,a4					*	cmp.l %a0,%a4
	jbne _?L787					*	jne .L787
_?L794:							*.L794:
	move.l 320(sp),8(a5)				*	move.l 320(%sp),8(%a5)
	move.w 326(sp),120(a5)				*	move.w 326(%sp),120(%a5)
	move.w 350(sp),122(a5)				*	move.w 350(%sp),122(%a5)
	move.l 154(sp),12(a5)				*	move.l 154(%sp),12(%a5)
	move.l 356(sp),4(a5)				*	move.l 356(%sp),4(%a5)
	move.l a5,d0					*	move.l %a5,%d0
	movem.l (sp)+,d3/a3/a4/a5			*	movem.l (%sp)+,#14344
	lea (344,sp),sp					*	lea (344,%sp),%sp
	rts						*	rts
_?L785:							*.L785:
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l d1,(a2)+					*	move.l %d1,(%a2)+
	addq.l #4,a1					*	addq.l #4,%a1
	cmp.l a0,a4					*	cmp.l %a0,%a4
	jbne _?L787					*	jne .L787
	jbra _?L794					*	jra .L794
_?L789:							*.L789:
	moveq #0,d0					*	moveq #0,%d0
	movem.l (sp)+,d3/a3/a4/a5			*	movem.l (%sp)+,#14344
	lea (344,sp),sp					*	lea (344,%sp),%sp
	rts						*	rts
							*	.size	__frame_state_for, .-__frame_state_for
	.align	2					*	.align	2
							*	.type	_Unwind_DebugHook, @function
__Unwind_DebugHook:					*_Unwind_DebugHook:
	rts						*	rts
							*	.size	_Unwind_DebugHook, .-_Unwind_DebugHook
	.align	2					*	.align	2
	.globl	__Unwind_RaiseException			*	.globl	_Unwind_RaiseException
							*	.hidden	_Unwind_RaiseException
							*	.type	_Unwind_RaiseException, @function
__Unwind_RaiseException:				*_Unwind_RaiseException:
	link.w a6,#-508					*	link.w %fp,#-508
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d5					*	move.l %fp,%d5
	add.l #-508,d5					*	add.l #-508,%d5
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-342,d3					*	add.l #-342,%d3
	pea 166.w					*	pea 166.w
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l #_memcpy,d6				*	move.l #memcpy,%d6
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-176,d4					*	add.l #-176,%d4
	lea _uw_frame_state_for,a4			*	lea uw_frame_state_for,%a4
	lea _uw_update_context_1,a5			*	lea uw_update_context_1,%a5
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #5,d1					*	moveq #5,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L797					*	jeq .L797
_?L825:							*.L825:
	tst.l d0					*	tst.l %d0
	jbne _?L804					*	jne .L804
	move.l -24(a6),a0				*	move.l -24(%fp),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L805					*	jeq .L805
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 4(a3),-(sp)				*	move.l 4(%a3),-(%sp)
	move.l (a3),-(sp)				*	move.l (%a3),-(%sp)
	pea 1.w						*	pea 1.w
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #6,d1					*	moveq #6,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L803					*	jeq .L803
	subq.l #8,d0					*	subq.l #8,%d0
	jbne _?L804					*	jne .L804
_?L805:							*.L805:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -12(a6),d0				*	move.l -12(%fp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #7,-72(a6,d0.l)				*	cmp.b #7,-72(%fp,%d0.l)
	jbne _?L824					*	jne .L824
	moveq #0,d0					*	moveq #0,%d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
_?L826:							*.L826:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #5,d1					*	moveq #5,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L825					*	jne .L825
_?L797:							*.L797:
	sub.l a0,a0					*	sub.l %a0,%a0
_?L813:							*.L813:
	movem.l -548(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -548(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L824:							*.L824:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L809					*	jlt .L809
	lea _dwarf_reg_size_table,a0			*	lea dwarf_reg_size_table,%a0
	move.b (a0,d0.l),d2				*	move.b (%a0,%d0.l),%d2
	move.l d0,d1					*	move.l %d0,%d1
	add.l d0,d1					*	add.l %d0,%d1
	add.l d1,d1					*	add.l %d1,%d1
	lea (a6,d1.l),a0				*	lea (%fp,%d1.l),%a0
	move.l -342(a0),a1				*	move.l -342(%a0),%a1
	btst #6,-214(a6)				*	btst #6,-214(%fp)
	jbeq _?L807					*	jeq .L807
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	tst.b -202(a0)					*	tst.b -202(%a0)
	jbne _?L808					*	jne .L808
_?L807:							*.L807:
	cmp.b #4,d2					*	cmp.b #4,%d2
	jbne _?L809					*	jne .L809
	move.l (a1),a1					*	move.l (%a1),%a1
_?L808:							*.L808:
	move.l a1,d0					*	move.l %a1,%d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
	jbra _?L826					*	jra .L826
_?L804:							*.L804:
	moveq #3,d0					*	moveq #3,%d0
	sub.l a0,a0					*	sub.l %a0,%a0
	jbra _?L813					*	jra .L813
_?L803:							*.L803:
	clr.l 12(a3)					*	clr.l 12(%a3)
	move.l -214(a6),d0				*	move.l -214(%fp),%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	move.l -238(a6),d1				*	move.l -238(%fp),%d1
	sub.l d0,d1					*	sub.l %d0,%d1
	move.l d1,16(a3)				*	move.l %d1,16(%a3)
	pea 166.w					*	pea 166.w
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_RaiseException_Phase2		*	jsr _Unwind_RaiseException_Phase2
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L797					*	jne .L797
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,d3					*	move.l %d0,%d3
	move.l -234(a6),d4				*	move.l -234(%fp),%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l -238(a6),-(sp)				*	move.l -238(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d3,a0					*	move.l %d3,%a0
	move.l d4,4(a6,d3.l)				*	move.l %d4,4(%fp,%d3.l)
	movem.l -548(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -548(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L809:							*.L809:
	trap #7						*	trap #7
							*	.size	_Unwind_RaiseException, .-_Unwind_RaiseException
	.align	2					*	.align	2
	.globl	__Unwind_ForcedUnwind			*	.globl	_Unwind_ForcedUnwind
							*	.hidden	_Unwind_ForcedUnwind
							*	.type	_Unwind_ForcedUnwind, @function
__Unwind_ForcedUnwind:					*_Unwind_ForcedUnwind:
	link.w a6,#-336					*	link.w %fp,#-336
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-332,d3					*	add.l #-332,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-166,d4					*	add.l #-166,%d4
	pea 166.w					*	pea 166.w
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l 12(a6),12(a3)				*	move.l 12(%fp),12(%a3)
	move.l 16(a6),16(a3)				*	move.l 16(%fp),16(%a3)
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_ForcedUnwind_Phase2		*	jsr _Unwind_ForcedUnwind_Phase2
	lea (36,sp),sp					*	lea (36,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	sub.l a0,a0					*	sub.l %a0,%a0
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L834					*	jeq .L834
	movem.l -376(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -376(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L834:							*.L834:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,d3					*	move.l %d0,%d3
	move.l -58(a6),d4				*	move.l -58(%fp),%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l -62(a6),-(sp)				*	move.l -62(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d3,a0					*	move.l %d3,%a0
	move.l d4,4(a6,d3.l)				*	move.l %d4,4(%fp,%d3.l)
	movem.l -376(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -376(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
							*	.size	_Unwind_ForcedUnwind, .-_Unwind_ForcedUnwind
	.align	2					*	.align	2
	.globl	__Unwind_Resume				*	.globl	_Unwind_Resume
							*	.hidden	_Unwind_Resume
							*	.type	_Unwind_Resume, @function
__Unwind_Resume:					*_Unwind_Resume:
	link.w a6,#-336					*	link.w %fp,#-336
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-332,d3					*	add.l #-332,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-166,d4					*	add.l #-166,%d4
	pea 166.w					*	pea 166.w
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	lea (24,sp),sp					*	lea (24,%sp),%sp
	tst.l 12(a3)					*	tst.l 12(%a3)
	jbne _?L836					*	jne .L836
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_RaiseException_Phase2		*	jsr _Unwind_RaiseException_Phase2
	lea (12,sp),sp					*	lea (12,%sp),%sp
_?L837:							*.L837:
	subq.l #7,d0					*	subq.l #7,%d0
	jbne _?L843					*	jne .L843
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,d3					*	move.l %d0,%d3
	move.l -58(a6),d4				*	move.l -58(%fp),%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l -62(a6),-(sp)				*	move.l -62(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d3,a0					*	move.l %d3,%a0
	move.l d4,4(a6,d3.l)				*	move.l %d4,4(%fp,%d3.l)
	movem.l -376(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -376(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L836:							*.L836:
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_ForcedUnwind_Phase2		*	jsr _Unwind_ForcedUnwind_Phase2
	lea (12,sp),sp					*	lea (12,%sp),%sp
	jbra _?L837					*	jra .L837
_?L843:							*.L843:
	trap #7						*	trap #7
							*	.size	_Unwind_Resume, .-_Unwind_Resume
	.align	2					*	.align	2
	.globl	__Unwind_Resume_or_Rethrow		*	.globl	_Unwind_Resume_or_Rethrow
							*	.hidden	_Unwind_Resume_or_Rethrow
							*	.type	_Unwind_Resume_or_Rethrow, @function
__Unwind_Resume_or_Rethrow:				*_Unwind_Resume_or_Rethrow:
	link.w a6,#-336					*	link.w %fp,#-336
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	tst.l 12(a3)					*	tst.l 12(%a3)
	jbne _?L845					*	jne .L845
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_RaiseException			*	jsr _Unwind_RaiseException
	addq.l #4,sp					*	addq.l #4,%sp
	sub.l a0,a0					*	sub.l %a0,%a0
	movem.l -376(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -376(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L845:							*.L845:
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-332,d3					*	add.l #-332,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-166,d4					*	add.l #-166,%d4
	pea 166.w					*	pea 166.w
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_ForcedUnwind_Phase2		*	jsr _Unwind_ForcedUnwind_Phase2
	lea (36,sp),sp					*	lea (36,%sp),%sp
	subq.l #7,d0					*	subq.l #7,%d0
	jbne _?L851					*	jne .L851
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,a3					*	move.l %d0,%a3
	move.l -58(a6),d3				*	move.l -58(%fp),%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l -62(a6),-(sp)				*	move.l -62(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l a3,a0					*	move.l %a3,%a0
	move.l d3,4(a6,a3.l)				*	move.l %d3,4(%fp,%a3.l)
	movem.l -376(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -376(%fp),#14587
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L851:							*.L851:
	trap #7						*	trap #7
							*	.size	_Unwind_Resume_or_Rethrow, .-_Unwind_Resume_or_Rethrow
	.align	2					*	.align	2
	.globl	__Unwind_DeleteException		*	.globl	_Unwind_DeleteException
							*	.hidden	_Unwind_DeleteException
							*	.type	_Unwind_DeleteException, @function
__Unwind_DeleteException:				*_Unwind_DeleteException:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(a1),a0					*	move.l 8(%a1),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L852					*	jeq .L852
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
_?L852:							*.L852:
	rts						*	rts
							*	.size	_Unwind_DeleteException, .-_Unwind_DeleteException
	.align	2					*	.align	2
	.globl	__Unwind_Backtrace			*	.globl	_Unwind_Backtrace
							*	.hidden	_Unwind_Backtrace
							*	.type	_Unwind_Backtrace, @function
__Unwind_Backtrace:					*_Unwind_Backtrace:
	link.w a6,#-344					*	link.w %fp,#-344
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a4					*	move.l 8(%fp),%a4
	move.l 12(a6),d6				*	move.l 12(%fp),%d6
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-342,d4					*	add.l #-342,%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a6,d5					*	move.l %fp,%d5
	add.l #-176,d5					*	add.l #-176,%d5
	lea _uw_frame_state_for,a3			*	lea uw_frame_state_for,%a3
	lea _uw_update_context_1,a5			*	lea uw_update_context_1,%a5
_?L868:							*.L868:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #8,sp					*	addq.l #8,%sp
	jbeq _?L860					*	jeq .L860
	moveq #5,d0					*	moveq #5,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbeq _?L861					*	jeq .L861
	subq.l #4,d3					*	subq.l #4,%d3
	jbne _?L862					*	jne .L862
_?L860:							*.L860:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbne _?L862					*	jne .L862
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -12(a6),d0				*	move.l -12(%fp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #7,-72(a6,d0.l)				*	cmp.b #7,-72(%fp,%d0.l)
	jbeq _?L871					*	jeq .L871
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L867					*	jlt .L867
	lea _dwarf_reg_size_table,a0			*	lea dwarf_reg_size_table,%a0
	move.b (a0,d0.l),d2				*	move.b (%a0,%d0.l),%d2
	move.l d0,d1					*	move.l %d0,%d1
	add.l d0,d1					*	add.l %d0,%d1
	add.l d1,d1					*	add.l %d1,%d1
	lea (a6,d1.l),a0				*	lea (%fp,%d1.l),%a0
	move.l -342(a0),a1				*	move.l -342(%a0),%a1
	btst #6,-214(a6)				*	btst #6,-214(%fp)
	jbeq _?L865					*	jeq .L865
	lea (a6,d0.l),a0				*	lea (%fp,%d0.l),%a0
	tst.b -202(a0)					*	tst.b -202(%a0)
	jbne _?L866					*	jne .L866
_?L865:							*.L865:
	cmp.b #4,d2					*	cmp.b #4,%d2
	jbne _?L867					*	jne .L867
	move.l (a1),a1					*	move.l (%a1),%a1
_?L866:							*.L866:
	move.l a1,d0					*	move.l %a1,%d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
	jbra _?L868					*	jra .L868
_?L861:							*.L861:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L859					*	jeq .L859
_?L862:							*.L862:
	moveq #3,d3					*	moveq #3,%d3
_?L859:							*.L859:
	move.l d3,d0					*	move.l %d3,%d0
	movem.l -376(a6),d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -376(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L871:							*.L871:
	moveq #0,d0					*	moveq #0,%d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
	jbra _?L868					*	jra .L868
_?L867:							*.L867:
	trap #7						*	trap #7
							*	.size	_Unwind_Backtrace, .-_Unwind_Backtrace
							*	.local	dwarf_reg_size_table
	.comm	_dwarf_reg_size_table,26		*	.comm	dwarf_reg_size_table,26,1
							*	.ident	"GCC: (GNU) 13.4.0"
