* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___floatsidf				*	.globl	__floatsidf
	.globl	___muldf3				*	.globl	__muldf3
	.globl	___floatunsidf				*	.globl	__floatunsidf
	.globl	___adddf3				*	.globl	__adddf3
	.align	2					*	.align	2
	.globl	___floatdidf				*	.globl	__floatdidf
							*	.hidden	__floatdidf
							*	.type	__floatdidf, @function
___floatdidf:						*__floatdidf:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	jbsr ___floatsidf				*	jsr __floatsidf
	clr.l (sp)					*	clr.l (%sp)
	move.l #1106247680,-(sp)			*	move.l #1106247680,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldf3					*	jsr __muldf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l 16(sp),-(sp)				*	move.l 16(%sp),-(%sp)
	jbsr ___floatunsidf				*	jsr __floatunsidf
	move.l d5,(sp)					*	move.l %d5,(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___adddf3					*	jsr __adddf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	move.l (sp)+,d5					*	move.l (%sp)+,%d5
	rts						*	rts
							*	.size	__floatdidf, .-__floatdidf
							*	.ident	"GCC: (GNU) 13.4.0"
