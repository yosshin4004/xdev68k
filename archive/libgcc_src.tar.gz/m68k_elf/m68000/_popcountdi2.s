* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___popcountdi2				*	.globl	__popcountdi2
							*	.hidden	__popcountdi2
							*	.type	__popcountdi2, @function
___popcountdi2:						*__popcountdi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l d1,d2					*	move.l %d1,%d2
	lsr.l #1,d2					*	lsr.l #1,%d2
	and.l #1431655765,d2				*	and.l #1431655765,%d2
	sub.l d2,d1					*	sub.l %d2,%d1
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l #1,d2					*	lsr.l #1,%d2
	and.l #1431655765,d2				*	and.l #1431655765,%d2
	sub.l d2,d0					*	sub.l %d2,%d0
	move.l d1,d2					*	move.l %d1,%d2
	and.l #858993459,d2				*	and.l #858993459,%d2
	lsr.l #2,d1					*	lsr.l #2,%d1
	and.l #858993459,d1				*	and.l #858993459,%d1
	add.l d2,d1					*	add.l %d2,%d1
	move.l d0,d2					*	move.l %d0,%d2
	and.l #858993459,d2				*	and.l #858993459,%d2
	lsr.l #2,d0					*	lsr.l #2,%d0
	and.l #858993459,d0				*	and.l #858993459,%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d1,d0					*	move.l %d1,%d0
	lsr.l #4,d0					*	lsr.l #4,%d0
	add.l d1,d0					*	add.l %d1,%d0
	and.l #252645135,d0				*	and.l #252645135,%d0
	move.l d2,d1					*	move.l %d2,%d1
	lsr.l #4,d1					*	lsr.l #4,%d1
	add.l d2,d1					*	add.l %d2,%d1
	and.l #252645135,d1				*	and.l #252645135,%d1
	add.l d0,d1					*	add.l %d0,%d1
	move.l d1,d0					*	move.l %d1,%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	add.l d1,d0					*	add.l %d1,%d0
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	add.l d1,d0					*	add.l %d1,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	lsr.w #8,d0					*	lsr.w #8,%d0
	rts						*	rts
							*	.size	__popcountdi2, .-__popcountdi2
							*	.ident	"GCC: (GNU) 13.4.0"
