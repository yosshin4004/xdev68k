* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clzsi2				*	.globl	__clzsi2
							*	.hidden	__clzsi2
							*	.type	__clzsi2, @function
___clzsi2:						*__clzsi2:
	move.l 4(sp),d2					*	move.l 4(%sp),%d2
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbhi _?L2					*	jhi .L2
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d1						*	shi %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	moveq #32,d0					*	moveq #32,%d0
	sub.l d1,d0					*	sub.l %d1,%d0
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d1					*	moveq #0,%d1
	move.b (a0,d2.l),d1				*	move.b (%a0,%d2.l),%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
_?L2:							*.L2:
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L4					*	jhi .L4
	moveq #16,d0					*	moveq #16,%d0
	moveq #16,d1					*	moveq #16,%d1
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d1					*	moveq #0,%d1
	move.b (a0,d2.l),d1				*	move.b (%a0,%d2.l),%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
_?L4:							*.L4:
	moveq #8,d0					*	moveq #8,%d0
	moveq #24,d1					*	moveq #24,%d1
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d1					*	moveq #0,%d1
	move.b (a0,d2.l),d1				*	move.b (%a0,%d2.l),%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
							*	.size	__clzsi2, .-__clzsi2
							*	.ident	"GCC: (GNU) 13.4.0"
