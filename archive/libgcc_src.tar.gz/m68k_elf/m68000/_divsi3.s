* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 540 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 .text							* .text
							* .type __divsi3,function
 .globl ___divsi3					* .globl __divsi3
 .globl ___divsi3_internal				* .globl __divsi3_internal
							* .hidden __divsi3_internal
___divsi3:						*__divsi3:
___divsi3_internal:					*__divsi3_internal:
 move.l d2,-(sp)					* movel %d2, %sp@-
							*
 moveq #1,d2						* moveq #1, %d2
 move.l 12(sp),d1					* movel %sp@(12), %d1
 jbpl _L1						* jpl L1
 neg.l d1						* negl %d1
							*
 neg.b d2						* negb %d2
							*
							*
							*
_L1: move.l 8(sp),d0					*L1: movel %sp@(8), %d0
 jbpl _L2						* jpl L2
 neg.l d0						* negl %d0
							*
 neg.b d2						* negb %d2
							*
							*
							*
							*
_L2: move.l d1,-(sp)					*L2: movel %d1, %sp@-
 move.l d0,-(sp)					* movel %d0, %sp@-
 PICCALL ___udivsi3_internal				* PICCALL __udivsi3_internal
 addq.l #8,sp						* addql #8, %sp
							*
 tst.b d2						* tstb %d2
 jbpl _L3						* jpl L3
 neg.l d0						* negl %d0
							*
_L3: move.l (sp)+,d2					*L3: movel %sp@+, %d2
 rts							* rts
							*# 3930 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
