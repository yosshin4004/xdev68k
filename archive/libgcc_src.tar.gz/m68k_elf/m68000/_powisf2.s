* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___mulsf3				*	.globl	__mulsf3
	.globl	___divsf3				*	.globl	__divsf3
	.align	2					*	.align	2
	.globl	___powisf2				*	.globl	__powisf2
							*	.hidden	__powisf2
							*	.type	__powisf2, @function
___powisf2:						*__powisf2:
	movem.l d3/d4/d5/d6/a3,-(sp)			*	movem.l #7696,-(%sp)
	move.l 24(sp),d3				*	move.l 24(%sp),%d3
	move.l 28(sp),d6				*	move.l 28(%sp),%d6
	move.l d6,d4					*	move.l %d6,%d4
	jbmi _?L18					*	jmi .L18
_?L2:							*.L2:
	btst #0,d4					*	btst #0,%d4
	jbeq _?L8					*	jeq .L8
	move.l d3,d5					*	move.l %d3,%d5
_?L3:							*.L3:
	lsr.l #1,d4					*	lsr.l #1,%d4
	jbeq _?L4					*	jeq .L4
	lea ___mulsf3,a3				*	lea __mulsf3,%a3
_?L6:							*.L6:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d3					*	move.l %d0,%d3
	btst #0,d4					*	btst #0,%d4
	jbeq _?L5					*	jeq .L5
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d5					*	move.l %d0,%d5
_?L5:							*.L5:
	lsr.l #1,d4					*	lsr.l #1,%d4
	jbne _?L6					*	jne .L6
_?L4:							*.L4:
	tst.l d6					*	tst.l %d6
	jblt _?L19					*	jlt .L19
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/a3			*	movem.l (%sp)+,#2168
	rts						*	rts
_?L8:							*.L8:
	move.l #0x3f800000,d5				*	move.l #0x3f800000,%d5
	jbra _?L3					*	jra .L3
_?L19:							*.L19:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l #0x3f800000,-(sp)			*	move.l #0x3f800000,-(%sp)
	jbsr ___divsf3					*	jsr __divsf3
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d0,d5					*	move.l %d0,%d5
	move.l d5,d0					*	move.l %d5,%d0
	movem.l (sp)+,d3/d4/d5/d6/a3			*	movem.l (%sp)+,#2168
	rts						*	rts
_?L18:							*.L18:
	neg.l d4					*	neg.l %d4
	jbra _?L2					*	jra .L2
							*	.size	__powisf2, .-__powisf2
							*	.ident	"GCC: (GNU) 13.4.0"
