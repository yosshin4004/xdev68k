* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ucmpdi2				*	.globl	__ucmpdi2
							*	.hidden	__ucmpdi2
							*	.type	__ucmpdi2, @function
___ucmpdi2:						*__ucmpdi2:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	move.l 20(sp),d2				*	move.l 20(%sp),%d2
	move.l 24(sp),d3				*	move.l 24(%sp),%d3
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbne _?L3					*	jne .L3
	cmp.l d3,d1					*	cmp.l %d3,%d1
_?L3:							*.L3:
	shi d4						*	shi %d4
	ext.w d4					*	ext.w %d4
	move.w d4,a1					*	move.w %d4,%a1
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbne _?L4					*	jne .L4
	cmp.l d3,d1					*	cmp.l %d3,%d1
_?L4:							*.L4:
	scs d0						*	scs %d0
	ext.w d0					*	ext.w %d0
	move.w d0,a0					*	move.w %d0,%a0
	sub.l a1,a0					*	sub.l %a1,%a0
	move.l a0,d0					*	move.l %a0,%d0
	addq.l #1,d0					*	addq.l #1,%d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
							*	.size	__ucmpdi2, .-__ucmpdi2
							*	.ident	"GCC: (GNU) 13.4.0"
