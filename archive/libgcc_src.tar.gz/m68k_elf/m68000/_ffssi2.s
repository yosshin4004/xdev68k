* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ffssi2				*	.globl	__ffssi2
							*	.hidden	__ffssi2
							*	.type	__ffssi2, @function
___ffssi2:						*__ffssi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	jbeq _?L5					*	jeq .L5
	move.l d0,d1					*	move.l %d0,%d1
	neg.l d1					*	neg.l %d1
	and.l d0,d1					*	and.l %d0,%d1
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbhi _?L3					*	jhi .L3
	cmp.l #255,d1					*	cmp.l #255,%d1
	shi d2						*	shi %d2
	ext.w d2					*	ext.w %d2
	ext.l d2					*	ext.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0,d1.l),d0				*	move.b (%a0,%d1.l),%d0
	add.l d2,d0					*	add.l %d2,%d0
_?L1:							*.L1:
	rts						*	rts
_?L3:							*.L3:
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbhi _?L6					*	jhi .L6
	moveq #16,d2					*	moveq #16,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0,d1.l),d0				*	move.b (%a0,%d1.l),%d0
	add.l d2,d0					*	add.l %d2,%d0
	jbra _?L1					*	jra .L1
_?L5:							*.L5:
	moveq #0,d0					*	moveq #0,%d0
	rts						*	rts
_?L6:							*.L6:
	moveq #24,d2					*	moveq #24,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0,d1.l),d0				*	move.b (%a0,%d1.l),%d0
	add.l d2,d0					*	add.l %d2,%d0
	jbra _?L1					*	jra .L1
							*	.size	__ffssi2, .-__ffssi2
							*	.ident	"GCC: (GNU) 13.4.0"
