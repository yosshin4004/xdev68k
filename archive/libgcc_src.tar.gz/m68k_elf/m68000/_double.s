* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 635 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 .globl __fpCCR						* .globl _fpCCR
 .globl _$_exception_handler				* .globl $_exception_handler
							*
QUIET_NaN = 0xffffffff					*QUIET_NaN = 0xffffffff
							*
D_MAX_EXP = 0x07ff					*D_MAX_EXP = 0x07ff
D_BIAS = 1022						*D_BIAS = 1022
DBL_MAX_EXP = D_MAX_EXP-D_BIAS				*DBL_MAX_EXP = D_MAX_EXP - D_BIAS
DBL_MIN_EXP = 1-D_BIAS					*DBL_MIN_EXP = 1 - D_BIAS
DBL_MANT_DIG = 53					*DBL_MANT_DIG = 53
							*
INEXACT_RESULT = 0x0001					*INEXACT_RESULT = 0x0001
UNDERFLOW = 0x0002					*UNDERFLOW = 0x0002
OVERFLOW = 0x0004					*OVERFLOW = 0x0004
DIVIDE_BY_ZERO = 0x0008					*DIVIDE_BY_ZERO = 0x0008
INVALID_OPERATION = 0x0010				*INVALID_OPERATION = 0x0010
							*
DOUBLE_FLOAT = 2					*DOUBLE_FLOAT = 2
							*
NOOP = 0						*NOOP = 0
ADD = 1							*ADD = 1
MULTIPLY = 2						*MULTIPLY = 2
DIVIDE = 3						*DIVIDE = 3
NEGATE = 4						*NEGATE = 4
COMPARE = 5						*COMPARE = 5
EXTENDSFDF = 6						*EXTENDSFDF = 6
TRUNCDFSF = 7						*TRUNCDFSF = 7
							*
UNKNOWN = -1						*UNKNOWN = -1
ROUND_TO_NEAREST = 0					*ROUND_TO_NEAREST = 0 | round result to nearest representable value
ROUND_TO_ZERO = 1					*ROUND_TO_ZERO = 1 | round result towards zero
ROUND_TO_PLUS = 2					*ROUND_TO_PLUS = 2 | round result towards plus infinity
ROUND_TO_MINUS = 3					*ROUND_TO_MINUS = 3 | round result towards minus infinity
							*
							*| Entry points:
							*
 .globl ___adddf3					* .globl __adddf3
 .globl ___subdf3					* .globl __subdf3
 .globl ___muldf3					* .globl __muldf3
 .globl ___divdf3					* .globl __divdf3
 .globl ___negdf2					* .globl __negdf2
 .globl ___cmpdf2					* .globl __cmpdf2
 .globl ___cmpdf2_internal				* .globl __cmpdf2_internal
							* .hidden __cmpdf2_internal
							*
 .text							* .text
 .even							* .even
							*
							*| These are common routines to return and signal exceptions.
							*
_Ld$den:						*Ld$den:
							*| Return and signal a denormalized number
 or.l d7,d0						* orl %d7,%d0
 move.w #INEXACT_RESULT+UNDERFLOW,d7			* movew #INEXACT_RESULT+UNDERFLOW,%d7
 moveq #DOUBLE_FLOAT,d6					* moveq #DOUBLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Ld$infty:						*Ld$infty:
_Ld$overflow:						*Ld$overflow:
							*| Return a properly signed INFINITY and set the exception flags
 move.l #0x7ff00000,d0					* movel #0x7ff00000,%d0
 move.l #0,d1						* movel #0,%d1
 or.l d7,d0						* orl %d7,%d0
 move.w #INEXACT_RESULT+OVERFLOW,d7			* movew #INEXACT_RESULT+OVERFLOW,%d7
 moveq #DOUBLE_FLOAT,d6					* moveq #DOUBLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Ld$underflow:						*Ld$underflow:
							*| Return 0 and set the exception flags
 move.l #0,d0						* movel #0,%d0
 move.l d0,d1						* movel %d0,%d1
 move.w #INEXACT_RESULT+UNDERFLOW,d7			* movew #INEXACT_RESULT+UNDERFLOW,%d7
 moveq #DOUBLE_FLOAT,d6					* moveq #DOUBLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Ld$inop:						*Ld$inop:
							*| Return a quiet NaN and set the exception flags
 move.l #QUIET_NaN,d0					* movel #QUIET_NaN,%d0
 move.l d0,d1						* movel %d0,%d1
 move.w #INEXACT_RESULT+INVALID_OPERATION,d7		* movew #INEXACT_RESULT+INVALID_OPERATION,%d7
 moveq #DOUBLE_FLOAT,d6					* moveq #DOUBLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Ld$div$0:						*Ld$div$0:
							*| Return a properly signed INFINITY and set the exception flags
 move.l #0x7ff00000,d0					* movel #0x7ff00000,%d0
 move.l #0,d1						* movel #0,%d1
 or.l d7,d0						* orl %d7,%d0
 move.w #INEXACT_RESULT+DIVIDE_BY_ZERO,d7		* movew #INEXACT_RESULT+DIVIDE_BY_ZERO,%d7
 moveq #DOUBLE_FLOAT,d6					* moveq #DOUBLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
							*|=============================================================================
							*|=============================================================================
							*| double precision routines
							*|=============================================================================
							*|=============================================================================
							*
							*| A double precision floating point number (double) has the format:
							*|
							*| struct _double {
							*| unsigned int sign : 1;
							*| unsigned int exponent : 11;
							*| unsigned int fraction : 52;
							*| } double;
							*|
							*| Thus sizeof(double) = 8 (64 bits).
							*|
							*| All the routines are callable from C programs, and return the result
							*| in the register pair %d0-%d1. They also preserve all registers except
							*| %d0-%d1 and %a0-%a1.
							*
							*|=============================================================================
							*| __subdf3
							*|=============================================================================
							*
							*| double __subdf3(double, double);
							* .type __subdf3,function
___subdf3:						*__subdf3:
 bchg #31,12(sp)					* bchg #31,%sp@(12) | change sign of second operand
							*    | and fall through, so we always add
							*|=============================================================================
							*| __adddf3
							*|=============================================================================
							*
							*| double __adddf3(double, double);
							* .type __adddf3,function
___adddf3:						*__adddf3:
							*
 link a6,#0						* link %a6,#0 | everything will be done in registers
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@- | save all data registers and %a2 (but %d0-%d1)
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get first operand
 move.l 12(a6),d1					* movel %a6@(12),%d1 |
 move.l 16(a6),d2					* movel %a6@(16),%d2 | get second operand
 move.l 20(a6),d3					* movel %a6@(20),%d3 |
							*
 move.l d0,d7						* movel %d0,%d7 | get %d0 's sign bit in d7 '
 add.l d1,d1						* addl %d1,%d1 | check and clear sign bit of a, and gain one
 addx.l d0,d0						* addxl %d0,%d0 | bit of extra precision
 beq _Ladddf$b						* beq Ladddf$b | if zero return second operand
							*
 move.l d2,d6						* movel %d2,%d6 | save sign in %d6
 add.l d3,d3						* addl %d3,%d3 | get rid of sign bit and gain one bit of
 addx.l d2,d2						* addxl %d2,%d2 | extra precision
 beq _Ladddf$a						* beq Ladddf$a | if zero return first operand
							*
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | isolate a's sign bit '
        swap d6						*        swap %d6 | and also b's sign bit '
							*
 and.w #0x8000,d6					* andw #0x8000,%d6 |
 or.w d6,d7						* orw %d6,%d7 | and combine them into %d7, so that a's sign '
							*    | bit is in the high word and b's is in the '
							*    | low word, so %d6 is free to be used
							*
							*
							*
							*
 move.l d7,a0						* movel %d7,%a0 | now save %d7 into %a0, so %d7 is free to
							*                  | be used also
							*
							*| Get the exponents and check for denormalized and/or infinity.
							*
 move.l #0x001fffff,d6					* movel #0x001fffff,%d6 | mask for the fraction
 move.l #0x00200000,d7					* movel #0x00200000,%d7 | mask to put hidden bit back
							*
 move.l d0,d4						* movel %d0,%d4 |
 and.l d6,d0						* andl %d6,%d0 | get fraction in %d0
 not.l d6						* notl %d6 | make %d6 into mask for the exponent
 and.l d6,d4						* andl %d6,%d4 | get exponent in %d4
 beq _Ladddf$a$den					* beq Ladddf$a$den | branch if a is denormalized
 cmp.l d6,d4						* cmpl %d6,%d4 | check for INFINITY or NaN
 beq _Ladddf$nf						* beq Ladddf$nf |
 or.l d7,d0						* orl %d7,%d0 | and put hidden bit back
_Ladddf$1:						*Ladddf$1:
 swap d4						* swap %d4 | shift right exponent so that it starts
							*
 lsr.w #5,d4						* lsrw #5,%d4 | in bit 0 and not bit 20
							*
							*
							*
							*| Now we have a's exponent in d4 and fraction in d0-d1 '
 move.l d2,d5						* movel %d2,%d5 | save b to get exponent
 and.l d6,d5						* andl %d6,%d5 | get exponent in %d5
 beq _Ladddf$b$den					* beq Ladddf$b$den | branch if b is denormalized
 cmp.l d6,d5						* cmpl %d6,%d5 | check for INFINITY or NaN
 beq _Ladddf$nf						* beq Ladddf$nf
 not.l d6						* notl %d6 | make %d6 into mask for the fraction again
 and.l d6,d2						* andl %d6,%d2 | and get fraction in %d2
 or.l d7,d2						* orl %d7,%d2 | and put hidden bit back
_Ladddf$2:						*Ladddf$2:
 swap d5						* swap %d5 | shift right exponent so that it starts
							*
 lsr.w #5,d5						* lsrw #5,%d5 | in bit 0 and not bit 20
							*
							*
							*
							*
							*| Now we have b's exponent in d5 and fraction in d2-d3. '
							*
							*| The situation now is as follows: the signs are combined in %a0, the
							*| numbers are in %d0-%d1 (a) and %d2-%d3 (b), and the exponents in %d4 (a)
							*| and %d5 (b). To do the rounding correctly we need to keep all the
							*| bits until the end, so we need to use %d0-%d1-%d2-%d3 for the first number
							*| and %d4-%d5-%d6-%d7 for the second. To do this we store (temporarily) the
							*| exponents in %a2-%a3.
							*
							*
 movem.l a2-a3,-(sp)					* moveml %a2-%a3,%sp@- | save the address registers
							*
							*
							*
							*
							*
							*
 move.l d4,a2						* movel %d4,%a2 | save the exponents
 move.l d5,a3						* movel %d5,%a3 |
							*
 move.l #0,d7						* movel #0,%d7 | and move the numbers around
 move.l d7,d6						* movel %d7,%d6 |
 move.l d3,d5						* movel %d3,%d5 |
 move.l d2,d4						* movel %d2,%d4 |
 move.l d7,d3						* movel %d7,%d3 |
 move.l d7,d2						* movel %d7,%d2 |
							*
							*| Here we shift the numbers until the exponents are the same, and put
							*| the largest exponent in %a2.
							*
 exg d4,a2						* exg %d4,%a2 | get exponents back
 exg d5,a3						* exg %d5,%a3 |
 cmp.w d4,d5						* cmpw %d4,%d5 | compare the exponents
							*# 878 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 beq _Ladddf$3						* beq Ladddf$3 | if equal don't shift '
 bhi 9f							* bhi 9f | branch if second exponent is higher
							*
							*| Here we have a's exponent larger than b's, so we have to shift b. We do
							*| this by using as counter %d2:
1: move.w d4,d2						*1: movew %d4,%d2 | move largest exponent to %d2
							*
 sub.w d5,d2						* subw %d5,%d2 | and subtract second exponent
 exg d4,a2						* exg %d4,%a2 | get back the longs we saved
 exg d5,a3						* exg %d5,%a3 |
							*# 897 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| if difference is too large we don't shift (actually, we can just exit) '
							*
 cmp.w #DBL_MANT_DIG+2,d2				* cmpw #DBL_MANT_DIG+2,%d2
							*
							*
							*
 bge _Ladddf$b$small					* bge Ladddf$b$small
							*
 cmp.w #32,d2						* cmpw #32,%d2 | if difference >= 32, shift by longs
							*
							*
							*
 bge 5f							* bge 5f
2:							*2:
							*
 cmp.w #16,d2						* cmpw #16,%d2 | if difference >= 16, shift by words
							*
							*
							*
 bge 6f							* bge 6f
 bra 3f							* bra 3f | enter dbra loop
							*
4:							*4:
							*
 lsr.l #1,d4						* lsrl #1,%d4
 roxr.l #1,d5						* roxrl #1,%d5
 roxr.l #1,d6						* roxrl #1,%d6
 roxr.l #1,d7						* roxrl #1,%d7
							*# 940 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
3:							*3:
							*
 dbra d2,4b						* dbra %d2,4b
							*
							*
							*
							*
 move.l #0,d2						* movel #0,%d2
 move.l d2,d3						* movel %d2,%d3
 bra _Ladddf$4						* bra Ladddf$4
5:							*5:
 move.l d6,d7						* movel %d6,%d7
 move.l d5,d6						* movel %d5,%d6
 move.l d4,d5						* movel %d4,%d5
 move.l #0,d4						* movel #0,%d4
							*
 sub.w #32,d2						* subw #32,%d2
							*
							*
							*
 bra 2b							* bra 2b
6:							*6:
 move.w d6,d7						* movew %d6,%d7
 swap d7						* swap %d7
 move.w d5,d6						* movew %d5,%d6
 swap d6						* swap %d6
 move.w d4,d5						* movew %d4,%d5
 swap d5						* swap %d5
 move.w #0,d4						* movew #0,%d4
 swap d4						* swap %d4
							*
 sub.w #16,d2						* subw #16,%d2
							*
							*
							*
 bra 3b							* bra 3b
							*
9:							*9:
							*
 exg d4,d5						* exg %d4,%d5
 move.w d4,d6						* movew %d4,%d6
 sub.w d5,d6						* subw %d5,%d6 | keep %d5 (largest exponent) in %d4
 exg d4,a2						* exg %d4,%a2
 exg d5,a3						* exg %d5,%a3
							*# 996 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| if difference is too large we don't shift (actually, we can just exit) '
							*
 cmp.w #DBL_MANT_DIG+2,d6				* cmpw #DBL_MANT_DIG+2,%d6
							*
							*
							*
 bge _Ladddf$a$small					* bge Ladddf$a$small
							*
 cmp.w #32,d6						* cmpw #32,%d6 | if difference >= 32, shift by longs
							*
							*
							*
 bge 5f							* bge 5f
2:							*2:
							*
 cmp.w #16,d6						* cmpw #16,%d6 | if difference >= 16, shift by words
							*
							*
							*
 bge 6f							* bge 6f
 bra 3f							* bra 3f | enter dbra loop
							*
4:							*4:
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
							*# 1039 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
3:							*3:
							*
 dbra d6,4b						* dbra %d6,4b
							*
							*
							*
							*
 move.l #0,d7						* movel #0,%d7
 move.l d7,d6						* movel %d7,%d6
 bra _Ladddf$4						* bra Ladddf$4
5:							*5:
 move.l d2,d3						* movel %d2,%d3
 move.l d1,d2						* movel %d1,%d2
 move.l d0,d1						* movel %d0,%d1
 move.l #0,d0						* movel #0,%d0
							*
 sub.w #32,d6						* subw #32,%d6
							*
							*
							*
 bra 2b							* bra 2b
6:							*6:
 move.w d2,d3						* movew %d2,%d3
 swap d3						* swap %d3
 move.w d1,d2						* movew %d1,%d2
 swap d2						* swap %d2
 move.w d0,d1						* movew %d0,%d1
 swap d1						* swap %d1
 move.w #0,d0						* movew #0,%d0
 swap d0						* swap %d0
							*
 sub.w #16,d6						* subw #16,%d6
							*
							*
							*
 bra 3b							* bra 3b
_Ladddf$3:						*Ladddf$3:
							*
 exg d4,a2						* exg %d4,%a2
 exg d5,a3						* exg %d5,%a3
							*# 1087 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
_Ladddf$4:						*Ladddf$4:
							*| Now we have the numbers in %d0--%d3 and %d4--%d7, the exponent in %a2, and
							*| the signs in %a4.
							*
							*| Here we have to decide whether to add or subtract the numbers:
							*
 exg d7,a0						* exg %d7,%a0 | get the signs
 exg d6,a3						* exg %d6,%a3 | %a3 is free to be used
							*# 1103 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 move.l d7,d6						* movel %d7,%d6 |
 move.w #0,d7						* movew #0,%d7 | get a's sign in d7 '
 swap d6						* swap %d6 |
 move.w #0,d6						* movew #0,%d6 | and b's sign in d6 '
 eor.l d7,d6						* eorl %d7,%d6 | compare the signs
 bmi _Lsubdf$0						* bmi Lsubdf$0 | if the signs are different we have
							*    | to subtract
							*
 exg d7,a0						* exg %d7,%a0 | else we add the numbers
 exg d6,a3						* exg %d6,%a3 |
							*# 1121 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 add.l d7,d3						* addl %d7,%d3 |
 addx.l d6,d2						* addxl %d6,%d2 |
 addx.l d5,d1						* addxl %d5,%d1 |
 addx.l d4,d0						* addxl %d4,%d0 |
							*
 move.l a2,d4						* movel %a2,%d4 | return exponent to %d4
 move.l a0,d7						* movel %a0,%d7 |
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | %d7 now has the sign
							*
							*
 movem.l (sp)+,a2-a3					* moveml %sp@+,%a2-%a3
							*
							*
							*
							*
							*
							*
							*| Before rounding normalize so bit #DBL_MANT_DIG is set (we will consider
							*| the case of denormalized numbers in the rounding routine itself).
							*| As in the addition (not in the subtraction!) we could have set
							*| one more bit we check this:
 btst #DBL_MANT_DIG+1,d0				* btst #DBL_MANT_DIG+1,%d0
 beq 1f							* beq 1f
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
 add.w #1,d4						* addw #1,%d4
							*# 1166 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
1:							*1:
 lea _Ladddf$5(pc),a0					* lea %pc@(Ladddf$5),%a0 | to return from rounding routine
 PICLEA __fpCCR,a1					* PICLEA _fpCCR,%a1 | check the rounding mode
							*
							*
							*
 move.w 6(a1),d6					* movew %a1@(6),%d6 | rounding mode in %d6
 beq _Lround$to$nearest					* beq Lround$to$nearest
							*
 cmp.w #ROUND_TO_PLUS,d6				* cmpw #ROUND_TO_PLUS,%d6
							*
							*
							*
 bhi _Lround$to$minus					* bhi Lround$to$minus
 blt _Lround$to$zero					* blt Lround$to$zero
 bra _Lround$to$plus					* bra Lround$to$plus
_Ladddf$5:						*Ladddf$5:
							*| Put back the exponent and check for overflow
							*
 cmp.w #0x7ff,d4					* cmpw #0x7ff,%d4 | is the exponent big?
							*
							*
							*
 bge 1f							* bge 1f
 bclr #DBL_MANT_DIG-1,d0				* bclr #DBL_MANT_DIG-1,%d0
							*
 lsl.w #4,d4						* lslw #4,%d4 | put exponent back into position
							*
							*
							*
 swap d0						* swap %d0 |
							*
 or.w d4,d0						* orw %d4,%d0 |
							*
							*
							*
 swap d0						* swap %d0 |
 bra _Ladddf$ret					* bra Ladddf$ret
1:							*1:
 moveq #ADD,d5						* moveq #ADD,%d5
 bra _Ld$overflow					* bra Ld$overflow
							*
_Lsubdf$0:						*Lsubdf$0:
							*| Here we do the subtraction.
							*
 exg d7,a0						* exg %d7,%a0 | put sign back in %a0
 exg d6,a3						* exg %d6,%a3 |
							*# 1221 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 sub.l d7,d3						* subl %d7,%d3 |
 subx.l d6,d2						* subxl %d6,%d2 |
 subx.l d5,d1						* subxl %d5,%d1 |
 subx.l d4,d0						* subxl %d4,%d0 |
 beq _Ladddf$ret$1					* beq Ladddf$ret$1 | if zero just exit
 bpl 1f							* bpl 1f | if positive skip the following
 move.l a0,d7						* movel %a0,%d7 |
 bchg #31,d7						* bchg #31,%d7 | change sign bit in %d7
 move.l d7,a0						* movel %d7,%a0 |
 neg.l d3						* negl %d3 |
 negx.l d2						* negxl %d2 |
 negx.l d1						* negxl %d1 | and negate result
 negx.l d0						* negxl %d0 |
1:							*1:
 move.l a2,d4						* movel %a2,%d4 | return exponent to %d4
 move.l a0,d7						* movel %a0,%d7
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | isolate sign bit
							*
 movem.l (sp)+,a2-a3					* moveml %sp@+,%a2-%a3 |
							*
							*
							*
							*
							*
							*
							*| Before rounding normalize so bit #DBL_MANT_DIG is set (we will consider
							*| the case of denormalized numbers in the rounding routine itself).
							*| As in the addition (not in the subtraction!) we could have set
							*| one more bit we check this:
 btst #DBL_MANT_DIG+1,d0				* btst #DBL_MANT_DIG+1,%d0
 beq 1f							* beq 1f
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
 add.w #1,d4						* addw #1,%d4
							*# 1274 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
1:							*1:
 lea _Lsubdf$1(pc),a0					* lea %pc@(Lsubdf$1),%a0 | to return from rounding routine
 PICLEA __fpCCR,a1					* PICLEA _fpCCR,%a1 | check the rounding mode
							*
							*
							*
 move.w 6(a1),d6					* movew %a1@(6),%d6 | rounding mode in %d6
 beq _Lround$to$nearest					* beq Lround$to$nearest
							*
 cmp.w #ROUND_TO_PLUS,d6				* cmpw #ROUND_TO_PLUS,%d6
							*
							*
							*
 bhi _Lround$to$minus					* bhi Lround$to$minus
 blt _Lround$to$zero					* blt Lround$to$zero
 bra _Lround$to$plus					* bra Lround$to$plus
_Lsubdf$1:						*Lsubdf$1:
							*| Put back the exponent and sign (we don't have overflow). '
 bclr #DBL_MANT_DIG-1,d0				* bclr #DBL_MANT_DIG-1,%d0
							*
 lsl.w #4,d4						* lslw #4,%d4 | put exponent back into position
							*
							*
							*
 swap d0						* swap %d0 |
							*
 or.w d4,d0						* orw %d4,%d0 |
							*
							*
							*
 swap d0						* swap %d0 |
 bra _Ladddf$ret					* bra Ladddf$ret
							*
							*| If one of the numbers was too small (difference of exponents >=
							*| DBL_MANT_DIG+1) we return the other (and now we don't have to '
							*| check for finiteness or zero).
_Ladddf$a$small:					*Ladddf$a$small:
							*
 movem.l (sp)+,a2-a3					* moveml %sp@+,%a2-%a3
							*
							*
							*
							*
							*
 move.l 16(a6),d0					* movel %a6@(16),%d0
 move.l 20(a6),d1					* movel %a6@(20),%d1
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | restore data registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 | and return
 rts							* rts
							*
_Ladddf$b$small:					*Ladddf$b$small:
							*
 movem.l (sp)+,a2-a3					* moveml %sp@+,%a2-%a3
							*
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0
 move.l 12(a6),d1					* movel %a6@(12),%d1
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | restore data registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 | and return
 rts							* rts
							*
_Ladddf$a$den:						*Ladddf$a$den:
 move.l d7,d4						* movel %d7,%d4 | %d7 contains 0x00200000
 bra _Ladddf$1						* bra Ladddf$1
							*
_Ladddf$b$den:						*Ladddf$b$den:
 move.l d7,d5						* movel %d7,%d5 | %d7 contains 0x00200000
 not.l d6						* notl %d6
 bra _Ladddf$2						* bra Ladddf$2
							*
_Ladddf$b:						*Ladddf$b:
							*| Return b (if a is zero)
 move.l d2,d0						* movel %d2,%d0
 move.l d3,d1						* movel %d3,%d1
 bne 1f							* bne 1f | Check if b is -0
 cmp.l #0x80000000,d0					* cmpl #0x80000000,%d0
 bne 1f							* bne 1f
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | Use the sign of a
 clr.l d0						* clrl %d0
 bra _Ladddf$ret					* bra Ladddf$ret
_Ladddf$a:						*Ladddf$a:
 move.l 8(a6),d0					* movel %a6@(8),%d0
 move.l 12(a6),d1					* movel %a6@(12),%d1
1:							*1:
 moveq #ADD,d5						* moveq #ADD,%d5
							*| Check for NaN and +/-INFINITY.
 move.l d0,d7						* movel %d0,%d7 |
 and.l #0x80000000,d7					* andl #0x80000000,%d7 |
 bclr #31,d0						* bclr #31,%d0 |
 cmp.l #0x7ff00000,d0					* cmpl #0x7ff00000,%d0 |
 bge 2f							* bge 2f |
 move.l d0,d0						* movel %d0,%d0 | check for zero, since we don't  '
 bne _Ladddf$ret					* bne Ladddf$ret | want to return -0 by mistake
 bclr #31,d7						* bclr #31,%d7 |
 bra _Ladddf$ret					* bra Ladddf$ret |
2:							*2:
 and.l #0x000fffff,d0					* andl #0x000fffff,%d0 | check for NaN (nonzero fraction)
 or.l d1,d0						* orl %d1,%d0 |
 bne _Ld$inop						* bne Ld$inop |
 bra _Ld$infty						* bra Ld$infty |
							*
_Ladddf$ret$1:						*Ladddf$ret$1:
							*
 movem.l (sp)+,a2-a3					* moveml %sp@+,%a2-%a3 | restore regs and exit
							*
							*
							*
							*
							*
							*
_Ladddf$ret:						*Ladddf$ret:
							*| Normal exit.
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
 or.l d7,d0						* orl %d7,%d0 | put sign bit back
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
							*
_Ladddf$ret$den:					*Ladddf$ret$den:
							*| Return a denormalized number.
							*
 lsr.l #1,d0						* lsrl #1,%d0 | shift right once more
 roxr.l #1,d1						* roxrl #1,%d1 |
							*
							*
							*
							*
							*
							*
							*
 bra _Ladddf$ret					* bra Ladddf$ret
							*
_Ladddf$nf:						*Ladddf$nf:
 moveq #ADD,d5						* moveq #ADD,%d5
							*| This could be faster but it is not worth the effort, since it is not
							*| executed very often. We sacrifice speed for clarity here.
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get the numbers back (remember that we
 move.l 12(a6),d1					* movel %a6@(12),%d1 | did some processing already)
 move.l 16(a6),d2					* movel %a6@(16),%d2 |
 move.l 20(a6),d3					* movel %a6@(20),%d3 |
 move.l #0x7ff00000,d4					* movel #0x7ff00000,%d4 | useful constant (INFINITY)
 move.l d0,d7						* movel %d0,%d7 | save sign bits
 move.l d2,d6						* movel %d2,%d6 |
 bclr #31,d0						* bclr #31,%d0 | clear sign bits
 bclr #31,d2						* bclr #31,%d2 |
							*| We know that one of them is either NaN of +/-INFINITY
							*| Check for NaN (if either one is NaN return NaN)
 cmp.l d4,d0						* cmpl %d4,%d0 | check first a (%d0)
 bhi _Ld$inop						* bhi Ld$inop | if %d0 > 0x7ff00000 or equal and
 bne 2f							* bne 2f
 tst.l d1						* tstl %d1 | %d1 > 0, a is NaN
 bne _Ld$inop						* bne Ld$inop |
2: cmp.l d4,d2						*2: cmpl %d4,%d2 | check now b (%d1)
 bhi _Ld$inop						* bhi Ld$inop |
 bne 3f							* bne 3f
 tst.l d3						* tstl %d3 |
 bne _Ld$inop						* bne Ld$inop |
3:							*3:
							*| Now comes the check for +/-INFINITY. We know that both are (maybe not
							*| finite) numbers, but we have to check if both are infinite whether we
							*| are adding or subtracting them.
 eor.l d7,d6						* eorl %d7,%d6 | to check sign bits
 bmi 1f							* bmi 1f
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | get (common) sign bit
 bra _Ld$infty						* bra Ld$infty
1:							*1:
							*| We know one (or both) are infinite, so we test for equality between the
							*| two numbers (if they are equal they have to be infinite both, so we
							*| return NaN).
 cmp.l d2,d0						* cmpl %d2,%d0 | are both infinite?
 bne 1f							* bne 1f | if %d0 <> %d2 they are not equal
 cmp.l d3,d1						* cmpl %d3,%d1 | if %d0 == %d2 test %d3 and %d1
 beq _Ld$inop						* beq Ld$inop | if equal return NaN
1:							*1:
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | get a's sign bit '
 cmp.l d4,d0						* cmpl %d4,%d0 | test now for infinity
 beq _Ld$infty						* beq Ld$infty | if a is INFINITY return with this sign
 bchg #31,d7						* bchg #31,%d7 | else we know b is INFINITY and has
 bra _Ld$infty						* bra Ld$infty | the opposite sign
							*
							*|=============================================================================
							*| __muldf3
							*|=============================================================================
							*
							*| double __muldf3(double, double);
							* .type __muldf3,function
___muldf3:						*__muldf3:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@-
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get a into %d0-%d1
 move.l 12(a6),d1					* movel %a6@(12),%d1 |
 move.l 16(a6),d2					* movel %a6@(16),%d2 | and b into %d2-%d3
 move.l 20(a6),d3					* movel %a6@(20),%d3 |
 move.l d0,d7						* movel %d0,%d7 | %d7 will hold the sign of the product
 eor.l d2,d7						* eorl %d2,%d7 |
 and.l #0x80000000,d7					* andl #0x80000000,%d7 |
 move.l d7,a0						* movel %d7,%a0 | save sign bit into %a0
 move.l #0x7ff00000,d7					* movel #0x7ff00000,%d7 | useful constant (+INFINITY)
 move.l d7,d6						* movel %d7,%d6 | another (mask for fraction)
 not.l d6						* notl %d6 |
 bclr #31,d0						* bclr #31,%d0 | get rid of a's sign bit '
 move.l d0,d4						* movel %d0,%d4 |
 or.l d1,d4						* orl %d1,%d4 |
 beq _Lmuldf$a$0					* beq Lmuldf$a$0 | branch if a is zero
 move.l d0,d4						* movel %d0,%d4 |
 bclr #31,d2						* bclr #31,%d2 | get rid of b's sign bit '
 move.l d2,d5						* movel %d2,%d5 |
 or.l d3,d5						* orl %d3,%d5 |
 beq _Lmuldf$b$0					* beq Lmuldf$b$0 | branch if b is zero
 move.l d2,d5						* movel %d2,%d5 |
 cmp.l d7,d0						* cmpl %d7,%d0 | is a big?
 bhi _Lmuldf$inop					* bhi Lmuldf$inop | if a is NaN return NaN
 beq _Lmuldf$a$nf					* beq Lmuldf$a$nf | we still have to check %d1 and b ...
 cmp.l d7,d2						* cmpl %d7,%d2 | now compare b with INFINITY
 bhi _Lmuldf$inop					* bhi Lmuldf$inop | is b NaN?
 beq _Lmuldf$b$nf					* beq Lmuldf$b$nf | we still have to check %d3 ...
							*| Here we have both numbers finite and nonzero (and with no sign bit).
							*| Now we get the exponents into %d4 and %d5.
 and.l d7,d4						* andl %d7,%d4 | isolate exponent in %d4
 beq _Lmuldf$a$den					* beq Lmuldf$a$den | if exponent zero, have denormalized
 and.l d6,d0						* andl %d6,%d0 | isolate fraction
 or.l #0x00100000,d0					* orl #0x00100000,%d0 | and put hidden bit back
 swap d4						* swap %d4 | I like exponents in the first byte
							*
 lsr.w #4,d4						* lsrw #4,%d4 |
							*
							*
							*
_Lmuldf$1:						*Lmuldf$1:
 and.l d7,d5						* andl %d7,%d5 |
 beq _Lmuldf$b$den					* beq Lmuldf$b$den |
 and.l d6,d2						* andl %d6,%d2 |
 or.l #0x00100000,d2					* orl #0x00100000,%d2 | and put hidden bit back
 swap d5						* swap %d5 |
							*
 lsr.w #4,d5						* lsrw #4,%d5 |
							*
							*
							*
_Lmuldf$2:						*Lmuldf$2: |
							*
 add.w d5,d4						* addw %d5,%d4 | add exponents
 sub.w #D_BIAS+1,d4					* subw #D_BIAS+1,%d4 | and subtract bias (plus one)
							*
							*
							*
							*
							*
							*| We are now ready to do the multiplication. The situation is as follows:
							*| both a and b have bit 52 ( bit 20 of %d0 and %d2) set (even if they were
							*| denormalized to start with!), which means that in the product bit 104
							*| (which will correspond to bit 8 of the fourth long) is set.
							*
							*| Here we have to do the product.
							*| To do it we have to juggle the registers back and forth, as there are not
							*| enough to keep everything in them. So we use the address registers to keep
							*| some intermediate data.
							*
							*
 movem.l a2-a3,-(sp)					* moveml %a2-%a3,%sp@- | save %a2 and %a3 for temporary use
							*
							*
							*
							*
							*
 move.l #0,a2						* movel #0,%a2 | %a2 is a null register
 move.l d4,a3						* movel %d4,%a3 | and %a3 will preserve the exponent
							*
							*| First, shift %d2-%d3 so bit 20 becomes bit 31:
							*
 ror.l #5,d2						* rorl #5,%d2 | rotate %d2 5 places right
 swap d2						* swap %d2 | and swap it
 ror.l #5,d3						* rorl #5,%d3 | do the same thing with %d3
 swap d3						* swap %d3 |
 move.w d3,d6						* movew %d3,%d6 | get the rightmost 11 bits of %d3
 and.w #0x07ff,d6					* andw #0x07ff,%d6 |
 or.w d6,d2						* orw %d6,%d2 | and put them into %d2
 and.w #0xf800,d3					* andw #0xf800,%d3 | clear those bits in %d3
							*# 1594 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 move.l d2,d6						* movel %d2,%d6 | move b into %d6-%d7
 move.l d3,d7						* movel %d3,%d7 | move a into %d4-%d5
 move.l d0,d4						* movel %d0,%d4 | and clear %d0-%d1-%d2-%d3 (to put result)
 move.l d1,d5						* movel %d1,%d5 |
 move.l #0,d3						* movel #0,%d3 |
 move.l d3,d2						* movel %d3,%d2 |
 move.l d3,d1						* movel %d3,%d1 |
 move.l d3,d0						* movel %d3,%d0 |
							*
							*| We use %a1 as counter:
 move.l #DBL_MANT_DIG-1,a1				* movel #DBL_MANT_DIG-1,%a1
							*
 exg d7,a1						* exg %d7,%a1
							*
							*
							*
							*
							*
							*
1:							*1:
							*
 exg d7,a1						* exg %d7,%a1 | put counter back in %a1
							*
							*
							*
							*
							*
 add.l d3,d3						* addl %d3,%d3 | shift sum once left
 addx.l d2,d2						* addxl %d2,%d2 |
 addx.l d1,d1						* addxl %d1,%d1 |
 addx.l d0,d0						* addxl %d0,%d0 |
 add.l d7,d7						* addl %d7,%d7 |
 addx.l d6,d6						* addxl %d6,%d6 |
 bcc 2f							* bcc 2f | if bit clear skip the following
							*
 exg d7,a2						* exg %d7,%a2 |
							*
							*
							*
							*
							*
 add.l d5,d3						* addl %d5,%d3 | else add a to the sum
 addx.l d4,d2						* addxl %d4,%d2 |
 addx.l d7,d1						* addxl %d7,%d1 |
 addx.l d7,d0						* addxl %d7,%d0 |
							*
 exg d7,a2						* exg %d7,%a2 |
							*
							*
							*
							*
							*
2:							*2:
							*
 exg d7,a1						* exg %d7,%a1 | put counter in %d7
 dbf d7,1b						* dbf %d7,1b | decrement and branch
							*# 1658 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 move.l a3,d4						* movel %a3,%d4 | restore exponent
							*
 movem.l (sp)+,a2-a3					* moveml %sp@+,%a2-%a3
							*
							*
							*
							*
							*
							*
							*| Now we have the product in %d0-%d1-%d2-%d3, with bit 8 of %d0 set. The
							*| first thing to do now is to normalize it so bit 8 becomes bit
							*| DBL_MANT_DIG-32 (to do the rounding); later we will shift right.
 swap d0						* swap %d0
 swap d1						* swap %d1
 move.w d1,d0						* movew %d1,%d0
 swap d2						* swap %d2
 move.w d2,d1						* movew %d2,%d1
 swap d3						* swap %d3
 move.w d3,d2						* movew %d3,%d2
 move.w #0,d3						* movew #0,%d3
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
							*# 1708 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| Now round, check for over- and underflow, and exit.
 move.l a0,d7						* movel %a0,%d7 | get sign bit back into %d7
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
							*
 btst #DBL_MANT_DIG+1-32,d0				* btst #DBL_MANT_DIG+1-32,%d0
 beq _Lround$exit					* beq Lround$exit
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 add.w #1,d4						* addw #1,%d4
							*# 1726 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 bra _Lround$exit					* bra Lround$exit
							*
_Lmuldf$inop:						*Lmuldf$inop:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
 bra _Ld$inop						* bra Ld$inop
							*
_Lmuldf$b$nf:						*Lmuldf$b$nf:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
 move.l a0,d7						* movel %a0,%d7 | get sign bit back into %d7
 tst.l d3						* tstl %d3 | we know %d2 == 0x7ff00000, so check %d3
 bne _Ld$inop						* bne Ld$inop | if %d3 <> 0 b is NaN
 bra _Ld$overflow					* bra Ld$overflow | else we have overflow (since a is finite)
							*
_Lmuldf$a$nf:						*Lmuldf$a$nf:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
 move.l a0,d7						* movel %a0,%d7 | get sign bit back into %d7
 tst.l d1						* tstl %d1 | we know %d0 == 0x7ff00000, so check %d1
 bne _Ld$inop						* bne Ld$inop | if %d1 <> 0 a is NaN
 bra _Ld$overflow					* bra Ld$overflow | else signal overflow
							*
							*| If either number is zero return zero, unless the other is +/-INFINITY or
							*| NaN, in which case we return NaN.
_Lmuldf$b$0:						*Lmuldf$b$0:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
							*
 exg d2,d0						* exg %d2,%d0 | put b (==0) into %d0-%d1
 exg d3,d1						* exg %d3,%d1 | and a (with sign bit cleared) into %d2-%d3
 move.l a0,d0						* movel %a0,%d0 | set result sign
							*
							*
							*
							*
							*
							*
 bra 1f							* bra 1f
_Lmuldf$a$0:						*Lmuldf$a$0:
 move.l a0,d0						* movel %a0,%d0 | set result sign
 move.l 16(a6),d2					* movel %a6@(16),%d2 | put b into %d2-%d3 again
 move.l 20(a6),d3					* movel %a6@(20),%d3 |
 bclr #31,d2						* bclr #31,%d2 | clear sign bit
1: cmp.l #0x7ff00000,d2					*1: cmpl #0x7ff00000,%d2 | check for non-finiteness
 bge _Ld$inop						* bge Ld$inop | in case NaN or +/-INFINITY return NaN
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
							*
							*| If a number is denormalized we put an exponent of 1 but do not put the
							*| hidden bit back into the fraction; instead we shift left until bit 21
							*| (the hidden bit) is set, adjusting the exponent accordingly. We do this
							*| to ensure that the product of the fractions is close to 1.
_Lmuldf$a$den:						*Lmuldf$a$den:
 move.l #1,d4						* movel #1,%d4
 and.l d6,d0						* andl %d6,%d0
1: add.l d1,d1						*1: addl %d1,%d1 | shift a left until bit 20 is set
 addx.l d0,d0						* addxl %d0,%d0 |
							*
 sub.w #1,d4						* subw #1,%d4 | and adjust exponent
							*
							*
							*
 btst #20,d0						* btst #20,%d0 |
 bne _Lmuldf$1						* bne Lmuldf$1 |
 bra 1b							* bra 1b
							*
_Lmuldf$b$den:						*Lmuldf$b$den:
 move.l #1,d5						* movel #1,%d5
 and.l d6,d2						* andl %d6,%d2
1: add.l d3,d3						*1: addl %d3,%d3 | shift b left until bit 20 is set
 addx.l d2,d2						* addxl %d2,%d2 |
							*
 sub.w #1,d5						* subw #1,%d5 | and adjust exponent
							*
							*
							*
 btst #20,d2						* btst #20,%d2 |
 bne _Lmuldf$2						* bne Lmuldf$2 |
 bra 1b							* bra 1b
							*
							*
							*|=============================================================================
							*| __divdf3
							*|=============================================================================
							*
							*| double __divdf3(double, double);
							* .type __divdf3,function
___divdf3:						*__divdf3:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@-
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get a into %d0-%d1
 move.l 12(a6),d1					* movel %a6@(12),%d1 |
 move.l 16(a6),d2					* movel %a6@(16),%d2 | and b into %d2-%d3
 move.l 20(a6),d3					* movel %a6@(20),%d3 |
 move.l d0,d7						* movel %d0,%d7 | %d7 will hold the sign of the result
 eor.l d2,d7						* eorl %d2,%d7 |
 and.l #0x80000000,d7					* andl #0x80000000,%d7
 move.l d7,a0						* movel %d7,%a0 | save sign into %a0
 move.l #0x7ff00000,d7					* movel #0x7ff00000,%d7 | useful constant (+INFINITY)
 move.l d7,d6						* movel %d7,%d6 | another (mask for fraction)
 not.l d6						* notl %d6 |
 bclr #31,d0						* bclr #31,%d0 | get rid of a's sign bit '
 move.l d0,d4						* movel %d0,%d4 |
 or.l d1,d4						* orl %d1,%d4 |
 beq _Ldivdf$a$0					* beq Ldivdf$a$0 | branch if a is zero
 move.l d0,d4						* movel %d0,%d4 |
 bclr #31,d2						* bclr #31,%d2 | get rid of b's sign bit '
 move.l d2,d5						* movel %d2,%d5 |
 or.l d3,d5						* orl %d3,%d5 |
 beq _Ldivdf$b$0					* beq Ldivdf$b$0 | branch if b is zero
 move.l d2,d5						* movel %d2,%d5
 cmp.l d7,d0						* cmpl %d7,%d0 | is a big?
 bhi _Ldivdf$inop					* bhi Ldivdf$inop | if a is NaN return NaN
 beq _Ldivdf$a$nf					* beq Ldivdf$a$nf | if %d0 == 0x7ff00000 we check %d1
 cmp.l d7,d2						* cmpl %d7,%d2 | now compare b with INFINITY
 bhi _Ldivdf$inop					* bhi Ldivdf$inop | if b is NaN return NaN
 beq _Ldivdf$b$nf					* beq Ldivdf$b$nf | if %d2 == 0x7ff00000 we check %d3
							*| Here we have both numbers finite and nonzero (and with no sign bit).
							*| Now we get the exponents into %d4 and %d5 and normalize the numbers to
							*| ensure that the ratio of the fractions is around 1. We do this by
							*| making sure that both numbers have bit #DBL_MANT_DIG-32-1 (hidden bit)
							*| set, even if they were denormalized to start with.
							*| Thus, the result will satisfy: 2 > result > 1/2.
 and.l d7,d4						* andl %d7,%d4 | and isolate exponent in %d4
 beq _Ldivdf$a$den					* beq Ldivdf$a$den | if exponent is zero we have a denormalized
 and.l d6,d0						* andl %d6,%d0 | and isolate fraction
 or.l #0x00100000,d0					* orl #0x00100000,%d0 | and put hidden bit back
 swap d4						* swap %d4 | I like exponents in the first byte
							*
 lsr.w #4,d4						* lsrw #4,%d4 |
							*
							*
							*
_Ldivdf$1:						*Ldivdf$1: |
 and.l d7,d5						* andl %d7,%d5 |
 beq _Ldivdf$b$den					* beq Ldivdf$b$den |
 and.l d6,d2						* andl %d6,%d2 |
 or.l #0x00100000,d2					* orl #0x00100000,%d2
 swap d5						* swap %d5 |
							*
 lsr.w #4,d5						* lsrw #4,%d5 |
							*
							*
							*
_Ldivdf$2:						*Ldivdf$2: |
							*
 sub.w d5,d4						* subw %d5,%d4 | subtract exponents
 add.w #D_BIAS,d4					* addw #D_BIAS,%d4 | and add bias
							*
							*
							*
							*
							*
							*| We are now ready to do the division. We have prepared things in such a way
							*| that the ratio of the fractions will be less than 2 but greater than 1/2.
							*| At this point the registers in use are:
							*| %d0-%d1 hold a (first operand, bit DBL_MANT_DIG-32=0, bit
							*| DBL_MANT_DIG-1-32=1)
							*| %d2-%d3 hold b (second operand, bit DBL_MANT_DIG-32=1)
							*| %d4 holds the difference of the exponents, corrected by the bias
							*| %a0 holds the sign of the ratio
							*
							*| To do the rounding correctly we need to keep information about the
							*| nonsignificant bits. One way to do this would be to do the division
							*| using four registers; another is to use two registers (as originally
							*| I did), but use a sticky bit to preserve information about the
							*| fractional part. Note that we can keep that info in %a1, which is not
							*| used.
 move.l #0,d6						* movel #0,%d6 | %d6-%d7 will hold the result
 move.l d6,d7						* movel %d6,%d7 |
 move.l #0,a1						* movel #0,%a1 | and %a1 will hold the sticky bit
							*
 move.l #DBL_MANT_DIG-32+1,d5				* movel #DBL_MANT_DIG-32+1,%d5
							*
1: cmp.l d0,d2						*1: cmpl %d0,%d2 | is a < b?
 bhi 3f							* bhi 3f | if b > a skip the following
 beq 4f							* beq 4f | if %d0==%d2 check %d1 and %d3
2: sub.l d3,d1						*2: subl %d3,%d1 |
 subx.l d2,d0						* subxl %d2,%d0 | a <-- a - b
 bset d5,d6						* bset %d5,%d6 | set the corresponding bit in %d6
3: add.l d1,d1						*3: addl %d1,%d1 | shift a by 1
 addx.l d0,d0						* addxl %d0,%d0 |
							*
 dbra d5,1b						* dbra %d5,1b | and branch back
							*
							*
							*
							*
 bra 5f							* bra 5f
4: cmp.l d1,d3						*4: cmpl %d1,%d3 | here %d0==%d2, so check %d1 and %d3
 bhi 3b							* bhi 3b | if %d1 > %d2 skip the subtraction
 bra 2b							* bra 2b | else go do it
5:							*5:
							*| Here we have to start setting the bits in the second long.
 move.l #31,d5						* movel #31,%d5 | again %d5 is counter
							*
1: cmp.l d0,d2						*1: cmpl %d0,%d2 | is a < b?
 bhi 3f							* bhi 3f | if b > a skip the following
 beq 4f							* beq 4f | if %d0==%d2 check %d1 and %d3
2: sub.l d3,d1						*2: subl %d3,%d1 |
 subx.l d2,d0						* subxl %d2,%d0 | a <-- a - b
 bset d5,d7						* bset %d5,%d7 | set the corresponding bit in %d7
3: add.l d1,d1						*3: addl %d1,%d1 | shift a by 1
 addx.l d0,d0						* addxl %d0,%d0 |
							*
 dbra d5,1b						* dbra %d5,1b | and branch back
							*
							*
							*
							*
 bra 5f							* bra 5f
4: cmp.l d1,d3						*4: cmpl %d1,%d3 | here %d0==%d2, so check %d1 and %d3
 bhi 3b							* bhi 3b | if %d1 > %d2 skip the subtraction
 bra 2b							* bra 2b | else go do it
5:							*5:
							*| Now go ahead checking until we hit a one, which we store in %d2.
 move.l #DBL_MANT_DIG,d5				* movel #DBL_MANT_DIG,%d5
1: cmp.l d2,d0						*1: cmpl %d2,%d0 | is a < b?
 bhi 4f							* bhi 4f | if b < a, exit
 beq 3f							* beq 3f | if %d0==%d2 check %d1 and %d3
2: add.l d1,d1						*2: addl %d1,%d1 | shift a by 1
 addx.l d0,d0						* addxl %d0,%d0 |
							*
 dbra d5,1b						* dbra %d5,1b | and branch back
							*
							*
							*
							*
 move.l #0,d2						* movel #0,%d2 | here no sticky bit was found
 move.l d2,d3						* movel %d2,%d3
 bra 5f							* bra 5f
3: cmp.l d1,d3						*3: cmpl %d1,%d3 | here %d0==%d2, so check %d1 and %d3
 bhi 2b							* bhi 2b | if %d1 > %d2 go back
4:							*4:
							*| Here put the sticky bit in %d2-%d3 (in the position which actually corresponds
							*| to it; if you don't do this the algorithm loses in some cases). '
 move.l #0,d2						* movel #0,%d2
 move.l d2,d3						* movel %d2,%d3
							*
 sub.w #DBL_MANT_DIG,d5					* subw #DBL_MANT_DIG,%d5
 add.w #63,d5						* addw #63,%d5
 cmp.w #31,d5						* cmpw #31,%d5
							*
							*
							*
							*
							*
 bhi 2f							* bhi 2f
1: bset d5,d3						*1: bset %d5,%d3
 bra 5f							* bra 5f
							*
 sub.w #32,d5						* subw #32,%d5
							*
							*
							*
2: bset d5,d2						*2: bset %d5,%d2
5:							*5:
							*| Finally we are finished! Move the longs in the address registers to
							*| their final destination:
 move.l d6,d0						* movel %d6,%d0
 move.l d7,d1						* movel %d7,%d1
 move.l #0,d3						* movel #0,%d3
							*
							*| Here we have finished the division, with the result in %d0-%d1-%d2-%d3, with
							*| 2^21 <= %d6 < 2^23. Thus bit 23 is not set, but bit 22 could be set.
							*| If it is not, then definitely bit 21 is set. Normalize so bit 22 is
							*| not set:
 btst #DBL_MANT_DIG-32+1,d0				* btst #DBL_MANT_DIG-32+1,%d0
 beq 1f							* beq 1f
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 roxr.l #1,d2						* roxrl #1,%d2
 roxr.l #1,d3						* roxrl #1,%d3
 add.w #1,d4						* addw #1,%d4
							*# 2028 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
1:							*1:
							*| Now round, check for over- and underflow, and exit.
 move.l a0,d7						* movel %a0,%d7 | restore sign bit to %d7
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bra _Lround$exit					* bra Lround$exit
							*
_Ldivdf$inop:						*Ldivdf$inop:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bra _Ld$inop						* bra Ld$inop
							*
_Ldivdf$a$0:						*Ldivdf$a$0:
							*| If a is zero check to see whether b is zero also. In that case return
							*| NaN; then check if b is NaN, and return NaN also in that case. Else
							*| return a properly signed zero.
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bclr #31,d2						* bclr #31,%d2 |
 move.l d2,d4						* movel %d2,%d4 |
 or.l d3,d4						* orl %d3,%d4 |
 beq _Ld$inop						* beq Ld$inop | if b is also zero return NaN
 cmp.l #0x7ff00000,d2					* cmpl #0x7ff00000,%d2 | check for NaN
 bhi _Ld$inop						* bhi Ld$inop |
 blt 1f							* blt 1f |
 tst.l d3						* tstl %d3 |
 bne _Ld$inop						* bne Ld$inop |
1: move.l a0,d0						*1: movel %a0,%d0 | else return signed zero
 moveq #0,d1						* moveq #0,%d1 |
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0 | clear exception flags
 move.w #0,(a0)						* movew #0,%a0@ |
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 |
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 |
 rts |							* rts |
							*
_Ldivdf$b$0:						*Ldivdf$b$0:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
							*| If we got here a is not zero. Check if a is NaN; in that case return NaN,
							*| else return +/-INFINITY. Remember that a is in %d0 with the sign bit
							*| cleared already.
 move.l a0,d7						* movel %a0,%d7 | put a's sign bit back in d7 '
 cmp.l #0x7ff00000,d0					* cmpl #0x7ff00000,%d0 | compare %d0 with INFINITY
 bhi _Ld$inop						* bhi Ld$inop | if larger it is NaN
 tst.l d1						* tstl %d1 |
 bne _Ld$inop						* bne Ld$inop |
 bra _Ld$div$0						* bra Ld$div$0 | else signal DIVIDE_BY_ZERO
							*
_Ldivdf$b$nf:						*Ldivdf$b$nf:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
							*| If %d2 == 0x7ff00000 we have to check %d3.
 tst.l d3						* tstl %d3 |
 bne _Ld$inop						* bne Ld$inop | if %d3 <> 0, b is NaN
 bra _Ld$underflow					* bra Ld$underflow | else b is +/-INFINITY, so signal underflow
							*
_Ldivdf$a$nf:						*Ldivdf$a$nf:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
							*| If %d0 == 0x7ff00000 we have to check %d1.
 tst.l d1						* tstl %d1 |
 bne _Ld$inop						* bne Ld$inop | if %d1 <> 0, a is NaN
							*| If a is INFINITY we have to check b
 cmp.l d7,d2						* cmpl %d7,%d2 | compare b with INFINITY
 bge _Ld$inop						* bge Ld$inop | if b is NaN or INFINITY return NaN
 tst.l d3						* tstl %d3 |
 bne _Ld$inop						* bne Ld$inop |
 bra _Ld$overflow					* bra Ld$overflow | else return overflow
							*
							*| If a number is denormalized we put an exponent of 1 but do not put the
							*| bit back into the fraction.
_Ldivdf$a$den:						*Ldivdf$a$den:
 move.l #1,d4						* movel #1,%d4
 and.l d6,d0						* andl %d6,%d0
1: add.l d1,d1						*1: addl %d1,%d1 | shift a left until bit 20 is set
 addx.l d0,d0						* addxl %d0,%d0
							*
 sub.w #1,d4						* subw #1,%d4 | and adjust exponent
							*
							*
							*
 btst #DBL_MANT_DIG-32-1,d0				* btst #DBL_MANT_DIG-32-1,%d0
 bne _Ldivdf$1						* bne Ldivdf$1
 bra 1b							* bra 1b
							*
_Ldivdf$b$den:						*Ldivdf$b$den:
 move.l #1,d5						* movel #1,%d5
 and.l d6,d2						* andl %d6,%d2
1: add.l d3,d3						*1: addl %d3,%d3 | shift b left until bit 20 is set
 addx.l d2,d2						* addxl %d2,%d2
							*
 sub.w #1,d5						* subw #1,%d5 | and adjust exponent
							*
							*
							*
 btst #DBL_MANT_DIG-32-1,d2				* btst #DBL_MANT_DIG-32-1,%d2
 bne _Ldivdf$2						* bne Ldivdf$2
 bra 1b							* bra 1b
							*
_Lround$exit:						*Lround$exit:
							*| This is a common exit point for __muldf3 and __divdf3. When they enter
							*| this point the sign of the result is in %d7, the result in %d0-%d1, normalized
							*| so that 2^21 <= %d0 < 2^22, and the exponent is in the lower byte of %d4.
							*
							*| First check for underlow in the exponent:
							*
 cmp.w #-DBL_MANT_DIG-1,d4				* cmpw #-DBL_MANT_DIG-1,%d4
							*
							*
							*
 blt _Ld$underflow					* blt Ld$underflow
							*| It could happen that the exponent is less than 1, in which case the
							*| number is denormalized. In this case we shift right and adjust the
							*| exponent until it becomes 1 or the fraction is zero (in the latter case
							*| we signal underflow and return zero).
 move.l d7,a0						* movel %d7,%a0 |
 move.l #0,d6						* movel #0,%d6 | use %d6-%d7 to collect bits flushed right
 move.l d6,d7						* movel %d6,%d7 | use %d6-%d7 to collect bits flushed right
							*
 cmp.w #1,d4						* cmpw #1,%d4 | if the exponent is less than 1 we
							*
							*
							*
 bge 2f							* bge 2f | have to shift right (denormalize)
1:							*1:
							*
 add.w #1,d4						* addw #1,%d4 | adjust the exponent
 lsr.l #1,d0						* lsrl #1,%d0 | shift right once
 roxr.l #1,d1						* roxrl #1,%d1 |
 roxr.l #1,d2						* roxrl #1,%d2 |
 roxr.l #1,d3						* roxrl #1,%d3 |
 roxr.l #1,d6						* roxrl #1,%d6 |
 roxr.l #1,d7						* roxrl #1,%d7 |
 cmp.w #1,d4						* cmpw #1,%d4 | is the exponent 1 already?
							*# 2187 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 beq 2f							* beq 2f | if not loop back
 bra 1b							* bra 1b |
 bra _Ld$underflow					* bra Ld$underflow | safety check, shouldn't execute '
2: or.l d6,d2						*2: orl %d6,%d2 | this is a trick so we don't lose  '
 or.l d7,d3						* orl %d7,%d3 | the bits which were flushed right
 move.l a0,d7						* movel %a0,%d7 | get back sign bit into %d7
							*| Now call the rounding routine (which takes care of denormalized numbers):
 lea _Lround$0(pc),a0					* lea %pc@(Lround$0),%a0 | to return from rounding routine
 PICLEA __fpCCR,a1					* PICLEA _fpCCR,%a1 | check the rounding mode
							*
							*
							*
 move.w 6(a1),d6					* movew %a1@(6),%d6 | rounding mode in %d6
 beq _Lround$to$nearest					* beq Lround$to$nearest
							*
 cmp.w #ROUND_TO_PLUS,d6				* cmpw #ROUND_TO_PLUS,%d6
							*
							*
							*
 bhi _Lround$to$minus					* bhi Lround$to$minus
 blt _Lround$to$zero					* blt Lround$to$zero
 bra _Lround$to$plus					* bra Lround$to$plus
_Lround$0:						*Lround$0:
							*| Here we have a correctly rounded result (either normalized or denormalized).
							*
							*| Here we should have either a normalized number or a denormalized one, and
							*| the exponent is necessarily larger or equal to 1 (so we don't have to  '
							*| check again for underflow!). We have to check for overflow or for a
							*| denormalized number (which also signals underflow).
							*| Check for overflow (i.e., exponent >= 0x7ff).
							*
 cmp.w #0x07ff,d4					* cmpw #0x07ff,%d4
							*
							*
							*
 bge _Ld$overflow					* bge Ld$overflow
							*| Now check for a denormalized number (exponent==0):
 move.w d4,d4						* movew %d4,%d4
 beq _Ld$den						* beq Ld$den
1:							*1:
							*| Put back the exponents and sign and return.
							*
 lsl.w #4,d4						* lslw #4,%d4 | exponent back to fourth byte
							*
							*
							*
 bclr #DBL_MANT_DIG-32-1,d0				* bclr #DBL_MANT_DIG-32-1,%d0
 swap d0						* swap %d0 | and put back exponent
							*
 or.w d4,d0						* orw %d4,%d0 |
							*
							*
							*
 swap d0						* swap %d0 |
 or.l d7,d0						* orl %d7,%d0 | and sign also
							*
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
							*
							*|=============================================================================
							*| __negdf2
							*|=============================================================================
							*
							*| double __negdf2(double, double);
							* .type __negdf2,function
___negdf2:						*__negdf2:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@-
							*
							*
							*
							*
 moveq #NEGATE,d5					* moveq #NEGATE,%d5
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get number to negate in %d0-%d1
 move.l 12(a6),d1					* movel %a6@(12),%d1 |
 bchg #31,d0						* bchg #31,%d0 | negate
 move.l d0,d2						* movel %d0,%d2 | make a positive copy (for the tests)
 bclr #31,d2						* bclr #31,%d2 |
 move.l d2,d4						* movel %d2,%d4 | check for zero
 or.l d1,d4						* orl %d1,%d4 |
 beq 2f							* beq 2f | if zero (either sign) return +zero
 cmp.l #0x7ff00000,d2					* cmpl #0x7ff00000,%d2 | compare to +INFINITY
 blt 1f							* blt 1f | if finite, return
 bhi _Ld$inop						* bhi Ld$inop | if larger (fraction not zero) is NaN
 tst.l d1						* tstl %d1 | if %d2 == 0x7ff00000 check %d1
 bne _Ld$inop						* bne Ld$inop |
 move.l d0,d7						* movel %d0,%d7 | else get sign and return INFINITY
 and.l #0x80000000,d7					* andl #0x80000000,%d7
 bra _Ld$infty						* bra Ld$infty
1: PICLEA __fpCCR,a0					*1: PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
2: bclr #31,d0						*2: bclr #31,%d0
 bra 1b							* bra 1b
							*
							*|=============================================================================
							*| __cmpdf2
							*|=============================================================================
							*
GREATER = 1						*GREATER = 1
LESS = -1						*LESS = -1
EQUAL = 0						*EQUAL = 0
							*
							*| int __cmpdf2_internal(double, double, int);
___cmpdf2_internal:					*__cmpdf2_internal:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@- | save registers
							*
							*
							*
							*
 moveq #COMPARE,d5					* moveq #COMPARE,%d5
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get first operand
 move.l 12(a6),d1					* movel %a6@(12),%d1 |
 move.l 16(a6),d2					* movel %a6@(16),%d2 | get second operand
 move.l 20(a6),d3					* movel %a6@(20),%d3 |
							*| First check if a and/or b are (+/-) zero and in that case clear
							*| the sign bit.
 move.l d0,d6						* movel %d0,%d6 | copy signs into %d6 (a) and %d7(b)
 bclr #31,d0						* bclr #31,%d0 | and clear signs in %d0 and %d2
 move.l d2,d7						* movel %d2,%d7 |
 bclr #31,d2						* bclr #31,%d2 |
 cmp.l #0x7ff00000,d0					* cmpl #0x7ff00000,%d0 | check for a == NaN
 bhi _Lcmpd$inop					* bhi Lcmpd$inop | if %d0 > 0x7ff00000, a is NaN
 beq _Lcmpdf$a$nf					* beq Lcmpdf$a$nf | if equal can be INFINITY, so check %d1
 move.l d0,d4						* movel %d0,%d4 | copy into %d4 to test for zero
 or.l d1,d4						* orl %d1,%d4 |
 beq _Lcmpdf$a$0					* beq Lcmpdf$a$0 |
_Lcmpdf$0:						*Lcmpdf$0:
 cmp.l #0x7ff00000,d2					* cmpl #0x7ff00000,%d2 | check for b == NaN
 bhi _Lcmpd$inop					* bhi Lcmpd$inop | if %d2 > 0x7ff00000, b is NaN
 beq _Lcmpdf$b$nf					* beq Lcmpdf$b$nf | if equal can be INFINITY, so check %d3
 move.l d2,d4						* movel %d2,%d4 |
 or.l d3,d4						* orl %d3,%d4 |
 beq _Lcmpdf$b$0					* beq Lcmpdf$b$0 |
_Lcmpdf$1:						*Lcmpdf$1:
							*| Check the signs
 eor.l d6,d7						* eorl %d6,%d7
 bpl 1f							* bpl 1f
							*| If the signs are not equal check if a >= 0
 tst.l d6						* tstl %d6
 bpl _Lcmpdf$a$gt$b					* bpl Lcmpdf$a$gt$b | if (a >= 0 && b < 0) => a > b
 bmi _Lcmpdf$b$gt$a					* bmi Lcmpdf$b$gt$a | if (a < 0 && b >= 0) => a < b
1:							*1:
							*| If the signs are equal check for < 0
 tst.l d6						* tstl %d6
 bpl 1f							* bpl 1f
							*| If both are negative exchange them
							*
 exg d0,d2						* exg %d0,%d2
 exg d1,d3						* exg %d1,%d3
							*# 2365 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
1:							*1:
							*| Now that they are positive we just compare them as longs (does this also
							*| work for denormalized numbers?).
 cmp.l d0,d2						* cmpl %d0,%d2
 bhi _Lcmpdf$b$gt$a					* bhi Lcmpdf$b$gt$a | |b| > |a|
 bne _Lcmpdf$a$gt$b					* bne Lcmpdf$a$gt$b | |b| < |a|
							*| If we got here %d0 == %d2, so we compare %d1 and %d3.
 cmp.l d1,d3						* cmpl %d1,%d3
 bhi _Lcmpdf$b$gt$a					* bhi Lcmpdf$b$gt$a | |b| > |a|
 bne _Lcmpdf$a$gt$b					* bne Lcmpdf$a$gt$b | |b| < |a|
							*| If we got here a == b.
 move.l #EQUAL,d0					* movel #EQUAL,%d0
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | put back the registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
_Lcmpdf$a$gt$b:						*Lcmpdf$a$gt$b:
 move.l #GREATER,d0					* movel #GREATER,%d0
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | put back the registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
_Lcmpdf$b$gt$a:						*Lcmpdf$b$gt$a:
 move.l #LESS,d0					* movel #LESS,%d0
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | put back the registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
							*
_Lcmpdf$a$0:						*Lcmpdf$a$0:
 bclr #31,d6						* bclr #31,%d6
 bra _Lcmpdf$0						* bra Lcmpdf$0
_Lcmpdf$b$0:						*Lcmpdf$b$0:
 bclr #31,d7						* bclr #31,%d7
 bra _Lcmpdf$1						* bra Lcmpdf$1
							*
_Lcmpdf$a$nf:						*Lcmpdf$a$nf:
 tst.l d1						* tstl %d1
 bne _Ld$inop						* bne Ld$inop
 bra _Lcmpdf$0						* bra Lcmpdf$0
							*
_Lcmpdf$b$nf:						*Lcmpdf$b$nf:
 tst.l d3						* tstl %d3
 bne _Ld$inop						* bne Ld$inop
 bra _Lcmpdf$1						* bra Lcmpdf$1
							*
_Lcmpd$inop:						*Lcmpd$inop:
 move.l 24(a6),d0					* movl %a6@(24),%d0
 moveq #INEXACT_RESULT+INVALID_OPERATION,d7		* moveq #INEXACT_RESULT+INVALID_OPERATION,%d7
 moveq #DOUBLE_FLOAT,d6					* moveq #DOUBLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
							*| int __cmpdf2(double, double);
							* .type __cmpdf2,function
___cmpdf2:						*__cmpdf2:
 link a6,#0						* link %a6,#0
 pea 1							* pea 1
 move.l 20(a6),-(sp)					* movl %a6@(20),%sp@-
 move.l 16(a6),-(sp)					* movl %a6@(16),%sp@-
 move.l 12(a6),-(sp)					* movl %a6@(12),%sp@-
 move.l 8(a6),-(sp)					* movl %a6@(8),%sp@-
 PICCALL ___cmpdf2_internal				* PICCALL __cmpdf2_internal
 unlk a6						* unlk %a6
 rts							* rts
							*
							*|=============================================================================
							*| rounding routines
							*|=============================================================================
							*
							*| The rounding routines expect the number to be normalized in registers
							*| %d0-%d1-%d2-%d3, with the exponent in register %d4. They assume that the
							*| exponent is larger or equal to 1. They return a properly normalized number
							*| if possible, and a denormalized number otherwise. The exponent is returned
							*| in %d4.
							*
_Lround$to$nearest:					*Lround$to$nearest:
							*| We now normalize as suggested by D. Knuth ("Seminumerical Algorithms"):
							*| Here we assume that the exponent is not too small (this should be checked
							*| before entering the rounding routine), but the number could be denormalized.
							*
							*| Check for denormalized numbers:
1: btst #DBL_MANT_DIG-32,d0				*1: btst #DBL_MANT_DIG-32,%d0
 bne 2f							* bne 2f | if set the number is normalized
							*| Normalize shifting left until bit #DBL_MANT_DIG-32 is set or the exponent
							*| is one (remember that a denormalized number corresponds to an
							*| exponent of -D_BIAS+1).
							*
 cmp.w #1,d4						* cmpw #1,%d4 | remember that the exponent is at least one
							*
							*
							*
  beq 2f						*  beq 2f | an exponent of one means denormalized
 add.l d3,d3						* addl %d3,%d3 | else shift and adjust the exponent
 addx.l d2,d2						* addxl %d2,%d2 |
 addx.l d1,d1						* addxl %d1,%d1 |
 addx.l d0,d0						* addxl %d0,%d0 |
							*
 dbra d4,1b						* dbra %d4,1b |
							*
							*
							*
							*
2:							*2:
							*| Now round: we do it as follows: after the shifting we can write the
							*| fraction part as f + delta, where 1 < f < 2^25, and 0 <= delta <= 2.
							*| If delta < 1, do nothing. If delta > 1, add 1 to f.
							*| If delta == 1, we make sure the rounded number will be even (odd?)
							*| (after shifting).
 btst #0,d1						* btst #0,%d1 | is delta < 1?
 beq 2f							* beq 2f | if so, do not do anything
 or.l d2,d3						* orl %d2,%d3 | is delta == 1?
 bne 1f							* bne 1f | if so round to even
 move.l d1,d3						* movel %d1,%d3 |
 and.l #2,d3						* andl #2,%d3 | bit 1 is the last significant bit
 move.l #0,d2						* movel #0,%d2 |
 add.l d3,d1						* addl %d3,%d1 |
 addx.l d2,d0						* addxl %d2,%d0 |
 bra 2f							* bra 2f |
1: move.l #1,d3						*1: movel #1,%d3 | else add 1
 move.l #0,d2						* movel #0,%d2 |
 add.l d3,d1						* addl %d3,%d1 |
 addx.l d2,d0						* addxl %d2,%d0
							*| Shift right once (because we used bit #DBL_MANT_DIG-32!).
2:							*2:
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
							*# 2515 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| Now check again bit #DBL_MANT_DIG-32 (rounding could have produced a
							*| 'fraction overflow' ...).
 btst #DBL_MANT_DIG-32,d0				* btst #DBL_MANT_DIG-32,%d0
 beq 1f							* beq 1f
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 add.w #1,d4						* addw #1,%d4
							*# 2531 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
1:							*1:
							*| If bit #DBL_MANT_DIG-32-1 is clear we have a denormalized number, so we
							*| have to put the exponent to zero and return a denormalized number.
 btst #DBL_MANT_DIG-32-1,d0				* btst #DBL_MANT_DIG-32-1,%d0
 beq 1f							* beq 1f
 jmp (a0)						* jmp %a0@
1: move.l #0,d4						*1: movel #0,%d4
 jmp (a0)						* jmp %a0@
							*
_Lround$to$zero:					*Lround$to$zero:
_Lround$to$plus:					*Lround$to$plus:
_Lround$to$minus:					*Lround$to$minus:
 jmp (a0)						* jmp %a0@
							*# 3930 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
