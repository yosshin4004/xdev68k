* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___floatunsidf				*	.globl	__floatunsidf
	.globl	___muldf3				*	.globl	__muldf3
	.globl	___adddf3				*	.globl	__adddf3
	.align	2					*	.align	2
	.globl	___floatundidf				*	.globl	__floatundidf
							*	.hidden	__floatundidf
							*	.type	__floatundidf, @function
___floatundidf:						*__floatundidf:
	movem.l d4/d5/a3,-(sp)				*	movem.l #3088,-(%sp)
	lea ___floatunsidf,a3				*	lea __floatunsidf,%a3
	move.l 16(sp),-(sp)				*	move.l 16(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	clr.l (sp)					*	clr.l (%sp)
	move.l #1106247680,-(sp)			*	move.l #1106247680,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldf3					*	jsr __muldf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l 20(sp),-(sp)				*	move.l 20(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d5,(sp)					*	move.l %d5,(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___adddf3					*	jsr __adddf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	movem.l (sp)+,d4/d5/a3				*	movem.l (%sp)+,#2096
	rts						*	rts
							*	.size	__floatundidf, .-__floatundidf
							*	.ident	"GCC: (GNU) 13.4.0"
