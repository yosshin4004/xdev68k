* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clear_cache				*	.globl	__clear_cache
							*	.hidden	__clear_cache
							*	.type	__clear_cache, @function
___clear_cache:						*__clear_cache:
	rts						*	rts
							*	.size	__clear_cache, .-__clear_cache
							*	.ident	"GCC: (GNU) 13.4.0"
