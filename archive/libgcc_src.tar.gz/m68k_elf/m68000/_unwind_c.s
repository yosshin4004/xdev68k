* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"unwind-c.c"				*	.file	"unwind-c.c"
	.text						*	.text
	.align	2					*	.align	2
							*	.type	base_of_encoded_value, @function
_base_of_encoded_value:					*base_of_encoded_value:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L1					*	jeq .L1
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbeq _?L3					*	jeq .L3
	jbhi _?L4					*	jhi .L4
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbne _?L14					*	jne .L14
	move.l d1,4(sp)					*	move.l %d1,4(%sp)
	jbra __Unwind_GetTextRelBase			*	jra _Unwind_GetTextRelBase
_?L4:							*.L4:
	cmp.b #64,d0					*	cmp.b #64,%d0
	jbne _?L15					*	jne .L15
	move.l d1,4(sp)					*	move.l %d1,4(%sp)
	jbra __Unwind_GetRegionStart			*	jra _Unwind_GetRegionStart
_?L14:							*.L14:
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbhi _?L6					*	jhi .L6
_?L1:							*.L1:
	moveq #0,d0					*	moveq #0,%d0
	rts						*	rts
_?L15:							*.L15:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L1					*	jeq .L1
_?L6:							*.L6:
	trap #7						*	trap #7
_?L3:							*.L3:
	move.l d1,4(sp)					*	move.l %d1,4(%sp)
	jbra __Unwind_GetDataRelBase			*	jra _Unwind_GetDataRelBase
							*	.size	base_of_encoded_value, .-base_of_encoded_value
	.align	2					*	.align	2
							*	.type	read_encoded_value_with_base, @function
_read_encoded_value_with_base:				*read_encoded_value_with_base:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d2				*	move.l 16(%sp),%d2
	move.l 24(sp),a1				*	move.l 24(%sp),%a1
	move.b d2,d3					*	move.b %d2,%d3
	cmp.b #80,d2					*	cmp.b #80,%d2
	jbeq _?L46					*	jeq .L46
	move.b d2,d0					*	move.b %d2,%d0
	and.b #15,d0					*	and.b #15,%d0
	cmp.b #12,d0					*	cmp.b #12,%d0
	jbhi _?L19					*	jhi .L19
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w _?L21(pc,d0.l),d0			*	move.w .L21(%pc,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&13
_?L21:							*.L21:
	.dc.w _?L22-_?L21				*	.word .L22-.L21
	.dc.w _?L33-_?L21				*	.word .L33-.L21
	.dc.w _?L27-_?L21				*	.word .L27-.L21
	.dc.w _?L22-_?L21				*	.word .L22-.L21
	.dc.w _?L20-_?L21				*	.word .L20-.L21
	.dc.w _?L19-_?L21				*	.word .L19-.L21
	.dc.w _?L19-_?L21				*	.word .L19-.L21
	.dc.w _?L19-_?L21				*	.word .L19-.L21
	.dc.w _?L19-_?L21				*	.word .L19-.L21
	.dc.w _?L34-_?L21				*	.word .L34-.L21
	.dc.w _?L23-_?L21				*	.word .L23-.L21
	.dc.w _?L22-_?L21				*	.word .L22-.L21
	.dc.w _?L20-_?L21				*	.word .L20-.L21
_?L22:							*.L22:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.w #8,d1					*	lsl.w #8,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 3(a1),d1					*	or.b 3(%a1),%d1
	lea (4,a1),a0					*	lea (4,%a1),%a0
_?L30:							*.L30:
	tst.l d1					*	tst.l %d1
	jbne _?L31					*	jne .L31
_?L18:							*.L18:
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L34:							*.L34:
	move.l a1,a0					*	move.l %a1,%a0
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d4					*	moveq #0,%d4
_?L24:							*.L24:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L24					*	jlt .L24
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L30					*	jcs .L30
	btst #6,d5					*	btst #6,%d5
	jbeq _?L30					*	jeq .L30
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
_?L31:							*.L31:
	and.b #112,d2					*	and.b #112,%d2
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbeq _?L47					*	jeq .L47
	add.l 20(sp),d1					*	add.l 20(%sp),%d1
	tst.b d3					*	tst.b %d3
	jbge _?L18					*	jge .L18
_?L48:							*.L48:
	move.l d1,a1					*	move.l %d1,%a1
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L46:							*.L46:
	lea (3,a1),a0					*	lea (3,%a1),%a0
	move.l a0,d0					*	move.l %a0,%d0
	moveq #-4,d1					*	moveq #-4,%d1
	and.l d1,d0					*	and.l %d1,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.l (a0)+,d1					*	move.l (%a0)+,%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L47:							*.L47:
	move.l a1,20(sp)				*	move.l %a1,20(%sp)
	add.l 20(sp),d1					*	add.l 20(%sp),%d1
	tst.b d3					*	tst.b %d3
	jbge _?L18					*	jge .L18
	jbra _?L48					*	jra .L48
_?L20:							*.L20:
	moveq #0,d1					*	moveq #0,%d1
	move.b 4(a1),d1					*	move.b 4(%a1),%d1
	lsl.w #8,d1					*	lsl.w #8,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 5(a1),d0					*	move.b 5(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 6(a1),d1					*	move.b 6(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 7(a1),d1					*	or.b 7(%a1),%d1
	lea (8,a1),a0					*	lea (8,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L18					*	jeq .L18
	jbra _?L31					*	jra .L31
_?L27:							*.L27:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L18					*	jeq .L18
	jbra _?L31					*	jra .L31
_?L23:							*.L23:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	ext.l d1					*	ext.l %d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L18					*	jeq .L18
	jbra _?L31					*	jra .L31
_?L33:							*.L33:
	move.l a1,a0					*	move.l %a1,%a0
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d4					*	moveq #0,%d4
_?L28:							*.L28:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jbge _?L30					*	jge .L30
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L28					*	jlt .L28
	jbra _?L30					*	jra .L30
_?L19:							*.L19:
	trap #7						*	trap #7
							*	.size	read_encoded_value_with_base, .-read_encoded_value_with_base
	.align	2					*	.align	2
	.globl	___gcc_personality_v0			*	.globl	__gcc_personality_v0
							*	.hidden	__gcc_personality_v0
							*	.type	__gcc_personality_v0, @function
___gcc_personality_v0:					*__gcc_personality_v0:
	link.w a6,#-48					*	link.w %fp,#-48
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	clr.l -38(a6)					*	clr.l -38(%fp)
	moveq #1,d0					*	moveq #1,%d0
	cmp.l 8(a6),d0					*	cmp.l 8(%fp),%d0
	jbne _?L73					*	jne .L73
	btst #1,15(a6)					*	btst #1,15(%fp)
	jbne _?L92					*	jne .L92
_?L52:							*.L52:
	moveq #8,d0					*	moveq #8,%d0
	movem.l -80(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -80(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L73:							*.L73:
	moveq #3,d0					*	moveq #3,%d0
	movem.l -80(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -80(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L92:							*.L92:
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	jbsr __Unwind_GetLanguageSpecificData		*	jsr _Unwind_GetLanguageSpecificData
	move.l d0,a0					*	move.l %d0,%a0
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L52					*	jeq .L52
	tst.l 28(a6)					*	tst.l 28(%fp)
	jbeq _?L74					*	jeq .L74
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	move.l d0,-46(a6)				*	move.l %d0,-46(%fp)
	jbsr __Unwind_GetRegionStart			*	jsr _Unwind_GetRegionStart
	move.l d0,-42(a6)				*	move.l %d0,-42(%fp)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l -46(a6),a0				*	move.l -46(%fp),%a0
_?L54:							*.L54:
	move.l -42(a6),-22(a6)				*	move.l -42(%fp),-22(%fp)
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L55					*	jeq .L55
	moveq #0,d3					*	moveq #0,%d3
	move.b d0,d3					*	move.b %d0,%d3
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbeq _?L56					*	jeq .L56
	jbhi _?L57					*	jhi .L57
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbne _?L93					*	jne .L93
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	move.l a0,-46(a6)				*	move.l %a0,-46(%fp)
	jbsr __Unwind_GetTextRelBase			*	jsr _Unwind_GetTextRelBase
	move.l d0,d1					*	move.l %d0,%d1
	addq.l #4,sp					*	addq.l #4,%sp
	move.l -46(a6),a0				*	move.l -46(%fp),%a0
_?L60:							*.L60:
	pea -18(a6)					*	pea -18(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l d0,a0					*	move.l %d0,%a0
	lea (16,sp),sp					*	lea (16,%sp),%sp
_?L62:							*.L62:
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	move.b d0,-2(a6)				*	move.b %d0,-2(%fp)
	moveq #0,d3					*	moveq #0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L63					*	jeq .L63
	moveq #0,d1					*	moveq #0,%d1
_?L64:							*.L64:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L64					*	jlt .L64
	add.l a0,d3					*	add.l %a0,%d3
_?L63:							*.L63:
	move.l d3,-10(a6)				*	move.l %d3,-10(%fp)
	move.l a0,a5					*	move.l %a0,%a5
	move.b (a5)+,d3					*	move.b (%a5)+,%d3
	move.b d3,-1(a6)				*	move.b %d3,-1(%fp)
	moveq #0,d5					*	moveq #0,%d5
	moveq #0,d1					*	moveq #0,%d1
_?L65:							*.L65:
	move.b (a5)+,d2					*	move.b (%a5)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L65					*	jlt .L65
	add.l a5,d5					*	add.l %a5,%d5
	move.l d5,-6(a6)				*	move.l %d5,-6(%fp)
	pea -38(a6)					*	pea -38(%fp)
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	jbsr __Unwind_GetIPInfo				*	jsr _Unwind_GetIPInfo
	move.l d0,d6					*	move.l %d0,%d6
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l -38(a6)					*	tst.l -38(%fp)
	jbne _?L66					*	jne .L66
	subq.l #1,d6					*	subq.l #1,%d6
_?L66:							*.L66:
	cmp.l a5,d5					*	cmp.l %a5,%d5
	jbls _?L52					*	jls .L52
	and.l #255,d3					*	and.l #255,%d3
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
	lea _base_of_encoded_value,a3			*	lea base_of_encoded_value,%a3
	moveq #-34,d7					*	moveq #-34,%d7
	add.l a6,d7					*	add.l %fp,%d7
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,d4					*	move.l %d0,%d4
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (32,sp),sp					*	lea (32,%sp),%sp
	pea -30(a6)					*	pea -30(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,d4					*	move.l %d0,%d4
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	pea -26(a6)					*	pea -26(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,a5					*	move.l %d0,%a5
	lea (40,sp),sp					*	lea (40,%sp),%sp
_?L67:							*.L67:
	tst.b (a5)+					*	tst.b (%a5)+
	jblt _?L67					*	jlt .L67
	move.l -42(a6),d0				*	move.l -42(%fp),%d0
	add.l -34(a6),d0				*	add.l -34(%fp),%d0
	cmp.l d0,d6					*	cmp.l %d0,%d6
	jbcs _?L52					*	jcs .L52
	add.l -30(a6),d0				*	add.l -30(%fp),%d0
	cmp.l d0,d6					*	cmp.l %d0,%d6
	jbcs _?L94					*	jcs .L94
	cmp.l a5,d5					*	cmp.l %a5,%d5
	jbls _?L52					*	jls .L52
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,d4					*	move.l %d0,%d4
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (32,sp),sp					*	lea (32,%sp),%sp
	pea -30(a6)					*	pea -30(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,d4					*	move.l %d0,%d4
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	pea -26(a6)					*	pea -26(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,a5					*	move.l %d0,%a5
	lea (40,sp),sp					*	lea (40,%sp),%sp
	jbra _?L67					*	jra .L67
_?L55:							*.L55:
	move.l -42(a6),-18(a6)				*	move.l -42(%fp),-18(%fp)
	jbra _?L62					*	jra .L62
_?L74:							*.L74:
	clr.l -42(a6)					*	clr.l -42(%fp)
	jbra _?L54					*	jra .L54
_?L94:							*.L94:
	move.l -26(a6),d0				*	move.l -26(%fp),%d0
	jbeq _?L52					*	jeq .L52
	move.l d0,d3					*	move.l %d0,%d3
	add.l -18(a6),d3				*	add.l -18(%fp),%d3
	jbeq _?L52					*	jeq .L52
	move.l 24(a6),-(sp)				*	move.l 24(%fp),-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	lea __Unwind_SetGR,a3				*	lea _Unwind_SetGR,%a3
	jbsr (a3)					*	jsr (%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	pea 1.w						*	pea 1.w
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	jbsr __Unwind_SetIP				*	jsr _Unwind_SetIP
	lea (32,sp),sp					*	lea (32,%sp),%sp
	moveq #7,d0					*	moveq #7,%d0
	movem.l -80(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -80(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L57:							*.L57:
	cmp.b #64,d0					*	cmp.b #64,%d0
	jbne _?L95					*	jne .L95
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	move.l a0,-46(a6)				*	move.l %a0,-46(%fp)
	jbsr __Unwind_GetRegionStart			*	jsr _Unwind_GetRegionStart
	move.l d0,d1					*	move.l %d0,%d1
	addq.l #4,sp					*	addq.l #4,%sp
	move.l -46(a6),a0				*	move.l -46(%fp),%a0
	pea -18(a6)					*	pea -18(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l d0,a0					*	move.l %d0,%a0
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L62					*	jra .L62
_?L56:							*.L56:
	move.l 28(a6),-(sp)				*	move.l 28(%fp),-(%sp)
	move.l a0,-46(a6)				*	move.l %a0,-46(%fp)
	jbsr __Unwind_GetDataRelBase			*	jsr _Unwind_GetDataRelBase
	move.l d0,d1					*	move.l %d0,%d1
	addq.l #4,sp					*	addq.l #4,%sp
	move.l -46(a6),a0				*	move.l -46(%fp),%a0
	pea -18(a6)					*	pea -18(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l d0,a0					*	move.l %d0,%a0
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L62					*	jra .L62
_?L93:							*.L93:
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbhi _?L59					*	jhi .L59
	moveq #0,d1					*	moveq #0,%d1
	pea -18(a6)					*	pea -18(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l d0,a0					*	move.l %d0,%a0
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L62					*	jra .L62
_?L95:							*.L95:
	moveq #0,d1					*	moveq #0,%d1
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L60					*	jeq .L60
_?L59:							*.L59:
	trap #7						*	trap #7
							*	.size	__gcc_personality_v0, .-__gcc_personality_v0
							*	.ident	"GCC: (GNU) 13.4.0"
