* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clrsbsi2				*	.globl	__clrsbsi2
							*	.hidden	__clrsbsi2
							*	.type	__clrsbsi2, @function
___clrsbsi2:						*__clrsbsi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l d0,d1					*	move.l %d0,%d1
	add.l d1,d1					*	add.l %d1,%d1
	subx.l d1,d1					*	subx.l %d1,%d1
	move.l d0,d2					*	move.l %d0,%d2
	eor.l d1,d2					*	eor.l %d1,%d2
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L5					*	jeq .L5
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbgt _?L3					*	jgt .L3
	cmp.l #255,d2					*	cmp.l #255,%d2
	sgt d1						*	sgt %d1
	ext.w d1					*	ext.w %d1
	ext.l d1					*	ext.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	moveq #31,d0					*	moveq #31,%d0
	sub.l d1,d0					*	sub.l %d1,%d0
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d1					*	moveq #0,%d1
	move.b (a0,d2.l),d1				*	move.b (%a0,%d2.l),%d1
	sub.l d1,d0					*	sub.l %d1,%d0
_?L1:							*.L1:
	rts						*	rts
_?L3:							*.L3:
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbgt _?L6					*	jgt .L6
	moveq #15,d0					*	moveq #15,%d0
	moveq #16,d1					*	moveq #16,%d1
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d1					*	moveq #0,%d1
	move.b (a0,d2.l),d1				*	move.b (%a0,%d2.l),%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	jbra _?L1					*	jra .L1
_?L5:							*.L5:
	moveq #31,d0					*	moveq #31,%d0
	rts						*	rts
_?L6:							*.L6:
	moveq #7,d0					*	moveq #7,%d0
	moveq #24,d1					*	moveq #24,%d1
	lsr.l d1,d2					*	lsr.l %d1,%d2
	lea ___clz_tab,a0				*	lea __clz_tab,%a0
	moveq #0,d1					*	moveq #0,%d1
	move.b (a0,d2.l),d1				*	move.b (%a0,%d2.l),%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	jbra _?L1					*	jra .L1
							*	.size	__clrsbsi2, .-__clrsbsi2
							*	.ident	"GCC: (GNU) 13.4.0"
