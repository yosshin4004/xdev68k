* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___floatunsidf				*	.globl	__floatunsidf
	.globl	___muldf3				*	.globl	__muldf3
	.globl	___adddf3				*	.globl	__adddf3
	.globl	___truncdfsf2				*	.globl	__truncdfsf2
	.align	2					*	.align	2
	.globl	___floatundisf				*	.globl	__floatundisf
							*	.hidden	__floatundisf
							*	.type	__floatundisf, @function
___floatundisf:						*__floatundisf:
	movem.l d4/d5/d6/d7/a3,-(sp)			*	movem.l #3856,-(%sp)
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	move.l #2097151,d0				*	move.l #2097151,%d0
	moveq #-1,d1					*	moveq #-1,%d1
	sub.l d5,d1					*	sub.l %d5,%d1
	subx.l d4,d0					*	subx.l %d4,%d0
	jbcc _?L2					*	jcc .L2
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	move.l d5,d1					*	move.l %d5,%d1
	and.l #2047,d1					*	and.l #2047,%d1
	move.l d0,d2					*	move.l %d0,%d2
	or.l d1,d2					*	or.l %d1,%d2
	jbeq _?L2					*	jeq .L2
	move.l d5,d0					*	move.l %d5,%d0
	and.w #63488,d0					*	and.w #63488,%d0
	move.l d0,d5					*	move.l %d0,%d5
	or.w #2048,d5					*	or.w #2048,%d5
_?L2:							*.L2:
	lea ___floatunsidf,a3				*	lea __floatunsidf,%a3
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	clr.l (sp)					*	clr.l (%sp)
	move.l #1106247680,-(sp)			*	move.l #1106247680,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___muldf3					*	jsr __muldf3
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d6					*	move.l %d0,%d6
	move.l d1,d7					*	move.l %d1,%d7
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d7,(sp)					*	move.l %d7,(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___adddf3					*	jsr __adddf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___truncdfsf2				*	jsr __truncdfsf2
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2288
	rts						*	rts
							*	.size	__floatundisf, .-__floatundisf
							*	.ident	"GCC: (GNU) 13.4.0"
