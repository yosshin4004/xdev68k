* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"unwind-dw2-fde.c"			*	.file	"unwind-dw2-fde.c"
	.text						*	.text
	.align	2					*	.align	2
							*	.type	frame_downheap, @function
_frame_downheap:					*frame_downheap:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d5				*	move.l 40(%sp),%d5
	move.l 44(sp),a4				*	move.l 44(%sp),%a4
	move.l 48(sp),a3				*	move.l 48(%sp),%a3
	move.l 56(sp),d4				*	move.l 56(%sp),%d4
	move.l 52(sp),d3				*	move.l 52(%sp),%d3
	add.l d3,d3					*	add.l %d3,%d3
	move.l d3,d7					*	move.l %d3,%d7
	addq.l #1,d7					*	addq.l #1,%d7
	cmp.l d7,d4					*	cmp.l %d7,%d4
	jble _?L1					*	jle .L1
_?L2:							*.L2:
	move.l d7,d6					*	move.l %d7,%d6
	addq.l #1,d6					*	addq.l #1,%d6
	move.l d7,d0					*	move.l %d7,%d0
	add.l d7,d0					*	add.l %d7,%d0
	add.l d0,d0					*	add.l %d0,%d0
	lea (a3,d0.l),a6				*	lea (%a3,%d0.l),%a6
	cmp.l d6,d4					*	cmp.l %d6,%d4
	jble _?L3					*	jle .L3
	lea 4(a3,d0.l),a5				*	lea 4(%a3,%d0.l),%a5
	move.l (a5),-(sp)				*	move.l (%a5),-(%sp)
	move.l (a6),-(sp)				*	move.l (%a6),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	tst.l d0					*	tst.l %d0
	jblt _?L4					*	jlt .L4
_?L3:							*.L3:
	move.l a6,a5					*	move.l %a6,%a5
	move.l d7,d6					*	move.l %d7,%d6
_?L4:							*.L4:
	add.l d3,d3					*	add.l %d3,%d3
	lea (a3,d3.l),a6				*	lea (%a3,%d3.l),%a6
	move.l (a5),-(sp)				*	move.l (%a5),-(%sp)
	move.l (a6),-(sp)				*	move.l (%a6),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbge _?L1					*	jge .L1
	move.l (a6),d0					*	move.l (%a6),%d0
	move.l (a5),(a6)				*	move.l (%a5),(%a6)
	move.l d0,(a5)					*	move.l %d0,(%a5)
	move.l d6,d3					*	move.l %d6,%d3
	add.l d6,d3					*	add.l %d6,%d3
	move.l d3,d7					*	move.l %d3,%d7
	addq.l #1,d7					*	addq.l #1,%d7
	cmp.l d4,d7					*	cmp.l %d4,%d7
	jblt _?L2					*	jlt .L2
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
							*	.size	frame_downheap, .-frame_downheap
	.align	2					*	.align	2
							*	.type	read_encoded_value_with_base, @function
_read_encoded_value_with_base:				*read_encoded_value_with_base:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d2				*	move.l 16(%sp),%d2
	move.l 24(sp),a1				*	move.l 24(%sp),%a1
	move.b d2,d3					*	move.b %d2,%d3
	cmp.b #80,d2					*	cmp.b #80,%d2
	jbeq _?L40					*	jeq .L40
	move.b d2,d0					*	move.b %d2,%d0
	and.b #15,d0					*	and.b #15,%d0
	cmp.b #12,d0					*	cmp.b #12,%d0
	jbhi _?L13					*	jhi .L13
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w _?L15(pc,d0.l),d0			*	move.w .L15(%pc,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&13
_?L15:							*.L15:
	.dc.w _?L16-_?L15				*	.word .L16-.L15
	.dc.w _?L27-_?L15				*	.word .L27-.L15
	.dc.w _?L21-_?L15				*	.word .L21-.L15
	.dc.w _?L16-_?L15				*	.word .L16-.L15
	.dc.w _?L14-_?L15				*	.word .L14-.L15
	.dc.w _?L13-_?L15				*	.word .L13-.L15
	.dc.w _?L13-_?L15				*	.word .L13-.L15
	.dc.w _?L13-_?L15				*	.word .L13-.L15
	.dc.w _?L13-_?L15				*	.word .L13-.L15
	.dc.w _?L28-_?L15				*	.word .L28-.L15
	.dc.w _?L17-_?L15				*	.word .L17-.L15
	.dc.w _?L16-_?L15				*	.word .L16-.L15
	.dc.w _?L14-_?L15				*	.word .L14-.L15
_?L16:							*.L16:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.w #8,d1					*	lsl.w #8,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 3(a1),d1					*	or.b 3(%a1),%d1
	lea (4,a1),a0					*	lea (4,%a1),%a0
_?L24:							*.L24:
	tst.l d1					*	tst.l %d1
	jbne _?L25					*	jne .L25
_?L12:							*.L12:
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L28:							*.L28:
	move.l a1,a0					*	move.l %a1,%a0
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d4					*	moveq #0,%d4
_?L18:							*.L18:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L18					*	jlt .L18
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L24					*	jcs .L24
	btst #6,d5					*	btst #6,%d5
	jbeq _?L24					*	jeq .L24
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
_?L25:							*.L25:
	and.b #112,d2					*	and.b #112,%d2
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbeq _?L41					*	jeq .L41
	add.l 20(sp),d1					*	add.l 20(%sp),%d1
	tst.b d3					*	tst.b %d3
	jbge _?L12					*	jge .L12
_?L42:							*.L42:
	move.l d1,a1					*	move.l %d1,%a1
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L40:							*.L40:
	lea (3,a1),a0					*	lea (3,%a1),%a0
	move.l a0,d0					*	move.l %a0,%d0
	moveq #-4,d1					*	moveq #-4,%d1
	and.l d1,d0					*	and.l %d1,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.l (a0)+,d1					*	move.l (%a0)+,%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L41:							*.L41:
	move.l a1,20(sp)				*	move.l %a1,20(%sp)
	add.l 20(sp),d1					*	add.l 20(%sp),%d1
	tst.b d3					*	tst.b %d3
	jbge _?L12					*	jge .L12
	jbra _?L42					*	jra .L42
_?L14:							*.L14:
	moveq #0,d1					*	moveq #0,%d1
	move.b 4(a1),d1					*	move.b 4(%a1),%d1
	lsl.w #8,d1					*	lsl.w #8,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	moveq #0,d0					*	moveq #0,%d0
	move.b 5(a1),d0					*	move.b 5(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	moveq #0,d1					*	moveq #0,%d1
	move.b 6(a1),d1					*	move.b 6(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 7(a1),d1					*	or.b 7(%a1),%d1
	lea (8,a1),a0					*	lea (8,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L12					*	jeq .L12
	jbra _?L25					*	jra .L25
_?L21:							*.L21:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L12					*	jeq .L12
	jbra _?L25					*	jra .L25
_?L17:							*.L17:
	moveq #0,d1					*	moveq #0,%d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	ext.l d1					*	ext.l %d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L12					*	jeq .L12
	jbra _?L25					*	jra .L25
_?L27:							*.L27:
	move.l a1,a0					*	move.l %a1,%a0
	moveq #0,d1					*	moveq #0,%d1
	moveq #0,d4					*	moveq #0,%d4
_?L22:							*.L22:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jbge _?L24					*	jge .L24
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L22					*	jlt .L22
	jbra _?L24					*	jra .L24
_?L13:							*.L13:
	trap #7						*	trap #7
							*	.size	read_encoded_value_with_base, .-read_encoded_value_with_base
	.align	2					*	.align	2
							*	.type	fde_unencoded_compare, @function
_fde_unencoded_compare:					*fde_unencoded_compare:
	subq.l #8,sp					*	subq.l #8,%sp
	move.l 16(sp),a1				*	move.l 16(%sp),%a1
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.b 8(a1),(sp)				*	move.b 8(%a1),(%sp)
	move.b 9(a1),1(sp)				*	move.b 9(%a1),1(%sp)
	move.b 10(a1),2(sp)				*	move.b 10(%a1),2(%sp)
	move.b 11(a1),3(sp)				*	move.b 11(%a1),3(%sp)
	move.b 8(a0),4(sp)				*	move.b 8(%a0),4(%sp)
	move.b 9(a0),5(sp)				*	move.b 9(%a0),5(%sp)
	move.b 10(a0),6(sp)				*	move.b 10(%a0),6(%sp)
	move.b 11(a0),7(sp)				*	move.b 11(%a0),7(%sp)
	move.l (sp),d0					*	move.l (%sp),%d0
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L45					*	jcs .L45
	shi d0						*	shi %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
_?L45:							*.L45:
	moveq #1,d0					*	moveq #1,%d0
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
							*	.size	fde_unencoded_compare, .-fde_unencoded_compare
	.align	2					*	.align	2
							*	.type	fde_unencoded_extract, @function
_fde_unencoded_extract:					*fde_unencoded_extract:
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	jble _?L48					*	jle .L48
	move.l 12(sp),a2				*	move.l 12(%sp),%a2
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	add.l d1,d1					*	add.l %d1,%d1
	add.l d1,d1					*	add.l %d1,%d1
	add.l a2,d1					*	add.l %a2,%d1
_?L50:							*.L50:
	move.l (a2)+,a1					*	move.l (%a2)+,%a1
	move.l d0,a0					*	move.l %d0,%a0
	move.b 8(a1),(a0)+				*	move.b 8(%a1),(%a0)+
	move.b 9(a1),(a0)+				*	move.b 9(%a1),(%a0)+
	move.b 10(a1),(a0)+				*	move.b 10(%a1),(%a0)+
	move.b 11(a1),(a0)				*	move.b 11(%a1),(%a0)
	addq.l #4,d0					*	addq.l #4,%d0
	cmp.l a2,d1					*	cmp.l %a2,%d1
	jbne _?L50					*	jne .L50
_?L48:							*.L48:
	rts						*	rts
							*	.size	fde_unencoded_extract, .-fde_unencoded_extract
	.align	2					*	.align	2
							*	.type	fde_radixsort, @function
_fde_radixsort:						*fde_radixsort:
	lea (-1560,sp),sp				*	lea (-1560,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 1600(sp),40(sp)				*	move.l 1600(%sp),40(%sp)
	move.l 1604(sp),a3				*	move.l 1604(%sp),%a3
	move.l 1608(sp),a0				*	move.l 1608(%sp),%a0
	move.l 1612(sp),a4				*	move.l 1612(%sp),%a4
	lea (8,a0),a1					*	lea (8,%a0),%a1
	move.l a1,52(sp)				*	move.l %a1,52(%sp)
	move.l 4(a0),d5					*	move.l 4(%a0),%d5
	pea 1024.w					*	pea 1024.w
	clr.l -(sp)					*	clr.l -(%sp)
	pea 580(sp)					*	pea 580(%sp)
	jbsr _memset					*	jsr memset
	lea (12,sp),sp					*	lea (12,%sp),%sp
	tst.l d5					*	tst.l %d5
	jbeq _?L70					*	jeq .L70
	addq.l #8,a4					*	addq.l #8,%a4
	move.l 52(sp),44(sp)				*	move.l 52(%sp),44(%sp)
	moveq #0,d7					*	moveq #0,%d7
	moveq #60,d6					*	moveq #60,%d6
	add.l sp,d6					*	add.l %sp,%d6
	move.l d6,36(sp)				*	move.l %d6,36(%sp)
	sub.l a6,a6					*	sub.l %a6,%a6
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d4					*	moveq #0,%d4
	move.l a4,48(sp)				*	move.l %a4,48(%sp)
	move.l 44(sp),a5				*	move.l 44(%sp),%a5
	move.l d5,a4					*	move.l %d5,%a4
_?L59:							*.L59:
	move.l a4,d5					*	move.l %a4,%d5
	sub.l a6,d5					*	sub.l %a6,%d5
	cmp.l #128,d5					*	cmp.l #128,%d5
	jbls _?L56					*	jls .L56
	moveq #127,d5					*	moveq #127,%d5
	not.b d5					*	not.b %d5
_?L56:							*.L56:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a6,d0					*	move.l %a6,%d0
	add.l a6,d0					*	add.l %a6,%d0
	add.l d0,d0					*	add.l %d0,%d0
	pea (a5,d0.l)					*	pea (%a5,%d0.l)
	move.l 44(sp),-(sp)				*	move.l 44(%sp),-(%sp)
	move.l 52(sp),-(sp)				*	move.l 52(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d3,72(sp)				*	move.l %d3,72(%sp)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l a4,a6					*	cmp.l %a4,%a6
	jbeq _?L86					*	jeq .L86
	move.l 36(sp),a1				*	move.l 36(%sp),%a1
	move.l d5,d2					*	move.l %d5,%d2
	add.l d5,d2					*	add.l %d5,%d2
	move.l d2,d1					*	move.l %d2,%d1
	add.l d2,d1					*	add.l %d2,%d1
	add.l a1,d1					*	add.l %a1,%d1
	move.l d2,a2					*	move.l %d2,%a2
_?L58:							*.L58:
	move.l d3,d0					*	move.l %d3,%d0
	move.l (a1)+,d3					*	move.l (%a1)+,%d3
	move.l d3,d6					*	move.l %d3,%d6
	lsr.l d7,d6					*	lsr.l %d7,%d6
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d6,d2					*	and.l %d6,%d2
	move.l d2,a0					*	move.l %d2,%a0
	add.l d2,a0					*	add.l %d2,%a0
	add.l a0,a0					*	add.l %a0,%a0
	move.l #1596,d2					*	move.l #1596,%d2
	add.l sp,d2					*	add.l %sp,%d2
	add.l d2,a0					*	add.l %d2,%a0
	addq.l #1,-1024(a0)				*	addq.l #1,-1024(%a0)
	cmp.l d3,d0					*	cmp.l %d3,%d0
	shi d0						*	shi %d0
	ext.w d0					*	ext.w %d0
	move.w d0,a0					*	move.w %d0,%a0
	sub.l a0,d4					*	sub.l %a0,%d4
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbne _?L58					*	jne .L58
	move.l a2,d2					*	move.l %a2,%d2
	add.l d5,a6					*	add.l %d5,%a6
	add.l d2,d2					*	add.l %d2,%d2
	lea (1596,sp),a0				*	lea (1596,%sp),%a0
	add.l d2,a0					*	add.l %d2,%a0
	move.l -1540(a0),d3				*	move.l -1540(%a0),%d3
	cmp.l a4,a6					*	cmp.l %a4,%a6
	jbcs _?L59					*	jcs .L59
_?L87:							*.L87:
	move.l a4,d5					*	move.l %a4,%d5
	move.l 48(sp),a4				*	move.l 48(%sp),%a4
	tst.l d4					*	tst.l %d4
	jbeq _?L71					*	jeq .L71
	lea (572,sp),a0					*	lea (572,%sp),%a0
	lea (1596,sp),a6				*	lea (1596,%sp),%a6
	moveq #0,d0					*	moveq #0,%d0
_?L60:							*.L60:
	move.l d0,d1					*	move.l %d0,%d1
	add.l (a0),d0					*	add.l (%a0),%d0
	move.l d1,(a0)+					*	move.l %d1,(%a0)+
	cmp.l a6,a0					*	cmp.l %a6,%a0
	jbne _?L60					*	jne .L60
	moveq #0,d4					*	moveq #0,%d4
	move.l 44(sp),d3				*	move.l 44(%sp),%d3
	move.l 40(sp),d6				*	move.l 40(%sp),%d6
_?L63:							*.L63:
	move.l d5,a6					*	move.l %d5,%a6
	sub.l d4,a6					*	sub.l %d4,%a6
	cmp.w #128,a6					*	cmp.w #128,%a6
	jbls _?L61					*	jls .L61
	move.w #128,a6					*	move.w #128,%a6
_?L61:							*.L61:
	move.l d4,d0					*	move.l %d4,%d0
	add.l d4,d0					*	add.l %d4,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l d3,a5					*	move.l %d3,%a5
	add.l d0,a5					*	add.l %d0,%a5
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	pea 64(sp)					*	pea 64(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbeq _?L66					*	jeq .L66
	lea (56,sp),a1					*	lea (56,%sp),%a1
	move.l a6,d0					*	move.l %a6,%d0
	add.l a6,d0					*	add.l %a6,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l a1,d0					*	add.l %a1,%d0
_?L65:							*.L65:
	move.l (a1)+,a0					*	move.l (%a1)+,%a0
	move.l a0,d1					*	move.l %a0,%d1
	lsr.l d7,d1					*	lsr.l %d7,%d1
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d2,d1					*	and.l %d2,%d1
	move.l d1,a0					*	move.l %d1,%a0
	add.l d1,a0					*	add.l %d1,%a0
	add.l a0,a0					*	add.l %a0,%a0
	move.l #1596,d1					*	move.l #1596,%d1
	add.l sp,d1					*	add.l %sp,%d1
	add.l d1,a0					*	add.l %d1,%a0
	lea (-1024,a0),a0				*	lea (-1024,%a0),%a0
	move.l (a0),d1					*	move.l (%a0),%d1
	move.l d1,d2					*	move.l %d1,%d2
	addq.l #1,d2					*	addq.l #1,%d2
	move.l d2,(a0)					*	move.l %d2,(%a0)
	add.l d1,d1					*	add.l %d1,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l (a5)+,(a4,d1.l)				*	move.l (%a5)+,(%a4,%d1.l)
	cmp.l d0,a1					*	cmp.l %d0,%a1
	jbne _?L65					*	jne .L65
_?L66:							*.L66:
	add.l a6,d4					*	add.l %a6,%d4
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbcs _?L63					*	jcs .L63
	addq.l #8,d7					*	addq.l #8,%d7
	moveq #32,d0					*	moveq #32,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbeq _?L67					*	jeq .L67
	pea 1024.w					*	pea 1024.w
	clr.l -(sp)					*	clr.l -(%sp)
	pea 580(sp)					*	pea 580(%sp)
	jbsr _memset					*	jsr memset
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l 44(sp),d0				*	move.l 44(%sp),%d0
	move.l a4,44(sp)				*	move.l %a4,44(%sp)
	move.l d0,a4					*	move.l %d0,%a4
	sub.l a6,a6					*	sub.l %a6,%a6
	moveq #0,d3					*	moveq #0,%d3
	moveq #0,d4					*	moveq #0,%d4
	move.l a4,48(sp)				*	move.l %a4,48(%sp)
	move.l 44(sp),a5				*	move.l 44(%sp),%a5
	move.l d5,a4					*	move.l %d5,%a4
	jbra _?L59					*	jra .L59
_?L86:							*.L86:
	move.l d5,d2					*	move.l %d5,%d2
	add.l d5,d2					*	add.l %d5,%d2
	add.l d5,a6					*	add.l %d5,%a6
	add.l d2,d2					*	add.l %d2,%d2
	lea (1596,sp),a0				*	lea (1596,%sp),%a0
	add.l d2,a0					*	add.l %d2,%a0
	move.l -1540(a0),d3				*	move.l -1540(%a0),%d3
	cmp.l a4,a6					*	cmp.l %a4,%a6
	jbcs _?L59					*	jcs .L59
	jbra _?L87					*	jra .L87
_?L70:							*.L70:
	move.l 52(sp),a4				*	move.l 52(%sp),%a4
_?L67:							*.L67:
	cmp.l 52(sp),a4					*	cmp.l 52(%sp),%a4
	jbeq _?L54					*	jeq .L54
	add.l d5,d5					*	add.l %d5,%d5
	add.l d5,d5					*	add.l %d5,%d5
	move.l d5,1608(sp)				*	move.l %d5,1608(%sp)
	move.l a4,1604(sp)				*	move.l %a4,1604(%sp)
	move.l 52(sp),1600(sp)				*	move.l 52(%sp),1600(%sp)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (1560,sp),sp				*	lea (1560,%sp),%sp
	jbra _memcpy					*	jra memcpy
_?L54:							*.L54:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (1560,sp),sp				*	lea (1560,%sp),%sp
	rts						*	rts
_?L71:							*.L71:
	move.l 44(sp),a4				*	move.l 44(%sp),%a4
	jbra _?L67					*	jra .L67
							*	.size	fde_radixsort, .-fde_radixsort
	.align	2					*	.align	2
							*	.type	get_cie_encoding, @function
_get_cie_encoding:					*get_cie_encoding:
	subq.l #4,sp					*	subq.l #4,%sp
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 16(sp),a4				*	move.l 16(%sp),%a4
	lea (9,a4),a3					*	lea (9,%a4),%a3
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _strlen					*	jsr strlen
	addq.l #4,sp					*	addq.l #4,%sp
	lea 1(a3,d0.l),a0				*	lea 1(%a3,%d0.l),%a0
	move.b 8(a4),d1					*	move.b 8(%a4),%d1
	cmp.b #3,d1					*	cmp.b #3,%d1
	jbhi _?L117					*	jhi .L117
	cmp.b #122,9(a4)				*	cmp.b #122,9(%a4)
	jbeq _?L91					*	jeq .L91
_?L100:							*.L100:
	moveq #0,d0					*	moveq #0,%d0
_?L88:							*.L88:
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	move.l (sp)+,a4					*	move.l (%sp)+,%a4
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L91:							*.L91:
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L91					*	jlt .L91
_?L92:							*.L92:
	move.l a0,d0					*	move.l %a0,%d0
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L92					*	jlt .L92
	cmp.b #1,d1					*	cmp.b #1,%d1
	jbeq _?L118					*	jeq .L118
_?L93:							*.L93:
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L93					*	jlt .L93
	lea (10,a4),a3					*	lea (10,%a4),%a3
_?L95:							*.L95:
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L95					*	jlt .L95
	move.b 10(a4),d0				*	move.b 10(%a4),%d0
	cmp.b #82,d0					*	cmp.b #82,%d0
	jbeq _?L101					*	jeq .L101
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
_?L96:							*.L96:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L119					*	jeq .L119
	cmp.b #76,d0					*	cmp.b #76,%d0
	jbeq _?L114					*	jeq .L114
	cmp.b #66,d0					*	cmp.b #66,%d0
	jbne _?L100					*	jne .L100
_?L114:							*.L114:
	addq.l #1,a0					*	addq.l #1,%a0
	addq.l #1,a3					*	addq.l #1,%a3
	move.b (a3),d0					*	move.b (%a3),%d0
	cmp.b #82,d0					*	cmp.b #82,%d0
	jbne _?L96					*	jne .L96
_?L101:							*.L101:
	moveq #0,d0					*	moveq #0,%d0
	move.b (a0),d0					*	move.b (%a0),%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	move.l (sp)+,a4					*	move.l (%sp)+,%a4
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L119:							*.L119:
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	and.b #127,d0					*	and.b #127,%d0
	pea 8(sp)					*	pea 8(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #127,d1					*	moveq #127,%d1
	and.l d0,d1					*	and.l %d0,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,a0					*	move.l %d0,%a0
	lea (16,sp),sp					*	lea (16,%sp),%sp
	addq.l #1,a3					*	addq.l #1,%a3
	move.b (a3),d0					*	move.b (%a3),%d0
	cmp.b #82,d0					*	cmp.b #82,%d0
	jbne _?L96					*	jne .L96
	jbra _?L101					*	jra .L101
_?L118:							*.L118:
	move.l d0,a0					*	move.l %d0,%a0
	addq.l #2,a0					*	addq.l #2,%a0
	lea (10,a4),a3					*	lea (10,%a4),%a3
	jbra _?L95					*	jra .L95
_?L117:							*.L117:
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	cmp.b #4,(a0)					*	cmp.b #4,(%a0)
	jbne _?L88					*	jne .L88
	tst.b 1(a0)					*	tst.b 1(%a0)
	jbne _?L88					*	jne .L88
	addq.l #2,a0					*	addq.l #2,%a0
	cmp.b #122,9(a4)				*	cmp.b #122,9(%a4)
	jbeq _?L91					*	jeq .L91
	jbra _?L100					*	jra .L100
							*	.size	get_cie_encoding, .-get_cie_encoding
	.align	2					*	.align	2
							*	.type	fde_mixed_encoding_extract, @function
_fde_mixed_encoding_extract:				*fde_mixed_encoding_extract:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d7				*	move.l 40(%sp),%d7
	move.l 52(sp),d5				*	move.l 52(%sp),%d5
	jble _?L120					*	jle .L120
	move.l 48(sp),a3				*	move.l 48(%sp),%a3
	move.l 44(sp),d4				*	move.l 44(%sp),%d4
	moveq #0,d3					*	moveq #0,%d3
	lea _get_cie_encoding,a5			*	lea get_cie_encoding,%a5
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
_?L126:							*.L126:
	move.l (a3)+,a6					*	move.l (%a3)+,%a6
	move.l a6,d0					*	move.l %a6,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a6),d0					*	sub.l 4(%a6),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a6,d6					*	move.l %a6,%d6
	addq.l #8,d6					*	addq.l #8,%d6
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L129					*	jeq .L129
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L123					*	jeq .L123
	jbls _?L129					*	jls .L129
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L134					*	jne .L134
	move.l d7,a0					*	move.l %d7,%a0
	move.l 8(a0),d0					*	move.l 8(%a0),%d0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L126					*	jne .L126
_?L120:							*.L120:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L134:							*.L134:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L135					*	jne .L135
_?L129:							*.L129:
	moveq #0,d0					*	moveq #0,%d0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L126					*	jne .L126
	jbra _?L120					*	jra .L120
_?L123:							*.L123:
	move.l d7,a0					*	move.l %d7,%a0
	move.l 4(a0),d0					*	move.l 4(%a0),%d0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L126					*	jne .L126
	jbra _?L120					*	jra .L120
_?L135:							*.L135:
	trap #7						*	trap #7
							*	.size	fde_mixed_encoding_extract, .-fde_mixed_encoding_extract
	.align	2					*	.align	2
							*	.type	classify_object_over_fdes.constprop.0, @function
_classify_object_over_fdes?constprop?0:			*classify_object_over_fdes.constprop.0:
	subq.l #4,sp					*	subq.l #4,%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 44(sp),a5				*	move.l 44(%sp),%a5
	move.l 48(sp),a3				*	move.l 48(%sp),%a3
	move.l (a3),a6					*	move.l (%a3),%a6
	cmp.w #0,a6					*	cmp.w #0,%a6
	jbeq _?L157					*	jeq .L157
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d4					*	moveq #0,%d4
	moveq #0,d7					*	moveq #0,%d7
	moveq #0,d5					*	moveq #0,%d5
_?L155:							*.L155:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbeq _?L154					*	jeq .L154
	move.l a3,d1					*	move.l %a3,%d1
	addq.l #4,d1					*	addq.l #4,%d1
	move.l d1,a4					*	move.l %d1,%a4
	sub.l d0,a4					*	sub.l %d0,%a4
	cmp.l a4,d5					*	cmp.l %a4,%d5
	jbeq _?L175					*	jeq .L175
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d4					*	move.l %d0,%d4
	cmp.l #255,d0					*	cmp.l #255,%d0
	jbeq _?L176					*	jeq .L176
	move.b d0,d3					*	move.b %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L142					*	jeq .L142
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L143					*	jeq .L143
	jbls _?L159					*	jls .L159
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L177					*	jne .L177
	move.l 8(a5),d6					*	move.l 8(%a5),%d6
_?L144:							*.L144:
	move.w 16(a5),d0				*	move.w 16(%a5),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	cmp.w #8160,d0					*	cmp.w #8160,%d0
	jbeq _?L147					*	jeq .L147
	move.w 16(a5),d5				*	move.w 16(%a5),%d5
	lsr.w #5,d5					*	lsr.w #5,%d5
	moveq #0,d0					*	moveq #0,%d0
	move.b d5,d0					*	move.b %d5,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbeq _?L150					*	jeq .L150
_?L148:							*.L148:
	or.b #32,16(a5)					*	or.b #32,16(%a5)
	move.l a4,d5					*	move.l %a4,%d5
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbeq _?L154					*	jeq .L154
_?L156:							*.L156:
	and.b #7,d3					*	and.b #7,%d3
	cmp.b #2,d3					*	cmp.b #2,%d3
	jbeq _?L161					*	jeq .L161
_?L178:							*.L178:
	cmp.b #2,d3					*	cmp.b #2,%d3
	jbhi _?L152					*	jhi .L152
	tst.b d3					*	tst.b %d3
	jbne _?L146					*	jne .L146
_?L162:							*.L162:
	moveq #-1,d0					*	moveq #-1,%d0
_?L151:							*.L151:
	move.l 36(sp),d1				*	move.l 36(%sp),%d1
	and.l d1,d0					*	and.l %d1,%d0
	jbeq _?L154					*	jeq .L154
	addq.l #1,d7					*	addq.l #1,%d7
	cmp.l (a5),d1					*	cmp.l (%a5),%d1
	jbcc _?L154					*	jcc .L154
	move.l d1,(a5)					*	move.l %d1,(%a5)
_?L154:							*.L154:
	lea 4(a3,a6.l),a3				*	lea 4(%a3,%a6.l),%a3
	move.l (a3),a6					*	move.l (%a3),%a6
	cmp.w #0,a6					*	cmp.w #0,%a6
	jbne _?L155					*	jne .L155
	move.l d7,d0					*	move.l %d7,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L150:							*.L150:
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.b d5,d3					*	move.b %d5,%d3
	move.l a4,d5					*	move.l %a4,%d5
	and.b #7,d3					*	and.b #7,%d3
	cmp.b #2,d3					*	cmp.b #2,%d3
	jbne _?L178					*	jne .L178
_?L161:							*.L161:
	moveq #0,d0					*	moveq #0,%d0
	not.w d0					*	not.w %d0
	jbra _?L151					*	jra .L151
_?L175:							*.L175:
	move.b d4,d3					*	move.b %d4,%d3
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbne _?L156					*	jne .L156
	jbra _?L154					*	jra .L154
_?L152:							*.L152:
	subq.b #3,d3					*	subq.b #3,%d3
	cmp.b #1,d3					*	cmp.b #1,%d3
	jbls _?L162					*	jls .L162
_?L146:							*.L146:
	trap #7						*	trap #7
_?L142:							*.L142:
	move.w 16(a5),d0				*	move.w 16(%a5),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	moveq #0,d6					*	moveq #0,%d6
	cmp.w #8160,d0					*	cmp.w #8160,%d0
	jbne _?L148					*	jne .L148
_?L147:							*.L147:
	clr.w d0					*	clr.w %d0
	move.b d3,d0					*	move.b %d3,%d0
	lsl.w #5,d0					*	lsl.w #5,%d0
	move.w 16(a5),d2				*	move.w 16(%a5),%d2
	and.w #-8161,d2					*	and.w #-8161,%d2
	or.w d0,d2					*	or.w %d0,%d2
	move.w d2,16(a5)				*	move.w %d2,16(%a5)
	move.l a4,d5					*	move.l %a4,%d5
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbne _?L156					*	jne .L156
	jbra _?L154					*	jra .L154
_?L177:							*.L177:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L146					*	jne .L146
_?L159:							*.L159:
	moveq #0,d6					*	moveq #0,%d6
	jbra _?L144					*	jra .L144
_?L143:							*.L143:
	move.l 4(a5),d6					*	move.l 4(%a5),%d6
	jbra _?L144					*	jra .L144
_?L176:							*.L176:
	moveq #-1,d7					*	moveq #-1,%d7
	move.l d7,d0					*	move.l %d7,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L157:							*.L157:
	moveq #0,d7					*	moveq #0,%d7
	move.l d7,d0					*	move.l %d7,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	classify_object_over_fdes.constprop.0, .-classify_object_over_fdes.constprop.0
	.align	2					*	.align	2
							*	.type	fde_single_encoding_extract, @function
_fde_single_encoding_extract:				*fde_single_encoding_extract:
	movem.l d3/d4/d5/d6/d7/a3/a4,-(sp)		*	movem.l #7960,-(%sp)
	move.l 32(sp),a0				*	move.l 32(%sp),%a0
	move.l 44(sp),d5				*	move.l 44(%sp),%d5
	move.w 16(a0),d0				*	move.w 16(%a0),%d0
	lsr.w #5,d0					*	lsr.w #5,%d0
	moveq #0,d6					*	moveq #0,%d6
	move.b d0,d6					*	move.b %d0,%d6
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L187					*	jeq .L187
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L181					*	jeq .L181
	jbls _?L187					*	jls .L187
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L194					*	jne .L194
	move.l 8(a0),d7					*	move.l 8(%a0),%d7
_?L180:							*.L180:
	tst.l d5					*	tst.l %d5
	jble _?L179					*	jle .L179
	move.l 40(sp),a3				*	move.l 40(%sp),%a3
	move.l 36(sp),d4				*	move.l 36(%sp),%d4
	moveq #0,d3					*	moveq #0,%d3
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
_?L185:							*.L185:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l (a3)+,d0					*	move.l (%a3)+,%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L185					*	jne .L185
_?L179:							*.L179:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4		*	movem.l (%sp)+,#6392
	rts						*	rts
_?L187:							*.L187:
	moveq #0,d7					*	moveq #0,%d7
	jbra _?L180					*	jra .L180
_?L181:							*.L181:
	move.l 4(a0),d7					*	move.l 4(%a0),%d7
	jbra _?L180					*	jra .L180
_?L194:							*.L194:
	moveq #0,d7					*	moveq #0,%d7
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L180					*	jeq .L180
	trap #7						*	trap #7
							*	.size	fde_single_encoding_extract, .-fde_single_encoding_extract
	.align	2					*	.align	2
							*	.type	fde_single_encoding_compare, @function
_fde_single_encoding_compare:				*fde_single_encoding_compare:
	link.w a6,#-8					*	link.w %fp,#-8
	movem.l d3/d4/a3,-(sp)				*	movem.l #6160,-(%sp)
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.w 16(a0),d0				*	move.w 16(%a0),%d0
	lsr.w #5,d0					*	lsr.w #5,%d0
	moveq #0,d3					*	moveq #0,%d3
	move.b d0,d3					*	move.b %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L202					*	jeq .L202
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L197					*	jeq .L197
	jbls _?L202					*	jls .L202
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L209					*	jne .L209
	move.l 8(a0),d4					*	move.l 8(%a0),%d4
_?L196:							*.L196:
	pea -8(a6)					*	pea -8(%fp)
	move.l 12(a6),d0				*	move.l 12(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	lea _read_encoded_value_with_base,a3		*	lea read_encoded_value_with_base,%a3
	jbsr (a3)					*	jsr (%a3)
	pea -4(a6)					*	pea -4(%fp)
	move.l 16(a6),d0				*	move.l 16(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	lea (32,sp),sp					*	lea (32,%sp),%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L204					*	jcs .L204
_?L210:							*.L210:
	cmp.l d0,d1					*	cmp.l %d0,%d1
	shi d0						*	shi %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	movem.l -20(a6),d3/d4/a3			*	movem.l -20(%fp),#2072
	unlk a6						*	unlk %fp
	rts						*	rts
_?L202:							*.L202:
	moveq #0,d4					*	moveq #0,%d4
	pea -8(a6)					*	pea -8(%fp)
	move.l 12(a6),d0				*	move.l 12(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	lea _read_encoded_value_with_base,a3		*	lea read_encoded_value_with_base,%a3
	jbsr (a3)					*	jsr (%a3)
	pea -4(a6)					*	pea -4(%fp)
	move.l 16(a6),d0				*	move.l 16(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	lea (32,sp),sp					*	lea (32,%sp),%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L210					*	jcc .L210
_?L204:							*.L204:
	moveq #1,d0					*	moveq #1,%d0
	movem.l -20(a6),d3/d4/a3			*	movem.l -20(%fp),#2072
	unlk a6						*	unlk %fp
	rts						*	rts
_?L197:							*.L197:
	move.l 4(a0),d4					*	move.l 4(%a0),%d4
	jbra _?L196					*	jra .L196
_?L209:							*.L209:
	moveq #0,d4					*	moveq #0,%d4
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L196					*	jeq .L196
	trap #7						*	trap #7
							*	.size	fde_single_encoding_compare, .-fde_single_encoding_compare
	.align	2					*	.align	2
							*	.type	fde_mixed_encoding_compare, @function
_fde_mixed_encoding_compare:				*fde_mixed_encoding_compare:
	link.w a6,#-8					*	link.w %fp,#-8
	movem.l a3/a4/a5,-(sp)				*	movem.l #28,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 12(a6),a5				*	move.l 12(%fp),%a5
	move.l 16(a6),a4				*	move.l 16(%fp),%a4
	move.l a5,d0					*	move.l %a5,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a5),d0					*	sub.l 4(%a5),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	addq.l #8,a5					*	addq.l #8,%a5
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L221					*	jeq .L221
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L213					*	jeq .L213
	jbls _?L221					*	jls .L221
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L231					*	jne .L231
	move.l 8(a3),a0					*	move.l 8(%a3),%a0
_?L212:							*.L212:
	pea -8(a6)					*	pea -8(%fp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	lea _read_encoded_value_with_base,a5		*	lea read_encoded_value_with_base,%a5
	jbsr (a5)					*	jsr (%a5)
	move.l a4,d0					*	move.l %a4,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a4),d0					*	sub.l 4(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #8,a4					*	addq.l #8,%a4
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	lea (20,sp),sp					*	lea (20,%sp),%sp
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L224					*	jeq .L224
_?L233:							*.L233:
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L217					*	jeq .L217
	jbls _?L224					*	jls .L224
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L232					*	jne .L232
	move.l 8(a3),a0					*	move.l 8(%a3),%a0
_?L216:							*.L216:
	pea -4(a6)					*	pea -4(%fp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L226					*	jcs .L226
_?L234:							*.L234:
	cmp.l d0,d1					*	cmp.l %d0,%d1
	shi d0						*	shi %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	movem.l -20(a6),a3/a4/a5			*	movem.l -20(%fp),#14336
	unlk a6						*	unlk %fp
	rts						*	rts
_?L221:							*.L221:
	sub.l a0,a0					*	sub.l %a0,%a0
	pea -8(a6)					*	pea -8(%fp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	lea _read_encoded_value_with_base,a5		*	lea read_encoded_value_with_base,%a5
	jbsr (a5)					*	jsr (%a5)
	move.l a4,d0					*	move.l %a4,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a4),d0					*	sub.l 4(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #8,a4					*	addq.l #8,%a4
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	lea (20,sp),sp					*	lea (20,%sp),%sp
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L233					*	jne .L233
_?L224:							*.L224:
	sub.l a0,a0					*	sub.l %a0,%a0
	pea -4(a6)					*	pea -4(%fp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L234					*	jcc .L234
_?L226:							*.L226:
	moveq #1,d0					*	moveq #1,%d0
	movem.l -20(a6),a3/a4/a5			*	movem.l -20(%fp),#14336
	unlk a6						*	unlk %fp
	rts						*	rts
_?L217:							*.L217:
	move.l 4(a3),a0					*	move.l 4(%a3),%a0
	jbra _?L216					*	jra .L216
_?L213:							*.L213:
	move.l 4(a3),a0					*	move.l 4(%a3),%a0
	jbra _?L212					*	jra .L212
_?L231:							*.L231:
	sub.l a0,a0					*	sub.l %a0,%a0
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L212					*	jeq .L212
	trap #7						*	trap #7
_?L232:							*.L232:
	sub.l a0,a0					*	sub.l %a0,%a0
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L216					*	jeq .L216
	trap #7						*	trap #7
							*	.size	fde_mixed_encoding_compare, .-fde_mixed_encoding_compare
	.align	2					*	.align	2
							*	.type	add_fdes.isra.0, @function
_add_fdes?isra?0:					*add_fdes.isra.0:
	link.w a6,#-4					*	link.w %fp,#-4
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a4					*	move.l 8(%fp),%a4
	move.l 12(a6),a5				*	move.l 12(%fp),%a5
	move.l 16(a6),a3				*	move.l 16(%fp),%a3
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	lsr.w #5,d0					*	lsr.w #5,%d0
	moveq #0,d3					*	moveq #0,%d3
	move.b d0,d3					*	move.b %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L263					*	jeq .L263
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L237					*	jeq .L237
	jbls _?L264					*	jls .L264
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L292					*	jne .L292
	move.l 8(a4),d4					*	move.l 8(%a4),%d4
	moveq #0,d6					*	moveq #0,%d6
	tst.l (a3)					*	tst.l (%a3)
	jbeq _?L235					*	jeq .L235
_?L240:							*.L240:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbeq _?L241					*	jeq .L241
	btst #5,16(a4)					*	btst #5,16(%a4)
	jbeq _?L242					*	jeq .L242
	move.l a3,d7					*	move.l %a3,%d7
	addq.l #4,d7					*	addq.l #4,%d7
	sub.l d0,d7					*	sub.l %d0,%d7
	cmp.l d7,d6					*	cmp.l %d7,%d6
	jbeq _?L242					*	jeq .L242
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.b d0,d5					*	move.b %d0,%d5
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L243					*	jeq .L243
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L244					*	jeq .L244
	jbls _?L245					*	jls .L245
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L293					*	jne .L293
	move.l 8(a4),d4					*	move.l 8(%a4),%d4
	tst.l d3					*	tst.l %d3
	jbne _?L294					*	jne .L294
_?L269:							*.L269:
	move.l d7,d6					*	move.l %d7,%d6
_?L260:							*.L260:
	move.b 8(a3),-4(a6)				*	move.b 8(%a3),-4(%fp)
	move.b 9(a3),-3(a6)				*	move.b 9(%a3),-3(%fp)
	move.b 10(a3),-2(a6)				*	move.b 10(%a3),-2(%fp)
	move.b 11(a3),-1(a6)				*	move.b 11(%a3),-1(%fp)
	moveq #0,d3					*	moveq #0,%d3
	tst.l -4(a6)					*	tst.l -4(%fp)
	jbeq _?L241					*	jeq .L241
_?L250:							*.L250:
	cmp.w #0,a5					*	cmp.w #0,%a5
	jbeq _?L241					*	jeq .L241
	move.l 4(a5),d1					*	move.l 4(%a5),%d1
	move.l d1,d0					*	move.l %d1,%d0
	addq.l #1,d0					*	addq.l #1,%d0
	move.l d0,4(a5)					*	move.l %d0,4(%a5)
	addq.l #2,d1					*	addq.l #2,%d1
	add.l d1,d1					*	add.l %d1,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l a3,(a5,d1.l)				*	move.l %a3,(%a5,%d1.l)
_?L241:							*.L241:
	move.l (a3),d0					*	move.l (%a3),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a3					*	add.l %d0,%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
_?L235:							*.L235:
	movem.l -36(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -36(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L242:							*.L242:
	tst.l d3					*	tst.l %d3
	jbeq _?L260					*	jeq .L260
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.b d3,d5					*	move.b %d3,%d5
	lea (16,sp),sp					*	lea (16,%sp),%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbeq _?L241					*	jeq .L241
_?L259:							*.L259:
	and.b #7,d5					*	and.b #7,%d5
	cmp.b #2,d5					*	cmp.b #2,%d5
	jbeq _?L267					*	jeq .L267
	jbhi _?L253					*	jhi .L253
	tst.b d5					*	tst.b %d5
	jbne _?L239					*	jne .L239
_?L268:							*.L268:
	moveq #-1,d0					*	moveq #-1,%d0
	and.l -4(a6),d0					*	and.l -4(%fp),%d0
	jbne _?L250					*	jne .L250
_?L290:							*.L290:
	move.l (a3),d0					*	move.l (%a3),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a3					*	add.l %d0,%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
	jbra _?L235					*	jra .L235
_?L253:							*.L253:
	subq.b #3,d5					*	subq.b #3,%d5
	cmp.b #1,d5					*	cmp.b #1,%d5
	jbls _?L268					*	jls .L268
_?L239:							*.L239:
	trap #7						*	trap #7
_?L267:							*.L267:
	moveq #0,d0					*	moveq #0,%d0
	not.w d0					*	not.w %d0
	and.l -4(a6),d0					*	and.l -4(%fp),%d0
	jbne _?L250					*	jne .L250
	jbra _?L290					*	jra .L290
_?L293:							*.L293:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L239					*	jne .L239
_?L245:							*.L245:
	tst.l d3					*	tst.l %d3
	jbne _?L295					*	jne .L295
	move.l d7,d6					*	move.l %d7,%d6
	moveq #0,d4					*	moveq #0,%d4
	move.b 8(a3),-4(a6)				*	move.b 8(%a3),-4(%fp)
	move.b 9(a3),-3(a6)				*	move.b 9(%a3),-3(%fp)
	move.b 10(a3),-2(a6)				*	move.b 10(%a3),-2(%fp)
	move.b 11(a3),-1(a6)				*	move.b 11(%a3),-1(%fp)
	moveq #0,d3					*	moveq #0,%d3
	tst.l -4(a6)					*	tst.l -4(%fp)
	jbne _?L250					*	jne .L250
	jbra _?L241					*	jra .L241
_?L244:							*.L244:
	move.l 4(a4),d4					*	move.l 4(%a4),%d4
	tst.l d3					*	tst.l %d3
	jbeq _?L269					*	jeq .L269
_?L294:							*.L294:
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d7,d6					*	move.l %d7,%d6
	jbra _?L259					*	jra .L259
_?L243:							*.L243:
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d7,d6					*	move.l %d7,%d6
	moveq #0,d4					*	moveq #0,%d4
	move.l (a3),d0					*	move.l (%a3),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a3					*	add.l %d0,%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
	jbra _?L235					*	jra .L235
_?L237:							*.L237:
	move.l 4(a4),d4					*	move.l 4(%a4),%d4
	moveq #0,d6					*	moveq #0,%d6
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
	jbra _?L235					*	jra .L235
_?L263:							*.L263:
	moveq #0,d4					*	moveq #0,%d4
	moveq #0,d3					*	moveq #0,%d3
	not.b d3					*	not.b %d3
	moveq #0,d6					*	moveq #0,%d6
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
	jbra _?L235					*	jra .L235
_?L264:							*.L264:
	moveq #0,d4					*	moveq #0,%d4
	moveq #0,d6					*	moveq #0,%d6
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
	jbra _?L235					*	jra .L235
_?L295:							*.L295:
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.b d3,d5					*	move.b %d3,%d5
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d7,d6					*	move.l %d7,%d6
	moveq #0,d4					*	moveq #0,%d4
	jbra _?L259					*	jra .L259
_?L292:							*.L292:
	moveq #0,d4					*	moveq #0,%d4
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L239					*	jne .L239
	moveq #0,d6					*	moveq #0,%d6
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L240					*	jne .L240
	jbra _?L235					*	jra .L235
							*	.size	add_fdes.isra.0, .-add_fdes.isra.0
	.align	2					*	.align	2
							*	.type	linear_search_fdes, @function
_linear_search_fdes:					*linear_search_fdes:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 12(a6),a3				*	move.l 12(%fp),%a3
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.w 16(a0),d0				*	move.w 16(%a0),%d0
	lsr.w #5,d0					*	lsr.w #5,%d0
	moveq #0,d4					*	moveq #0,%d4
	move.b d0,d4					*	move.b %d0,%d4
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L319					*	jeq .L319
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L298					*	jeq .L298
	jbls _?L320					*	jls .L320
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L348					*	jne .L348
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 8(a0),d6					*	move.l 8(%a0),%d6
_?L297:							*.L297:
	move.l (a3),d3					*	move.l (%a3),%d3
	moveq #0,d5					*	moveq #0,%d5
	tst.l d3					*	tst.l %d3
	jbeq _?L315					*	jeq .L315
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
	lea _get_cie_encoding,a5			*	lea get_cie_encoding,%a5
_?L301:							*.L301:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbeq _?L314					*	jeq .L314
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	btst #5,16(a0)					*	btst #5,16(%a0)
	jbeq _?L304					*	jeq .L304
	move.l a3,d7					*	move.l %a3,%d7
	addq.l #4,d7					*	addq.l #4,%d7
	sub.l d0,d7					*	sub.l %d0,%d7
	cmp.l d5,d7					*	cmp.l %d5,%d7
	jbeq _?L304					*	jeq .L304
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.b d0,d1					*	move.b %d0,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L305					*	jeq .L305
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L306					*	jeq .L306
	jbls _?L325					*	jls .L325
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L349					*	jne .L349
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 8(a0),d6					*	move.l 8(%a0),%d6
	tst.l d4					*	tst.l %d4
	jbne _?L350					*	jne .L350
_?L329:							*.L329:
	move.l d7,d5					*	move.l %d7,%d5
_?L317:							*.L317:
	move.l 8(a3),d0					*	move.l 8(%a3),%d0
	move.l d0,-8(a6)				*	move.l %d0,-8(%fp)
	move.l 12(a3),d1				*	move.l 12(%a3),%d1
	move.l d1,-4(a6)				*	move.l %d1,-4(%fp)
	moveq #0,d4					*	moveq #0,%d4
	tst.l d0					*	tst.l %d0
	jbeq _?L314					*	jeq .L314
	move.l 16(a6),a1				*	move.l 16(%fp),%a1
	sub.l d0,a1					*	sub.l %d0,%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbhi _?L351					*	jhi .L351
_?L314:							*.L314:
	lea 4(a3,d3.l),a3				*	lea 4(%a3,%d3.l),%a3
	move.l (a3),d3					*	move.l (%a3),%d3
	jbne _?L301					*	jne .L301
_?L315:							*.L315:
	moveq #0,d0					*	moveq #0,%d0
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L351:							*.L351:
	move.l a3,d0					*	move.l %a3,%d0
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L349:							*.L349:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L300					*	jne .L300
_?L325:							*.L325:
	move.l d7,d5					*	move.l %d7,%d5
	moveq #0,d6					*	moveq #0,%d6
_?L304:							*.L304:
	tst.l d4					*	tst.l %d4
	jbeq _?L317					*	jeq .L317
	pea -8(a6)					*	pea -8(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	pea -4(a6)					*	pea -4(%fp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.b d4,d1					*	move.b %d4,%d1
	lea (32,sp),sp					*	lea (32,%sp),%sp
	cmp.b #-1,d4					*	cmp.b #-1,%d4
	jbeq _?L314					*	jeq .L314
_?L316:							*.L316:
	and.b #7,d1					*	and.b #7,%d1
	cmp.b #2,d1					*	cmp.b #2,%d1
	jbeq _?L327					*	jeq .L327
	jbhi _?L313					*	jhi .L313
	tst.b d1					*	tst.b %d1
	jbne _?L300					*	jne .L300
_?L328:							*.L328:
	moveq #-1,d1					*	moveq #-1,%d1
_?L312:							*.L312:
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	and.l d0,d1					*	and.l %d0,%d1
	jbeq _?L314					*	jeq .L314
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	move.l 16(a6),a1				*	move.l 16(%fp),%a1
	sub.l d0,a1					*	sub.l %d0,%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbls _?L314					*	jls .L314
	jbra _?L351					*	jra .L351
_?L313:							*.L313:
	subq.b #3,d1					*	subq.b #3,%d1
	cmp.b #1,d1					*	cmp.b #1,%d1
	jbls _?L328					*	jls .L328
_?L300:							*.L300:
	trap #7						*	trap #7
_?L327:							*.L327:
	moveq #0,d1					*	moveq #0,%d1
	not.w d1					*	not.w %d1
	jbra _?L312					*	jra .L312
_?L306:							*.L306:
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 4(a0),d6					*	move.l 4(%a0),%d6
	tst.l d4					*	tst.l %d4
	jbeq _?L329					*	jeq .L329
_?L350:							*.L350:
	pea -8(a6)					*	pea -8(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l #_read_encoded_value_with_base,d5	*	move.l #read_encoded_value_with_base,%d5
	move.l d1,-12(a6)				*	move.l %d1,-12(%fp)
	move.l d5,a0					*	move.l %d5,%a0
	jbsr (a0)					*	jsr (%a0)
	pea -4(a6)					*	pea -4(%fp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,a0					*	move.l %d5,%a0
	jbsr (a0)					*	jsr (%a0)
	lea (32,sp),sp					*	lea (32,%sp),%sp
	move.l d7,d5					*	move.l %d7,%d5
	move.l -12(a6),d1				*	move.l -12(%fp),%d1
	jbra _?L316					*	jra .L316
_?L305:							*.L305:
	pea -8(a6)					*	pea -8(%fp)
	pea 8(a3)					*	pea 8(%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l #_read_encoded_value_with_base,d6	*	move.l #read_encoded_value_with_base,%d6
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	pea -4(a6)					*	pea -4(%fp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	lea (32,sp),sp					*	lea (32,%sp),%sp
	move.l d7,d5					*	move.l %d7,%d5
	moveq #0,d6					*	moveq #0,%d6
	lea 4(a3,d3.l),a3				*	lea 4(%a3,%d3.l),%a3
	move.l (a3),d3					*	move.l (%a3),%d3
	jbne _?L301					*	jne .L301
	jbra _?L315					*	jra .L315
_?L298:							*.L298:
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 4(a0),d6					*	move.l 4(%a0),%d6
	jbra _?L297					*	jra .L297
_?L319:							*.L319:
	moveq #0,d6					*	moveq #0,%d6
	moveq #0,d4					*	moveq #0,%d4
	not.b d4					*	not.b %d4
	jbra _?L297					*	jra .L297
_?L320:							*.L320:
	moveq #0,d6					*	moveq #0,%d6
	jbra _?L297					*	jra .L297
_?L348:							*.L348:
	moveq #0,d6					*	moveq #0,%d6
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L297					*	jeq .L297
	trap #7						*	trap #7
							*	.size	linear_search_fdes, .-linear_search_fdes
	.align	2					*	.align	2
							*	.type	search_object, @function
_search_object:						*search_object:
	lea (-20,sp),sp					*	lea (-20,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 60(sp),a3				*	move.l 60(%sp),%a3
	move.l 64(sp),d3				*	move.l 64(%sp),%d3
	move.b 16(a3),d0				*	move.b 16(%a3),%d0
	jbpl _?L461					*	jpl .L461
_?L353:							*.L353:
	btst #5,d0					*	btst #5,%d0
	jbne _?L462					*	jne .L462
	move.w 16(a3),d0				*	move.w 16(%a3),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	jbeq _?L463					*	jeq .L463
	move.l 12(a3),36(sp)				*	move.l 12(%a3),36(%sp)
	move.w 16(a3),d6				*	move.w 16(%a3),%d6
	lsr.w #5,d6					*	lsr.w #5,%d6
	moveq #0,d1					*	moveq #0,%d1
	move.b d6,d1					*	move.b %d6,%d1
	move.l d1,40(sp)				*	move.l %d1,40(%sp)
	cmp.b #-1,d6					*	cmp.b #-1,%d6
	jbeq _?L413					*	jeq .L413
	move.b d6,d0					*	move.b %d6,%d0
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L396					*	jeq .L396
	jbls _?L413					*	jls .L413
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L464					*	jne .L464
	move.l 8(a3),44(sp)				*	move.l 8(%a3),44(%sp)
_?L395:							*.L395:
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 4(a0),d4					*	move.l 4(%a0),%d4
	jbeq _?L383					*	jeq .L383
	moveq #15,d0					*	moveq #15,%d0
	and.l d0,d6					*	and.l %d0,%d6
	moveq #0,d5					*	moveq #0,%d5
	lea (48,sp),a4					*	lea (48,%sp),%a4
	lea _read_encoded_value_with_base,a5		*	lea read_encoded_value_with_base,%a5
	lea (52,sp),a3					*	lea (52,%sp),%a3
_?L400:							*.L400:
	move.l d5,d7					*	move.l %d5,%d7
	add.l d4,d7					*	add.l %d4,%d7
	lsr.l #1,d7					*	lsr.l #1,%d7
	move.l d7,d0					*	move.l %d7,%d0
	addq.l #2,d0					*	addq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l (a0,d0.l),a6				*	move.l (%a0,%d0.l),%a6
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	pea 8(a6)					*	pea 8(%a6)
	move.l 52(sp),-(sp)				*	move.l 52(%sp),-(%sp)
	move.l 52(sp),-(sp)				*	move.l 52(%sp),-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	lea (32,sp),sp					*	lea (32,%sp),%sp
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L415					*	jhi .L415
	add.l 52(sp),d0					*	add.l 52(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L352					*	jhi .L352
	move.l d7,d5					*	move.l %d7,%d5
	addq.l #1,d5					*	addq.l #1,%d5
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbhi _?L400					*	jhi .L400
_?L383:							*.L383:
	sub.l a6,a6					*	sub.l %a6,%a6
_?L352:							*.L352:
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L461:							*.L461:
	move.l 16(a3),d4				*	move.l 16(%a3),%d4
	and.l #2097151,d4				*	and.l #2097151,%d4
	jbne _?L354					*	jne .L354
	move.l 12(a3),a4				*	move.l 12(%a3),%a4
	btst #6,d0					*	btst #6,%d0
	jbeq _?L355					*	jeq .L355
	move.l (a4),d1					*	move.l (%a4),%d1
	jbeq _?L378					*	jeq .L378
	lea (_classify_object_over_fdes?constprop?0),a5	*	lea (classify_object_over_fdes.constprop.0),%a5
_?L359:							*.L359:
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #-1,d1					*	moveq #-1,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L361					*	jeq .L361
	add.l d0,d4					*	add.l %d0,%d4
	addq.l #4,a4					*	addq.l #4,%a4
	move.l (a4),d1					*	move.l (%a4),%d1
	jbne _?L359					*	jne .L359
_?L360:							*.L360:
	move.l 16(a3),d0				*	move.l 16(%a3),%d0
	and.l #-2097152,d0				*	and.l #-2097152,%d0
	move.l d4,d1					*	move.l %d4,%d1
	and.l #2097151,d1				*	and.l #2097151,%d1
	or.l d1,d0					*	or.l %d1,%d0
	move.l d0,16(a3)				*	move.l %d0,16(%a3)
	cmp.l #2097152,d4				*	cmp.l #2097152,%d4
	jbcs _?L362					*	jcs .L362
	and.l #-2097152,d0				*	and.l #-2097152,%d0
	move.l d0,16(a3)				*	move.l %d0,16(%a3)
_?L354:							*.L354:
	move.l d4,d5					*	move.l %d4,%d5
	addq.l #2,d5					*	addq.l #2,%d5
	add.l d5,d5					*	add.l %d5,%d5
	add.l d5,d5					*	add.l %d5,%d5
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	lea _malloc,a5					*	lea malloc,%a5
	jbsr (a5)					*	jsr (%a5)
	move.l d0,a4					*	move.l %d0,%a4
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L378					*	jeq .L378
	clr.l 4(a4)					*	clr.l 4(%a4)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l d0,a6					*	move.l %d0,%a6
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L364					*	jeq .L364
	clr.l 4(a6)					*	clr.l 4(%a6)
_?L364:							*.L364:
	move.b 16(a3),d6				*	move.b 16(%a3),%d6
	move.l 12(a3),a5				*	move.l 12(%a3),%a5
	btst #6,d6					*	btst #6,%d6
	jbeq _?L365					*	jeq .L365
	move.l (a5),d1					*	move.l (%a5),%d1
	jbeq _?L387					*	jeq .L387
	move.l #_add_fdes?isra?0,d5			*	move.l #add_fdes.isra.0,%d5
_?L367:							*.L367:
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d5,a0					*	move.l %d5,%a0
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,a5					*	addq.l #4,%a5
	move.l (a5),d1					*	move.l (%a5),%d1
	lea (12,sp),sp					*	lea (12,%sp),%sp
	jbne _?L367					*	jne .L367
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
_?L368:							*.L368:
	cmp.l d4,d5					*	cmp.l %d4,%d5
	jbne _?L387					*	jne .L387
	and.b #32,d6					*	and.b #32,%d6
	cmp.w #0,a6					*	cmp.w #0,%a6
	jbeq _?L370					*	jeq .L370
	tst.b d6					*	tst.b %d6
	jbne _?L403					*	jne .L403
	move.w 16(a3),d0				*	move.w 16(%a3),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	jbne _?L404					*	jne .L404
	move.l #_fde_unencoded_extract,d0		*	move.l #fde_unencoded_extract,%d0
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _fde_radixsort				*	jsr fde_radixsort
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr _free					*	jsr free
	lea (20,sp),sp					*	lea (20,%sp),%sp
_?L372:							*.L372:
	move.l 12(a3),(a4)				*	move.l 12(%a3),(%a4)
	move.l a4,12(a3)				*	move.l %a4,12(%a3)
	or.b #-128,16(a3)				*	or.b #-128,16(%a3)
_?L378:							*.L378:
	cmp.l (a3),d3					*	cmp.l (%a3),%d3
	jbcs _?L383					*	jcs .L383
	move.b 16(a3),d0				*	move.b 16(%a3),%d0
	jbmi _?L353					*	jmi .L353
	move.l 12(a3),a4				*	move.l 12(%a3),%a4
	btst #6,d0					*	btst #6,%d0
	jbeq _?L401					*	jeq .L401
	move.l (a4),d0					*	move.l (%a4),%d0
	jbeq _?L383					*	jeq .L383
	lea _linear_search_fdes,a5			*	lea linear_search_fdes,%a5
_?L402:							*.L402:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,a6					*	move.l %d0,%a6
	tst.l d0					*	tst.l %d0
	jbne _?L352					*	jne .L352
	addq.l #4,a4					*	addq.l #4,%a4
	move.l (a4),d0					*	move.l (%a4),%d0
	jbne _?L402					*	jne .L402
	sub.l a6,a6					*	sub.l %a6,%a6
	jbra _?L352					*	jra .L352
_?L463:							*.L463:
	move.l 12(a3),a2				*	move.l 12(%a3),%a2
	move.l 4(a2),a1					*	move.l 4(%a2),%a1
	cmp.w #0,a1					*	cmp.w #0,%a1
	jbeq _?L383					*	jeq .L383
	moveq #0,d2					*	moveq #0,%d2
	lea (48,sp),a4					*	lea (48,%sp),%a4
	lea (52,sp),a3					*	lea (52,%sp),%a3
	move.l a1,d1					*	move.l %a1,%d1
	add.l d2,d1					*	add.l %d2,%d1
	lsr.l #1,d1					*	lsr.l #1,%d1
	move.l d1,d0					*	move.l %d1,%d0
	addq.l #2,d0					*	addq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a2,d0.l),a6				*	move.l (%a2,%d0.l),%a6
	move.b 8(a6),(a4)				*	move.b 8(%a6),(%a4)
	move.b 9(a6),49(sp)				*	move.b 9(%a6),49(%sp)
	move.b 10(a6),50(sp)				*	move.b 10(%a6),50(%sp)
	move.b 11(a6),51(sp)				*	move.b 11(%a6),51(%sp)
	move.b 12(a6),(a3)				*	move.b 12(%a6),(%a3)
	move.b 13(a6),53(sp)				*	move.b 13(%a6),53(%sp)
	move.b 14(a6),54(sp)				*	move.b 14(%a6),54(%sp)
	move.b 15(a6),55(sp)				*	move.b 15(%a6),55(%sp)
	move.l 48(sp),d0				*	move.l 48(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L411					*	jhi .L411
_?L465:							*.L465:
	add.l 52(sp),d0					*	add.l 52(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L352					*	jhi .L352
	move.l d1,d2					*	move.l %d1,%d2
	addq.l #1,d2					*	addq.l #1,%d2
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbls _?L383					*	jls .L383
_?L458:							*.L458:
	move.l a1,d1					*	move.l %a1,%d1
	add.l d2,d1					*	add.l %d2,%d1
	lsr.l #1,d1					*	lsr.l #1,%d1
	move.l d1,d0					*	move.l %d1,%d0
	addq.l #2,d0					*	addq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a2,d0.l),a6				*	move.l (%a2,%d0.l),%a6
	move.b 8(a6),(a4)				*	move.b 8(%a6),(%a4)
	move.b 9(a6),49(sp)				*	move.b 9(%a6),49(%sp)
	move.b 10(a6),50(sp)				*	move.b 10(%a6),50(%sp)
	move.b 11(a6),51(sp)				*	move.b 11(%a6),51(%sp)
	move.b 12(a6),(a3)				*	move.b 12(%a6),(%a3)
	move.b 13(a6),53(sp)				*	move.b 13(%a6),53(%sp)
	move.b 14(a6),54(sp)				*	move.b 14(%a6),54(%sp)
	move.b 15(a6),55(sp)				*	move.b 15(%a6),55(%sp)
	move.l 48(sp),d0				*	move.l 48(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbls _?L465					*	jls .L465
_?L411:							*.L411:
	move.l d1,a1					*	move.l %d1,%a1
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbhi _?L458					*	jhi .L458
	jbra _?L383					*	jra .L383
_?L355:							*.L355:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (_classify_object_over_fdes?constprop?0)	*	jsr (classify_object_over_fdes.constprop.0)
	move.l d0,d4					*	move.l %d0,%d4
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #-1,d0					*	moveq #-1,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbne _?L360					*	jne .L360
_?L361:							*.L361:
	clr.l 16(a3)					*	clr.l 16(%a3)
	move.w #8160,16(a3)				*	move.w #8160,16(%a3)
	move.l #_terminator?0,12(a3)			*	move.l #terminator.0,12(%a3)
	jbra _?L378					*	jra .L378
_?L401:							*.L401:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _linear_search_fdes			*	jsr linear_search_fdes
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (20,sp),sp					*	lea (20,%sp),%sp
	rts						*	rts
_?L462:							*.L462:
	move.l 12(a3),a5				*	move.l 12(%a3),%a5
	move.l 4(a5),d5					*	move.l 4(%a5),%d5
	jbeq _?L383					*	jeq .L383
	moveq #0,d6					*	moveq #0,%d6
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
	move.l d6,d4					*	move.l %d6,%d4
	add.l d5,d4					*	add.l %d5,%d4
	lsr.l #1,d4					*	lsr.l #1,%d4
	move.l d4,d0					*	move.l %d4,%d0
	addq.l #2,d0					*	addq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a5,d0.l),a6				*	move.l (%a5,%d0.l),%a6
	move.l a6,d0					*	move.l %a6,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a6),d0					*	sub.l 4(%a6),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d7					*	move.l %d0,%d7
	lea (8,a6),a1					*	lea (8,%a6),%a1
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d0,d2					*	and.l %d0,%d2
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L409					*	jeq .L409
_?L467:							*.L467:
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L385					*	jeq .L385
	jbls _?L409					*	jls .L409
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L466					*	jne .L466
	move.l 8(a3),d0					*	move.l 8(%a3),%d0
_?L384:							*.L384:
	pea 48(sp)					*	pea 48(%sp)
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	pea 68(sp)					*	pea 68(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	lea (32,sp),sp					*	lea (32,%sp),%sp
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L410					*	jhi .L410
_?L468:							*.L468:
	add.l 52(sp),d0					*	add.l 52(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L352					*	jhi .L352
	move.l d4,d6					*	move.l %d4,%d6
	addq.l #1,d6					*	addq.l #1,%d6
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbls _?L383					*	jls .L383
_?L459:							*.L459:
	move.l d6,d4					*	move.l %d6,%d4
	add.l d5,d4					*	add.l %d5,%d4
	lsr.l #1,d4					*	lsr.l #1,%d4
	move.l d4,d0					*	move.l %d4,%d0
	addq.l #2,d0					*	addq.l #2,%d0
	add.l d0,d0					*	add.l %d0,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l (a5,d0.l),a6				*	move.l (%a5,%d0.l),%a6
	move.l a6,d0					*	move.l %a6,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a6),d0					*	sub.l 4(%a6),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d7					*	move.l %d0,%d7
	lea (8,a6),a1					*	lea (8,%a6),%a1
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d0,d2					*	and.l %d0,%d2
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L467					*	jne .L467
_?L409:							*.L409:
	moveq #0,d0					*	moveq #0,%d0
	pea 48(sp)					*	pea 48(%sp)
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	pea 68(sp)					*	pea 68(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	lea (32,sp),sp					*	lea (32,%sp),%sp
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbls _?L468					*	jls .L468
_?L410:							*.L410:
	move.l d4,d5					*	move.l %d4,%d5
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbhi _?L459					*	jhi .L459
	jbra _?L383					*	jra .L383
_?L385:							*.L385:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbra _?L384					*	jra .L384
_?L466:							*.L466:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L409					*	jeq .L409
_?L387:							*.L387:
	trap #7						*	trap #7
_?L403:							*.L403:
	move.l #_fde_mixed_encoding_extract,d0		*	move.l #fde_mixed_encoding_extract,%d0
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _fde_radixsort				*	jsr fde_radixsort
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr _free					*	jsr free
	lea (20,sp),sp					*	lea (20,%sp),%sp
	jbra _?L372					*	jra .L372
_?L365:							*.L365:
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (_add_fdes?isra?0)				*	jsr (add_fdes.isra.0)
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
	lea (12,sp),sp					*	lea (12,%sp),%sp
	jbra _?L368					*	jra .L368
_?L370:							*.L370:
	tst.b d6					*	tst.b %d6
	jbne _?L405					*	jne .L405
	move.w 16(a3),d0				*	move.w 16(%a3),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	jbne _?L406					*	jne .L406
	move.l #_fde_unencoded_compare,d7		*	move.l #fde_unencoded_compare,%d7
	move.l a4,d6					*	move.l %a4,%d6
	addq.l #8,d6					*	addq.l #8,%d6
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l d0,d4					*	move.l %d0,%d4
	subq.l #1,d4					*	subq.l #1,%d4
	lea _frame_downheap,a5				*	lea frame_downheap,%a5
	tst.l d0					*	tst.l %d0
	jbeq _?L372					*	jeq .L372
_?L375:							*.L375:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	lea (20,sp),sp					*	lea (20,%sp),%sp
	dbra d4,_?L375					*	dbra %d4,.L375
	clr.w d4					*	clr.w %d4
	subq.l #1,d4					*	subq.l #1,%d4
	jbcc _?L375					*	jcc .L375
	move.l d5,d4					*	move.l %d5,%d4
	subq.l #1,d4					*	subq.l #1,%d4
	tst.l d4					*	tst.l %d4
	jble _?L372					*	jle .L372
	addq.l #1,d5					*	addq.l #1,%d5
	add.l d5,d5					*	add.l %d5,%d5
	add.l d5,d5					*	add.l %d5,%d5
	lea (a4,d5.l),a6				*	lea (%a4,%d5.l),%a6
_?L377:							*.L377:
	move.l 8(a4),d0					*	move.l 8(%a4),%d0
	move.l (a6),8(a4)				*	move.l (%a6),8(%a4)
	move.l d0,(a6)					*	move.l %d0,(%a6)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	subq.l #1,d4					*	subq.l #1,%d4
	subq.l #4,a6					*	subq.l #4,%a6
	lea (20,sp),sp					*	lea (20,%sp),%sp
	jbeq _?L372					*	jeq .L372
	move.l 8(a4),d0					*	move.l 8(%a4),%d0
	move.l (a6),8(a4)				*	move.l (%a6),8(%a4)
	move.l d0,(a6)					*	move.l %d0,(%a6)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	subq.l #1,d4					*	subq.l #1,%d4
	subq.l #4,a6					*	subq.l #4,%a6
	lea (20,sp),sp					*	lea (20,%sp),%sp
	jbne _?L377					*	jne .L377
	jbra _?L372					*	jra .L372
_?L413:							*.L413:
	clr.l 44(sp)					*	clr.l 44(%sp)
	jbra _?L395					*	jra .L395
_?L415:							*.L415:
	move.l d7,d4					*	move.l %d7,%d4
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbhi _?L400					*	jhi .L400
	jbra _?L383					*	jra .L383
_?L404:							*.L404:
	move.l #_fde_single_encoding_extract,d0		*	move.l #fde_single_encoding_extract,%d0
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _fde_radixsort				*	jsr fde_radixsort
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr _free					*	jsr free
	lea (20,sp),sp					*	lea (20,%sp),%sp
	jbra _?L372					*	jra .L372
_?L405:							*.L405:
	move.l #_fde_mixed_encoding_compare,d7		*	move.l #fde_mixed_encoding_compare,%d7
	move.l a4,d6					*	move.l %a4,%d6
	addq.l #8,d6					*	addq.l #8,%d6
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l d0,d4					*	move.l %d0,%d4
	subq.l #1,d4					*	subq.l #1,%d4
	lea _frame_downheap,a5				*	lea frame_downheap,%a5
	tst.l d0					*	tst.l %d0
	jbne _?L375					*	jne .L375
	jbra _?L372					*	jra .L372
_?L464:							*.L464:
	clr.l 44(sp)					*	clr.l 44(%sp)
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L395					*	jeq .L395
	trap #7						*	trap #7
_?L362:							*.L362:
	tst.l d4					*	tst.l %d4
	jbeq _?L378					*	jeq .L378
	jbra _?L354					*	jra .L354
_?L396:							*.L396:
	move.l 4(a3),44(sp)				*	move.l 4(%a3),44(%sp)
	jbra _?L395					*	jra .L395
_?L406:							*.L406:
	move.l #_fde_single_encoding_compare,d7		*	move.l #fde_single_encoding_compare,%d7
	move.l a4,d6					*	move.l %a4,%d6
	addq.l #8,d6					*	addq.l #8,%d6
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l d0,d4					*	move.l %d0,%d4
	subq.l #1,d4					*	subq.l #1,%d4
	lea _frame_downheap,a5				*	lea frame_downheap,%a5
	tst.l d0					*	tst.l %d0
	jbne _?L375					*	jne .L375
	jbra _?L372					*	jra .L372
							*	.size	search_object, .-search_object
	.align	2					*	.align	2
	.globl	___register_frame_info_bases		*	.globl	__register_frame_info_bases
							*	.hidden	__register_frame_info_bases
							*	.type	__register_frame_info_bases, @function
___register_frame_info_bases:				*__register_frame_info_bases:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	cmp.w #0,a1					*	cmp.w #0,%a1
	jbeq _?L469					*	jeq .L469
	tst.l (a1)					*	tst.l (%a1)
	jbeq _?L469					*	jeq .L469
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l 12(sp),4(a0)				*	move.l 12(%sp),4(%a0)
	move.l 16(sp),8(a0)				*	move.l 16(%sp),8(%a0)
	move.l a1,12(a0)				*	move.l %a1,12(%a0)
	clr.l 16(a0)					*	clr.l 16(%a0)
	move.w #8160,16(a0)				*	move.w #8160,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
_?L469:							*.L469:
	rts						*	rts
							*	.size	__register_frame_info_bases, .-__register_frame_info_bases
	.align	2					*	.align	2
	.globl	___register_frame_info			*	.globl	__register_frame_info
							*	.hidden	__register_frame_info
							*	.type	__register_frame_info, @function
___register_frame_info:					*__register_frame_info:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	cmp.w #0,a1					*	cmp.w #0,%a1
	jbeq _?L476					*	jeq .L476
	tst.l (a1)					*	tst.l (%a1)
	jbeq _?L476					*	jeq .L476
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l a1,12(a0)				*	move.l %a1,12(%a0)
	clr.l 16(a0)					*	clr.l 16(%a0)
	move.w #8160,16(a0)				*	move.w #8160,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
_?L476:							*.L476:
	rts						*	rts
							*	.size	__register_frame_info, .-__register_frame_info
	.align	2					*	.align	2
	.globl	___register_frame			*	.globl	__register_frame
							*	.hidden	__register_frame
							*	.type	__register_frame, @function
___register_frame:					*__register_frame:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 8(sp),a3					*	move.l 8(%sp),%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L487					*	jne .L487
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
_?L487:							*.L487:
	pea 24.w					*	pea 24.w
	jbsr _malloc					*	jsr malloc
	move.l d0,a0					*	move.l %d0,%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l a3,12(a0)				*	move.l %a3,12(%a0)
	move.l #534773760,16(a0)			*	move.l #534773760,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	addq.l #4,sp					*	addq.l #4,%sp
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
							*	.size	__register_frame, .-__register_frame
	.align	2					*	.align	2
	.globl	___register_frame_info_table_bases	*	.globl	__register_frame_info_table_bases
							*	.hidden	__register_frame_info_table_bases
							*	.type	__register_frame_info_table_bases, @function
___register_frame_info_table_bases:			*__register_frame_info_table_bases:
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l 12(sp),4(a0)				*	move.l 12(%sp),4(%a0)
	move.l 16(sp),8(a0)				*	move.l 16(%sp),8(%a0)
	move.l 4(sp),12(a0)				*	move.l 4(%sp),12(%a0)
	move.w #24544,16(a0)				*	move.w #24544,16(%a0)
	clr.w 18(a0)					*	clr.w 18(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	rts						*	rts
							*	.size	__register_frame_info_table_bases, .-__register_frame_info_table_bases
	.align	2					*	.align	2
	.globl	___register_frame_info_table		*	.globl	__register_frame_info_table
							*	.hidden	__register_frame_info_table
							*	.type	__register_frame_info_table, @function
___register_frame_info_table:				*__register_frame_info_table:
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l 4(sp),12(a0)				*	move.l 4(%sp),12(%a0)
	move.w #24544,16(a0)				*	move.w #24544,16(%a0)
	clr.w 18(a0)					*	clr.w 18(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	rts						*	rts
							*	.size	__register_frame_info_table, .-__register_frame_info_table
	.align	2					*	.align	2
	.globl	___register_frame_table			*	.globl	__register_frame_table
							*	.hidden	__register_frame_table
							*	.type	__register_frame_table, @function
___register_frame_table:				*__register_frame_table:
	pea 24.w					*	pea 24.w
	jbsr _malloc					*	jsr malloc
	move.l d0,a0					*	move.l %d0,%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l 8(sp),12(a0)				*	move.l 8(%sp),12(%a0)
	move.l #1608515584,16(a0)			*	move.l #1608515584,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	__register_frame_table, .-__register_frame_table
	.align	2					*	.align	2
	.globl	___deregister_frame_info_bases		*	.globl	__deregister_frame_info_bases
							*	.hidden	__deregister_frame_info_bases
							*	.type	__deregister_frame_info_bases, @function
___deregister_frame_info_bases:				*__deregister_frame_info_bases:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L505					*	jeq .L505
	tst.l (a0)					*	tst.l (%a0)
	jbeq _?L505					*	jeq .L505
	move.l _unseen_objects,a3			*	move.l unseen_objects,%a3
	cmp.w #0,a3					*	cmp.w #0,%a3
	jbeq _?L496					*	jeq .L496
	lea _unseen_objects,a1				*	lea unseen_objects,%a1
_?L498:							*.L498:
	cmp.l 12(a3),a0					*	cmp.l 12(%a3),%a0
	jbeq _?L514					*	jeq .L514
	lea (20,a3),a1					*	lea (20,%a3),%a1
	move.l 20(a3),a3				*	move.l 20(%a3),%a3
	cmp.w #0,a3					*	cmp.w #0,%a3
	jbne _?L498					*	jne .L498
_?L496:							*.L496:
	move.l _seen_objects,a3				*	move.l seen_objects,%a3
	cmp.w #0,a3					*	cmp.w #0,%a3
	jbeq _?L499					*	jeq .L499
	lea _seen_objects,a1				*	lea seen_objects,%a1
_?L503:							*.L503:
	tst.b 16(a3)					*	tst.b 16(%a3)
	jblt _?L517					*	jlt .L517
	cmp.l 12(a3),a0					*	cmp.l 12(%a3),%a0
	jbeq _?L514					*	jeq .L514
_?L501:							*.L501:
	lea (20,a3),a1					*	lea (20,%a3),%a1
	move.l 20(a3),a3				*	move.l 20(%a3),%a3
	cmp.w #0,a3					*	cmp.w #0,%a3
	jbne _?L503					*	jne .L503
_?L499:							*.L499:
	trap #7						*	trap #7
_?L514:							*.L514:
	move.l 20(a3),(a1)				*	move.l 20(%a3),(%a1)
	move.l a3,d0					*	move.l %a3,%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
_?L517:							*.L517:
	move.l 12(a3),a2				*	move.l 12(%a3),%a2
	cmp.l (a2),a0					*	cmp.l (%a2),%a0
	jbne _?L501					*	jne .L501
	move.l 20(a3),(a1)				*	move.l 20(%a3),(%a1)
	move.l a2,-(sp)					*	move.l %a2,-(%sp)
	jbsr _free					*	jsr free
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a3,d0					*	move.l %a3,%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
_?L505:							*.L505:
	sub.l a3,a3					*	sub.l %a3,%a3
	move.l a3,d0					*	move.l %a3,%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
							*	.size	__deregister_frame_info_bases, .-__deregister_frame_info_bases
	.align	2					*	.align	2
	.globl	___deregister_frame_info		*	.globl	__deregister_frame_info
							*	.hidden	__deregister_frame_info
							*	.type	__deregister_frame_info, @function
___deregister_frame_info:				*__deregister_frame_info:
	jbra ___deregister_frame_info_bases		*	jra __deregister_frame_info_bases
							*	.size	__deregister_frame_info, .-__deregister_frame_info
	.align	2					*	.align	2
	.globl	___deregister_frame			*	.globl	__deregister_frame
							*	.hidden	__deregister_frame
							*	.type	__deregister_frame, @function
___deregister_frame:					*__deregister_frame:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	tst.l (a0)					*	tst.l (%a0)
	jbne _?L524					*	jne .L524
	rts						*	rts
_?L524:							*.L524:
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr ___deregister_frame_info_bases		*	jsr __deregister_frame_info_bases
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,4(sp)					*	move.l %d0,4(%sp)
	jbra _free					*	jra free
							*	.size	__deregister_frame, .-__deregister_frame
	.align	2					*	.align	2
	.globl	__Unwind_Find_FDE			*	.globl	_Unwind_Find_FDE
							*	.hidden	_Unwind_Find_FDE
							*	.type	_Unwind_Find_FDE, @function
__Unwind_Find_FDE:					*_Unwind_Find_FDE:
	link.w a6,#-4					*	link.w %fp,#-4
	movem.l d3/d4/a3/a4/a5,-(sp)			*	movem.l #6172,-(%sp)
	move.l 8(a6),d3					*	move.l 8(%fp),%d3
	move.l 12(a6),a5				*	move.l 12(%fp),%a5
	move.l _seen_objects,a4				*	move.l seen_objects,%a4
	cmp.w #0,a4					*	cmp.w #0,%a4
	jbeq _?L526					*	jeq .L526
_?L529:							*.L529:
	cmp.l (a4),d3					*	cmp.l (%a4),%d3
	jbcc _?L556					*	jcc .L556
	move.l 20(a4),a4				*	move.l 20(%a4),%a4
	cmp.w #0,a4					*	cmp.w #0,%a4
	jbne _?L529					*	jne .L529
_?L526:							*.L526:
	lea _search_object,a4				*	lea search_object,%a4
	move.l #_seen_objects,d4			*	move.l #seen_objects,%d4
_?L532:							*.L532:
	move.l _unseen_objects,a3			*	move.l unseen_objects,%a3
	cmp.w #0,a3					*	cmp.w #0,%a3
	jbeq _?L525					*	jeq .L525
	move.l 20(a3),_unseen_objects			*	move.l 20(%a3),unseen_objects
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l _seen_objects,a0				*	move.l seen_objects,%a0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbeq _?L541					*	jeq .L541
	move.l (a3),d1					*	move.l (%a3),%d1
	move.l d4,a1					*	move.l %d4,%a1
_?L531:							*.L531:
	cmp.l (a0),d1					*	cmp.l (%a0),%d1
	jbhi _?L530					*	jhi .L530
	lea (20,a0),a1					*	lea (20,%a0),%a1
	move.l 20(a0),a0				*	move.l 20(%a0),%a0
	cmp.w #0,a0					*	cmp.w #0,%a0
	jbne _?L531					*	jne .L531
_?L530:							*.L530:
	move.l a0,20(a3)				*	move.l %a0,20(%a3)
	move.l a3,(a1)					*	move.l %a3,(%a1)
	tst.l d0					*	tst.l %d0
	jbeq _?L532					*	jeq .L532
_?L560:							*.L560:
	move.l a3,a4					*	move.l %a3,%a4
	move.l d0,a3					*	move.l %d0,%a3
	move.l 4(a4),d4					*	move.l 4(%a4),%d4
	move.l d4,(a5)					*	move.l %d4,(%a5)
	move.l 8(a4),d3					*	move.l 8(%a4),%d3
	move.l d3,4(a5)					*	move.l %d3,4(%a5)
	move.w 16(a4),d1				*	move.w 16(%a4),%d1
	lsr.w #5,d1					*	lsr.w #5,%d1
	move.b d1,d0					*	move.b %d1,%d0
	btst #5,16(a4)					*	btst #5,16(%a4)
	jbne _?L535					*	jne .L535
_?L558:							*.L558:
	and.l #255,d1					*	and.l #255,%d1
	lea (8,a3),a0					*	lea (8,%a3),%a0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L544					*	jeq .L544
_?L559:							*.L559:
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L538					*	jeq .L538
	jbls _?L544					*	jls .L544
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L557					*	jne .L557
_?L537:							*.L537:
	pea -4(a6)					*	pea -4(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l -4(a6),8(a5)				*	move.l -4(%fp),8(%a5)
	lea (16,sp),sp					*	lea (16,%sp),%sp
_?L525:							*.L525:
	move.l a3,d0					*	move.l %a3,%d0
	movem.l -24(a6),d3/d4/a3/a4/a5			*	movem.l -24(%fp),#14360
	unlk a6						*	unlk %fp
	rts						*	rts
_?L556:							*.L556:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	jbsr _search_object				*	jsr search_object
	move.l d0,a3					*	move.l %d0,%a3
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L526					*	jeq .L526
	move.l 4(a4),d4					*	move.l 4(%a4),%d4
	move.l d4,(a5)					*	move.l %d4,(%a5)
	move.l 8(a4),d3					*	move.l 8(%a4),%d3
	move.l d3,4(a5)					*	move.l %d3,4(%a5)
	move.w 16(a4),d1				*	move.w 16(%a4),%d1
	lsr.w #5,d1					*	lsr.w #5,%d1
	move.b d1,d0					*	move.b %d1,%d0
	btst #5,16(a4)					*	btst #5,16(%a4)
	jbeq _?L558					*	jeq .L558
_?L535:							*.L535:
	move.l a3,d0					*	move.l %a3,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a3),d0					*	sub.l 4(%a3),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	lea (8,a3),a0					*	lea (8,%a3),%a0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L559					*	jne .L559
_?L544:							*.L544:
	moveq #0,d3					*	moveq #0,%d3
	pea -4(a6)					*	pea -4(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l -4(a6),8(a5)				*	move.l -4(%fp),8(%a5)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L525					*	jra .L525
_?L541:							*.L541:
	lea _seen_objects,a1				*	lea seen_objects,%a1
	move.l a0,20(a3)				*	move.l %a0,20(%a3)
	move.l a3,(a1)					*	move.l %a3,(%a1)
	tst.l d0					*	tst.l %d0
	jbeq _?L532					*	jeq .L532
	jbra _?L560					*	jra .L560
_?L538:							*.L538:
	move.l d4,d3					*	move.l %d4,%d3
	pea -4(a6)					*	pea -4(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l -4(a6),8(a5)				*	move.l -4(%fp),8(%a5)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L525					*	jra .L525
_?L557:							*.L557:
	moveq #0,d3					*	moveq #0,%d3
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L537					*	jeq .L537
	trap #7						*	trap #7
							*	.size	_Unwind_Find_FDE, .-_Unwind_Find_FDE
	.data						*	.section	.rodata
	.align	2					*	.align	2
							*	.type	terminator.0, @object
							*	.size	terminator.0, 8
_terminator?0:						*terminator.0:
	.ds.b	8					*	.zero	8
							*	.local	seen_objects
	.align 2	* workaround for 3 args .comm directive.
	.comm	_seen_objects,4				*	.comm	seen_objects,4,2
							*	.local	unseen_objects
	.align 2	* workaround for 3 args .comm directive.
	.comm	_unseen_objects,4			*	.comm	unseen_objects,4,2
							*	.ident	"GCC: (GNU) 13.4.0"
