* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___gedf2				*	.globl	__gedf2
	.globl	___subdf3				*	.globl	__subdf3
	.globl	___fixdfsi				*	.globl	__fixdfsi
	.align	2					*	.align	2
	.globl	___fixunsdfsi				*	.globl	__fixunsdfsi
							*	.hidden	__fixunsdfsi
							*	.type	__fixunsdfsi, @function
___fixunsdfsi:						*__fixunsdfsi:
	movem.l d4/d5/d6/d7,-(sp)			*	movem.l #3840,-(%sp)
	move.l 20(sp),d4				*	move.l 20(%sp),%d4
	move.l 24(sp),d5				*	move.l 24(%sp),%d5
	move.l #1105199104,d6				*	move.l #1105199104,%d6
	clr.l d7					*	clr.l %d7
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___gedf2					*	jsr __gedf2
	lea (16,sp),sp					*	lea (16,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbge _?L9					*	jge .L9
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___fixdfsi					*	jsr __fixdfsi
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d4/d5/d6/d7			*	movem.l (%sp)+,#240
	rts						*	rts
_?L9:							*.L9:
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___subdf3					*	jsr __subdf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___fixdfsi					*	jsr __fixdfsi
	addq.l #8,sp					*	addq.l #8,%sp
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	movem.l (sp)+,d4/d5/d6/d7			*	movem.l (%sp)+,#240
	rts						*	rts
							*	.size	__fixunsdfsi, .-__fixunsdfsi
							*	.ident	"GCC: (GNU) 13.4.0"
