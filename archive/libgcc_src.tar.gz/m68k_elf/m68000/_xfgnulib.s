* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"_xfgnulib.c"				*	.file	"_xfgnulib.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___unordxf2				*	.globl	__unordxf2
							*	.hidden	__unordxf2
							*	.type	__unordxf2, @function
___unordxf2:						*__unordxf2:
	lea (-72,sp),sp					*	lea (-72,%sp),%sp
	move.l 76(sp),d0				*	move.l 76(%sp),%d0
	and.l #2147418112,d0				*	and.l #2147418112,%d0
	cmp.l #2147418112,d0				*	cmp.l #2147418112,%d0
	jbeq _?L8					*	jeq .L8
_?L2:							*.L2:
	move.l 88(sp),d0				*	move.l 88(%sp),%d0
	and.l #2147418112,d0				*	and.l #2147418112,%d0
	cmp.l #2147418112,d0				*	cmp.l #2147418112,%d0
	jbeq _?L9					*	jeq .L9
	moveq #0,d0					*	moveq #0,%d0
	lea (72,sp),sp					*	lea (72,%sp),%sp
	rts						*	rts
_?L8:							*.L8:
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	bclr #31,d0					*	bclr #31,%d0
	move.l 76(sp),36(sp)				*	move.l 76(%sp),36(%sp)
	move.l 80(sp),40(sp)				*	move.l 80(%sp),40(%sp)
	move.l 84(sp),44(sp)				*	move.l 84(%sp),44(%sp)
	or.l 44(sp),d0					*	or.l 44(%sp),%d0
	jbeq _?L2					*	jeq .L2
	moveq #1,d0					*	moveq #1,%d0
	lea (72,sp),sp					*	lea (72,%sp),%sp
	rts						*	rts
_?L9:							*.L9:
	move.l 92(sp),d0				*	move.l 92(%sp),%d0
	bclr #31,d0					*	bclr #31,%d0
	move.l 88(sp),(sp)				*	move.l 88(%sp),(%sp)
	move.l 92(sp),4(sp)				*	move.l 92(%sp),4(%sp)
	move.l 96(sp),8(sp)				*	move.l 96(%sp),8(%sp)
	or.l 8(sp),d0					*	or.l 8(%sp),%d0
	sne d0						*	sne %d0
	ext.w d0					*	ext.w %d0
	ext.l d0					*	ext.l %d0
	neg.l d0					*	neg.l %d0
	lea (72,sp),sp					*	lea (72,%sp),%sp
	rts						*	rts
							*	.size	__unordxf2, .-__unordxf2
	.align	2					*	.align	2
	.globl	___extenddfxf2				*	.globl	__extenddfxf2
							*	.hidden	__extenddfxf2
							*	.type	__extenddfxf2, @function
___extenddfxf2:						*__extenddfxf2:
	lea (-12,sp),sp					*	lea (-12,%sp),%sp
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	move.l 24(sp),d2				*	move.l 24(%sp),%d2
	move.l d0,d3					*	move.l %d0,%d3
	and.l #-2147483648,d3				*	and.l #-2147483648,%d3
	move.l d3,4(sp)					*	move.l %d3,4(%sp)
	move.l d0,d1					*	move.l %d0,%d1
	bclr #31,d1					*	bclr #31,%d1
	or.l d2,d1					*	or.l %d2,%d1
	jbeq _?L15					*	jeq .L15
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	asr.w #4,d1					*	asr.w #4,%d1
	ext.l d1					*	ext.l %d1
	and.l #2047,d1					*	and.l #2047,%d1
	add.l #15360,d1					*	add.l #15360,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d3,d1					*	or.l %d3,%d1
	move.l d1,4(sp)					*	move.l %d1,4(%sp)
	moveq #11,d1					*	moveq #11,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	and.l #2147481600,d0				*	and.l #2147481600,%d0
	move.l d2,d1					*	move.l %d2,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	lsr.w #5,d1					*	lsr.w #5,%d1
	or.l d1,d0					*	or.l %d1,%d0
	bset #31,d0					*	bset #31,%d0
	move.l d0,8(sp)					*	move.l %d0,8(%sp)
	moveq #11,d0					*	moveq #11,%d0
	lsl.l d0,d2					*	lsl.l %d0,%d2
	move.l d2,12(sp)				*	move.l %d2,12(%sp)
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l 12(sp),d2				*	move.l 12(%sp),%d2
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
_?L15:							*.L15:
	clr.l 8(sp)					*	clr.l 8(%sp)
	clr.l 12(sp)					*	clr.l 12(%sp)
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l 12(sp),d2				*	move.l 12(%sp),%d2
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
							*	.size	__extenddfxf2, .-__extenddfxf2
	.align	2					*	.align	2
	.globl	___truncxfdf2				*	.globl	__truncxfdf2
							*	.hidden	__truncxfdf2
							*	.type	__truncxfdf2, @function
___truncxfdf2:						*__truncxfdf2:
	lea (-36,sp),sp					*	lea (-36,%sp),%sp
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 56(sp),a1				*	move.l 56(%sp),%a1
	move.l 60(sp),a2				*	move.l 60(%sp),%a2
	move.l 64(sp),a3				*	move.l 64(%sp),%a3
	move.l a1,d0					*	move.l %a1,%d0
	move.l d0,d4					*	move.l %d0,%d4
	and.l #-2147483648,d4				*	and.l #-2147483648,%d4
	move.l a2,d1					*	move.l %a2,%d1
	move.l a1,16(sp)				*	move.l %a1,16(%sp)
	move.l a2,20(sp)				*	move.l %a2,20(%sp)
	move.l a3,24(sp)				*	move.l %a3,24(%sp)
	move.l 24(sp),d3				*	move.l 24(%sp),%d3
	move.l d0,d2					*	move.l %d0,%d2
	bclr #31,d2					*	bclr #31,%d2
	move.l a2,d5					*	move.l %a2,%d5
	or.l d3,d5					*	or.l %d3,%d5
	or.l d5,d2					*	or.l %d5,%d2
	jbeq _?L22					*	jeq .L22
	swap d0						*	swap %d0
	ext.l d0					*	ext.l %d0
	and.l #32767,d0					*	and.l #32767,%d0
	add.l #-15360,d0				*	add.l #-15360,%d0
	cmp.l #2046,d0					*	cmp.l #2046,%d0
	jbgt _?L23					*	jgt .L23
	lsl.w #4,d0					*	lsl.w #4,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d1,d2					*	move.l %d1,%d2
	moveq #11,d5					*	moveq #11,%d5
	lsr.l d5,d2					*	lsr.l %d5,%d2
	and.l #1048575,d2				*	and.l #1048575,%d2
	or.l d4,d2					*	or.l %d4,%d2
	lsl.w #5,d1					*	lsl.w #5,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	lsr.l d5,d3					*	lsr.l %d5,%d3
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	move.l d1,d4					*	move.l %d1,%d4
	or.l d3,d4					*	or.l %d3,%d4
	move.l d5,d0					*	move.l %d5,%d0
	move.l d4,d1					*	move.l %d4,%d1
_?L18:							*.L18:
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	lea (36,sp),sp					*	lea (36,%sp),%sp
	rts						*	rts
_?L23:							*.L23:
	move.l #2046,d0					*	move.l #2046,%d0
	lsl.w #4,d0					*	lsl.w #4,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d1,d2					*	move.l %d1,%d2
	moveq #11,d5					*	moveq #11,%d5
	lsr.l d5,d2					*	lsr.l %d5,%d2
	and.l #1048575,d2				*	and.l #1048575,%d2
	or.l d4,d2					*	or.l %d4,%d2
	lsl.w #5,d1					*	lsl.w #5,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	lsr.l d5,d3					*	lsr.l %d5,%d3
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	move.l d1,d4					*	move.l %d1,%d4
	or.l d3,d4					*	or.l %d3,%d4
	move.l d5,d0					*	move.l %d5,%d0
	move.l d4,d1					*	move.l %d4,%d1
	jbra _?L18					*	jra .L18
_?L22:							*.L22:
	sub.l a0,a0					*	sub.l %a0,%a0
	move.l d4,d0					*	move.l %d4,%d0
	move.l a0,d1					*	move.l %a0,%d1
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	lea (36,sp),sp					*	lea (36,%sp),%sp
	rts						*	rts
							*	.size	__truncxfdf2, .-__truncxfdf2
	.align	2					*	.align	2
	.globl	___extendsfxf2				*	.globl	__extendsfxf2
							*	.hidden	__extendsfxf2
							*	.type	__extendsfxf2, @function
___extendsfxf2:						*__extendsfxf2:
	lea (-12,sp),sp					*	lea (-12,%sp),%sp
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 20(sp),-(sp)				*	move.l 20(%sp),-(%sp)
	jbsr ___extendsfdf2				*	jsr __extendsfdf2
	move.l d0,d3					*	move.l %d0,%d3
	and.l #-2147483648,d3				*	and.l #-2147483648,%d3
	move.l d3,8(sp)					*	move.l %d3,8(%sp)
	move.l d0,d2					*	move.l %d0,%d2
	bclr #31,d2					*	bclr #31,%d2
	or.l d1,d2					*	or.l %d1,%d2
	addq.l #4,sp					*	addq.l #4,%sp
	jbeq _?L29					*	jeq .L29
	move.l d0,d2					*	move.l %d0,%d2
	swap d2						*	swap %d2
	asr.w #4,d2					*	asr.w #4,%d2
	ext.l d2					*	ext.l %d2
	and.l #2047,d2					*	and.l #2047,%d2
	add.l #15360,d2					*	add.l #15360,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d3,d2					*	or.l %d3,%d2
	move.l d2,4(sp)					*	move.l %d2,4(%sp)
	moveq #11,d2					*	moveq #11,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	and.l #2147481600,d0				*	and.l #2147481600,%d0
	move.l d1,d2					*	move.l %d1,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	lsr.w #5,d2					*	lsr.w #5,%d2
	or.l d2,d0					*	or.l %d2,%d0
	bset #31,d0					*	bset #31,%d0
	move.l d0,8(sp)					*	move.l %d0,8(%sp)
	moveq #11,d0					*	moveq #11,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	move.l d1,12(sp)				*	move.l %d1,12(%sp)
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l 12(sp),d2				*	move.l 12(%sp),%d2
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
_?L29:							*.L29:
	clr.l 8(sp)					*	clr.l 8(%sp)
	clr.l 12(sp)					*	clr.l 12(%sp)
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l 12(sp),d2				*	move.l 12(%sp),%d2
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
							*	.size	__extendsfxf2, .-__extendsfxf2
	.align	2					*	.align	2
	.globl	___truncxfsf2				*	.globl	__truncxfsf2
							*	.hidden	__truncxfsf2
							*	.type	__truncxfsf2, @function
___truncxfsf2:						*__truncxfsf2:
	lea (-36,sp),sp					*	lea (-36,%sp),%sp
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 56(sp),a1				*	move.l 56(%sp),%a1
	move.l 60(sp),a2				*	move.l 60(%sp),%a2
	move.l 64(sp),a3				*	move.l 64(%sp),%a3
	move.l a1,d0					*	move.l %a1,%d0
	move.l a1,40(sp)				*	move.l %a1,40(%sp)
	move.l a2,44(sp)				*	move.l %a2,44(%sp)
	move.l a3,48(sp)				*	move.l %a3,48(%sp)
	move.l d0,d4					*	move.l %d0,%d4
	and.l #-2147483648,d4				*	and.l #-2147483648,%d4
	move.l a2,d1					*	move.l %a2,%d1
	move.l a1,28(sp)				*	move.l %a1,28(%sp)
	move.l a2,32(sp)				*	move.l %a2,32(%sp)
	move.l a3,36(sp)				*	move.l %a3,36(%sp)
	move.l a1,16(sp)				*	move.l %a1,16(%sp)
	move.l a2,20(sp)				*	move.l %a2,20(%sp)
	move.l a3,24(sp)				*	move.l %a3,24(%sp)
	move.l 24(sp),d3				*	move.l 24(%sp),%d3
	move.l d0,d2					*	move.l %d0,%d2
	bclr #31,d2					*	bclr #31,%d2
	move.l a2,d5					*	move.l %a2,%d5
	or.l d3,d5					*	or.l %d3,%d5
	or.l d5,d2					*	or.l %d5,%d2
	jbeq _?L36					*	jeq .L36
	swap d0						*	swap %d0
	ext.l d0					*	ext.l %d0
	and.l #32767,d0					*	and.l #32767,%d0
	add.l #-15360,d0				*	add.l #-15360,%d0
	cmp.l #2046,d0					*	cmp.l #2046,%d0
	jbgt _?L37					*	jgt .L37
	lsl.w #4,d0					*	lsl.w #4,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d1,d2					*	move.l %d1,%d2
	moveq #11,d5					*	moveq #11,%d5
	lsr.l d5,d2					*	lsr.l %d5,%d2
	and.l #1048575,d2				*	and.l #1048575,%d2
	or.l d4,d2					*	or.l %d4,%d2
	lsl.w #5,d1					*	lsl.w #5,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	lsr.l d5,d3					*	lsr.l %d5,%d3
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	move.l d1,d4					*	move.l %d1,%d4
	or.l d3,d4					*	or.l %d3,%d4
	move.l d5,d0					*	move.l %d5,%d0
	move.l d4,d1					*	move.l %d4,%d1
_?L32:							*.L32:
	move.l d0,56(sp)				*	move.l %d0,56(%sp)
	move.l d1,60(sp)				*	move.l %d1,60(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	lea (36,sp),sp					*	lea (36,%sp),%sp
	jbra ___truncdfsf2				*	jra __truncdfsf2
_?L37:							*.L37:
	move.l #2046,d0					*	move.l #2046,%d0
	lsl.w #4,d0					*	lsl.w #4,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d1,d2					*	move.l %d1,%d2
	moveq #11,d5					*	moveq #11,%d5
	lsr.l d5,d2					*	lsr.l %d5,%d2
	and.l #1048575,d2				*	and.l #1048575,%d2
	or.l d4,d2					*	or.l %d4,%d2
	lsl.w #5,d1					*	lsl.w #5,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	lsr.l d5,d3					*	lsr.l %d5,%d3
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	move.l d1,d4					*	move.l %d1,%d4
	or.l d3,d4					*	or.l %d3,%d4
	move.l d5,d0					*	move.l %d5,%d0
	move.l d4,d1					*	move.l %d4,%d1
	jbra _?L32					*	jra .L32
_?L36:							*.L36:
	sub.l a0,a0					*	sub.l %a0,%a0
	move.l d4,d0					*	move.l %d4,%d0
	move.l a0,d1					*	move.l %a0,%d1
	move.l d0,56(sp)				*	move.l %d0,56(%sp)
	move.l d1,60(sp)				*	move.l %d1,60(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	lea (36,sp),sp					*	lea (36,%sp),%sp
	jbra ___truncdfsf2				*	jra __truncdfsf2
							*	.size	__truncxfsf2, .-__truncxfsf2
							*	.globl	__extenddfxf2
	.align	2					*	.align	2
	.globl	___floatsixf				*	.globl	__floatsixf
							*	.hidden	__floatsixf
							*	.type	__floatsixf, @function
___floatsixf:						*__floatsixf:
	move.l 4(sp),-(sp)				*	move.l 4(%sp),-(%sp)
	jbsr ___floatsidf				*	jsr __floatsidf
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
							*	.size	__floatsixf, .-__floatsixf
	.align	2					*	.align	2
	.globl	___floatunsixf				*	.globl	__floatunsixf
							*	.hidden	__floatunsixf
							*	.type	__floatunsixf, @function
___floatunsixf:						*__floatunsixf:
	move.l 4(sp),-(sp)				*	move.l 4(%sp),-(%sp)
	jbsr ___floatunsidf				*	jsr __floatunsidf
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
							*	.size	__floatunsixf, .-__floatunsixf
							*	.globl	__truncxfdf2
	.align	2					*	.align	2
	.globl	___fixxfsi				*	.globl	__fixxfsi
							*	.hidden	__fixxfsi
							*	.type	__fixxfsi, @function
___fixxfsi:						*__fixxfsi:
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	jbsr ___truncxfdf2				*	jsr __truncxfdf2
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,4(sp)					*	move.l %d0,4(%sp)
	move.l d1,8(sp)					*	move.l %d1,8(%sp)
	jbra ___fixdfsi					*	jra __fixdfsi
							*	.size	__fixxfsi, .-__fixxfsi
	.globl	___adddf3				*	.globl	__adddf3
	.align	2					*	.align	2
	.globl	___addxf3				*	.globl	__addxf3
							*	.hidden	__addxf3
							*	.type	__addxf3, @function
___addxf3:						*__addxf3:
	movem.l d4/d5/a3,-(sp)				*	movem.l #3088,-(%sp)
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___adddf3					*	jsr __adddf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d4/d5/a3				*	movem.l (%sp)+,#2096
	rts						*	rts
							*	.size	__addxf3, .-__addxf3
	.globl	___subdf3				*	.globl	__subdf3
	.align	2					*	.align	2
	.globl	___subxf3				*	.globl	__subxf3
							*	.hidden	__subxf3
							*	.type	__subxf3, @function
___subxf3:						*__subxf3:
	movem.l d4/d5/a3,-(sp)				*	movem.l #3088,-(%sp)
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___subdf3					*	jsr __subdf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d4/d5/a3				*	movem.l (%sp)+,#2096
	rts						*	rts
							*	.size	__subxf3, .-__subxf3
	.globl	___muldf3				*	.globl	__muldf3
	.align	2					*	.align	2
	.globl	___mulxf3				*	.globl	__mulxf3
							*	.hidden	__mulxf3
							*	.type	__mulxf3, @function
___mulxf3:						*__mulxf3:
	movem.l d4/d5/a3,-(sp)				*	movem.l #3088,-(%sp)
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___muldf3					*	jsr __muldf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d4/d5/a3				*	movem.l (%sp)+,#2096
	rts						*	rts
							*	.size	__mulxf3, .-__mulxf3
	.globl	___divdf3				*	.globl	__divdf3
	.align	2					*	.align	2
	.globl	___divxf3				*	.globl	__divxf3
							*	.hidden	__divxf3
							*	.type	__divxf3, @function
___divxf3:						*__divxf3:
	movem.l d4/d5/a3,-(sp)				*	movem.l #3088,-(%sp)
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr ___divdf3					*	jsr __divdf3
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d1,(sp)					*	move.l %d1,(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	addq.l #8,sp					*	addq.l #8,%sp
	movem.l (sp)+,d4/d5/a3				*	movem.l (%sp)+,#2096
	rts						*	rts
							*	.size	__divxf3, .-__divxf3
	.align	2					*	.align	2
	.globl	___negxf2				*	.globl	__negxf2
							*	.hidden	__negxf2
							*	.type	__negxf2, @function
___negxf2:						*__negxf2:
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	move.l 12(sp),-(sp)				*	move.l 12(%sp),-(%sp)
	jbsr ___truncxfdf2				*	jsr __truncxfdf2
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,a0					*	move.l %d0,%a0
	add.l #-2147483648,a0				*	add.l #-2147483648,%a0
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr ___extenddfxf2				*	jsr __extenddfxf2
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
							*	.size	__negxf2, .-__negxf2
	.align	2					*	.align	2
	.globl	___cmpxf2				*	.globl	__cmpxf2
							*	.hidden	__cmpxf2
							*	.type	__cmpxf2, @function
___cmpxf2:						*__cmpxf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__cmpxf2, .-__cmpxf2
	.align	2					*	.align	2
	.globl	___eqxf2				*	.globl	__eqxf2
							*	.hidden	__eqxf2
							*	.type	__eqxf2, @function
___eqxf2:						*__eqxf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__eqxf2, .-__eqxf2
	.align	2					*	.align	2
	.globl	___nexf2				*	.globl	__nexf2
							*	.hidden	__nexf2
							*	.type	__nexf2, @function
___nexf2:						*__nexf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__nexf2, .-__nexf2
	.align	2					*	.align	2
	.globl	___ltxf2				*	.globl	__ltxf2
							*	.hidden	__ltxf2
							*	.type	__ltxf2, @function
___ltxf2:						*__ltxf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__ltxf2, .-__ltxf2
	.align	2					*	.align	2
	.globl	___lexf2				*	.globl	__lexf2
							*	.hidden	__lexf2
							*	.type	__lexf2, @function
___lexf2:						*__lexf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__lexf2, .-__lexf2
	.align	2					*	.align	2
	.globl	___gtxf2				*	.globl	__gtxf2
							*	.hidden	__gtxf2
							*	.type	__gtxf2, @function
___gtxf2:						*__gtxf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__gtxf2, .-__gtxf2
	.align	2					*	.align	2
	.globl	___gexf2				*	.globl	__gexf2
							*	.hidden	__gexf2
							*	.type	__gexf2, @function
___gexf2:						*__gexf2:
	movem.l d3/d4/d5/a3,-(sp)			*	movem.l #7184,-(%sp)
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l 24(sp),d4				*	move.l 24(%sp),%d4
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	lea ___truncxfdf2,a3				*	lea __truncxfdf2,%a3
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	move.l 40(sp),-(sp)				*	move.l 40(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,40(sp)				*	move.l %d0,40(%sp)
	move.l d1,44(sp)				*	move.l %d1,44(%sp)
	move.l d3,(sp)					*	move.l %d3,(%sp)
	move.l d4,4(sp)					*	move.l %d4,4(%sp)
	move.l d5,8(sp)					*	move.l %d5,8(%sp)
	jbsr (a3)					*	jsr (%a3)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d0,20(sp)				*	move.l %d0,20(%sp)
	move.l d1,24(sp)				*	move.l %d1,24(%sp)
	movem.l (sp)+,d3/d4/d5/a3			*	movem.l (%sp)+,#2104
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__gexf2, .-__gexf2
							*	.ident	"GCC: (GNU) 13.4.0"
