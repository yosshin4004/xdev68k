* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68000
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___mulsi3				*	.globl	__mulsi3
	.align	2					*	.align	2
	.globl	___muldi3				*	.globl	__muldi3
							*	.hidden	__muldi3
							*	.type	__muldi3, @function
___muldi3:						*__muldi3:
	movem.l d3/d4/d5/d6/d7/a3,-(sp)			*	movem.l #7952,-(%sp)
	move.l 32(sp),a0				*	move.l 32(%sp),%a0
	move.l 40(sp),d5				*	move.l 40(%sp),%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 532 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	a0,d0					*	move.l	%a0,%d0
	move.l	d5,d1					*	move.l	%d5,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,d6					*	move.l	%d2,%d6
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,d7					*	move.l	%d0,%d7
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	lea ___mulsi3,a3				*	lea __mulsi3,%a3
	move.l 36(sp),-(sp)				*	move.l 36(%sp),-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	add.l d0,d7					*	add.l %d0,%d7
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l 32(sp),-(sp)				*	move.l 32(%sp),-(%sp)
	jbsr (a3)					*	jsr (%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	add.l d7,d0					*	add.l %d7,%d0
	move.l d6,d1					*	move.l %d6,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2296
	rts						*	rts
							*	.size	__muldi3, .-__muldi3
							*	.ident	"GCC: (GNU) 13.4.0"
