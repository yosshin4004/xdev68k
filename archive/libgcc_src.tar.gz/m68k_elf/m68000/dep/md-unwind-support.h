/* Dummy header for targets without a definition of
   MD_FALLBACK_FRAME_STATE_FOR.  */
