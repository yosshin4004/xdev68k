* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ctzsi2				*	.globl	__ctzsi2
							*	.hidden	__ctzsi2
							*	.type	__ctzsi2, @function
___ctzsi2:						*__ctzsi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	and.l d1,d0					*	and.l %d1,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 722 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d0				*	bfffo %d0{#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	moveq #31,d1					*	moveq #31,%d1
	sub.l d0,d1					*	sub.l %d0,%d1
	move.l d1,d0					*	move.l %d1,%d0
	rts						*	rts
							*	.size	__ctzsi2, .-__ctzsi2
							*	.ident	"GCC: (GNU) 13.4.0"
