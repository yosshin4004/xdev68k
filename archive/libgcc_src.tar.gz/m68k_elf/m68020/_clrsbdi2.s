* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clrsbdi2				*	.globl	__clrsbdi2
							*	.hidden	__clrsbdi2
							*	.type	__clrsbdi2, @function
___clrsbdi2:						*__clrsbdi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	tst.l d1					*	tst.l %d1
	jbeq _?L3					*	jeq .L3
	moveq #-1,d2					*	moveq #-1,%d2
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbeq _?L10					*	jeq .L10
	move.l d1,d0					*	move.l %d1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	eor.l d1,d0					*	eor.l %d1,%d0
	sub.l a0,a0					*	sub.l %a0,%a0
* APP ON (APP) asm_mode=gas				*#APP
							*| 784 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d0				*	bfffo %d0{#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	lea -1(a0,d0.l),a0				*	lea -1(%a0,%d0.l),%a0
	move.l a0,d0					*	move.l %a0,%d0
_?L1:							*.L1:
	rts						*	rts
_?L10:							*.L10:
	not.l d0					*	not.l %d0
_?L3:							*.L3:
	tst.l d0					*	tst.l %d0
	jbne _?L11					*	jne .L11
	moveq #63,d0					*	moveq #63,%d0
	rts						*	rts
_?L11:							*.L11:
	move.w #32,a0					*	move.w #32,%a0
* APP ON (APP) asm_mode=gas				*#APP
							*| 784 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d0				*	bfffo %d0{#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	lea -1(a0,d0.l),a0				*	lea -1(%a0,%d0.l),%a0
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L1					*	jra .L1
							*	.size	__clrsbdi2, .-__clrsbdi2
							*	.ident	"GCC: (GNU) 13.4.0"
