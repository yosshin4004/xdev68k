* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixsfdi				*	.globl	__fixsfdi
							*	.hidden	__fixsfdi
							*	.type	__fixsfdi, @function
___fixsfdi:						*__fixsfdi:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	ftst.s d0					*	ftst.s %d0
	fblt _?L8					*	fjlt .L8
	move.l d0,4(sp)					*	move.l %d0,4(%sp)
	jbra ___fixunssfdi				*	jra __fixunssfdi
_?L8:							*.L8:
	fneg.s d0,fp0					*	fneg.s %d0,%fp0
	fmove.s fp0,-(sp)				*	fmove.s %fp0,-(%sp)
	jbsr ___fixunssfdi				*	jsr __fixunssfdi
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	__fixsfdi, .-__fixsfdi
							*	.ident	"GCC: (GNU) 13.4.0"
