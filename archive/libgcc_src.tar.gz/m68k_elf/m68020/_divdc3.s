* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divdc3				*	.globl	__divdc3
							*	.hidden	__divdc3
							*	.type	__divdc3, @function
___divdc3:						*__divdc3:
	fmovem fp2/fp3/fp4/fp6,-(sp)			*	fmovem #92,-(%sp)
	fabs.d 68(sp),fp0				*	fabs.d 68(%sp),%fp0
	fabs.d 76(sp),fp2				*	fabs.d 76(%sp),%fp2
	fcmp.x fp2,fp0					*	fcmp.x %fp2,%fp0
	fbnlt _?L77					*	fjnlt .L77
	fcmp.d #0x7fdfffff,#0xffffffff,fp2		*	fcmp.d #0x7fdfffffffffffff,%fp2
	fbnge _?L4					*	fjnge .L4
	fmove.d 52(sp),fp0				*	fmove.d 52(%sp),%fp0
	fmul.d #0x3fe00000,#0x00000000,fp0		*	fmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fmove.d 60(sp),fp1				*	fmove.d 60(%sp),%fp1
	fmul.d #0x3fe00000,#0x00000000,fp1		*	fmul.d #0x3fe0000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fmove.d 68(sp),fp2				*	fmove.d 68(%sp),%fp2
	fmul.d #0x3fe00000,#0x00000000,fp2		*	fmul.d #0x3fe0000000000000,%fp2
	fmove.d fp2,68(sp)				*	fmove.d %fp2,68(%sp)
	fmove.d 76(sp),fp0				*	fmove.d 76(%sp),%fp0
	fmul.d #0x3fe00000,#0x00000000,fp0		*	fmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,76(sp)				*	fmove.d %fp0,76(%sp)
	fabs.x fp0,fp2					*	fabs.x %fp0,%fp2
_?L4:							*.L4:
	fcmp.d #0x3cb00000,#0x00000000,fp2		*	fcmp.d #0x3cb0000000000000,%fp2
	fbnlt _?L78					*	fjnlt .L78
	fmove.d 52(sp),fp1				*	fmove.d 52(%sp),%fp1
	fmul.d #0x43300000,#0x00000000,fp1		*	fmul.d #0x4330000000000000,%fp1
	fmove.d fp1,52(sp)				*	fmove.d %fp1,52(%sp)
	fmove.d 60(sp),fp2				*	fmove.d 60(%sp),%fp2
	fmul.d #0x43300000,#0x00000000,fp2		*	fmul.d #0x4330000000000000,%fp2
	fmove.d fp2,60(sp)				*	fmove.d %fp2,60(%sp)
	fmove.d 68(sp),fp0				*	fmove.d 68(%sp),%fp0
	fmul.d #0x43300000,#0x00000000,fp0		*	fmul.d #0x4330000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fmove.d 76(sp),fp1				*	fmove.d 76(%sp),%fp1
	fmul.d #0x43300000,#0x00000000,fp1		*	fmul.d #0x4330000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
_?L8:							*.L8:
	fmove.d 68(sp),fp2				*	fmove.d 68(%sp),%fp2
	fdiv.d 76(sp),fp2				*	fdiv.d 76(%sp),%fp2
	fmove.d 68(sp),fp1				*	fmove.d 68(%sp),%fp1
	fmul.x fp2,fp1					*	fmul.x %fp2,%fp1
	fadd.d 76(sp),fp1				*	fadd.d 76(%sp),%fp1
	fabs.x fp2,fp0					*	fabs.x %fp2,%fp0
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fbngt _?L80					*	fjngt .L80
_?L96:							*.L96:
	fmove.d 52(sp),fp0				*	fmove.d 52(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fadd.d 60(sp),fp0				*	fadd.d 60(%sp),%fp0
	fmove.x fp0,fp3					*	fmove.x %fp0,%fp3
	fdiv.x fp1,fp3					*	fdiv.x %fp1,%fp3
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fsub.d 52(sp),fp0				*	fsub.d 52(%sp),%fp0
	fdiv.x fp1,fp0					*	fdiv.x %fp1,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbun _?L92					*	fjun .L92
_?L31:							*.L31:
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L77:							*.L77:
	fcmp.d #0x7fdfffff,#0xffffffff,fp0		*	fcmp.d #0x7fdfffffffffffff,%fp0
	fbnge _?L18					*	fjnge .L18
	fmove.d 52(sp),fp0				*	fmove.d 52(%sp),%fp0
	fmul.d #0x3fe00000,#0x00000000,fp0		*	fmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fmove.d 60(sp),fp1				*	fmove.d 60(%sp),%fp1
	fmul.d #0x3fe00000,#0x00000000,fp1		*	fmul.d #0x3fe0000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fmove.d 68(sp),fp2				*	fmove.d 68(%sp),%fp2
	fmul.d #0x3fe00000,#0x00000000,fp2		*	fmul.d #0x3fe0000000000000,%fp2
	fmove.d fp2,68(sp)				*	fmove.d %fp2,68(%sp)
	fmove.d 76(sp),fp0				*	fmove.d 76(%sp),%fp0
	fmul.d #0x3fe00000,#0x00000000,fp0		*	fmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,76(sp)				*	fmove.d %fp0,76(%sp)
	fabs.x fp2,fp0					*	fabs.x %fp2,%fp0
_?L18:							*.L18:
	fcmp.d #0x3cb00000,#0x00000000,fp0		*	fcmp.d #0x3cb0000000000000,%fp0
	fbnlt _?L81					*	fjnlt .L81
	fmove.d 52(sp),fp1				*	fmove.d 52(%sp),%fp1
	fmul.d #0x43300000,#0x00000000,fp1		*	fmul.d #0x4330000000000000,%fp1
	fmove.d fp1,52(sp)				*	fmove.d %fp1,52(%sp)
	fmove.d 60(sp),fp2				*	fmove.d 60(%sp),%fp2
	fmul.d #0x43300000,#0x00000000,fp2		*	fmul.d #0x4330000000000000,%fp2
	fmove.d fp2,60(sp)				*	fmove.d %fp2,60(%sp)
	fmove.d 68(sp),fp0				*	fmove.d 68(%sp),%fp0
	fmul.d #0x43300000,#0x00000000,fp0		*	fmul.d #0x4330000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fmove.d 76(sp),fp1				*	fmove.d 76(%sp),%fp1
	fmul.d #0x43300000,#0x00000000,fp1		*	fmul.d #0x4330000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
_?L22:							*.L22:
	fmove.d 76(sp),fp1				*	fmove.d 76(%sp),%fp1
	fdiv.d 68(sp),fp1				*	fdiv.d 68(%sp),%fp1
	fmove.d 76(sp),fp2				*	fmove.d 76(%sp),%fp2
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fadd.d 68(sp),fp2				*	fadd.d 68(%sp),%fp2
	fabs.x fp1,fp0					*	fabs.x %fp1,%fp0
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fbngt _?L83					*	fjngt .L83
_?L94:							*.L94:
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fadd.d 52(sp),fp0				*	fadd.d 52(%sp),%fp0
	fmove.x fp0,fp3					*	fmove.x %fp0,%fp3
	fdiv.x fp2,fp3					*	fdiv.x %fp2,%fp3
	fmul.d 52(sp),fp1				*	fmul.d 52(%sp),%fp1
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fdiv.x fp2,fp0					*	fdiv.x %fp2,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L31					*	fjor .L31
	jbra _?L92					*	jra .L92
_?L81:							*.L81:
	fabs.d 52(sp),fp2				*	fabs.d 52(%sp),%fp2
	fabs.d 60(sp),fp4				*	fabs.d 60(%sp),%fp4
	fcmp.d #0x10000000,#0x000000,fp2		*	fcmp.d #0x10000000000000,%fp2
	fblt _?L93					*	fjlt .L93
	fcmp.d #0x10000000,#0x000000,fp4		*	fcmp.d #0x10000000000000,%fp4
	fbnlt _?L22					*	fjnlt .L22
	fcmp.d #0x7c9fffff,#0xffffffff,fp2		*	fcmp.d #0x7c9fffffffffffff,%fp2
	fbnlt _?L22					*	fjnlt .L22
_?L25:							*.L25:
	fcmp.d #0x7c9fffff,#0xffffffff,fp0		*	fcmp.d #0x7c9fffffffffffff,%fp0
	fbnlt _?L22					*	fjnlt .L22
	fmove.d 52(sp),fp2				*	fmove.d 52(%sp),%fp2
	fmul.d #0x43300000,#0x00000000,fp2		*	fmul.d #0x4330000000000000,%fp2
	fmove.d fp2,52(sp)				*	fmove.d %fp2,52(%sp)
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fmul.d #0x43300000,#0x00000000,fp0		*	fmul.d #0x4330000000000000,%fp0
	fmove.d fp0,60(sp)				*	fmove.d %fp0,60(%sp)
	fmove.d 68(sp),fp1				*	fmove.d 68(%sp),%fp1
	fmul.d #0x43300000,#0x00000000,fp1		*	fmul.d #0x4330000000000000,%fp1
	fmove.d fp1,68(sp)				*	fmove.d %fp1,68(%sp)
	fmove.d 76(sp),fp2				*	fmove.d 76(%sp),%fp2
	fmul.d #0x43300000,#0x00000000,fp2		*	fmul.d #0x4330000000000000,%fp2
	fmove.d fp2,76(sp)				*	fmove.d %fp2,76(%sp)
	fmove.d 76(sp),fp1				*	fmove.d 76(%sp),%fp1
	fdiv.d 68(sp),fp1				*	fdiv.d 68(%sp),%fp1
	fmove.d 76(sp),fp2				*	fmove.d 76(%sp),%fp2
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fadd.d 68(sp),fp2				*	fadd.d 68(%sp),%fp2
	fabs.x fp1,fp0					*	fabs.x %fp1,%fp0
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fbgt _?L94					*	fjgt .L94
_?L83:							*.L83:
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fdiv.d 68(sp),fp0				*	fdiv.d 68(%sp),%fp0
	fmul.d 76(sp),fp0				*	fmul.d 76(%sp),%fp0
	fadd.d 52(sp),fp0				*	fadd.d 52(%sp),%fp0
	fmove.x fp0,fp3					*	fmove.x %fp0,%fp3
	fdiv.x fp2,fp3					*	fdiv.x %fp2,%fp3
	fmove.d 52(sp),fp0				*	fmove.d 52(%sp),%fp0
	fdiv.d 68(sp),fp0				*	fdiv.d 68(%sp),%fp0
	fmove.d 76(sp),fp1				*	fmove.d 76(%sp),%fp1
	fmul.x fp0,fp1					*	fmul.x %fp0,%fp1
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fdiv.x fp2,fp0					*	fdiv.x %fp2,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L31					*	fjor .L31
	jbra _?L92					*	jra .L92
_?L78:							*.L78:
	fabs.d 52(sp),fp0				*	fabs.d 52(%sp),%fp0
	fabs.d 60(sp),fp4				*	fabs.d 60(%sp),%fp4
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fblt _?L95					*	fjlt .L95
	fcmp.d #0x10000000,#0x000000,fp4		*	fcmp.d #0x10000000000000,%fp4
	fbnlt _?L8					*	fjnlt .L8
	fcmp.d #0x7c9fffff,#0xffffffff,fp0		*	fcmp.d #0x7c9fffffffffffff,%fp0
	fbnlt _?L8					*	fjnlt .L8
_?L11:							*.L11:
	fcmp.d #0x7c9fffff,#0xffffffff,fp2		*	fcmp.d #0x7c9fffffffffffff,%fp2
	fbnlt _?L8					*	fjnlt .L8
	fmove.d 52(sp),fp2				*	fmove.d 52(%sp),%fp2
	fmul.d #0x43300000,#0x00000000,fp2		*	fmul.d #0x4330000000000000,%fp2
	fmove.d fp2,52(sp)				*	fmove.d %fp2,52(%sp)
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fmul.d #0x43300000,#0x00000000,fp0		*	fmul.d #0x4330000000000000,%fp0
	fmove.d fp0,60(sp)				*	fmove.d %fp0,60(%sp)
	fmove.d 68(sp),fp1				*	fmove.d 68(%sp),%fp1
	fmul.d #0x43300000,#0x00000000,fp1		*	fmul.d #0x4330000000000000,%fp1
	fmove.d fp1,68(sp)				*	fmove.d %fp1,68(%sp)
	fmove.d 76(sp),fp2				*	fmove.d 76(%sp),%fp2
	fmul.d #0x43300000,#0x00000000,fp2		*	fmul.d #0x4330000000000000,%fp2
	fmove.d fp2,76(sp)				*	fmove.d %fp2,76(%sp)
	fmove.d 68(sp),fp2				*	fmove.d 68(%sp),%fp2
	fdiv.d 76(sp),fp2				*	fdiv.d 76(%sp),%fp2
	fmove.d 68(sp),fp1				*	fmove.d 68(%sp),%fp1
	fmul.x fp2,fp1					*	fmul.x %fp2,%fp1
	fadd.d 76(sp),fp1				*	fadd.d 76(%sp),%fp1
	fabs.x fp2,fp0					*	fabs.x %fp2,%fp0
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fbgt _?L96					*	fjgt .L96
_?L80:							*.L80:
	fmove.d 52(sp),fp0				*	fmove.d 52(%sp),%fp0
	fdiv.d 76(sp),fp0				*	fdiv.d 76(%sp),%fp0
	fmul.d 68(sp),fp0				*	fmul.d 68(%sp),%fp0
	fadd.d 60(sp),fp0				*	fadd.d 60(%sp),%fp0
	fmove.x fp0,fp3					*	fmove.x %fp0,%fp3
	fdiv.x fp1,fp3					*	fdiv.x %fp1,%fp3
	fmove.d 60(sp),fp0				*	fmove.d 60(%sp),%fp0
	fdiv.d 76(sp),fp0				*	fdiv.d 76(%sp),%fp0
	fmul.d 68(sp),fp0				*	fmul.d 68(%sp),%fp0
	fsub.d 52(sp),fp0				*	fsub.d 52(%sp),%fp0
	fdiv.x fp1,fp0					*	fdiv.x %fp1,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L31					*	fjor .L31
	jbra _?L92					*	jra .L92
_?L95:							*.L95:
	fcmp.d #0x7c9fffff,#0xffffffff,fp4		*	fcmp.d #0x7c9fffffffffffff,%fp4
	fblt _?L11					*	fjlt .L11
	jbra _?L8					*	jra .L8
_?L93:							*.L93:
	fcmp.d #0x7c9fffff,#0xffffffff,fp4		*	fcmp.d #0x7c9fffffffffffff,%fp4
	fblt _?L25					*	fjlt .L25
	jbra _?L22					*	jra .L22
_?L92:							*.L92:
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L31					*	fjor .L31
	ftst.d 68(sp)					*	ftst.d 68(%sp)
	fbne _?L32					*	fjne .L32
	ftst.d 76(sp)					*	ftst.d 76(%sp)
	fbeq _?L33					*	fjeq .L33
	fabs.d 52(sp),fp2				*	fabs.d 52(%sp),%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbule _?L34					*	fjule .L34
_?L86:							*.L86:
	clr.b d0					*	clr.b %d0
	fmove.d #0x7ff00000,#0x00000000,fp2		*	fmove.d #0x7ff0000000000000,%fp2
_?L35:							*.L35:
	fabs.d 76(sp),fp4				*	fabs.d 76(%sp),%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbugt _?L40					*	fjugt .L40
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp2					*	fmove.l %d0,%fp2
	fabs.x fp2,fp2					*	fabs.x %fp2,%fp2
	tst.l 52(sp)					*	tst.l 52(%sp)
	jbge _?L41					*	jge .L41
	fneg.x fp2,fp2					*	fneg.x %fp2,%fp2
_?L41:							*.L41:
	fabs.d 60(sp),fp0				*	fabs.d 60(%sp),%fp0
	fcmp.d #0x7fefffff,#0xffffffff,fp0		*	fcmp.d #0x7fefffffffffffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp1					*	fabs.x %fp0,%fp1
	tst.l 60(sp)					*	tst.l 60(%sp)
	jbge _?L42					*	jge .L42
	fneg.x fp1,fp1					*	fneg.x %fp1,%fp1
_?L42:							*.L42:
	fmove.d 68(sp),fp0				*	fmove.d 68(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.d 76(sp),fp3				*	fmove.d 76(%sp),%fp3
	fmul.x fp1,fp3					*	fmul.x %fp1,%fp3
	fadd.x fp3,fp0					*	fadd.x %fp3,%fp0
	fmove.x fp0,fp3					*	fmove.x %fp0,%fp3
	fmul.d #0x7ff00000,#0x00000000,fp3		*	fmul.d #0x7ff0000000000000,%fp3
	fmove.d 68(sp),fp0				*	fmove.d 68(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fmul.d 76(sp),fp2				*	fmul.d 76(%sp),%fp2
	fsub.x fp2,fp0					*	fsub.x %fp2,%fp0
	fmul.d #0x7ff00000,#0x00000000,fp0		*	fmul.d #0x7ff0000000000000,%fp0
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L34:							*.L34:
	fabs.d 60(sp),fp4				*	fabs.d 60(%sp),%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbule _?L47					*	fjule .L47
_?L87:							*.L87:
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L35					*	jra .L35
_?L47:							*.L47:
	fabs.d 76(sp),fp4				*	fabs.d 76(%sp),%fp4
_?L40:							*.L40:
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbule _?L31					*	fjule .L31
	moveq #1,d0					*	moveq #1,%d0
_?L43:							*.L43:
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbugt _?L31					*	fjugt .L31
	fabs.d 60(sp),fp2				*	fabs.d 60(%sp),%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbugt _?L31					*	fjugt .L31
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 68(sp)					*	tst.l 68(%sp)
	jbge _?L45					*	jge .L45
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L45:							*.L45:
	fabs.d 76(sp),fp2				*	fabs.d 76(%sp),%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp1					*	fmove.l %d0,%fp1
	fabs.x fp1,fp1					*	fabs.x %fp1,%fp1
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L46					*	jge .L46
	fneg.x fp1,fp1					*	fneg.x %fp1,%fp1
_?L46:							*.L46:
	fmove.d 52(sp),fp3				*	fmove.d 52(%sp),%fp3
	fmul.x fp0,fp3					*	fmul.x %fp0,%fp3
	fmove.d 60(sp),fp2				*	fmove.d 60(%sp),%fp2
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fadd.x fp2,fp3					*	fadd.x %fp2,%fp3
	fmovecr #0xf,fp2				*	fmovecr #0xf,%fp2
	fmul.x fp2,fp3					*	fmul.x %fp2,%fp3
	fmul.d 60(sp),fp0				*	fmul.d 60(%sp),%fp0
	fmul.d 52(sp),fp1				*	fmul.d 52(%sp),%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L32:							*.L32:
	fabs.d 52(sp),fp2				*	fabs.d 52(%sp),%fp2
	fabs.d 68(sp),fp4				*	fabs.d 68(%sp),%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbule _?L38					*	fjule .L38
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbole _?L86					*	fjole .L86
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L33:							*.L33:
	fmove.d 52(sp),fp1				*	fmove.d 52(%sp),%fp1
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbun _?L97					*	fjun .L97
_?L36:							*.L36:
	fmove.d #0x7ff00000,#0x00000000,fp0		*	fmove.d #0x7ff0000000000000,%fp0
	tst.l 68(sp)					*	tst.l 68(%sp)
	jbge _?L37					*	jge .L37
	fmove.d #0xfff00000,#0x00000000,fp0		*	fmove.d #0xfff0000000000000,%fp0
_?L37:							*.L37:
	fmove.d 52(sp),fp3				*	fmove.d 52(%sp),%fp3
	fmul.x fp0,fp3					*	fmul.x %fp0,%fp3
	fmul.d 60(sp),fp0				*	fmul.d 60(%sp),%fp0
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L97:							*.L97:
	fmove.d 60(sp),fp2				*	fmove.d 60(%sp),%fp2
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbor _?L36					*	fjor .L36
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L38:							*.L38:
	fabs.d 60(sp),fp6				*	fabs.d 60(%sp),%fp6
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fbule _?L39					*	fjule .L39
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbole _?L87					*	fjole .L87
_?L39:							*.L39:
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbule _?L47					*	fjule .L47
	clr.b d0					*	clr.b %d0
	jbra _?L43					*	jra .L43
							*	.size	__divdc3, .-__divdc3
							*	.ident	"GCC: (GNU) 13.4.0"
