* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divdi3				*	.globl	__divdi3
							*	.hidden	__divdi3
							*	.type	__divdi3, @function
___divdi3:						*__divdi3:
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 24(sp),d2				*	move.l 24(%sp),%d2
	move.l 28(sp),d3				*	move.l 28(%sp),%d3
	move.l 32(sp),d6				*	move.l 32(%sp),%d6
	move.l 36(sp),d7				*	move.l 36(%sp),%d7
	move.l d2,d0					*	move.l %d2,%d0
	jbmi _?L21					*	jmi .L21
	clr.l d4					*	clr.l %d4
	move.l d6,d1					*	move.l %d6,%d1
	jbmi _?L22					*	jmi .L22
_?L3:							*.L3:
	move.l d7,d6					*	move.l %d7,%d6
	tst.l d1					*	tst.l %d1
	jbne _?L4					*	jne .L4
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcc _?L5					*	jcc .L5
	move.l d3,d1					*	move.l %d3,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1016 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d7,d0:d1					*	divu.l %d7,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	clr.l d0					*	clr.l %d0
_?L6:							*.L6:
	move.l d0,d2					*	move.l %d0,%d2
	move.l d1,d3					*	move.l %d1,%d3
	tst.l d4					*	tst.l %d4
	jbeq _?L1					*	jeq .L1
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
_?L1:							*.L1:
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L4:							*.L4:
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcc _?L23					*	jcc .L23
_?L14:							*.L14:
	clr.l d1					*	clr.l %d1
_?L18:							*.L18:
	clr.l d0					*	clr.l %d0
	jbra _?L6					*	jra .L6
_?L22:							*.L22:
	not.l d4					*	not.l %d4
	neg.l d7					*	neg.l %d7
	negx.l d6					*	negx.l %d6
	move.l d6,d1					*	move.l %d6,%d1
	jbra _?L3					*	jra .L3
_?L23:							*.L23:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1139 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d1{#0:#32},d7				*	bfffo %d1{#0:#0},%d7
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	tst.l d7					*	tst.l %d7
	jbne _?L7					*	jne .L7
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbhi _?L8					*	jhi .L8
	cmp.l d6,d3					*	cmp.l %d6,%d3
	jbcs _?L14					*	jcs .L14
_?L8:							*.L8:
	moveq #1,d1					*	moveq #1,%d1
	clr.l d0					*	clr.l %d0
	jbra _?L6					*	jra .L6
_?L5:							*.L5:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1028 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d7,d1:d0					*	divu.l %d7,%d1:%d0
							*| 0 "" 2
							*| 1029 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d7,d1:d3					*	divu.l %d7,%d1:%d3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d3,d1					*	move.l %d3,%d1
	jbra _?L6					*	jra .L6
_?L21:							*.L21:
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
	move.l d2,d0					*	move.l %d2,%d0
	moveq #-1,d4					*	moveq #-1,%d4
	move.l d6,d1					*	move.l %d6,%d1
	jbpl _?L3					*	jpl .L3
	jbra _?L22					*	jra .L22
_?L7:							*.L7:
	lsl.l d7,d1					*	lsl.l %d7,%d1
	moveq #32,d5					*	moveq #32,%d5
	sub.l d7,d5					*	sub.l %d7,%d5
	move.l d6,d2					*	move.l %d6,%d2
	lsr.l d5,d2					*	lsr.l %d5,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d2,a0					*	move.l %d2,%a0
	move.l d6,d2					*	move.l %d6,%d2
	lsl.l d7,d2					*	lsl.l %d7,%d2
	move.l d0,d6					*	move.l %d0,%d6
	lsr.l d5,d6					*	lsr.l %d5,%d6
	lsl.l d7,d0					*	lsl.l %d7,%d0
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l d5,d1					*	lsr.l %d5,%d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l a0,d0					*	move.l %a0,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1180 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d0,d6:d1					*	divu.l %d0,%d6:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,d5					*	move.l %d1,%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d2,d2:d5					*	mulu.l %d2,%d2:%d5
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbhi _?L9					*	jhi .L9
	jbne _?L18					*	jne .L18
	lsl.l d7,d3					*	lsl.l %d7,%d3
	cmp.l d3,d5					*	cmp.l %d3,%d5
	jbls _?L18					*	jls .L18
_?L9:							*.L9:
	subq.l #1,d1					*	subq.l #1,%d1
	clr.l d0					*	clr.l %d0
	jbra _?L6					*	jra .L6
							*	.size	__divdi3, .-__divdi3
							*	.ident	"GCC: (GNU) 13.4.0"
