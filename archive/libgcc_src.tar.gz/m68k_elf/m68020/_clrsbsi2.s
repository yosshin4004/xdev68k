* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clrsbsi2				*	.globl	__clrsbsi2
							*	.hidden	__clrsbsi2
							*	.type	__clrsbsi2, @function
___clrsbsi2:						*__clrsbsi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l d1,d2					*	move.l %d1,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	move.l d1,d0					*	move.l %d1,%d0
	eor.l d2,d0					*	eor.l %d2,%d0
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbeq _?L3					*	jeq .L3
* APP ON (APP) asm_mode=gas				*#APP
							*| 758 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d0				*	bfffo %d0{#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	subq.l #1,d0					*	subq.l #1,%d0
	rts						*	rts
_?L3:							*.L3:
	moveq #31,d0					*	moveq #31,%d0
	rts						*	rts
							*	.size	__clrsbsi2, .-__clrsbsi2
							*	.ident	"GCC: (GNU) 13.4.0"
