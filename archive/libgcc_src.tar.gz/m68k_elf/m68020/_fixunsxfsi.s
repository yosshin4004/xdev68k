* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	1075707904				*	.long	1075707904
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsxfsi				*	.globl	__fixunsxfsi
							*	.hidden	__fixunsxfsi
							*	.type	__fixunsxfsi, @function
___fixunsxfsi:						*__fixunsxfsi:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x _?LC0,fp0				*	fmove.x .LC0,%fp0
	fcmp.x fp0,fp2					*	fcmp.x %fp0,%fp2
	fbge _?L9					*	fjge .L9
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L9:							*.L9:
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
							*	.size	__fixunsxfsi, .-__fixunsxfsi
							*	.ident	"GCC: (GNU) 13.4.0"
