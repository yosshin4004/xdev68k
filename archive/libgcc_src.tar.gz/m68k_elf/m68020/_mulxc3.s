* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	2147352576				*	.long	2147352576
	.dc.l	-1					*	.long	-1
	.dc.l	-1					*	.long	-1
	.align	2					*	.align	2
_?LC1:							*.LC1:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC2:							*.LC2:
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC3:							*.LC3:
	.dc.l	2147418112				*	.long	2147418112
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___mulxc3				*	.globl	__mulxc3
							*	.hidden	__mulxc3
							*	.type	__mulxc3, @function
___mulxc3:						*__mulxc3:
	lea (-24,sp),sp					*	lea (-24,%sp),%sp
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	fmove.x 100(sp),fp0				*	fmove.x 100(%sp),%fp0
	fmul.x 124(sp),fp0				*	fmul.x 124(%sp),%fp0
	fmove.x 112(sp),fp1				*	fmove.x 112(%sp),%fp1
	fmul.x 136(sp),fp1				*	fmul.x 136(%sp),%fp1
	fmove.x 100(sp),fp4				*	fmove.x 100(%sp),%fp4
	fmul.x 136(sp),fp4				*	fmul.x 136(%sp),%fp4
	fmove.x 124(sp),fp3				*	fmove.x 124(%sp),%fp3
	fmul.x 112(sp),fp3				*	fmul.x 112(%sp),%fp3
	fmove.x fp0,fp2					*	fmove.x %fp0,%fp2
	fsub.x fp1,fp2					*	fsub.x %fp1,%fp2
	fmove.x fp4,fp5					*	fmove.x %fp4,%fp5
	fadd.x fp3,fp5					*	fadd.x %fp3,%fp5
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbun _?L76					*	fjun .L76
_?L2:							*.L2:
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	lea (24,sp),sp					*	lea (24,%sp),%sp
	rts						*	rts
_?L76:							*.L76:
	fcmp.x fp5,fp5					*	fcmp.x %fp5,%fp5
	fbor _?L2					*	fjor .L2
	fabs.x 100(sp),fp6				*	fabs.x 100(%sp),%fp6
	fabs.x 112(sp),fp7				*	fabs.x 112(%sp),%fp7
	fmove.x fp7,84(sp)				*	fmove.x %fp7,84(%sp)
	fmove.x _?LC0,fp7				*	fmove.x .LC0,%fp7
	fcmp.x fp7,fp6					*	fcmp.x %fp7,%fp6
	fbogt _?L3					*	fjogt .L3
	fcmp.x 84(sp),fp7				*	fcmp.x 84(%sp),%fp7
	fbolt _?L3					*	fjolt .L3
	clr.b d0					*	clr.b %d0
_?L5:							*.L5:
	fabs.x 124(sp),fp6				*	fabs.x 124(%sp),%fp6
	fmove.x fp6,72(sp)				*	fmove.x %fp6,72(%sp)
	fabs.x 136(sp),fp6				*	fabs.x 136(%sp),%fp6
	fmove.x fp6,84(sp)				*	fmove.x %fp6,84(%sp)
	fcmp.x 72(sp),fp7				*	fcmp.x 72(%sp),%fp7
	fbolt _?L11					*	fjolt .L11
	fcmp.x fp7,fp6					*	fcmp.x %fp7,%fp6
	fbogt _?L11					*	fjogt .L11
	tst.b d0					*	tst.b %d0
	jbne _?L18					*	jne .L18
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	fcmp.x fp7,fp0					*	fcmp.x %fp7,%fp0
	fbogt _?L20					*	fjogt .L20
	fabs.x fp1,fp1					*	fabs.x %fp1,%fp1
	fcmp.x fp7,fp1					*	fcmp.x %fp7,%fp1
	fbogt _?L20					*	fjogt .L20
	fabs.x fp4,fp4					*	fabs.x %fp4,%fp4
	fcmp.x fp7,fp4					*	fcmp.x %fp7,%fp4
	fbogt _?L20					*	fjogt .L20
	fabs.x fp3,fp3					*	fabs.x %fp3,%fp3
	fcmp.x fp7,fp3					*	fcmp.x %fp7,%fp3
	fbule _?L2					*	fjule .L2
_?L20:							*.L20:
	fmove.x 100(sp),fp6				*	fmove.x 100(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbun _?L77					*	fjun .L77
	fmove.x 112(sp),fp7				*	fmove.x 112(%sp),%fp7
	fcmp.x fp7,fp7					*	fcmp.x %fp7,%fp7
	fbun _?L78					*	fjun .L78
_?L26:							*.L26:
	fmove.x 124(sp),fp0				*	fmove.x 124(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L79					*	fjun .L79
_?L28:							*.L28:
	fmove.x 136(sp),fp6				*	fmove.x 136(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbun _?L80					*	fjun .L80
_?L18:							*.L18:
	fmove.x 100(sp),fp2				*	fmove.x 100(%sp),%fp2
	fmul.x 124(sp),fp2				*	fmul.x 124(%sp),%fp2
	fmove.x 112(sp),fp0				*	fmove.x 112(%sp),%fp0
	fmul.x 136(sp),fp0				*	fmul.x 136(%sp),%fp0
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fmove.x _?LC3,fp6				*	fmove.x .LC3,%fp6
	fmul.x fp6,fp2					*	fmul.x %fp6,%fp2
	fmove.x 100(sp),fp0				*	fmove.x 100(%sp),%fp0
	fmul.x 136(sp),fp0				*	fmul.x 136(%sp),%fp0
	fmove.x 112(sp),fp1				*	fmove.x 112(%sp),%fp1
	fmul.x 124(sp),fp1				*	fmul.x 124(%sp),%fp1
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	fmove.x fp0,fp5					*	fmove.x %fp0,%fp5
	fmul.x fp6,fp5					*	fmul.x %fp6,%fp5
_?L81:							*.L81:
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	lea (24,sp),sp					*	lea (24,%sp),%sp
	rts						*	rts
_?L80:							*.L80:
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 136(sp)					*	tst.l 136(%sp)
	jbge _?L30					*	jge .L30
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L30:							*.L30:
	move.l d0,136(sp)				*	move.l %d0,136(%sp)
	move.l d1,140(sp)				*	move.l %d1,140(%sp)
	move.l d2,144(sp)				*	move.l %d2,144(%sp)
	fmove.x 100(sp),fp2				*	fmove.x 100(%sp),%fp2
	fmul.x 124(sp),fp2				*	fmul.x 124(%sp),%fp2
	fmove.x 112(sp),fp0				*	fmove.x 112(%sp),%fp0
	fmul.x 136(sp),fp0				*	fmul.x 136(%sp),%fp0
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fmove.x _?LC3,fp6				*	fmove.x .LC3,%fp6
	fmul.x fp6,fp2					*	fmul.x %fp6,%fp2
	fmove.x 100(sp),fp0				*	fmove.x 100(%sp),%fp0
	fmul.x 136(sp),fp0				*	fmul.x 136(%sp),%fp0
	fmove.x 112(sp),fp1				*	fmove.x 112(%sp),%fp1
	fmul.x 124(sp),fp1				*	fmul.x 124(%sp),%fp1
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	fmove.x fp0,fp5					*	fmove.x %fp0,%fp5
	fmul.x fp6,fp5					*	fmul.x %fp6,%fp5
	jbra _?L81					*	jra .L81
_?L77:							*.L77:
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L25					*	jge .L25
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L25:							*.L25:
	move.l d0,100(sp)				*	move.l %d0,100(%sp)
	move.l d1,104(sp)				*	move.l %d1,104(%sp)
	move.l d2,108(sp)				*	move.l %d2,108(%sp)
	fmove.x 112(sp),fp7				*	fmove.x 112(%sp),%fp7
	fcmp.x fp7,fp7					*	fcmp.x %fp7,%fp7
	fbor _?L26					*	fjor .L26
	jbra _?L78					*	jra .L78
_?L79:							*.L79:
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 124(sp)					*	tst.l 124(%sp)
	jbge _?L29					*	jge .L29
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L29:							*.L29:
	move.l d0,124(sp)				*	move.l %d0,124(%sp)
	move.l d1,128(sp)				*	move.l %d1,128(%sp)
	move.l d2,132(sp)				*	move.l %d2,132(%sp)
	fmove.x 136(sp),fp6				*	fmove.x 136(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbor _?L18					*	fjor .L18
	jbra _?L80					*	jra .L80
_?L78:							*.L78:
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 112(sp)					*	tst.l 112(%sp)
	jbge _?L27					*	jge .L27
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L27:							*.L27:
	move.l d0,112(sp)				*	move.l %d0,112(%sp)
	move.l d1,116(sp)				*	move.l %d1,116(%sp)
	move.l d2,120(sp)				*	move.l %d2,120(%sp)
	fmove.x 124(sp),fp0				*	fmove.x 124(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L28					*	fjor .L28
	jbra _?L79					*	jra .L79
_?L11:							*.L11:
	fcmp.x 72(sp),fp7				*	fcmp.x 72(%sp),%fp7
	fsuge d0					*	fsuge %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp2					*	fmove.l %d0,%fp2
	fabs.x fp2,fp2					*	fabs.x %fp2,%fp2
	tst.l 124(sp)					*	tst.l 124(%sp)
	jbge _?L14					*	jge .L14
	fneg.x fp2,fp2					*	fneg.x %fp2,%fp2
_?L14:							*.L14:
	fmove.x fp2,124(sp)				*	fmove.x %fp2,124(%sp)
	fcmp.x 84(sp),fp7				*	fcmp.x 84(%sp),%fp7
	fsuge d0					*	fsuge %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp2					*	fmove.l %d0,%fp2
	fabs.x fp2,fp2					*	fabs.x %fp2,%fp2
	tst.l 136(sp)					*	tst.l 136(%sp)
	jbge _?L15					*	jge .L15
	fneg.x fp2,fp2					*	fneg.x %fp2,%fp2
_?L15:							*.L15:
	fmove.x fp2,136(sp)				*	fmove.x %fp2,136(%sp)
	fmove.x 100(sp),fp7				*	fmove.x 100(%sp),%fp7
	fcmp.x fp7,fp7					*	fcmp.x %fp7,%fp7
	fbun _?L82					*	fjun .L82
_?L16:							*.L16:
	fmove.x 112(sp),fp0				*	fmove.x 112(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L18					*	fjor .L18
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 112(sp)					*	tst.l 112(%sp)
	jbge _?L19					*	jge .L19
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L19:							*.L19:
	move.l d0,112(sp)				*	move.l %d0,112(%sp)
	move.l d1,116(sp)				*	move.l %d1,116(%sp)
	move.l d2,120(sp)				*	move.l %d2,120(%sp)
	fmove.x 100(sp),fp2				*	fmove.x 100(%sp),%fp2
	fmul.x 124(sp),fp2				*	fmul.x 124(%sp),%fp2
	fmove.x 112(sp),fp0				*	fmove.x 112(%sp),%fp0
	fmul.x 136(sp),fp0				*	fmul.x 136(%sp),%fp0
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fmove.x _?LC3,fp6				*	fmove.x .LC3,%fp6
	fmul.x fp6,fp2					*	fmul.x %fp6,%fp2
	fmove.x 100(sp),fp0				*	fmove.x 100(%sp),%fp0
	fmul.x 136(sp),fp0				*	fmul.x 136(%sp),%fp0
	fmove.x 112(sp),fp1				*	fmove.x 112(%sp),%fp1
	fmul.x 124(sp),fp1				*	fmul.x 124(%sp),%fp1
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	fmove.x fp0,fp5					*	fmove.x %fp0,%fp5
	fmul.x fp6,fp5					*	fmul.x %fp6,%fp5
	jbra _?L81					*	jra .L81
_?L82:							*.L82:
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L17					*	jge .L17
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L17:							*.L17:
	move.l d0,100(sp)				*	move.l %d0,100(%sp)
	move.l d1,104(sp)				*	move.l %d1,104(%sp)
	move.l d2,108(sp)				*	move.l %d2,108(%sp)
	jbra _?L16					*	jra .L16
_?L3:							*.L3:
	fcmp.x fp7,fp6					*	fcmp.x %fp7,%fp6
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp6					*	fmove.l %d0,%fp6
	fabs.x fp6,fp6					*	fabs.x %fp6,%fp6
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L6					*	jge .L6
	fneg.x fp6,fp6					*	fneg.x %fp6,%fp6
_?L6:							*.L6:
	fmove.x fp6,100(sp)				*	fmove.x %fp6,100(%sp)
	fcmp.x 84(sp),fp7				*	fcmp.x 84(%sp),%fp7
	fsuge d0					*	fsuge %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp6					*	fmove.l %d0,%fp6
	fabs.x fp6,fp6					*	fabs.x %fp6,%fp6
	tst.l 112(sp)					*	tst.l 112(%sp)
	jbge _?L7					*	jge .L7
	fneg.x fp6,fp6					*	fneg.x %fp6,%fp6
_?L7:							*.L7:
	fmove.x fp6,112(sp)				*	fmove.x %fp6,112(%sp)
	fmove.x 124(sp),fp6				*	fmove.x 124(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbun _?L83					*	fjun .L83
_?L8:							*.L8:
	moveq #1,d0					*	moveq #1,%d0
	fmove.x 136(sp),fp6				*	fmove.x 136(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbor _?L5					*	fjor .L5
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 136(sp)					*	tst.l 136(%sp)
	jbge _?L10					*	jge .L10
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L10:							*.L10:
	move.l d0,136(sp)				*	move.l %d0,136(%sp)
	move.l d1,140(sp)				*	move.l %d1,140(%sp)
	move.l d2,144(sp)				*	move.l %d2,144(%sp)
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L5					*	jra .L5
_?L83:							*.L83:
	move.l _?LC1,d0					*	move.l .LC1,%d0
	move.l _?LC1+4,d1				*	move.l .LC1+4,%d1
	move.l _?LC1+8,d2				*	move.l .LC1+8,%d2
	tst.l 124(sp)					*	tst.l 124(%sp)
	jbge _?L9					*	jge .L9
	move.l _?LC2,d0					*	move.l .LC2,%d0
	move.l _?LC2+4,d1				*	move.l .LC2+4,%d1
	move.l _?LC2+8,d2				*	move.l .LC2+8,%d2
_?L9:							*.L9:
	move.l d0,124(sp)				*	move.l %d0,124(%sp)
	move.l d1,128(sp)				*	move.l %d1,128(%sp)
	move.l d2,132(sp)				*	move.l %d2,132(%sp)
	jbra _?L8					*	jra .L8
							*	.size	__mulxc3, .-__mulxc3
							*	.ident	"GCC: (GNU) 13.4.0"
