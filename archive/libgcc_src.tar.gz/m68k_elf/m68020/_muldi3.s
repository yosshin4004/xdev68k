* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___muldi3				*	.globl	__muldi3
							*	.hidden	__muldi3
							*	.type	__muldi3, @function
___muldi3:						*__muldi3:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d2				*	move.l 12(%sp),%d2
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	move.l d2,d1					*	move.l %d2,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 532 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d0,d3:d1					*	mulu.l %d0,%d3:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	muls.l 16(sp),d2				*	muls.l 16(%sp),%d2
	add.l d3,d2					*	add.l %d3,%d2
	muls.l 8(sp),d0					*	muls.l 8(%sp),%d0
	add.l d2,d0					*	add.l %d2,%d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	rts						*	rts
							*	.size	__muldi3, .-__muldi3
							*	.ident	"GCC: (GNU) 13.4.0"
