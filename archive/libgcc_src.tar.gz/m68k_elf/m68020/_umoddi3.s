* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___umoddi3				*	.globl	__umoddi3
							*	.hidden	__umoddi3
							*	.type	__umoddi3, @function
___umoddi3:						*__umoddi3:
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 24(sp),d0				*	move.l 24(%sp),%d0
	move.l 28(sp),d1				*	move.l 28(%sp),%d1
	move.l 32(sp),d2				*	move.l 32(%sp),%d2
	move.l 36(sp),d3				*	move.l 36(%sp),%d3
	move.l d0,a0					*	move.l %d0,%a0
	tst.l d2					*	tst.l %d2
	jbne _?L2					*	jne .L2
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L3					*	jcc .L3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1016 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d0:d1					*	divu.l %d3,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	clr.l d0					*	clr.l %d0
_?L5:							*.L5:
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L2:							*.L2:
	move.l d1,a1					*	move.l %d1,%a1
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L5					*	jcs .L5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1139 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d2{#0:#32},d4				*	bfffo %d2{#0:#0},%d4
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	tst.l d4					*	tst.l %d4
	jbne _?L7					*	jne .L7
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbhi _?L8					*	jhi .L8
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcs _?L9					*	jcs .L9
_?L8:							*.L8:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d1					*	sub.l %d3,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a1					*	move.l %d1,%a1
	move.l d0,a0					*	move.l %d0,%a0
_?L9:							*.L9:
	move.l a0,d0					*	move.l %a0,%d0
	move.l a1,d1					*	move.l %a1,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L3:							*.L3:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1028 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d2:d0					*	divu.l %d3,%d2:%d0
							*| 0 "" 2
							*| 1029 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d2:d1					*	divu.l %d3,%d2:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d2,d1					*	move.l %d2,%d1
	clr.l d0					*	clr.l %d0
	jbra _?L5					*	jra .L5
_?L7:							*.L7:
	moveq #32,d5					*	moveq #32,%d5
	sub.l d4,d5					*	sub.l %d4,%d5
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d3,d7					*	move.l %d3,%d7
	lsr.l d5,d7					*	lsr.l %d5,%d7
	or.l d2,d7					*	or.l %d2,%d7
	lsl.l d4,d3					*	lsl.l %d4,%d3
	move.l d0,d6					*	move.l %d0,%d6
	lsr.l d5,d6					*	lsr.l %d5,%d6
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l d1,d2					*	move.l %d1,%d2
	lsr.l d5,d2					*	lsr.l %d5,%d2
	or.l d2,d0					*	or.l %d2,%d0
	move.l d1,d2					*	move.l %d1,%d2
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d0,d1					*	move.l %d0,%d1
	move.l d6,d0					*	move.l %d6,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1180 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d7,d0:d1					*	divu.l %d7,%d0:%d1
							*| 0 "" 2
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d3,d6:d1					*	mulu.l %d3,%d6:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a1					*	move.l %d1,%a1
	move.l d6,a0					*	move.l %d6,%a0
	cmp.l d0,d6					*	cmp.l %d0,%d6
	jbhi _?L10					*	jhi .L10
	jbeq _?L14					*	jeq .L14
_?L11:							*.L11:
	move.l a0,d1					*	move.l %a0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a1,d2					*	sub.l %a1,%d2
	subx.l d1,d0					*	subx.l %d1,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	lsl.l d5,d1					*	lsl.l %d5,%d1
	lsr.l d4,d2					*	lsr.l %d4,%d2
	lsr.l d4,d0					*	lsr.l %d4,%d0
	or.l d2,d1					*	or.l %d2,%d1
_?L15:							*.L15:
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L14:							*.L14:
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbls _?L11					*	jls .L11
_?L10:							*.L10:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d1					*	sub.l %d3,%d1
	subx.l d7,d6					*	subx.l %d7,%d6
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d6,a0					*	move.l %d6,%a0
	move.l d1,a1					*	move.l %d1,%a1
	move.l a0,d1					*	move.l %a0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a1,d2					*	sub.l %a1,%d2
	subx.l d1,d0					*	subx.l %d1,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	lsl.l d5,d1					*	lsl.l %d5,%d1
	lsr.l d4,d2					*	lsr.l %d4,%d2
	lsr.l d4,d0					*	lsr.l %d4,%d0
	or.l d2,d1					*	or.l %d2,%d1
	jbra _?L15					*	jra .L15
							*	.size	__umoddi3, .-__umoddi3
							*	.ident	"GCC: (GNU) 13.4.0"
