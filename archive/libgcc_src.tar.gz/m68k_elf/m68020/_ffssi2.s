* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ffssi2				*	.globl	__ffssi2
							*	.hidden	__ffssi2
							*	.type	__ffssi2, @function
___ffssi2:						*__ffssi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	jbeq _?L3					*	jeq .L3
	move.l d0,d1					*	move.l %d0,%d1
	neg.l d1					*	neg.l %d1
	and.l d0,d1					*	and.l %d0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 501 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d1{#0:#32},d1				*	bfffo %d1{#0:#0},%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	moveq #32,d0					*	moveq #32,%d0
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
_?L3:							*.L3:
	clr.l d0					*	clr.l %d0
	rts						*	rts
							*	.size	__ffssi2, .-__ffssi2
							*	.ident	"GCC: (GNU) 13.4.0"
