* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___moddi3				*	.globl	__moddi3
							*	.hidden	__moddi3
							*	.type	__moddi3, @function
___moddi3:						*__moddi3:
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 24(sp),d6				*	move.l 24(%sp),%d6
	move.l 28(sp),d7				*	move.l 28(%sp),%d7
	move.l 32(sp),d4				*	move.l 32(%sp),%d4
	move.l 36(sp),d5				*	move.l 36(%sp),%d5
	move.l d6,d1					*	move.l %d6,%d1
	jbmi _?L21					*	jmi .L21
	sub.l a0,a0					*	sub.l %a0,%a0
	move.l d4,d0					*	move.l %d4,%d0
	jbmi _?L22					*	jmi .L22
_?L3:							*.L3:
	move.l d5,d4					*	move.l %d5,%d4
	move.l d7,d2					*	move.l %d7,%d2
	tst.l d0					*	tst.l %d0
	jbne _?L4					*	jne .L4
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcc _?L5					*	jcc .L5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1016 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d5,d1:d2					*	divu.l %d5,%d1:%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	clr.l d4					*	clr.l %d4
	move.l d1,d5					*	move.l %d1,%d5
_?L7:							*.L7:
	tst.l a0					*	tst.l %a0
	jbeq _?L1					*	jeq .L1
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
_?L1:							*.L1:
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L4:							*.L4:
	move.l d7,a1					*	move.l %d7,%a1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L8					*	jcc .L8
	move.l d1,d4					*	move.l %d1,%d4
	move.l d7,d5					*	move.l %d7,%d5
	jbra _?L7					*	jra .L7
_?L22:							*.L22:
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
	move.l d4,d0					*	move.l %d4,%d0
	jbra _?L3					*	jra .L3
_?L8:							*.L8:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1139 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d6				*	bfffo %d0{#0:#0},%d6
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	tst.l d6					*	tst.l %d6
	jbne _?L9					*	jne .L9
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbhi _?L10					*	jhi .L10
	cmp.l d5,d7					*	cmp.l %d5,%d7
	jbcs _?L11					*	jcs .L11
_?L10:							*.L10:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d4,d2					*	sub.l %d4,%d2
	subx.l d0,d1					*	subx.l %d0,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d2,a1					*	move.l %d2,%a1
_?L11:							*.L11:
	move.l d1,d4					*	move.l %d1,%d4
	move.l a1,d5					*	move.l %a1,%d5
	jbra _?L7					*	jra .L7
_?L5:							*.L5:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1028 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d5,d0:d1					*	divu.l %d5,%d0:%d1
							*| 0 "" 2
							*| 1029 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d5,d0:d2					*	divu.l %d5,%d0:%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	clr.l d4					*	clr.l %d4
	move.l d1,d5					*	move.l %d1,%d5
	jbra _?L7					*	jra .L7
_?L21:							*.L21:
	neg.l d7					*	neg.l %d7
	negx.l d6					*	negx.l %d6
	move.l d6,d1					*	move.l %d6,%d1
	move.w #-1,a0					*	move.w #-1,%a0
	move.l d4,d0					*	move.l %d4,%d0
	jbpl _?L3					*	jpl .L3
	jbra _?L22					*	jra .L22
_?L9:							*.L9:
	moveq #32,d5					*	moveq #32,%d5
	sub.l d6,d5					*	sub.l %d6,%d5
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d4,d3					*	move.l %d4,%d3
	lsr.l d5,d3					*	lsr.l %d5,%d3
	or.l d0,d3					*	or.l %d0,%d3
	lsl.l d6,d4					*	lsl.l %d6,%d4
	move.l d1,d7					*	move.l %d1,%d7
	lsr.l d5,d7					*	lsr.l %d5,%d7
	lsl.l d6,d1					*	lsl.l %d6,%d1
	move.l d2,d0					*	move.l %d2,%d0
	lsr.l d5,d0					*	lsr.l %d5,%d0
	or.l d1,d0					*	or.l %d1,%d0
	lsl.l d6,d2					*	lsl.l %d6,%d2
	move.l d7,d1					*	move.l %d7,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1180 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d1:d0					*	divu.l %d3,%d1:%d0
							*| 0 "" 2
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d4,d7:d0					*	mulu.l %d4,%d7:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,a2					*	move.l %d0,%a2
	move.l d7,a1					*	move.l %d7,%a1
	cmp.l d1,d7					*	cmp.l %d1,%d7
	jbhi _?L12					*	jhi .L12
	jbeq _?L23					*	jeq .L23
_?L13:							*.L13:
	move.l a1,d0					*	move.l %a1,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a2,d2					*	sub.l %a2,%d2
	subx.l d0,d1					*	subx.l %d0,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,d0					*	move.l %d1,%d0
	lsl.l d5,d0					*	lsl.l %d5,%d0
	lsr.l d6,d2					*	lsr.l %d6,%d2
	move.l d1,d4					*	move.l %d1,%d4
	lsr.l d6,d4					*	lsr.l %d6,%d4
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	jbra _?L7					*	jra .L7
_?L23:							*.L23:
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbls _?L13					*	jls .L13
_?L12:							*.L12:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d4,d0					*	sub.l %d4,%d0
	subx.l d3,d7					*	subx.l %d3,%d7
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d7,a1					*	move.l %d7,%a1
	move.l d0,a2					*	move.l %d0,%a2
	move.l a1,d0					*	move.l %a1,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a2,d2					*	sub.l %a2,%d2
	subx.l d0,d1					*	subx.l %d0,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,d0					*	move.l %d1,%d0
	lsl.l d5,d0					*	lsl.l %d5,%d0
	lsr.l d6,d2					*	lsr.l %d6,%d2
	move.l d1,d4					*	move.l %d1,%d4
	lsr.l d6,d4					*	lsr.l %d6,%d4
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
	jbra _?L7					*	jra .L7
							*	.size	__moddi3, .-__moddi3
							*	.ident	"GCC: (GNU) 13.4.0"
