* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 435 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 .text							* .text
							* .type __mulsi3,function
 .globl ___mulsi3					* .globl __mulsi3
 .globl ___mulsi3_internal				* .globl __mulsi3_internal
							* .hidden __mulsi3_internal
___mulsi3:						*__mulsi3:
___mulsi3_internal:					*__mulsi3_internal:
 move.w 4(sp),d0					* movew %sp@(4), %d0
 mulu.w 10(sp),d0					* muluw %sp@(10), %d0
 move.w 6(sp),d1					* movew %sp@(6), %d1
 mulu.w 8(sp),d1					* muluw %sp@(8), %d1
							*
 add.w d1,d0						* addw %d1, %d0
							*
							*
							*
 swap d0						* swap %d0
 clr.w d0						* clrw %d0
 move.w 6(sp),d1					* movew %sp@(6), %d1
 mulu.w 10(sp),d1					* muluw %sp@(10), %d1
 add.l d1,d0						* addl %d1, %d0
							*
 rts							* rts
							*# 3930 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
