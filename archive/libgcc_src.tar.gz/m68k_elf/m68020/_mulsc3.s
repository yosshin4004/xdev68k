* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___mulsc3				*	.globl	__mulsc3
							*	.hidden	__mulsc3
							*	.type	__mulsc3, @function
___mulsc3:						*__mulsc3:
	lea (-16,sp),sp					*	lea (-16,%sp),%sp
	fmovem fp2/fp3/fp4,-(sp)			*	fmovem #28,-(%sp)
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 76(sp),d0				*	move.l 76(%sp),%d0
	move.l 80(sp),d1				*	move.l 80(%sp),%d1
	move.l 84(sp),d2				*	move.l 84(%sp),%d2
	move.l 88(sp),d3				*	move.l 88(%sp),%d3
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fsglmul.s d2,fp0				*	fsglmul.s %d2,%fp0
	fmove.s fp0,56(sp)				*	fmove.s %fp0,56(%sp)
	fmove.s d1,fp3					*	fmove.s %d1,%fp3
	fsglmul.s d3,fp3				*	fsglmul.s %d3,%fp3
	fmove.s fp3,60(sp)				*	fmove.s %fp3,60(%sp)
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fsglmul.s d3,fp0				*	fsglmul.s %d3,%fp0
	fmove.s fp0,64(sp)				*	fmove.s %fp0,64(%sp)
	fmove.s d2,fp3					*	fmove.s %d2,%fp3
	fsglmul.s d1,fp3				*	fsglmul.s %d1,%fp3
	fmove.s fp3,68(sp)				*	fmove.s %fp3,68(%sp)
	fmove.s 56(sp),fp2				*	fmove.s 56(%sp),%fp2
	move.l 60(sp),d4				*	move.l 60(%sp),%d4
	fmove.x fp2,fp0					*	fmove.x %fp2,%fp0
	fsub.s d4,fp0					*	fsub.s %d4,%fp0
	move.l 64(sp),d6				*	move.l 64(%sp),%d6
	move.l 68(sp),d5				*	move.l 68(%sp),%d5
	fmove.s d6,fp1					*	fmove.s %d6,%fp1
	fadd.s d5,fp1					*	fadd.s %d5,%fp1
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L76					*	fjun .L76
_?L2:							*.L2:
	fmove.s fp0,d0					*	fmove.s %fp0,%d0
	fmove.s fp1,d1					*	fmove.s %fp1,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	fmovem (sp)+,fp2/fp3/fp4			*	fmovem (%sp)+,#56
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L76:							*.L76:
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L2					*	fjor .L2
	fabs.s d0,fp3					*	fabs.s %d0,%fp3
	fabs.s d1,fp4					*	fabs.s %d1,%fp4
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbogt _?L3					*	fjogt .L3
	fcmp.s #0x7f7fffff,fp4				*	fcmp.s #0x7f7fffff,%fp4
	fbogt _?L3					*	fjogt .L3
	clr.b d7					*	clr.b %d7
_?L5:							*.L5:
	fabs.s d2,fp3					*	fabs.s %d2,%fp3
	fabs.s d3,fp4					*	fabs.s %d3,%fp4
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbogt _?L11					*	fjogt .L11
	fcmp.s #0x7f7fffff,fp4				*	fcmp.s #0x7f7fffff,%fp4
	fbogt _?L11					*	fjogt .L11
	tst.b d7					*	tst.b %d7
	jbne _?L18					*	jne .L18
	fabs.x fp2,fp2					*	fabs.x %fp2,%fp2
	fcmp.s #0x7f7fffff,fp2				*	fcmp.s #0x7f7fffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fabs.s d4,fp2					*	fabs.s %d4,%fp2
	fcmp.s #0x7f7fffff,fp2				*	fcmp.s #0x7f7fffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fabs.s d6,fp2					*	fabs.s %d6,%fp2
	fcmp.s #0x7f7fffff,fp2				*	fcmp.s #0x7f7fffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fabs.s d5,fp2					*	fabs.s %d5,%fp2
	fcmp.s #0x7f7fffff,fp2				*	fcmp.s #0x7f7fffff,%fp2
	fbule _?L2					*	fjule .L2
_?L20:							*.L20:
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fcmp.s d0,fp0					*	fcmp.s %d0,%fp0
	fbun _?L77					*	fjun .L77
	fmove.s d1,fp3					*	fmove.s %d1,%fp3
	fcmp.s d1,fp3					*	fcmp.s %d1,%fp3
	fbun _?L78					*	fjun .L78
_?L26:							*.L26:
	fmove.s d2,fp0					*	fmove.s %d2,%fp0
	fcmp.s d2,fp0					*	fcmp.s %d2,%fp0
	fbun _?L79					*	fjun .L79
_?L28:							*.L28:
	fmove.s d3,fp3					*	fmove.s %d3,%fp3
	fcmp.s d3,fp3					*	fcmp.s %d3,%fp3
	fbun _?L80					*	fjun .L80
_?L18:							*.L18:
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fsglmul.s d2,fp0				*	fsglmul.s %d2,%fp0
	fmove.s d1,fp1					*	fmove.s %d1,%fp1
	fsglmul.s d3,fp1				*	fsglmul.s %d3,%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fsglmul.s #0x7f800000,fp0			*	fsglmul.s #0x7f800000,%fp0
	fmove.s d0,fp1					*	fmove.s %d0,%fp1
	fsglmul.s d3,fp1				*	fsglmul.s %d3,%fp1
	fmove.s d1,fp2					*	fmove.s %d1,%fp2
	fsglmul.s d2,fp2				*	fsglmul.s %d2,%fp2
	fadd.x fp2,fp1					*	fadd.x %fp2,%fp1
	fsglmul.s #0x7f800000,fp1			*	fsglmul.s #0x7f800000,%fp1
_?L81:							*.L81:
	fmove.s fp0,d0					*	fmove.s %fp0,%d0
	fmove.s fp1,d1					*	fmove.s %fp1,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	fmovem (sp)+,fp2/fp3/fp4			*	fmovem (%sp)+,#56
	lea (16,sp),sp					*	lea (16,%sp),%sp
	rts						*	rts
_?L80:							*.L80:
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d3					*	tst.l %d3
	jbge _?L30					*	jge .L30
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L30:							*.L30:
	move.l a0,d3					*	move.l %a0,%d3
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fsglmul.s d2,fp0				*	fsglmul.s %d2,%fp0
	fmove.s d1,fp1					*	fmove.s %d1,%fp1
	fsglmul.s d3,fp1				*	fsglmul.s %d3,%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fsglmul.s #0x7f800000,fp0			*	fsglmul.s #0x7f800000,%fp0
	fmove.s d0,fp1					*	fmove.s %d0,%fp1
	fsglmul.s d3,fp1				*	fsglmul.s %d3,%fp1
	fmove.s d1,fp2					*	fmove.s %d1,%fp2
	fsglmul.s d2,fp2				*	fsglmul.s %d2,%fp2
	fadd.x fp2,fp1					*	fadd.x %fp2,%fp1
	fsglmul.s #0x7f800000,fp1			*	fsglmul.s #0x7f800000,%fp1
	jbra _?L81					*	jra .L81
_?L77:							*.L77:
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d0					*	tst.l %d0
	jbge _?L25					*	jge .L25
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L25:							*.L25:
	move.l a0,d0					*	move.l %a0,%d0
	fmove.s d1,fp3					*	fmove.s %d1,%fp3
	fcmp.s d1,fp3					*	fcmp.s %d1,%fp3
	fbor _?L26					*	fjor .L26
	jbra _?L78					*	jra .L78
_?L79:							*.L79:
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d2					*	tst.l %d2
	jbge _?L29					*	jge .L29
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L29:							*.L29:
	move.l a0,d2					*	move.l %a0,%d2
	fmove.s d3,fp3					*	fmove.s %d3,%fp3
	fcmp.s d3,fp3					*	fcmp.s %d3,%fp3
	fbor _?L18					*	fjor .L18
	jbra _?L80					*	jra .L80
_?L78:							*.L78:
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d1					*	tst.l %d1
	jbge _?L27					*	jge .L27
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L27:							*.L27:
	move.l a0,d1					*	move.l %a0,%d1
	fmove.s d2,fp0					*	fmove.s %d2,%fp0
	fcmp.s d2,fp0					*	fcmp.s %d2,%fp0
	fbor _?L28					*	fjor .L28
	jbra _?L79					*	jra .L79
_?L11:							*.L11:
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fsule d4					*	fsule %d4
	addq.b #1,d4					*	addq.b #1,%d4
	and.l #255,d4					*	and.l #255,%d4
	fmove.l d4,fp0					*	fmove.l %d4,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l d2					*	tst.l %d2
	jbge _?L14					*	jge .L14
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L14:							*.L14:
	fmove.s fp0,d2					*	fmove.s %fp0,%d2
	fcmp.s #0x7f7fffff,fp4				*	fcmp.s #0x7f7fffff,%fp4
	fsule d4					*	fsule %d4
	addq.b #1,d4					*	addq.b #1,%d4
	and.l #255,d4					*	and.l #255,%d4
	fmove.l d4,fp0					*	fmove.l %d4,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l d3					*	tst.l %d3
	jbge _?L15					*	jge .L15
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L15:							*.L15:
	fmove.s fp0,d3					*	fmove.s %fp0,%d3
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fcmp.s d0,fp0					*	fcmp.s %d0,%fp0
	fbun _?L82					*	fjun .L82
_?L16:							*.L16:
	fmove.s d1,fp3					*	fmove.s %d1,%fp3
	fcmp.s d1,fp3					*	fcmp.s %d1,%fp3
	fbor _?L18					*	fjor .L18
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d1					*	tst.l %d1
	jbge _?L19					*	jge .L19
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L19:							*.L19:
	move.l a0,d1					*	move.l %a0,%d1
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	fsglmul.s d2,fp0				*	fsglmul.s %d2,%fp0
	fmove.s d1,fp1					*	fmove.s %d1,%fp1
	fsglmul.s d3,fp1				*	fsglmul.s %d3,%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fsglmul.s #0x7f800000,fp0			*	fsglmul.s #0x7f800000,%fp0
	fmove.s d0,fp1					*	fmove.s %d0,%fp1
	fsglmul.s d3,fp1				*	fsglmul.s %d3,%fp1
	fmove.s d1,fp2					*	fmove.s %d1,%fp2
	fsglmul.s d2,fp2				*	fsglmul.s %d2,%fp2
	fadd.x fp2,fp1					*	fadd.x %fp2,%fp1
	fsglmul.s #0x7f800000,fp1			*	fsglmul.s #0x7f800000,%fp1
	jbra _?L81					*	jra .L81
_?L82:							*.L82:
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d0					*	tst.l %d0
	jbge _?L17					*	jge .L17
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L17:							*.L17:
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L16					*	jra .L16
_?L3:							*.L3:
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fsule d7					*	fsule %d7
	addq.b #1,d7					*	addq.b #1,%d7
	and.l #255,d7					*	and.l #255,%d7
	fmove.l d7,fp3					*	fmove.l %d7,%fp3
	fabs.x fp3,fp3					*	fabs.x %fp3,%fp3
	tst.l d0					*	tst.l %d0
	jbge _?L6					*	jge .L6
	fneg.x fp3,fp3					*	fneg.x %fp3,%fp3
_?L6:							*.L6:
	fmove.s fp3,d0					*	fmove.s %fp3,%d0
	fcmp.s #0x7f7fffff,fp4				*	fcmp.s #0x7f7fffff,%fp4
	fsule d7					*	fsule %d7
	addq.b #1,d7					*	addq.b #1,%d7
	and.l #255,d7					*	and.l #255,%d7
	fmove.l d7,fp3					*	fmove.l %d7,%fp3
	fabs.x fp3,fp3					*	fabs.x %fp3,%fp3
	tst.l d1					*	tst.l %d1
	jbge _?L7					*	jge .L7
	fneg.x fp3,fp3					*	fneg.x %fp3,%fp3
_?L7:							*.L7:
	fmove.s fp3,d1					*	fmove.s %fp3,%d1
	fmove.s d2,fp3					*	fmove.s %d2,%fp3
	fcmp.s d2,fp3					*	fcmp.s %d2,%fp3
	fbun _?L83					*	fjun .L83
_?L8:							*.L8:
	moveq #1,d7					*	moveq #1,%d7
	fmove.s d3,fp3					*	fmove.s %d3,%fp3
	fcmp.s d3,fp3					*	fcmp.s %d3,%fp3
	fbor _?L5					*	fjor .L5
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d3					*	tst.l %d3
	jbge _?L10					*	jge .L10
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L10:							*.L10:
	move.l a0,d3					*	move.l %a0,%d3
	moveq #1,d7					*	moveq #1,%d7
	jbra _?L5					*	jra .L5
_?L83:							*.L83:
	sub.l a0,a0					*	sub.l %a0,%a0
	tst.l d2					*	tst.l %d2
	jbge _?L9					*	jge .L9
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L9:							*.L9:
	move.l a0,d2					*	move.l %a0,%d2
	jbra _?L8					*	jra .L8
							*	.size	__mulsc3, .-__mulsc3
							*	.ident	"GCC: (GNU) 13.4.0"
