* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___cmpdi2				*	.globl	__cmpdi2
							*	.hidden	__cmpdi2
							*	.type	__cmpdi2, @function
___cmpdi2:						*__cmpdi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l 12(sp),a0				*	move.l 12(%sp),%a0
	move.l 16(sp),a1				*	move.l 16(%sp),%a1
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbne _?L3					*	jne .L3
	cmp.l a1,d1					*	cmp.l %a1,%d1
	shi d2						*	shi %d2
	jbra _?L4					*	jra .L4
_?L3:							*.L3:
	sgt d2						*	sgt %d2
_?L4:							*.L4:
	extb.l d2					*	extb.l %d2
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbne _?L5					*	jne .L5
	cmp.l a1,d1					*	cmp.l %a1,%d1
	scs d0						*	scs %d0
	jbra _?L6					*	jra .L6
_?L5:							*.L5:
	slt d0						*	slt %d0
_?L6:							*.L6:
	extb.l d0					*	extb.l %d0
	sub.l d2,d0					*	sub.l %d2,%d0
	addq.l #1,d0					*	addq.l #1,%d0
	rts						*	rts
							*	.size	__cmpdi2, .-__cmpdi2
							*	.ident	"GCC: (GNU) 13.4.0"
