* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___paritysi2				*	.globl	__paritysi2
							*	.hidden	__paritysi2
							*	.type	__paritysi2, @function
___paritysi2:						*__paritysi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l d0,d1					*	move.l %d0,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	eor.l d0,d1					*	eor.l %d0,%d1
	move.l d1,d0					*	move.l %d1,%d0
	lsr.l #8,d0					*	lsr.l #8,%d0
	eor.l d1,d0					*	eor.l %d1,%d0
	move.l d0,d1					*	move.l %d0,%d1
	lsr.l #4,d1					*	lsr.l #4,%d1
	eor.l d0,d1					*	eor.l %d0,%d1
	moveq #15,d0					*	moveq #15,%d0
	and.l d0,d1					*	and.l %d0,%d1
	move.l #27030,d0				*	move.l #27030,%d0
	asr.l d1,d0					*	asr.l %d1,%d0
	moveq #1,d1					*	moveq #1,%d1
	and.l d1,d0					*	and.l %d1,%d0
	rts						*	rts
							*	.size	__paritysi2, .-__paritysi2
							*	.ident	"GCC: (GNU) 13.4.0"
