* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ashldi3				*	.globl	__ashldi3
							*	.hidden	__ashldi3
							*	.type	__ashldi3, @function
___ashldi3:						*__ashldi3:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	move.l 16(sp),d3				*	move.l 16(%sp),%d3
	move.l 20(sp),d2				*	move.l 20(%sp),%d2
	jbeq _?L5					*	jeq .L5
	moveq #32,d4					*	moveq #32,%d4
	sub.l d2,d4					*	sub.l %d2,%d4
	tst.l d4					*	tst.l %d4
	jble _?L8					*	jle .L8
	move.l d3,d1					*	move.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	lsl.l d2,d0					*	lsl.l %d2,%d0
	lsr.l d4,d3					*	lsr.l %d4,%d3
	or.l d3,d0					*	or.l %d3,%d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L8:							*.L8:
	moveq #-32,d0					*	moveq #-32,%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d3,d0					*	move.l %d3,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	clr.l d1					*	clr.l %d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L5:							*.L5:
	move.l d3,d1					*	move.l %d3,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
							*	.size	__ashldi3, .-__ashldi3
							*	.ident	"GCC: (GNU) 13.4.0"
