* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clzsi2				*	.globl	__clzsi2
							*	.hidden	__clzsi2
							*	.type	__clzsi2, @function
___clzsi2:						*__clzsi2:
* APP ON (APP) asm_mode=gas				*#APP
							*| 690 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo 4(sp){#0:#32},d0				*	bfffo 4(%sp){#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	rts						*	rts
							*	.size	__clzsi2, .-__clzsi2
							*	.ident	"GCC: (GNU) 13.4.0"
