* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 461 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 .text							* .text
							* .type __udivsi3,function
 .globl ___udivsi3					* .globl __udivsi3
 .globl ___udivsi3_internal				* .globl __udivsi3_internal
							* .hidden __udivsi3_internal
___udivsi3:						*__udivsi3:
___udivsi3_internal:					*__udivsi3_internal:
							*
 move.l d2,-(sp)					* movel %d2, %sp@-
 move.l 12(sp),d1					* movel %sp@(12), %d1
 move.l 8(sp),d0					* movel %sp@(8), %d0
							*
 cmp.l #0x10000,d1					* cmpl #0x10000, %d1
 jbcc _L3						* jcc L3
 move.l d0,d2						* movel %d0, %d2
 clr.w d2						* clrw %d2
 swap d2						* swap %d2
 divu d1,d2						* divu %d1, %d2
 move.w d2,d0						* movew %d2, %d0
 swap d0						* swap %d0
 move.w 10(sp),d2					* movew %sp@(10), %d2
 divu d1,d2						* divu %d1, %d2
 move.w d2,d0						* movew %d2, %d0
 jbra _L6						* jra L6
							*
_L3: move.l d1,d2					*L3: movel %d1, %d2
_L4: lsr.l #1,d1					*L4: lsrl #1, %d1
 lsr.l #1,d0						* lsrl #1, %d0
 cmp.l #0x10000,d1					* cmpl #0x10000, %d1
 jbcc _L4						* jcc L4
 divu d1,d0						* divu %d1, %d0
 and.l #0xffff,d0					* andl #0xffff, %d0
							*
							*
							*
							*
 move.l d2,d1						* movel %d2, %d1
 mulu d0,d1						* mulu %d0, %d1
 swap d2						* swap %d2
 mulu d0,d2						* mulu %d0, %d2
 swap d2						* swap %d2
 tst.w d2						* tstw %d2
 jbne _L5						* jne L5
 add.l d2,d1						* addl %d2, %d1
 jbcs _L5						* jcs L5
 cmp.l 8(sp),d1						* cmpl %sp@(8), %d1
 jbls _L6						* jls L6
_L5: subq.l #1,d0					*L5: subql #1, %d0
							*
_L6: move.l (sp)+,d2					*L6: movel %sp@+, %d2
 rts							* rts
							*# 3930 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
