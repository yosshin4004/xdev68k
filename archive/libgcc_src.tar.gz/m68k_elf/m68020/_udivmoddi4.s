* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___udivmoddi4				*	.globl	__udivmoddi4
							*	.hidden	__udivmoddi4
							*	.type	__udivmoddi4, @function
___udivmoddi4:						*__udivmoddi4:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 36(sp),d1				*	move.l 36(%sp),%d1
	move.l 40(sp),d0				*	move.l 40(%sp),%d0
	move.l 44(sp),d2				*	move.l 44(%sp),%d2
	move.l 48(sp),d3				*	move.l 48(%sp),%d3
	move.l 52(sp),a2				*	move.l 52(%sp),%a2
	move.l d0,a0					*	move.l %d0,%a0
	move.l d1,a1					*	move.l %d1,%a1
	tst.l d2					*	tst.l %d2
	jbne _?L2					*	jne .L2
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcc _?L3					*	jcc .L3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1016 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d1:d0					*	divu.l %d3,%d1:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,a0					*	move.l %d0,%a0
	move.l d1,a1					*	move.l %d1,%a1
	clr.l d0					*	clr.l %d0
_?L4:							*.L4:
	move.l a0,d1					*	move.l %a0,%d1
	tst.l a2					*	tst.l %a2
	jbeq _?L6					*	jeq .L6
	clr.l (a2)					*	clr.l (%a2)
	move.l a1,4(a2)					*	move.l %a1,4(%a2)
_?L6:							*.L6:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L2:							*.L2:
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L8					*	jcc .L8
	tst.l a2					*	tst.l %a2
	jbeq _?L15					*	jeq .L15
	move.l d1,(a2)					*	move.l %d1,(%a2)
	move.l d0,4(a2)					*	move.l %d0,4(%a2)
	clr.l d1					*	clr.l %d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L8:							*.L8:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1139 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d2{#0:#32},d4				*	bfffo %d2{#0:#0},%d4
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	tst.l d4					*	tst.l %d4
	jbne _?L9					*	jne .L9
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbhi _?L10					*	jhi .L10
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcs _?L16					*	jcs .L16
_?L10:							*.L10:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d0					*	sub.l %d3,%d0
	subx.l d2,d1					*	subx.l %d2,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a1					*	move.l %d1,%a1
	move.l d0,a0					*	move.l %d0,%a0
	moveq #1,d1					*	moveq #1,%d1
_?L11:							*.L11:
	tst.l a2					*	tst.l %a2
	jbeq _?L17					*	jeq .L17
	move.l a1,(a2)					*	move.l %a1,(%a2)
	move.l a0,4(a2)					*	move.l %a0,4(%a2)
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L3:							*.L3:
	move.l d1,d0					*	move.l %d1,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1028 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d2:d0					*	divu.l %d3,%d2:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a0,d1					*	move.l %a0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1029 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d2:d1					*	divu.l %d3,%d2:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a0					*	move.l %d1,%a0
	move.l d2,a1					*	move.l %d2,%a1
	jbra _?L4					*	jra .L4
_?L9:							*.L9:
	moveq #32,d7					*	moveq #32,%d7
	sub.l d4,d7					*	sub.l %d4,%d7
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d3,d5					*	move.l %d3,%d5
	lsr.l d7,d5					*	lsr.l %d7,%d5
	or.l d2,d5					*	or.l %d2,%d5
	move.l d5,a0					*	move.l %d5,%a0
	lsl.l d4,d3					*	lsl.l %d4,%d3
	move.l d1,d2					*	move.l %d1,%d2
	lsr.l d7,d2					*	lsr.l %d7,%d2
	lsl.l d4,d1					*	lsl.l %d4,%d1
	move.l d0,d5					*	move.l %d0,%d5
	lsr.l d7,d5					*	lsr.l %d7,%d5
	or.l d5,d1					*	or.l %d5,%d1
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l d0,a5					*	move.l %d0,%a5
	move.l d1,d0					*	move.l %d1,%d0
	move.l a0,d1					*	move.l %a0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1180 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d1,d2:d0					*	divu.l %d1,%d2:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,a4					*	move.l %d0,%a4
	move.l d0,d1					*	move.l %d0,%d1
	move.l d0,d5					*	move.l %d0,%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d3,d6:d5					*	mulu.l %d3,%d6:%d5
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d5,a3					*	move.l %d5,%a3
	move.l d6,a1					*	move.l %d6,%a1
	cmp.l d2,d6					*	cmp.l %d2,%d6
	jbhi _?L12					*	jhi .L12
	jbeq _?L23					*	jeq .L23
_?L13:							*.L13:
	tst.l a2					*	tst.l %a2
	jbeq _?L17					*	jeq .L17
	move.l a5,d0					*	move.l %a5,%d0
	move.l a1,d3					*	move.l %a1,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a3,d0					*	sub.l %a3,%d0
	subx.l d3,d2					*	subx.l %d3,%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d2,d3					*	move.l %d2,%d3
	lsl.l d7,d3					*	lsl.l %d7,%d3
	lsr.l d4,d0					*	lsr.l %d4,%d0
	lsr.l d4,d2					*	lsr.l %d4,%d2
	move.l d2,(a2)					*	move.l %d2,(%a2)
	or.l d0,d3					*	or.l %d0,%d3
	move.l d3,4(a2)					*	move.l %d3,4(%a2)
_?L17:							*.L17:
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L15:							*.L15:
	clr.l d1					*	clr.l %d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L23:							*.L23:
	cmp.l a5,d5					*	cmp.l %a5,%d5
	jbls _?L13					*	jls .L13
_?L12:							*.L12:
	move.l a4,d1					*	move.l %a4,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	move.l a0,d0					*	move.l %a0,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d5					*	sub.l %d3,%d5
	subx.l d0,d6					*	subx.l %d0,%d6
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d6,a1					*	move.l %d6,%a1
	move.l d5,a3					*	move.l %d5,%a3
	jbra _?L13					*	jra .L13
_?L16:							*.L16:
	clr.l d1					*	clr.l %d1
	jbra _?L11					*	jra .L11
							*	.size	__udivmoddi4, .-__udivmoddi4
							*	.ident	"GCC: (GNU) 13.4.0"
