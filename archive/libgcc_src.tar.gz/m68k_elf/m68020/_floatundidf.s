* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___floatundidf				*	.globl	__floatundidf
							*	.hidden	__floatundidf
							*	.type	__floatundidf, @function
___floatundidf:						*__floatundidf:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	fmove.l d1,fp0					*	fmove.l %d1,%fp0
	tst.l d1					*	tst.l %d1
	jblt _?L6					*	jlt .L6
	fmul.d #0x41f00000,#0x00000000,fp0		*	fmul.d #0x41f0000000000000,%fp0
	fmove.l d0,fp1					*	fmove.l %d0,%fp1
	tst.l d0					*	tst.l %d0
	jblt _?L7					*	jlt .L7
_?L3:							*.L3:
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	rts						*	rts
_?L7:							*.L7:
	fadd.d #0x41f00000,#0x00000000,fp1		*	fadd.d #0x41f0000000000000,%fp1
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	rts						*	rts
_?L6:							*.L6:
	fadd.d #0x41f00000,#0x00000000,fp0		*	fadd.d #0x41f0000000000000,%fp0
	fmul.d #0x41f00000,#0x00000000,fp0		*	fmul.d #0x41f0000000000000,%fp0
	fmove.l d0,fp1					*	fmove.l %d0,%fp1
	tst.l d0					*	tst.l %d0
	jbge _?L3					*	jge .L3
	jbra _?L7					*	jra .L7
							*	.size	__floatundidf, .-__floatundidf
							*	.ident	"GCC: (GNU) 13.4.0"
