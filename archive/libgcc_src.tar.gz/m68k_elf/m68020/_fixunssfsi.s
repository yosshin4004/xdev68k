* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunssfsi				*	.globl	__fixunssfsi
							*	.hidden	__fixunssfsi
							*	.type	__fixunssfsi, @function
___fixunssfsi:						*__fixunssfsi:
	fmove.s 4(sp),fp0				*	fmove.s 4(%sp),%fp0
	fcmp.s #0x4f000000,fp0				*	fcmp.s #0x4f000000,%fp0
	fbge _?L9					*	fjge .L9
	fintrz.x fp0,fp0				*	fintrz.x %fp0,%fp0
	fmove.l fp0,d0					*	fmove.l %fp0,%d0
	rts						*	rts
_?L9:							*.L9:
	fsub.s #0x4f000000,fp0				*	fsub.s #0x4f000000,%fp0
	fintrz.x fp0,fp0				*	fintrz.x %fp0,%fp0
	fmove.l fp0,d0					*	fmove.l %fp0,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	rts						*	rts
							*	.size	__fixunssfsi, .-__fixunssfsi
							*	.ident	"GCC: (GNU) 13.4.0"
