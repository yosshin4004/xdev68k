* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ffsdi2				*	.globl	__ffsdi2
							*	.hidden	__ffsdi2
							*	.type	__ffsdi2, @function
___ffsdi2:						*__ffsdi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	jbeq _?L2					*	jeq .L2
	move.w #32,a0					*	move.w #32,%a0
	move.l d0,d1					*	move.l %d0,%d1
	neg.l d1					*	neg.l %d1
	and.l d0,d1					*	and.l %d0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 521 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d1{#0:#32},d1				*	bfffo %d1{#0:#0},%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a0,d0					*	move.l %a0,%d0
	sub.l d1,d0					*	sub.l %d1,%d0
_?L1:							*.L1:
	rts						*	rts
_?L2:							*.L2:
	move.l d1,d0					*	move.l %d1,%d0
	jbeq _?L1					*	jeq .L1
	move.w #64,a0					*	move.w #64,%a0
	move.l d0,d1					*	move.l %d0,%d1
	neg.l d1					*	neg.l %d1
	and.l d0,d1					*	and.l %d0,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 521 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d1{#0:#32},d1				*	bfffo %d1{#0:#0},%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a0,d0					*	move.l %a0,%d0
	sub.l d1,d0					*	sub.l %d1,%d0
	jbra _?L1					*	jra .L1
							*	.size	__ffsdi2, .-__ffsdi2
							*	.ident	"GCC: (GNU) 13.4.0"
