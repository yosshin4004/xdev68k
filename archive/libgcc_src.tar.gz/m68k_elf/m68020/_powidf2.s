* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___powidf2				*	.globl	__powidf2
							*	.hidden	__powidf2
							*	.type	__powidf2, @function
___powidf2:						*__powidf2:
	fmove.d 4(sp),fp1				*	fmove.d 4(%sp),%fp1
	move.l 12(sp),d1				*	move.l 12(%sp),%d1
	move.l d1,d0					*	move.l %d1,%d0
	jbmi _?L18					*	jmi .L18
_?L2:							*.L2:
	btst #0,d0					*	btst #0,%d0
	jbeq _?L8					*	jeq .L8
	fmove.x fp1,fp0					*	fmove.x %fp1,%fp0
_?L3:							*.L3:
	lsr.l #1,d0					*	lsr.l #1,%d0
	jbeq _?L4					*	jeq .L4
_?L19:							*.L19:
	fmul.x fp1,fp1					*	fmul.x %fp1,%fp1
	btst #0,d0					*	btst #0,%d0
	jbeq _?L3					*	jeq .L3
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	lsr.l #1,d0					*	lsr.l #1,%d0
	jbne _?L19					*	jne .L19
_?L4:							*.L4:
	tst.l d1					*	tst.l %d1
	jblt _?L20					*	jlt .L20
	rts						*	rts
_?L8:							*.L8:
	fmovecr #0x32,fp0				*	fmovecr #0x32,%fp0
	jbra _?L3					*	jra .L3
_?L20:							*.L20:
	fmovecr #0x32,fp1				*	fmovecr #0x32,%fp1
	fdiv.x fp0,fp1					*	fdiv.x %fp0,%fp1
	fmove.x fp1,fp0					*	fmove.x %fp1,%fp0
	rts						*	rts
_?L18:							*.L18:
	neg.l d0					*	neg.l %d0
	jbra _?L2					*	jra .L2
							*	.size	__powidf2, .-__powidf2
							*	.ident	"GCC: (GNU) 13.4.0"
