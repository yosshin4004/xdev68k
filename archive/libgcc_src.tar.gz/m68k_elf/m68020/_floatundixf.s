* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	1075773440				*	.long	1075773440
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___floatundixf				*	.globl	__floatundixf
							*	.hidden	__floatundixf
							*	.type	__floatundixf, @function
___floatundixf:						*__floatundixf:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	fmove.l d1,fp2					*	fmove.l %d1,%fp2
	fmove.x _?LC0,fp1				*	fmove.x .LC0,%fp1
	tst.l d1					*	tst.l %d1
	jblt _?L5					*	jlt .L5
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	tst.l d0					*	tst.l %d0
	jblt _?L8					*	jlt .L8
_?L3:							*.L3:
	fadd.x fp2,fp0					*	fadd.x %fp2,%fp0
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L8:							*.L8:
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	fadd.x fp2,fp0					*	fadd.x %fp2,%fp0
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L5:							*.L5:
	fadd.x fp1,fp2					*	fadd.x %fp1,%fp2
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	tst.l d0					*	tst.l %d0
	jbge _?L3					*	jge .L3
	jbra _?L8					*	jra .L8
							*	.size	__floatundixf, .-__floatundixf
							*	.ident	"GCC: (GNU) 13.4.0"
