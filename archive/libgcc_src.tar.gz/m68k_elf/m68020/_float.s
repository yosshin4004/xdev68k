* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 2548 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 .globl __fpCCR						* .globl _fpCCR
 .globl _$_exception_handler				* .globl $_exception_handler
							*
QUIET_NaN = 0xffffffff					*QUIET_NaN = 0xffffffff
SIGNL_NaN = 0x7f800001					*SIGNL_NaN = 0x7f800001
INFINITY = 0x7f800000					*INFINITY = 0x7f800000
							*
F_MAX_EXP = 0xff					*F_MAX_EXP = 0xff
F_BIAS = 126						*F_BIAS = 126
FLT_MAX_EXP = F_MAX_EXP-F_BIAS				*FLT_MAX_EXP = F_MAX_EXP - F_BIAS
FLT_MIN_EXP = 1-F_BIAS					*FLT_MIN_EXP = 1 - F_BIAS
FLT_MANT_DIG = 24					*FLT_MANT_DIG = 24
							*
INEXACT_RESULT = 0x0001					*INEXACT_RESULT = 0x0001
UNDERFLOW = 0x0002					*UNDERFLOW = 0x0002
OVERFLOW = 0x0004					*OVERFLOW = 0x0004
DIVIDE_BY_ZERO = 0x0008					*DIVIDE_BY_ZERO = 0x0008
INVALID_OPERATION = 0x0010				*INVALID_OPERATION = 0x0010
							*
SINGLE_FLOAT = 1					*SINGLE_FLOAT = 1
							*
NOOP = 0						*NOOP = 0
ADD = 1							*ADD = 1
MULTIPLY = 2						*MULTIPLY = 2
DIVIDE = 3						*DIVIDE = 3
NEGATE = 4						*NEGATE = 4
COMPARE = 5						*COMPARE = 5
EXTENDSFDF = 6						*EXTENDSFDF = 6
TRUNCDFSF = 7						*TRUNCDFSF = 7
							*
UNKNOWN = -1						*UNKNOWN = -1
ROUND_TO_NEAREST = 0					*ROUND_TO_NEAREST = 0 | round result to nearest representable value
ROUND_TO_ZERO = 1					*ROUND_TO_ZERO = 1 | round result towards zero
ROUND_TO_PLUS = 2					*ROUND_TO_PLUS = 2 | round result towards plus infinity
ROUND_TO_MINUS = 3					*ROUND_TO_MINUS = 3 | round result towards minus infinity
							*
							*| Entry points:
							*
 .globl ___addsf3					* .globl __addsf3
 .globl ___subsf3					* .globl __subsf3
 .globl ___mulsf3					* .globl __mulsf3
 .globl ___divsf3					* .globl __divsf3
 .globl ___negsf2					* .globl __negsf2
 .globl ___cmpsf2					* .globl __cmpsf2
 .globl ___cmpsf2_internal				* .globl __cmpsf2_internal
							* .hidden __cmpsf2_internal
							*
							*| These are common routines to return and signal exceptions.
							*
 .text							* .text
 .even							* .even
							*
_Lf$den:						*Lf$den:
							*| Return and signal a denormalized number
 or.l d7,d0						* orl %d7,%d0
 moveq #INEXACT_RESULT+UNDERFLOW,d7			* moveq #INEXACT_RESULT+UNDERFLOW,%d7
 moveq #SINGLE_FLOAT,d6					* moveq #SINGLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Lf$infty:						*Lf$infty:
_Lf$overflow:						*Lf$overflow:
							*| Return a properly signed INFINITY and set the exception flags
 move.l #INFINITY,d0					* movel #INFINITY,%d0
 or.l d7,d0						* orl %d7,%d0
 moveq #INEXACT_RESULT+OVERFLOW,d7			* moveq #INEXACT_RESULT+OVERFLOW,%d7
 moveq #SINGLE_FLOAT,d6					* moveq #SINGLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Lf$underflow:						*Lf$underflow:
							*| Return 0 and set the exception flags
 moveq #0,d0						* moveq #0,%d0
 moveq #INEXACT_RESULT+UNDERFLOW,d7			* moveq #INEXACT_RESULT+UNDERFLOW,%d7
 moveq #SINGLE_FLOAT,d6					* moveq #SINGLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Lf$inop:						*Lf$inop:
							*| Return a quiet NaN and set the exception flags
 move.l #QUIET_NaN,d0					* movel #QUIET_NaN,%d0
 moveq #INEXACT_RESULT+INVALID_OPERATION,d7		* moveq #INEXACT_RESULT+INVALID_OPERATION,%d7
 moveq #SINGLE_FLOAT,d6					* moveq #SINGLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
_Lf$div$0:						*Lf$div$0:
							*| Return a properly signed INFINITY and set the exception flags
 move.l #INFINITY,d0					* movel #INFINITY,%d0
 or.l d7,d0						* orl %d7,%d0
 moveq #INEXACT_RESULT+DIVIDE_BY_ZERO,d7		* moveq #INEXACT_RESULT+DIVIDE_BY_ZERO,%d7
 moveq #SINGLE_FLOAT,d6					* moveq #SINGLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
							*|=============================================================================
							*|=============================================================================
							*| single precision routines
							*|=============================================================================
							*|=============================================================================
							*
							*| A single precision floating point number (float) has the format:
							*|
							*| struct _float {
							*| unsigned int sign : 1;
							*| unsigned int exponent : 8;
							*| unsigned int fraction : 23;
							*| } float;
							*|
							*| Thus sizeof(float) = 4 (32 bits).
							*|
							*| All the routines are callable from C programs, and return the result
							*| in the single register %d0. They also preserve all registers except
							*| %d0-%d1 and %a0-%a1.
							*
							*|=============================================================================
							*| __subsf3
							*|=============================================================================
							*
							*| float __subsf3(float, float);
							* .type __subsf3,function
___subsf3:						*__subsf3:
 bchg #31,8(sp)						* bchg #31,%sp@(8) | change sign of second operand
							*    | and fall through
							*|=============================================================================
							*| __addsf3
							*|=============================================================================
							*
							*| float __addsf3(float, float);
							* .type __addsf3,function
___addsf3:						*__addsf3:
							*
 link a6,#0						* link %a6,#0 | everything will be done in registers
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@- | save all data registers but %d0-%d1
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get first operand
 move.l 12(a6),d1					* movel %a6@(12),%d1 | get second operand
 move.l d0,a0						* movel %d0,%a0 | get %d0 's sign bit '
 add.l d0,d0						* addl %d0,%d0 | check and clear sign bit of a
 beq _Laddsf$b						* beq Laddsf$b | if zero return second operand
 move.l d1,a1						* movel %d1,%a1 | save b's sign bit '
 add.l d1,d1						* addl %d1,%d1 | get rid of sign bit
 beq _Laddsf$a						* beq Laddsf$a | if zero return first operand
							*
							*| Get the exponents and check for denormalized and/or infinity.
							*
 move.l #0x00ffffff,d4					* movel #0x00ffffff,%d4 | mask to get fraction
 move.l #0x01000000,d5					* movel #0x01000000,%d5 | mask to put hidden bit back
							*
 move.l d0,d6						* movel %d0,%d6 | save a to get exponent
 and.l d4,d0						* andl %d4,%d0 | get fraction in %d0
 not.l d4						* notl %d4 | make %d4 into a mask for the exponent
 and.l d4,d6						* andl %d4,%d6 | get exponent in %d6
 beq _Laddsf$a$den					* beq Laddsf$a$den | branch if a is denormalized
 cmp.l d4,d6						* cmpl %d4,%d6 | check for INFINITY or NaN
 beq _Laddsf$nf						* beq Laddsf$nf
 swap d6						* swap %d6 | put exponent into first word
 or.l d5,d0						* orl %d5,%d0 | and put hidden bit back
_Laddsf$1:						*Laddsf$1:
							*| Now we have a's exponent in d6 (second byte) and the mantissa in d0. '
 move.l d1,d7						* movel %d1,%d7 | get exponent in %d7
 and.l d4,d7						* andl %d4,%d7 |
 beq _Laddsf$b$den					* beq Laddsf$b$den | branch if b is denormalized
 cmp.l d4,d7						* cmpl %d4,%d7 | check for INFINITY or NaN
 beq _Laddsf$nf						* beq Laddsf$nf
 swap d7						* swap %d7 | put exponent into first word
 not.l d4						* notl %d4 | make %d4 into a mask for the fraction
 and.l d4,d1						* andl %d4,%d1 | get fraction in %d1
 or.l d5,d1						* orl %d5,%d1 | and put hidden bit back
_Laddsf$2:						*Laddsf$2:
							*| Now we have b's exponent in d7 (second byte) and the mantissa in d1. '
							*
							*| Note that the hidden bit corresponds to bit #FLT_MANT_DIG-1, and we
							*| shifted right once, so bit #FLT_MANT_DIG is set (so we have one extra
							*| bit).
							*
 move.l d1,d2						* movel %d1,%d2 | move b to %d2, since we want to use
							*    | two registers to do the sum
 move.l #0,d1						* movel #0,%d1 | and clear the new ones
 move.l d1,d3						* movel %d1,%d3 |
							*
							*| Here we shift the numbers in registers %d0 and %d1 so the exponents are the
							*| same, and put the largest exponent in %d6. Note that we are using two
							*| registers for each number (see the discussion by D. Knuth in "Seminumerical
							*| Algorithms").
							*
 cmp.w d6,d7						* cmpw %d6,%d7 | compare exponents
							*
							*
							*
 beq _Laddsf$3						* beq Laddsf$3 | if equal don't shift '
 bhi 5f							* bhi 5f | branch if second exponent largest
1:							*1:
 sub.l d6,d7						* subl %d6,%d7 | keep the largest exponent
 neg.l d7						* negl %d7
							*
 lsr.w #8,d7						* lsrw #8,%d7 | put difference in lower byte
							*
							*
							*
							*| if difference is too large we don't shift (actually, we can just exit) '
							*
 cmp.w #FLT_MANT_DIG+2,d7				* cmpw #FLT_MANT_DIG+2,%d7
							*
							*
							*
 bge _Laddsf$b$small					* bge Laddsf$b$small
							*
 cmp.w #16,d7						* cmpw #16,%d7 | if difference >= 16 swap
							*
							*
							*
 bge 4f							* bge 4f
2:							*2:
							*
 sub.w #1,d7						* subw #1,%d7
							*
							*
							*
3:							*3:
							*
 lsr.l #1,d2						* lsrl #1,%d2 | shift right second operand
 roxr.l #1,d3						* roxrl #1,%d3
 dbra d7,3b						* dbra %d7,3b
							*# 2779 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 bra _Laddsf$3						* bra Laddsf$3
4:							*4:
 move.w d2,d3						* movew %d2,%d3
 swap d3						* swap %d3
 move.w d3,d2						* movew %d3,%d2
 swap d2						* swap %d2
							*
 sub.w #16,d7						* subw #16,%d7
							*
							*
							*
 bne 2b							* bne 2b | if still more bits, go back to normal case
 bra _Laddsf$3						* bra Laddsf$3
5:							*5:
							*
 exg d6,d7						* exg %d6,%d7 | exchange the exponents
							*
							*
							*
							*
							*
 sub.l d6,d7						* subl %d6,%d7 | keep the largest exponent
 neg.l d7						* negl %d7 |
							*
 lsr.w #8,d7						* lsrw #8,%d7 | put difference in lower byte
							*
							*
							*
							*| if difference is too large we don't shift (and exit!) '
							*
 cmp.w #FLT_MANT_DIG+2,d7				* cmpw #FLT_MANT_DIG+2,%d7
							*
							*
							*
 bge _Laddsf$a$small					* bge Laddsf$a$small
							*
 cmp.w #16,d7						* cmpw #16,%d7 | if difference >= 16 swap
							*
							*
							*
 bge 8f							* bge 8f
6:							*6:
							*
 sub.w #1,d7						* subw #1,%d7
							*
							*
							*
7:							*7:
							*
 lsr.l #1,d0						* lsrl #1,%d0 | shift right first operand
 roxr.l #1,d1						* roxrl #1,%d1
 dbra d7,7b						* dbra %d7,7b
							*# 2840 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 bra _Laddsf$3						* bra Laddsf$3
8:							*8:
 move.w d0,d1						* movew %d0,%d1
 swap d1						* swap %d1
 move.w d1,d0						* movew %d1,%d0
 swap d0						* swap %d0
							*
 sub.w #16,d7						* subw #16,%d7
							*
							*
							*
 bne 6b							* bne 6b | if still more bits, go back to normal case
							*    | otherwise we fall through
							*
							*| Now we have a in %d0-%d1, b in %d2-%d3, and the largest exponent in %d6 (the
							*| signs are stored in %a0 and %a1).
							*
_Laddsf$3:						*Laddsf$3:
							*| Here we have to decide whether to add or subtract the numbers
							*
 exg d6,a0						* exg %d6,%a0 | get signs back
 exg d7,a1						* exg %d7,%a1 | and save the exponents
							*# 2870 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 eor.l d6,d7						* eorl %d6,%d7 | combine sign bits
 bmi _Lsubsf$0						* bmi Lsubsf$0 | if negative a and b have opposite
							*    | sign so we actually subtract the
							*    | numbers
							*
							*| Here we have both positive or both negative
							*
 exg d6,a0						* exg %d6,%a0 | now we have the exponent in %d6
							*
							*
							*
							*
							*
 move.l a0,d7						* movel %a0,%d7 | and sign in %d7
 and.l #0x80000000,d7					* andl #0x80000000,%d7
							*| Here we do the addition.
 add.l d3,d1						* addl %d3,%d1
 addx.l d2,d0						* addxl %d2,%d0
							*| Note: now we have %d2, %d3, %d4 and %d5 to play with!
							*
							*| Put the exponent, in the first byte, in %d2, to use the "standard" rounding
							*| routines:
 move.l d6,d2						* movel %d6,%d2
							*
 lsr.w #8,d2						* lsrw #8,%d2
							*
							*
							*
							*
							*| Before rounding normalize so bit #FLT_MANT_DIG is set (we will consider
							*| the case of denormalized numbers in the rounding routine itself).
							*| As in the addition (not in the subtraction!) we could have set
							*| one more bit we check this:
 btst #FLT_MANT_DIG+1,d0				* btst #FLT_MANT_DIG+1,%d0
 beq 1f							* beq 1f
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
							*
							*
							*
							*
							*
							*
							*
 add.l #1,d2						* addl #1,%d2
1:							*1:
 lea _Laddsf$4(pc),a0					* lea %pc@(Laddsf$4),%a0 | to return from rounding routine
 PICLEA __fpCCR,a1					* PICLEA _fpCCR,%a1 | check the rounding mode
							*
							*
							*
 move.w 6(a1),d6					* movew %a1@(6),%d6 | rounding mode in %d6
 beq _Lround$to$nearest					* beq Lround$to$nearest
							*
 cmp.w #ROUND_TO_PLUS,d6				* cmpw #ROUND_TO_PLUS,%d6
							*
							*
							*
 bhi _Lround$to$minus					* bhi Lround$to$minus
 blt _Lround$to$zero					* blt Lround$to$zero
 bra _Lround$to$plus					* bra Lround$to$plus
_Laddsf$4:						*Laddsf$4:
							*| Put back the exponent, but check for overflow.
							*
 cmp.w #0xff,d2						* cmpw #0xff,%d2
							*
							*
							*
 bhi 1f							* bhi 1f
 bclr #FLT_MANT_DIG-1,d0				* bclr #FLT_MANT_DIG-1,%d0
							*
 lsl.w #7,d2						* lslw #7,%d2
							*
							*
							*
 swap d2						* swap %d2
 or.l d2,d0						* orl %d2,%d0
 bra _Laddsf$ret					* bra Laddsf$ret
1:							*1:
 moveq #ADD,d5						* moveq #ADD,%d5
 bra _Lf$overflow					* bra Lf$overflow
							*
_Lsubsf$0:						*Lsubsf$0:
							*| We are here if a > 0 and b < 0 (sign bits cleared).
							*| Here we do the subtraction.
 move.l d6,d7						* movel %d6,%d7 | put sign in %d7
 and.l #0x80000000,d7					* andl #0x80000000,%d7
							*
 sub.l d3,d1						* subl %d3,%d1 | result in %d0-%d1
 subx.l d2,d0						* subxl %d2,%d0 |
 beq _Laddsf$ret					* beq Laddsf$ret | if zero just exit
 bpl 1f							* bpl 1f | if positive skip the following
 bchg #31,d7						* bchg #31,%d7 | change sign bit in %d7
 neg.l d1						* negl %d1
 negx.l d0						* negxl %d0
1:							*1:
							*
 exg d2,a0						* exg %d2,%a0 | now we have the exponent in %d2
 lsr.w #8,d2						* lsrw #8,%d2 | put it in the first byte
							*
							*
							*
							*
							*
							*
							*
							*| Now %d0-%d1 is positive and the sign bit is in %d7.
							*
							*| Note that we do not have to normalize, since in the subtraction bit
							*| #FLT_MANT_DIG+1 is never set, and denormalized numbers are handled by
							*| the rounding routines themselves.
 lea _Lsubsf$1(pc),a0					* lea %pc@(Lsubsf$1),%a0 | to return from rounding routine
 PICLEA __fpCCR,a1					* PICLEA _fpCCR,%a1 | check the rounding mode
							*
							*
							*
 move.w 6(a1),d6					* movew %a1@(6),%d6 | rounding mode in %d6
 beq _Lround$to$nearest					* beq Lround$to$nearest
							*
 cmp.w #ROUND_TO_PLUS,d6				* cmpw #ROUND_TO_PLUS,%d6
							*
							*
							*
 bhi _Lround$to$minus					* bhi Lround$to$minus
 blt _Lround$to$zero					* blt Lround$to$zero
 bra _Lround$to$plus					* bra Lround$to$plus
_Lsubsf$1:						*Lsubsf$1:
							*| Put back the exponent (we can't have overflow!). '
 bclr #FLT_MANT_DIG-1,d0				* bclr #FLT_MANT_DIG-1,%d0
							*
 lsl.w #7,d2						* lslw #7,%d2
							*
							*
							*
 swap d2						* swap %d2
 or.l d2,d0						* orl %d2,%d0
 bra _Laddsf$ret					* bra Laddsf$ret
							*
							*| If one of the numbers was too small (difference of exponents >=
							*| FLT_MANT_DIG+2) we return the other (and now we don't have to '
							*| check for finiteness or zero).
_Laddsf$a$small:					*Laddsf$a$small:
 move.l 12(a6),d0					* movel %a6@(12),%d0
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | restore data registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 | and return
 rts							* rts
							*
_Laddsf$b$small:					*Laddsf$b$small:
 move.l 8(a6),d0					* movel %a6@(8),%d0
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | restore data registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 | and return
 rts							* rts
							*
							*| If the numbers are denormalized remember to put exponent equal to 1.
							*
_Laddsf$a$den:						*Laddsf$a$den:
 move.l d5,d6						* movel %d5,%d6 | %d5 contains 0x01000000
 swap d6						* swap %d6
 bra _Laddsf$1						* bra Laddsf$1
							*
_Laddsf$b$den:						*Laddsf$b$den:
 move.l d5,d7						* movel %d5,%d7
 swap d7						* swap %d7
 not.l d4						* notl %d4 | make %d4 into a mask for the fraction
							*    | (this was not executed after the jump)
 bra _Laddsf$2						* bra Laddsf$2
							*
							*| The rest is mainly code for the different results which can be
							*| returned (checking always for +/-INFINITY and NaN).
							*
_Laddsf$b:						*Laddsf$b:
							*| Return b (if a is zero).
 move.l 12(a6),d0					* movel %a6@(12),%d0
 cmp.l #0x80000000,d0					* cmpl #0x80000000,%d0 | Check if b is -0
 bne 1f							* bne 1f
 move.l a0,d7						* movel %a0,%d7
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | Use the sign of a
 clr.l d0						* clrl %d0
 bra _Laddsf$ret					* bra Laddsf$ret
_Laddsf$a:						*Laddsf$a:
							*| Return a (if b is zero).
 move.l 8(a6),d0					* movel %a6@(8),%d0
1:							*1:
 moveq #ADD,d5						* moveq #ADD,%d5
							*| We have to check for NaN and +/-infty.
 move.l d0,d7						* movel %d0,%d7
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | put sign in %d7
 bclr #31,d0						* bclr #31,%d0 | clear sign
 cmp.l #INFINITY,d0					* cmpl #INFINITY,%d0 | check for infty or NaN
 bge 2f							* bge 2f
 move.l d0,d0						* movel %d0,%d0 | check for zero (we do this because we don't '
 bne _Laddsf$ret					* bne Laddsf$ret | want to return -0 by mistake
 bclr #31,d7						* bclr #31,%d7 | if zero be sure to clear sign
 bra _Laddsf$ret					* bra Laddsf$ret | if everything OK just return
2:							*2:
							*| The value to be returned is either +/-infty or NaN
 and.l #0x007fffff,d0					* andl #0x007fffff,%d0 | check for NaN
 bne _Lf$inop						* bne Lf$inop | if mantissa not zero is NaN
 bra _Lf$infty						* bra Lf$infty
							*
_Laddsf$ret:						*Laddsf$ret:
							*| Normal exit (a and b nonzero, result is not NaN nor +/-infty).
							*| We have to clear the exception flags (just the exception type).
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
 or.l d7,d0						* orl %d7,%d0 | put sign bit
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | restore data registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 | and return
 rts							* rts
							*
_Laddsf$ret$den:					*Laddsf$ret$den:
							*| Return a denormalized number (for addition we don't signal underflow) '
 lsr.l #1,d0						* lsrl #1,%d0 | remember to shift right back once
 bra _Laddsf$ret					* bra Laddsf$ret | and return
							*
							*| Note: when adding two floats of the same sign if either one is
							*| NaN we return NaN without regard to whether the other is finite or
							*| not. When subtracting them (i.e., when adding two numbers of
							*| opposite signs) things are more complicated: if both are INFINITY
							*| we return NaN, if only one is INFINITY and the other is NaN we return
							*| NaN, but if it is finite we return INFINITY with the corresponding sign.
							*
_Laddsf$nf:						*Laddsf$nf:
 moveq #ADD,d5						* moveq #ADD,%d5
							*| This could be faster but it is not worth the effort, since it is not
							*| executed very often. We sacrifice speed for clarity here.
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get the numbers back (remember that we
 move.l 12(a6),d1					* movel %a6@(12),%d1 | did some processing already)
 move.l #INFINITY,d4					* movel #INFINITY,%d4 | useful constant (INFINITY)
 move.l d0,d2						* movel %d0,%d2 | save sign bits
 move.l d0,d7						* movel %d0,%d7 | into %d7 as well as we may need the sign
							*    | bit before jumping to LfSinfty
 move.l d1,d3						* movel %d1,%d3
 bclr #31,d0						* bclr #31,%d0 | clear sign bits
 bclr #31,d1						* bclr #31,%d1
							*| We know that one of them is either NaN of +/-INFINITY
							*| Check for NaN (if either one is NaN return NaN)
 cmp.l d4,d0						* cmpl %d4,%d0 | check first a (%d0)
 bhi _Lf$inop						* bhi Lf$inop
 cmp.l d4,d1						* cmpl %d4,%d1 | check now b (%d1)
 bhi _Lf$inop						* bhi Lf$inop
							*| Now comes the check for +/-INFINITY. We know that both are (maybe not
							*| finite) numbers, but we have to check if both are infinite whether we
							*| are adding or subtracting them.
 eor.l d3,d2						* eorl %d3,%d2 | to check sign bits
 bmi 1f							* bmi 1f
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | get (common) sign bit
 bra _Lf$infty						* bra Lf$infty
1:							*1:
							*| We know one (or both) are infinite, so we test for equality between the
							*| two numbers (if they are equal they have to be infinite both, so we
							*| return NaN).
 cmp.l d1,d0						* cmpl %d1,%d0 | are both infinite?
 beq _Lf$inop						* beq Lf$inop | if so return NaN
							*
 and.l #0x80000000,d7					* andl #0x80000000,%d7 | get a's sign bit '
 cmp.l d4,d0						* cmpl %d4,%d0 | test now for infinity
 beq _Lf$infty						* beq Lf$infty | if a is INFINITY return with this sign
 bchg #31,d7						* bchg #31,%d7 | else we know b is INFINITY and has
 bra _Lf$infty						* bra Lf$infty | the opposite sign
							*
							*|=============================================================================
							*| __mulsf3
							*|=============================================================================
							*
							*| float __mulsf3(float, float);
							* .type __mulsf3,function
___mulsf3:						*__mulsf3:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@-
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get a into %d0
 move.l 12(a6),d1					* movel %a6@(12),%d1 | and b into %d1
 move.l d0,d7						* movel %d0,%d7 | %d7 will hold the sign of the product
 eor.l d1,d7						* eorl %d1,%d7 |
 and.l #0x80000000,d7					* andl #0x80000000,%d7
 move.l #INFINITY,d6					* movel #INFINITY,%d6 | useful constant (+INFINITY)
 move.l d6,d5						* movel %d6,%d5 | another (mask for fraction)
 not.l d5						* notl %d5 |
 move.l #0x00800000,d4					* movel #0x00800000,%d4 | this is to put hidden bit back
 bclr #31,d0						* bclr #31,%d0 | get rid of a's sign bit '
 move.l d0,d2						* movel %d0,%d2 |
 beq _Lmulsf$a$0					* beq Lmulsf$a$0 | branch if a is zero
 bclr #31,d1						* bclr #31,%d1 | get rid of b's sign bit '
 move.l d1,d3						* movel %d1,%d3 |
 beq _Lmulsf$b$0					* beq Lmulsf$b$0 | branch if b is zero
 cmp.l d6,d0						* cmpl %d6,%d0 | is a big?
 bhi _Lmulsf$inop					* bhi Lmulsf$inop | if a is NaN return NaN
 beq _Lmulsf$inf					* beq Lmulsf$inf | if a is INFINITY we have to check b
 cmp.l d6,d1						* cmpl %d6,%d1 | now compare b with INFINITY
 bhi _Lmulsf$inop					* bhi Lmulsf$inop | is b NaN?
 beq _Lmulsf$overflow					* beq Lmulsf$overflow | is b INFINITY?
							*| Here we have both numbers finite and nonzero (and with no sign bit).
							*| Now we get the exponents into %d2 and %d3.
 and.l d6,d2						* andl %d6,%d2 | and isolate exponent in %d2
 beq _Lmulsf$a$den					* beq Lmulsf$a$den | if exponent is zero we have a denormalized
 and.l d5,d0						* andl %d5,%d0 | and isolate fraction
 or.l d4,d0						* orl %d4,%d0 | and put hidden bit back
 swap d2						* swap %d2 | I like exponents in the first byte
							*
 lsr.w #7,d2						* lsrw #7,%d2 |
							*
							*
							*
_Lmulsf$1:						*Lmulsf$1: | number
 and.l d6,d3						* andl %d6,%d3 |
 beq _Lmulsf$b$den					* beq Lmulsf$b$den |
 and.l d5,d1						* andl %d5,%d1 |
 or.l d4,d1						* orl %d4,%d1 |
 swap d3						* swap %d3 |
							*
 lsr.w #7,d3						* lsrw #7,%d3 |
							*
							*
							*
_Lmulsf$2:						*Lmulsf$2: |
							*
 add.w d3,d2						* addw %d3,%d2 | add exponents
 sub.w #F_BIAS+1,d2					* subw #F_BIAS+1,%d2 | and subtract bias (plus one)
							*
							*
							*
							*
							*
							*| We are now ready to do the multiplication. The situation is as follows:
							*| both a and b have bit FLT_MANT_DIG-1 set (even if they were
							*| denormalized to start with!), which means that in the product
							*| bit 2*(FLT_MANT_DIG-1) (that is, bit 2*FLT_MANT_DIG-2-32 of the
							*| high long) is set.
							*
							*| To do the multiplication let us move the number a little bit around ...
 move.l d1,d6						* movel %d1,%d6 | second operand in %d6
 move.l d0,d5						* movel %d0,%d5 | first operand in %d4-%d5
 move.l #0,d4						* movel #0,%d4
 move.l d4,d1						* movel %d4,%d1 | the sums will go in %d0-%d1
 move.l d4,d0						* movel %d4,%d0
							*
							*| now bit FLT_MANT_DIG-1 becomes bit 31:
 lsl.l #31-FLT_MANT_DIG+1,d6				* lsll #31-FLT_MANT_DIG+1,%d6
							*
							*| Start the loop (we loop #FLT_MANT_DIG times):
 moveq #FLT_MANT_DIG-1,d3				* moveq #FLT_MANT_DIG-1,%d3
1: add.l d1,d1						*1: addl %d1,%d1 | shift sum
 addx.l d0,d0						* addxl %d0,%d0
 lsl.l #1,d6						* lsll #1,%d6 | get bit bn
 bcc 2f							* bcc 2f | if not set skip sum
 add.l d5,d1						* addl %d5,%d1 | add a
 addx.l d4,d0						* addxl %d4,%d0
2:							*2:
							*
 dbf d3,1b						* dbf %d3,1b | loop back
							*
							*
							*
							*
							*
							*| Now we have the product in %d0-%d1, with bit (FLT_MANT_DIG - 1) + FLT_MANT_DIG
							*| (mod 32) of %d0 set. The first thing to do now is to normalize it so bit
							*| FLT_MANT_DIG is set (to do the rounding).
							*
 ror.l #6,d1						* rorl #6,%d1
 swap d1						* swap %d1
 move.w d1,d3						* movew %d1,%d3
 and.w #0x03ff,d3					* andw #0x03ff,%d3
 and.w #0xfd00,d1					* andw #0xfd00,%d1
							*# 3272 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 lsl.l #8,d0						* lsll #8,%d0
 add.l d0,d0						* addl %d0,%d0
 add.l d0,d0						* addl %d0,%d0
							*
 or.w d3,d0						* orw %d3,%d0
							*
							*
							*
							*
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
							*
 btst #FLT_MANT_DIG+1,d0				* btst #FLT_MANT_DIG+1,%d0
 beq _Lround$exit					* beq Lround$exit
							*
 lsr.l #1,d0						* lsrl #1,%d0
 roxr.l #1,d1						* roxrl #1,%d1
 add.w #1,d2						* addw #1,%d2
							*# 3297 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 bra _Lround$exit					* bra Lround$exit
							*
_Lmulsf$inop:						*Lmulsf$inop:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
 bra _Lf$inop						* bra Lf$inop
							*
_Lmulsf$overflow:					*Lmulsf$overflow:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
 bra _Lf$overflow					* bra Lf$overflow
							*
_Lmulsf$inf:						*Lmulsf$inf:
 moveq #MULTIPLY,d5					* moveq #MULTIPLY,%d5
							*| If either is NaN return NaN; else both are (maybe infinite) numbers, so
							*| return INFINITY with the correct sign (which is in %d7).
 cmp.l d6,d1						* cmpl %d6,%d1 | is b NaN?
 bhi _Lf$inop						* bhi Lf$inop | if so return NaN
 bra _Lf$overflow					* bra Lf$overflow | else return +/-INFINITY
							*
							*| If either number is zero return zero, unless the other is +/-INFINITY,
							*| or NaN, in which case we return NaN.
_Lmulsf$b$0:						*Lmulsf$b$0:
							*| Here %d1 (==b) is zero.
 move.l 8(a6),d1					* movel %a6@(8),%d1 | get a again to check for non-finiteness
 bra 1f							* bra 1f
_Lmulsf$a$0:						*Lmulsf$a$0:
 move.l 12(a6),d1					* movel %a6@(12),%d1 | get b again to check for non-finiteness
1: bclr #31,d1						*1: bclr #31,%d1 | clear sign bit
 cmp.l #INFINITY,d1					* cmpl #INFINITY,%d1 | and check for a large exponent
 bge _Lf$inop						* bge Lf$inop | if b is +/-INFINITY or NaN return NaN
 move.l d7,d0						* movel %d7,%d0 | else return signed zero
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0 |
 move.w #0,(a0)						* movew #0,%a0@ |
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 |
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 |
 rts |							* rts |
							*
							*| If a number is denormalized we put an exponent of 1 but do not put the
							*| hidden bit back into the fraction; instead we shift left until bit 23
							*| (the hidden bit) is set, adjusting the exponent accordingly. We do this
							*| to ensure that the product of the fractions is close to 1.
_Lmulsf$a$den:						*Lmulsf$a$den:
 move.l #1,d2						* movel #1,%d2
 and.l d5,d0						* andl %d5,%d0
1: add.l d0,d0						*1: addl %d0,%d0 | shift a left (until bit 23 is set)
							*
 sub.w #1,d2						* subw #1,%d2 | and adjust exponent
							*
							*
							*
 btst #FLT_MANT_DIG-1,d0				* btst #FLT_MANT_DIG-1,%d0
 bne _Lmulsf$1						* bne Lmulsf$1 |
 bra 1b							* bra 1b | else loop back
							*
_Lmulsf$b$den:						*Lmulsf$b$den:
 move.l #1,d3						* movel #1,%d3
 and.l d5,d1						* andl %d5,%d1
1: add.l d1,d1						*1: addl %d1,%d1 | shift b left until bit 23 is set
							*
 sub.w #1,d3						* subw #1,%d3 | and adjust exponent
							*
							*
							*
 btst #FLT_MANT_DIG-1,d1				* btst #FLT_MANT_DIG-1,%d1
 bne _Lmulsf$2						* bne Lmulsf$2 |
 bra 1b							* bra 1b | else loop back
							*
							*|=============================================================================
							*| __divsf3
							*|=============================================================================
							*
							*| float __divsf3(float, float);
							* .type __divsf3,function
___divsf3:						*__divsf3:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@-
							*
							*
							*
							*
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get a into %d0
 move.l 12(a6),d1					* movel %a6@(12),%d1 | and b into %d1
 move.l d0,d7						* movel %d0,%d7 | %d7 will hold the sign of the result
 eor.l d1,d7						* eorl %d1,%d7 |
 and.l #0x80000000,d7					* andl #0x80000000,%d7 |
 move.l #INFINITY,d6					* movel #INFINITY,%d6 | useful constant (+INFINITY)
 move.l d6,d5						* movel %d6,%d5 | another (mask for fraction)
 not.l d5						* notl %d5 |
 move.l #0x00800000,d4					* movel #0x00800000,%d4 | this is to put hidden bit back
 bclr #31,d0						* bclr #31,%d0 | get rid of a's sign bit '
 move.l d0,d2						* movel %d0,%d2 |
 beq _Ldivsf$a$0					* beq Ldivsf$a$0 | branch if a is zero
 bclr #31,d1						* bclr #31,%d1 | get rid of b's sign bit '
 move.l d1,d3						* movel %d1,%d3 |
 beq _Ldivsf$b$0					* beq Ldivsf$b$0 | branch if b is zero
 cmp.l d6,d0						* cmpl %d6,%d0 | is a big?
 bhi _Ldivsf$inop					* bhi Ldivsf$inop | if a is NaN return NaN
 beq _Ldivsf$inf					* beq Ldivsf$inf | if a is INFINITY we have to check b
 cmp.l d6,d1						* cmpl %d6,%d1 | now compare b with INFINITY
 bhi _Ldivsf$inop					* bhi Ldivsf$inop | if b is NaN return NaN
 beq _Ldivsf$underflow					* beq Ldivsf$underflow
							*| Here we have both numbers finite and nonzero (and with no sign bit).
							*| Now we get the exponents into %d2 and %d3 and normalize the numbers to
							*| ensure that the ratio of the fractions is close to 1. We do this by
							*| making sure that bit #FLT_MANT_DIG-1 (hidden bit) is set.
 and.l d6,d2						* andl %d6,%d2 | and isolate exponent in %d2
 beq _Ldivsf$a$den					* beq Ldivsf$a$den | if exponent is zero we have a denormalized
 and.l d5,d0						* andl %d5,%d0 | and isolate fraction
 or.l d4,d0						* orl %d4,%d0 | and put hidden bit back
 swap d2						* swap %d2 | I like exponents in the first byte
							*
 lsr.w #7,d2						* lsrw #7,%d2 |
							*
							*
							*
_Ldivsf$1:						*Ldivsf$1: |
 and.l d6,d3						* andl %d6,%d3 |
 beq _Ldivsf$b$den					* beq Ldivsf$b$den |
 and.l d5,d1						* andl %d5,%d1 |
 or.l d4,d1						* orl %d4,%d1 |
 swap d3						* swap %d3 |
							*
 lsr.w #7,d3						* lsrw #7,%d3 |
							*
							*
							*
_Ldivsf$2:						*Ldivsf$2: |
							*
 sub.w d3,d2						* subw %d3,%d2 | subtract exponents
  add.w #F_BIAS,d2					*  addw #F_BIAS,%d2 | and add bias
							*
							*
							*
							*
							*
							*| We are now ready to do the division. We have prepared things in such a way
							*| that the ratio of the fractions will be less than 2 but greater than 1/2.
							*| At this point the registers in use are:
							*| %d0 holds a (first operand, bit FLT_MANT_DIG=0, bit FLT_MANT_DIG-1=1)
							*| %d1 holds b (second operand, bit FLT_MANT_DIG=1)
							*| %d2 holds the difference of the exponents, corrected by the bias
							*| %d7 holds the sign of the ratio
							*| %d4, %d5, %d6 hold some constants
 move.l d7,a0						* movel %d7,%a0 | %d6-%d7 will hold the ratio of the fractions
 move.l #0,d6						* movel #0,%d6 |
 move.l d6,d7						* movel %d6,%d7
							*
 moveq #FLT_MANT_DIG+1,d3				* moveq #FLT_MANT_DIG+1,%d3
1: cmp.l d0,d1						*1: cmpl %d0,%d1 | is a < b?
 bhi 2f							* bhi 2f |
 bset d3,d6						* bset %d3,%d6 | set a bit in %d6
 sub.l d1,d0						* subl %d1,%d0 | if a >= b a <-- a-b
 beq 3f							* beq 3f | if a is zero, exit
2: add.l d0,d0						*2: addl %d0,%d0 | multiply a by 2
							*
 dbra d3,1b						* dbra %d3,1b
							*
							*
							*
							*
							*
							*| Now we keep going to set the sticky bit ...
 moveq #FLT_MANT_DIG,d3					* moveq #FLT_MANT_DIG,%d3
1: cmp.l d0,d1						*1: cmpl %d0,%d1
 ble 2f							* ble 2f
 add.l d0,d0						* addl %d0,%d0
							*
 dbra d3,1b						* dbra %d3,1b
							*
							*
							*
							*
 move.l #0,d1						* movel #0,%d1
 bra 3f							* bra 3f
2: move.l #0,d1						*2: movel #0,%d1
							*
 sub.w #FLT_MANT_DIG,d3					* subw #FLT_MANT_DIG,%d3
 add.w #31,d3						* addw #31,%d3
							*
							*
							*
							*
 bset d3,d1						* bset %d3,%d1
3:							*3:
 move.l d6,d0						* movel %d6,%d0 | put the ratio in %d0-%d1
 move.l a0,d7						* movel %a0,%d7 | get sign back
							*
							*| Because of the normalization we did before we are guaranteed that
							*| %d0 is smaller than 2^26 but larger than 2^24. Thus bit 26 is not set,
							*| bit 25 could be set, and if it is not set then bit 24 is necessarily set.
 btst #FLT_MANT_DIG+1,d0				* btst #FLT_MANT_DIG+1,%d0
 beq 1f							* beq 1f | if it is not set, then bit 24 is set
 lsr.l #1,d0						* lsrl #1,%d0 |
							*
 add.w #1,d2						* addw #1,%d2 |
							*
							*
							*
1:							*1:
							*| Now round, check for over- and underflow, and exit.
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bra _Lround$exit					* bra Lround$exit
							*
_Ldivsf$inop:						*Ldivsf$inop:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bra _Lf$inop						* bra Lf$inop
							*
_Ldivsf$overflow:					*Ldivsf$overflow:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bra _Lf$overflow					* bra Lf$overflow
							*
_Ldivsf$underflow:					*Ldivsf$underflow:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
 bra _Lf$underflow					* bra Lf$underflow
							*
_Ldivsf$a$0:						*Ldivsf$a$0:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
							*| If a is zero check to see whether b is zero also. In that case return
							*| NaN; then check if b is NaN, and return NaN also in that case. Else
							*| return a properly signed zero.
 and.l #0x7fffffff,d1					* andl #0x7fffffff,%d1 | clear sign bit and test b
 beq _Lf$inop						* beq Lf$inop | if b is also zero return NaN
 cmp.l #INFINITY,d1					* cmpl #INFINITY,%d1 | check for NaN
 bhi _Lf$inop						* bhi Lf$inop |
 move.l d7,d0						* movel %d7,%d0 | else return signed zero
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0 |
 move.w #0,(a0)						* movew #0,%a0@ |
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 |
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6 |
 rts |							* rts |
							*
_Ldivsf$b$0:						*Ldivsf$b$0:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
							*| If we got here a is not zero. Check if a is NaN; in that case return NaN,
							*| else return +/-INFINITY. Remember that a is in %d0 with the sign bit
							*| cleared already.
 cmp.l #INFINITY,d0					* cmpl #INFINITY,%d0 | compare %d0 with INFINITY
 bhi _Lf$inop						* bhi Lf$inop | if larger it is NaN
 bra _Lf$div$0						* bra Lf$div$0 | else signal DIVIDE_BY_ZERO
							*
_Ldivsf$inf:						*Ldivsf$inf:
 moveq #DIVIDE,d5					* moveq #DIVIDE,%d5
							*| If a is INFINITY we have to check b
 cmp.l #INFINITY,d1					* cmpl #INFINITY,%d1 | compare b with INFINITY
 bge _Lf$inop						* bge Lf$inop | if b is NaN or INFINITY return NaN
 bra _Lf$overflow					* bra Lf$overflow | else return overflow
							*
							*| If a number is denormalized we put an exponent of 1 but do not put the
							*| bit back into the fraction.
_Ldivsf$a$den:						*Ldivsf$a$den:
 move.l #1,d2						* movel #1,%d2
 and.l d5,d0						* andl %d5,%d0
1: add.l d0,d0						*1: addl %d0,%d0 | shift a left until bit FLT_MANT_DIG-1 is set
							*
 sub.w #1,d2						* subw #1,%d2 | and adjust exponent
							*
							*
							*
 btst #FLT_MANT_DIG-1,d0				* btst #FLT_MANT_DIG-1,%d0
 bne _Ldivsf$1						* bne Ldivsf$1
 bra 1b							* bra 1b
							*
_Ldivsf$b$den:						*Ldivsf$b$den:
 move.l #1,d3						* movel #1,%d3
 and.l d5,d1						* andl %d5,%d1
1: add.l d1,d1						*1: addl %d1,%d1 | shift b left until bit FLT_MANT_DIG is set
							*
 sub.w #1,d3						* subw #1,%d3 | and adjust exponent
							*
							*
							*
 btst #FLT_MANT_DIG-1,d1				* btst #FLT_MANT_DIG-1,%d1
 bne _Ldivsf$2						* bne Ldivsf$2
 bra 1b							* bra 1b
							*
_Lround$exit:						*Lround$exit:
							*| This is a common exit point for __mulsf3 and __divsf3.
							*
							*| First check for underlow in the exponent:
							*
 cmp.w #-FLT_MANT_DIG-1,d2				* cmpw #-FLT_MANT_DIG-1,%d2
							*
							*
							*
 blt _Lf$underflow					* blt Lf$underflow
							*| It could happen that the exponent is less than 1, in which case the
							*| number is denormalized. In this case we shift right and adjust the
							*| exponent until it becomes 1 or the fraction is zero (in the latter case
							*| we signal underflow and return zero).
 move.l #0,d6						* movel #0,%d6 | %d6 is used temporarily
							*
 cmp.w #1,d2						* cmpw #1,%d2 | if the exponent is less than 1 we
							*
							*
							*
 bge 2f							* bge 2f | have to shift right (denormalize)
1:							*1:
							*
 add.w #1,d2						* addw #1,%d2 | adjust the exponent
 lsr.l #1,d0						* lsrl #1,%d0 | shift right once
 roxr.l #1,d1						* roxrl #1,%d1 |
 roxr.l #1,d6						* roxrl #1,%d6 | %d6 collect bits we would lose otherwise
 cmp.w #1,d2						* cmpw #1,%d2 | is the exponent 1 already?
							*# 3625 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 beq 2f							* beq 2f | if not loop back
 bra 1b							* bra 1b |
 bra _Lf$underflow					* bra Lf$underflow | safety check, shouldn't execute '
2: or.l d6,d1						*2: orl %d6,%d1 | this is a trick so we don't lose  '
							*    | the extra bits which were flushed right
							*| Now call the rounding routine (which takes care of denormalized numbers):
 lea _Lround$0(pc),a0					* lea %pc@(Lround$0),%a0 | to return from rounding routine
 PICLEA __fpCCR,a1					* PICLEA _fpCCR,%a1 | check the rounding mode
							*
							*
							*
 move.w 6(a1),d6					* movew %a1@(6),%d6 | rounding mode in %d6
 beq _Lround$to$nearest					* beq Lround$to$nearest
							*
 cmp.w #ROUND_TO_PLUS,d6				* cmpw #ROUND_TO_PLUS,%d6
							*
							*
							*
 bhi _Lround$to$minus					* bhi Lround$to$minus
 blt _Lround$to$zero					* blt Lround$to$zero
 bra _Lround$to$plus					* bra Lround$to$plus
_Lround$0:						*Lround$0:
							*| Here we have a correctly rounded result (either normalized or denormalized).
							*
							*| Here we should have either a normalized number or a denormalized one, and
							*| the exponent is necessarily larger or equal to 1 (so we don't have to  '
							*| check again for underflow!). We have to check for overflow or for a
							*| denormalized number (which also signals underflow).
							*| Check for overflow (i.e., exponent >= 255).
							*
 cmp.w #0x00ff,d2					* cmpw #0x00ff,%d2
							*
							*
							*
 bge _Lf$overflow					* bge Lf$overflow
							*| Now check for a denormalized number (exponent==0).
 move.w d2,d2						* movew %d2,%d2
 beq _Lf$den						* beq Lf$den
1:							*1:
							*| Put back the exponents and sign and return.
							*
 lsl.w #7,d2						* lslw #7,%d2 | exponent back to fourth byte
							*
							*
							*
 bclr #FLT_MANT_DIG-1,d0				* bclr #FLT_MANT_DIG-1,%d0
 swap d0						* swap %d0 | and put back exponent
							*
 or.w d2,d0						* orw %d2,%d0 |
							*
							*
							*
 swap d0						* swap %d0 |
 or.l d7,d0						* orl %d7,%d0 | and sign also
							*
 PICLEA __fpCCR,a0					* PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
							*
							*|=============================================================================
							*| __negsf2
							*|=============================================================================
							*
							*| This is trivial and could be shorter if we didn't bother checking for NaN '
							*| and +/-INFINITY.
							*
							*| float __negsf2(float);
							* .type __negsf2,function
___negsf2:						*__negsf2:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@-
							*
							*
							*
							*
 moveq #NEGATE,d5					* moveq #NEGATE,%d5
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get number to negate in %d0
 bchg #31,d0						* bchg #31,%d0 | negate
 move.l d0,d1						* movel %d0,%d1 | make a positive copy
 bclr #31,d1						* bclr #31,%d1 |
 tst.l d1						* tstl %d1 | check for zero
 beq 2f							* beq 2f | if zero (either sign) return +zero
 cmp.l #INFINITY,d1					* cmpl #INFINITY,%d1 | compare to +INFINITY
 blt 1f							* blt 1f |
 bhi _Lf$inop						* bhi Lf$inop | if larger (fraction not zero) is NaN
 move.l d0,d7						* movel %d0,%d7 | else get sign and return INFINITY
 and.l #0x80000000,d7					* andl #0x80000000,%d7
 bra _Lf$infty						* bra Lf$infty
1: PICLEA __fpCCR,a0					*1: PICLEA _fpCCR,%a0
 move.w #0,(a0)						* movew #0,%a0@
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
2: bclr #31,d0						*2: bclr #31,%d0
 bra 1b							* bra 1b
							*
							*|=============================================================================
							*| __cmpsf2
							*|=============================================================================
							*
GREATER = 1						*GREATER = 1
LESS = -1						*LESS = -1
EQUAL = 0						*EQUAL = 0
							*
							*| int __cmpsf2_internal(float, float, int);
___cmpsf2_internal:					*__cmpsf2_internal:
							*
 link a6,#0						* link %a6,#0
 movem.l d2-d7,-(sp)					* moveml %d2-%d7,%sp@- | save registers
							*
							*
							*
							*
 moveq #COMPARE,d5					* moveq #COMPARE,%d5
 move.l 8(a6),d0					* movel %a6@(8),%d0 | get first operand
 move.l 12(a6),d1					* movel %a6@(12),%d1 | get second operand
							*| Check if either is NaN, and in that case return garbage and signal
							*| INVALID_OPERATION. Check also if either is zero, and clear the signs
							*| if necessary.
 move.l d0,d6						* movel %d0,%d6
 and.l #0x7fffffff,d0					* andl #0x7fffffff,%d0
 beq _Lcmpsf$a$0					* beq Lcmpsf$a$0
 cmp.l #0x7f800000,d0					* cmpl #0x7f800000,%d0
 bhi _Lcmpf$inop					* bhi Lcmpf$inop
_Lcmpsf$1:						*Lcmpsf$1:
 move.l d1,d7						* movel %d1,%d7
 and.l #0x7fffffff,d1					* andl #0x7fffffff,%d1
 beq _Lcmpsf$b$0					* beq Lcmpsf$b$0
 cmp.l #0x7f800000,d1					* cmpl #0x7f800000,%d1
 bhi _Lcmpf$inop					* bhi Lcmpf$inop
_Lcmpsf$2:						*Lcmpsf$2:
							*| Check the signs
 eor.l d6,d7						* eorl %d6,%d7
 bpl 1f							* bpl 1f
							*| If the signs are not equal check if a >= 0
 tst.l d6						* tstl %d6
 bpl _Lcmpsf$a$gt$b					* bpl Lcmpsf$a$gt$b | if (a >= 0 && b < 0) => a > b
 bmi _Lcmpsf$b$gt$a					* bmi Lcmpsf$b$gt$a | if (a < 0 && b >= 0) => a < b
1:							*1:
							*| If the signs are equal check for < 0
 tst.l d6						* tstl %d6
 bpl 1f							* bpl 1f
							*| If both are negative exchange them
							*
 exg d0,d1						* exg %d0,%d1
							*
							*
							*
							*
							*
1:							*1:
							*| Now that they are positive we just compare them as longs (does this also
							*| work for denormalized numbers?).
 cmp.l d0,d1						* cmpl %d0,%d1
 bhi _Lcmpsf$b$gt$a					* bhi Lcmpsf$b$gt$a | |b| > |a|
 bne _Lcmpsf$a$gt$b					* bne Lcmpsf$a$gt$b | |b| < |a|
							*| If we got here a == b.
 move.l #EQUAL,d0					* movel #EQUAL,%d0
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | put back the registers
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
_Lcmpsf$a$gt$b:						*Lcmpsf$a$gt$b:
 move.l #GREATER,d0					* movel #GREATER,%d0
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | put back the registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
_Lcmpsf$b$gt$a:						*Lcmpsf$b$gt$a:
 move.l #LESS,d0					* movel #LESS,%d0
							*
 movem.l (sp)+,d2-d7					* moveml %sp@+,%d2-%d7 | put back the registers
							*
							*
							*
							*
							*
 unlk a6						* unlk %a6
 rts							* rts
							*
_Lcmpsf$a$0:						*Lcmpsf$a$0:
 bclr #31,d6						* bclr #31,%d6
 bra _Lcmpsf$1						* bra Lcmpsf$1
_Lcmpsf$b$0:						*Lcmpsf$b$0:
 bclr #31,d7						* bclr #31,%d7
 bra _Lcmpsf$2						* bra Lcmpsf$2
							*
_Lcmpf$inop:						*Lcmpf$inop:
 move.l 16(a6),d0					* movl %a6@(16),%d0
 moveq #INEXACT_RESULT+INVALID_OPERATION,d7		* moveq #INEXACT_RESULT+INVALID_OPERATION,%d7
 moveq #SINGLE_FLOAT,d6					* moveq #SINGLE_FLOAT,%d6
 PICJUMP _$_exception_handler				* PICJUMP $_exception_handler
							*
							*| int __cmpsf2(float, float);
							* .type __cmpsf2,function
___cmpsf2:						*__cmpsf2:
 link a6,#0						* link %a6,#0
 pea 1							* pea 1
 move.l 12(a6),-(sp)					* movl %a6@(12),%sp@-
 move.l 8(a6),-(sp)					* movl %a6@(8),%sp@-
 PICCALL ___cmpsf2_internal				* PICCALL __cmpsf2_internal
 unlk a6						* unlk %a6
 rts							* rts
							*
							*|=============================================================================
							*| rounding routines
							*|=============================================================================
							*
							*| The rounding routines expect the number to be normalized in registers
							*| %d0-%d1, with the exponent in register %d2. They assume that the
							*| exponent is larger or equal to 1. They return a properly normalized number
							*| if possible, and a denormalized number otherwise. The exponent is returned
							*| in %d2.
							*
_Lround$to$nearest:					*Lround$to$nearest:
							*| We now normalize as suggested by D. Knuth ("Seminumerical Algorithms"):
							*| Here we assume that the exponent is not too small (this should be checked
							*| before entering the rounding routine), but the number could be denormalized.
							*
							*| Check for denormalized numbers:
1: btst #FLT_MANT_DIG,d0				*1: btst #FLT_MANT_DIG,%d0
 bne 2f							* bne 2f | if set the number is normalized
							*| Normalize shifting left until bit #FLT_MANT_DIG is set or the exponent
							*| is one (remember that a denormalized number corresponds to an
							*| exponent of -F_BIAS+1).
							*
 cmp.w #1,d2						* cmpw #1,%d2 | remember that the exponent is at least one
							*
							*
							*
  beq 2f						*  beq 2f | an exponent of one means denormalized
 add.l d1,d1						* addl %d1,%d1 | else shift and adjust the exponent
 addx.l d0,d0						* addxl %d0,%d0 |
							*
 dbra d2,1b						* dbra %d2,1b |
							*
							*
							*
							*
2:							*2:
							*| Now round: we do it as follows: after the shifting we can write the
							*| fraction part as f + delta, where 1 < f < 2^25, and 0 <= delta <= 2.
							*| If delta < 1, do nothing. If delta > 1, add 1 to f.
							*| If delta == 1, we make sure the rounded number will be even (odd?)
							*| (after shifting).
 btst #0,d0						* btst #0,%d0 | is delta < 1?
 beq 2f							* beq 2f | if so, do not do anything
 tst.l d1						* tstl %d1 | is delta == 1?
 bne 1f							* bne 1f | if so round to even
 move.l d0,d1						* movel %d0,%d1 |
 and.l #2,d1						* andl #2,%d1 | bit 1 is the last significant bit
 add.l d1,d0						* addl %d1,%d0 |
 bra 2f							* bra 2f |
1: move.l #1,d1						*1: movel #1,%d1 | else add 1
 add.l d1,d0						* addl %d1,%d0 |
							*| Shift right once (because we used bit #FLT_MANT_DIG!).
2: lsr.l #1,d0						*2: lsrl #1,%d0
							*| Now check again bit #FLT_MANT_DIG (rounding could have produced a
							*| 'fraction overflow' ...).
 btst #FLT_MANT_DIG,d0					* btst #FLT_MANT_DIG,%d0
 beq 1f							* beq 1f
 lsr.l #1,d0						* lsrl #1,%d0
							*
 add.w #1,d2						* addw #1,%d2
							*
							*
							*
1:							*1:
							*| If bit #FLT_MANT_DIG-1 is clear we have a denormalized number, so we
							*| have to put the exponent to zero and return a denormalized number.
 btst #FLT_MANT_DIG-1,d0				* btst #FLT_MANT_DIG-1,%d0
 beq 1f							* beq 1f
 jmp (a0)						* jmp %a0@
1: move.l #0,d2						*1: movel #0,%d2
 jmp (a0)						* jmp %a0@
							*
_Lround$to$zero:					*Lround$to$zero:
_Lround$to$plus:					*Lround$to$plus:
_Lround$to$minus:					*Lround$to$minus:
 jmp (a0)						* jmp %a0@
							*
							*
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
