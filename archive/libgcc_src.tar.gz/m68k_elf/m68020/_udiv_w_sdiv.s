* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___udiv_w_sdiv				*	.globl	__udiv_w_sdiv
							*	.hidden	__udiv_w_sdiv
							*	.type	__udiv_w_sdiv, @function
___udiv_w_sdiv:						*__udiv_w_sdiv:
	movem.l d3/d4/d5/d6,-(sp)			*	movem.l #7680,-(%sp)
	move.l 24(sp),d1				*	move.l 24(%sp),%d1
	move.l 28(sp),d5				*	move.l 28(%sp),%d5
	move.l 32(sp),d2				*	move.l 32(%sp),%d2
	jbmi _?L2					*	jmi .L2
	move.l d2,d0					*	move.l %d2,%d0
	sub.l d1,d0					*	sub.l %d1,%d0
	move.l d5,d3					*	move.l %d5,%d3
	add.l d3,d3					*	add.l %d3,%d3
	subx.l d3,d3					*	subx.l %d3,%d3
	move.l d3,a0					*	move.l %d3,%a0
	add.l d0,a0					*	add.l %d0,%a0
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbcc _?L3					*	jcc .L3
	move.l d5,d0					*	move.l %d5,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 565 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divs.l d2,d1:d0					*	divs.l %d2,%d1:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
_?L4:							*.L4:
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L3:							*.L3:
	move.l d2,d3					*	move.l %d2,%d3
	lsr.l #1,d3					*	lsr.l #1,%d3
	move.l d2,d4					*	move.l %d2,%d4
	moveq #31,d6					*	moveq #31,%d6
	lsl.l d6,d4					*	lsl.l %d6,%d4
	move.l d5,d0					*	move.l %d5,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 570 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d4,d0					*	sub.l %d4,%d0
	subx.l d3,d1					*	subx.l %d3,%d1
							*| 0 "" 2
							*| 572 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divs.l d2,d1:d0					*	divs.l %d2,%d1:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L2:							*.L2:
	move.l d2,d3					*	move.l %d2,%d3
	lsr.l #1,d3					*	lsr.l #1,%d3
	move.l d1,d4					*	move.l %d1,%d4
	lsr.l #1,d4					*	lsr.l #1,%d4
	move.l d1,d0					*	move.l %d1,%d0
	moveq #31,d6					*	moveq #31,%d6
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d5,d6					*	move.l %d5,%d6
	lsr.l #1,d6					*	lsr.l #1,%d6
	add.l d6,d0					*	add.l %d6,%d0
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcc _?L5					*	jcc .L5
* APP ON (APP) asm_mode=gas				*#APP
							*| 585 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divs.l d3,d4:d0					*	divs.l %d3,%d4:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	add.l d4,d4					*	add.l %d4,%d4
	moveq #1,d1					*	moveq #1,%d1
	and.l d5,d1					*	and.l %d5,%d1
	add.l d4,d1					*	add.l %d4,%d1
	btst #0,d2					*	btst #0,%d2
	jbeq _?L4					*	jeq .L4
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L18					*	jcc .L18
	move.l d0,a0					*	move.l %d0,%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbcs _?L7					*	jcs .L7
	sub.l d0,d2					*	sub.l %d0,%d2
	add.l d2,d1					*	add.l %d2,%d1
	subq.l #1,d0					*	subq.l #1,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L5:							*.L5:
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbcc _?L8					*	jcc .L8
	move.l d3,d1					*	move.l %d3,%d1
	sub.l d4,d1					*	sub.l %d4,%d1
	move.l d0,d4					*	move.l %d0,%d4
	not.l d4					*	not.l %d4
	subq.l #1,d1					*	subq.l #1,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 609 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divs.l d3,d1:d4					*	divs.l %d3,%d1:%d4
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d4,d0					*	move.l %d4,%d0
	not.l d0					*	not.l %d0
	subq.l #1,d3					*	subq.l #1,%d3
	sub.l d1,d3					*	sub.l %d1,%d3
	add.l d3,d3					*	add.l %d3,%d3
	moveq #1,d1					*	moveq #1,%d1
	and.l d5,d1					*	and.l %d5,%d1
	add.l d3,d1					*	add.l %d3,%d1
	btst #0,d2					*	btst #0,%d2
	jbeq _?L4					*	jeq .L4
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L18					*	jcc .L18
	move.l d0,a0					*	move.l %d0,%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbcs _?L10					*	jcs .L10
	sub.l d0,d2					*	sub.l %d0,%d2
	add.l d2,d1					*	add.l %d2,%d1
	moveq #-2,d0					*	moveq #-2,%d0
	sub.l d4,d0					*	sub.l %d4,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L8:							*.L8:
	move.l d2,d0					*	move.l %d2,%d0
	neg.l d0					*	neg.l %d0
	cmp.l d0,d5					*	cmp.l %d0,%d5
	jbcs _?L11					*	jcs .L11
	move.l d2,d1					*	move.l %d2,%d1
	add.l d5,d1					*	add.l %d5,%d1
	moveq #-1,d0					*	moveq #-1,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L18:							*.L18:
	sub.l d0,d1					*	sub.l %d0,%d1
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L11:							*.L11:
	add.l d2,d2					*	add.l %d2,%d2
	move.l d2,d1					*	move.l %d2,%d1
	add.l d5,d1					*	add.l %d5,%d1
	moveq #-2,d0					*	moveq #-2,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L7:							*.L7:
	add.l d2,d2					*	add.l %d2,%d2
	sub.l d0,d2					*	sub.l %d0,%d2
	add.l d2,d1					*	add.l %d2,%d1
	subq.l #2,d0					*	subq.l #2,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L10:							*.L10:
	add.l d2,d2					*	add.l %d2,%d2
	sub.l d0,d2					*	sub.l %d0,%d2
	add.l d2,d1					*	add.l %d2,%d1
	moveq #-3,d0					*	moveq #-3,%d0
	sub.l d4,d0					*	sub.l %d4,%d0
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.l d1,(a0)					*	move.l %d1,(%a0)
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
							*	.size	__udiv_w_sdiv, .-__udiv_w_sdiv
							*	.ident	"GCC: (GNU) 13.4.0"
