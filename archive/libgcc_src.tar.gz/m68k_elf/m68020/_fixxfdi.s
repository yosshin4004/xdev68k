* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixxfdi				*	.globl	__fixxfdi
							*	.hidden	__fixxfdi
							*	.type	__fixxfdi, @function
___fixxfdi:						*__fixxfdi:
	fmove.x 4(sp),fp0				*	fmove.x 4(%sp),%fp0
	fcmp.x _?LC0,fp0				*	fcmp.x .LC0,%fp0
	fblt _?L8					*	fjlt .L8
	fmove.x fp0,4(sp)				*	fmove.x %fp0,4(%sp)
	jbra ___fixunsxfdi				*	jra __fixunsxfdi
_?L8:							*.L8:
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
	fmove.x fp0,-(sp)				*	fmove.x %fp0,-(%sp)
	jbsr ___fixunsxfdi				*	jsr __fixunsxfdi
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
							*	.size	__fixxfdi, .-__fixxfdi
							*	.ident	"GCC: (GNU) 13.4.0"
