* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___bswapdi2				*	.globl	__bswapdi2
							*	.hidden	__bswapdi2
							*	.type	__bswapdi2, @function
___bswapdi2:						*__bswapdi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	ror.w #8,d1					*	ror.w #8,%d1
	swap d1						*	swap %d1
	ror.w #8,d1					*	ror.w #8,%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	ror.w #8,d0					*	ror.w #8,%d0
	swap d0						*	swap %d0
	ror.w #8,d0					*	ror.w #8,%d0
	rts						*	rts
							*	.size	__bswapdi2, .-__bswapdi2
							*	.ident	"GCC: (GNU) 13.4.0"
