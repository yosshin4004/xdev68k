* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___floatundixf				*	.globl	__floatundixf
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC1:							*.LC1:
	.dc.l	1071579136				*	.long	1071579136
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC2:							*.LC2:
	.dc.l	1075707904				*	.long	1075707904
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsxfdi				*	.globl	__fixunsxfdi
							*	.hidden	__fixunsxfdi
							*	.type	__fixunsxfdi, @function
___fixunsxfdi:						*__fixunsxfdi:
	fmovem fp2/fp3/fp5,-(sp)			*	fmovem #44,-(%sp)
	movem.l d4/d5/d6/d7/a4/a5,-(sp)			*	movem.l #3852,-(%sp)
	fmove.x 64(sp),fp2				*	fmove.x 64(%sp),%fp2
	fmove.x _?LC0,fp5				*	fmove.x .LC0,%fp5
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fblt _?L11					*	fjlt .L11
	fmove.x fp2,fp0					*	fmove.x %fp2,%fp0
	fmul.x _?LC1,fp0				*	fmul.x .LC1,%fp0
	fmove.x _?LC2,fp3				*	fmove.x .LC2,%fp3
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbnge _?L16					*	fjnge .L16
	fsub.x fp3,fp0					*	fsub.x %fp3,%fp0
	fintrz.x fp0,fp0				*	fintrz.x %fp0,%fp0
	fmove.l fp0,d0					*	fmove.l %fp0,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l d0,d6					*	move.l %d0,%d6
	clr.l d7					*	clr.l %d7
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___floatundixf				*	jsr __floatundixf
	addq.l #8,sp					*	addq.l #8,%sp
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fblt _?L17					*	fjlt .L17
_?L13:							*.L13:
	fcmp.x fp3,fp2					*	fcmp.x %fp3,%fp2
	fbge _?L9					*	fjge .L9
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	move.l d0,d5					*	move.l %d0,%d5
	clr.l d4					*	clr.l %d4
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	add.l d7,d1					*	add.l %d7,%d1
	addx.l d6,d0					*	addx.l %d6,%d0
_?L1:							*.L1:
	movem.l (sp)+,d4/d5/d6/d7/a4/a5			*	movem.l (%sp)+,#12528
	fmovem (sp)+,fp2/fp3/fp5			*	fmovem (%sp)+,#52
	rts						*	rts
_?L16:							*.L16:
	fintrz.x fp0,fp0				*	fintrz.x %fp0,%fp0
	fmove.l fp0,d0					*	fmove.l %fp0,%d0
	move.l d0,d6					*	move.l %d0,%d6
	clr.l d7					*	clr.l %d7
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___floatundixf				*	jsr __floatundixf
	addq.l #8,sp					*	addq.l #8,%sp
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fbnlt _?L13					*	fjnlt .L13
_?L17:							*.L17:
	fneg.x fp2,fp2					*	fneg.x %fp2,%fp2
	fcmp.x fp3,fp2					*	fcmp.x %fp3,%fp2
	fbnge _?L18					*	fjnge .L18
	fsub.x fp3,fp2					*	fsub.x %fp3,%fp2
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l d0,a5					*	move.l %d0,%a5
	sub.l a4,a4					*	sub.l %a4,%a4
	move.l d6,d0					*	move.l %d6,%d0
	move.l d7,d1					*	move.l %d7,%d1
	move.l a4,d2					*	move.l %a4,%d2
	sub.l a5,d1					*	sub.l %a5,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
_?L19:							*.L19:
	movem.l (sp)+,d4/d5/d6/d7/a4/a5			*	movem.l (%sp)+,#12528
	fmovem (sp)+,fp2/fp3/fp5			*	fmovem (%sp)+,#52
	rts						*	rts
_?L11:							*.L11:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	movem.l (sp)+,d4/d5/d6/d7/a4/a5			*	movem.l (%sp)+,#12528
	fmovem (sp)+,fp2/fp3/fp5			*	fmovem (%sp)+,#52
	rts						*	rts
_?L9:							*.L9:
	fsub.x fp3,fp2					*	fsub.x %fp3,%fp2
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	move.l d0,d5					*	move.l %d0,%d5
	clr.l d4					*	clr.l %d4
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	add.l d7,d1					*	add.l %d7,%d1
	addx.l d6,d0					*	addx.l %d6,%d0
	jbra _?L1					*	jra .L1
_?L18:							*.L18:
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	move.l d0,a5					*	move.l %d0,%a5
	sub.l a4,a4					*	sub.l %a4,%a4
	move.l d6,d0					*	move.l %d6,%d0
	move.l d7,d1					*	move.l %d7,%d1
	move.l a4,d2					*	move.l %a4,%d2
	sub.l a5,d1					*	sub.l %a5,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
	jbra _?L19					*	jra .L19
							*	.size	__fixunsxfdi, .-__fixunsxfdi
							*	.ident	"GCC: (GNU) 13.4.0"
