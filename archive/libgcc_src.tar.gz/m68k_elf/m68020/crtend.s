* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"crtstuff.c"				*	.file	"crtstuff.c"
	.text						*	.text
							*	.section	.ctors,"aw"
	.align	2					*	.align	2
							*	.type	__CTOR_END__, @object
___CTOR_END__:						*__CTOR_END__:
	.ds.b	4					*	.zero	4
							*	.hidden	__DTOR_END__
	.globl	___DTOR_END__				*	.globl	__DTOR_END__
							*	.section	.dtors,"aw"
	.align	2					*	.align	2
							*	.type	__DTOR_END__, @object
___DTOR_END__:						*__DTOR_END__:
	.ds.b	4					*	.zero	4
							*	.section	.eh_frame,"a"
	.align	2					*	.align	2
							*	.type	__FRAME_END__, @object
___FRAME_END__:						*__FRAME_END__:
	.ds.b	4					*	.zero	4
							*	.hidden	__TMC_END__
	.globl	___TMC_END__				*	.globl	__TMC_END__
							*	.section	.tm_clone_table,"aw"
	.align	2					*	.align	2
							*	.type	__TMC_END__, @object
___TMC_END__:						*__TMC_END__:
	.text						*	.text
	.align	2					*	.align	2
							*	.type	__do_global_ctors_aux, @function
___do_global_ctors_aux:					*__do_global_ctors_aux:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l ___CTOR_END__-4,a0			*	move.l __CTOR_END__-4,%a0
	moveq #-1,d0					*	moveq #-1,%d0
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbeq _?L1					*	jeq .L1
	lea ___CTOR_END__-4,a3				*	lea __CTOR_END__-4,%a3
_?L3:							*.L3:
	jbsr (a0)					*	jsr (%a0)
	move.l -(a3),a0					*	move.l -(%a3),%a0
	moveq #-1,d0					*	moveq #-1,%d0
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbne _?L3					*	jne .L3
_?L1:							*.L1:
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
	.align	2					*	.align	2
							*	.type	call___do_global_ctors_aux, @function
_call___do_global_ctors_aux:				*call___do_global_ctors_aux:
* APP ON (APP) asm_mode=gas				*#APP
							*| 701 "build_gcc/src/gcc-13.4.0/libgcc/crtstuff.c" 1
							*		.section	.init
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	jbsr ___do_global_ctors_aux			*	jsr __do_global_ctors_aux
* APP ON (APP) asm_mode=gas				*#APP
							*| 701 "build_gcc/src/gcc-13.4.0/libgcc/crtstuff.c" 1
		.text					*		.text
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	rts						*	rts
							*	.ident	"GCC: (GNU) 13.4.0"
