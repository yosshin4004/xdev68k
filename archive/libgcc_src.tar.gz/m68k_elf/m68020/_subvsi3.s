* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___subvsi3				*	.globl	__subvsi3
							*	.hidden	__subvsi3
							*	.type	__subvsi3, @function
___subvsi3:						*__subvsi3:
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	sub.l d1,d0					*	sub.l %d1,%d0
	move.l 4(sp),d2					*	move.l 4(%sp),%d2
	eor.l d1,d2					*	eor.l %d1,%d2
	eor.l d0,d1					*	eor.l %d0,%d1
	not.l d1					*	not.l %d1
	and.l d2,d1					*	and.l %d2,%d1
	jbmi _?L7					*	jmi .L7
	rts						*	rts
_?L7:							*.L7:
	trap #7						*	trap #7
							*	.size	__subvsi3, .-__subvsi3
							*	.ident	"GCC: (GNU) 13.4.0"
