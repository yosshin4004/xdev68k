* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"unwind-dw2.c"				*	.file	"unwind-dw2.c"
	.text						*	.text
	.align	2					*	.align	2
							*	.type	uw_install_context_1, @function
_uw_install_context_1:					*uw_install_context_1:
	lea (-12,sp),sp					*	lea (-12,%sp),%sp
	movem.l d3/d4/a3/a4/a5/a6,-(sp)			*	movem.l #6174,-(%sp)
	move.l 40(sp),d4				*	move.l 40(%sp),%d4
	move.l 44(sp),d3				*	move.l 44(%sp),%d3
	move.l d3,a0					*	move.l %d3,%a0
	move.l 128(a0),d0				*	move.l 128(%a0),%d0
	and.l #1073741824,d0				*	and.l #1073741824,%d0
	jbeq _?L2					*	jeq .L2
	tst.b 155(a0)					*	tst.b 155(%a0)
	jbne _?L3					*	jne .L3
_?L2:							*.L2:
	move.l d3,a1					*	move.l %d3,%a1
	tst.l 60(a1)					*	tst.l 60(%a1)
	jbeq _?L37					*	jeq .L37
_?L3:							*.L3:
	move.l d4,a1					*	move.l %d4,%a1
	move.l d3,a6					*	move.l %d3,%a6
	lea (140,a1),a5					*	lea (140,%a1),%a5
	lea _dwarf_reg_size_table,a3			*	lea dwarf_reg_size_table,%a3
	lea (140,a6),a4					*	lea (140,%a6),%a4
_?L9:							*.L9:
	move.l (a1)+,a0					*	move.l (%a1)+,%a0
	move.l (a6)+,d0					*	move.l (%a6)+,%d0
	tst.b (a5)+					*	tst.b (%a5)+
	jbne _?L4					*	jne .L4
	tst.b (a4)+					*	tst.b (%a4)+
	jbeq _?L7					*	jeq .L7
	tst.l a0					*	tst.l %a0
	jbeq _?L8					*	jeq .L8
	cmp.b #4,(a3)					*	cmp.b #4,(%a3)
	jbne _?L4					*	jne .L4
	move.l d0,32(sp)				*	move.l %d0,32(%sp)
	move.b 32(sp),(a0)+				*	move.b 32(%sp),(%a0)+
	move.b 33(sp),(a0)+				*	move.b 33(%sp),(%a0)+
	move.b 34(sp),(a0)+				*	move.b 34(%sp),(%a0)+
	move.b 35(sp),(a0)				*	move.b 35(%sp),(%a0)
_?L8:							*.L8:
	addq.l #1,a3					*	addq.l #1,%a3
	cmp.l #_dwarf_reg_size_table+25,a3		*	cmp.l #dwarf_reg_size_table+25,%a3
	jbne _?L9					*	jne .L9
_?L39:							*.L39:
	move.l d4,a1					*	move.l %d4,%a1
	clr.l d0					*	clr.l %d0
	btst #6,128(a1)					*	btst #6,128(%a1)
	jbeq _?L10					*	jeq .L10
	tst.b 155(a1)					*	tst.b 155(%a1)
	jbne _?L1					*	jne .L1
_?L10:							*.L10:
	move.l d4,a0					*	move.l %d4,%a0
	tst.l 60(a0)					*	tst.l 60(%a0)
	jbeq _?L38					*	jeq .L38
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/a3/a4/a5/a6			*	movem.l (%sp)+,#30744
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
_?L7:							*.L7:
	tst.l d0					*	tst.l %d0
	jbeq _?L8					*	jeq .L8
	tst.l a0					*	tst.l %a0
	jbeq _?L8					*	jeq .L8
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbeq _?L8					*	jeq .L8
	clr.l d1					*	clr.l %d1
	move.b (a3),d1					*	move.b (%a3),%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a1,36(sp)				*	move.l %a1,36(%sp)
	jbsr _memcpy					*	jsr memcpy
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l 24(sp),a1				*	move.l 24(%sp),%a1
	addq.l #1,a3					*	addq.l #1,%a3
	cmp.l #_dwarf_reg_size_table+25,a3		*	cmp.l #dwarf_reg_size_table+25,%a3
	jbne _?L9					*	jne .L9
	jbra _?L39					*	jra .L39
_?L37:							*.L37:
	move.l 104(a1),d1				*	move.l 104(%a1),%d1
	cmp.b #4,_dwarf_reg_size_table+15		*	cmp.b #4,dwarf_reg_size_table+15
	jbne _?L4					*	jne .L4
	move.l d1,28(sp)				*	move.l %d1,28(%sp)
	tst.l d0					*	tst.l %d0
	jbeq _?L6					*	jeq .L6
	clr.b 155(a1)					*	clr.b 155(%a1)
_?L6:							*.L6:
	moveq #28,d0					*	moveq #28,%d0
	add.l sp,d0					*	add.l %sp,%d0
	move.l d3,a0					*	move.l %d3,%a0
	move.l d0,60(a0)				*	move.l %d0,60(%a0)
	move.l d4,a1					*	move.l %d4,%a1
	move.l d3,a6					*	move.l %d3,%a6
	lea (140,a1),a5					*	lea (140,%a1),%a5
	lea _dwarf_reg_size_table,a3			*	lea dwarf_reg_size_table,%a3
	lea (140,a6),a4					*	lea (140,%a6),%a4
	jbra _?L9					*	jra .L9
_?L38:							*.L38:
	move.b _dwarf_reg_size_table+15,d0		*	move.b dwarf_reg_size_table+15,%d0
	move.l d3,a1					*	move.l %d3,%a1
	move.l 60(a1),a0				*	move.l 60(%a1),%a0
	btst #6,128(a1)					*	btst #6,128(%a1)
	jbeq _?L12					*	jeq .L12
	tst.b 155(a1)					*	tst.b 155(%a1)
	jbne _?L13					*	jne .L13
_?L12:							*.L12:
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbne _?L4					*	jne .L4
	move.l (a0),a0					*	move.l (%a0),%a0
_?L13:							*.L13:
	move.l d4,a1					*	move.l %d4,%a1
	sub.l 104(a1),a0				*	sub.l 104(%a1),%a0
	move.l a0,d0					*	move.l %a0,%d0
	move.l d3,a1					*	move.l %d3,%a1
	add.l 136(a1),d0				*	add.l 136(%a1),%d0
	movem.l (sp)+,d3/d4/a3/a4/a5/a6			*	movem.l (%sp)+,#30744
	lea (12,sp),sp					*	lea (12,%sp),%sp
	rts						*	rts
_?L4:							*.L4:
	trap #7						*	trap #7
							*	.size	uw_install_context_1, .-uw_install_context_1
	.align	2					*	.align	2
							*	.type	read_encoded_value, @function
_read_encoded_value:					*read_encoded_value:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	move.l 24(sp),a1				*	move.l 24(%sp),%a1
	move.b d0,d3					*	move.b %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L41					*	jeq .L41
	move.b d0,d2					*	move.b %d0,%d2
	and.b #112,d2					*	and.b #112,%d2
	cmp.b #48,d2					*	cmp.b #48,%d2
	jbeq _?L42					*	jeq .L42
	jbhi _?L43					*	jhi .L43
	cmp.b #32,d2					*	cmp.b #32,%d2
	jbne _?L80					*	jne .L80
	move.l 16(sp),a0				*	move.l 16(%sp),%a0
	move.l 116(a0),a2				*	move.l 116(%a0),%a2
_?L45:							*.L45:
	cmp.b #80,d3					*	cmp.b #80,%d3
	jbeq _?L81					*	jeq .L81
_?L47:							*.L47:
	and.b #15,d0					*	and.b #15,%d0
	cmp.b #12,d0					*	cmp.b #12,%d0
	jbhi _?L41					*	jhi .L41
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w _?L50(pc,d0.l),d0			*	move.w .L50(%pc,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&13
_?L50:							*.L50:
	.dc.w _?L51-_?L50				*	.word .L51-.L50
	.dc.w _?L63-_?L50				*	.word .L63-.L50
	.dc.w _?L56-_?L50				*	.word .L56-.L50
	.dc.w _?L51-_?L50				*	.word .L51-.L50
	.dc.w _?L49-_?L50				*	.word .L49-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L41-_?L50				*	.word .L41-.L50
	.dc.w _?L64-_?L50				*	.word .L64-.L50
	.dc.w _?L52-_?L50				*	.word .L52-.L50
	.dc.w _?L51-_?L50				*	.word .L51-.L50
	.dc.w _?L49-_?L50				*	.word .L49-.L50
_?L43:							*.L43:
	cmp.b #64,d2					*	cmp.b #64,%d2
	jbne _?L82					*	jne .L82
	move.l 16(sp),a0				*	move.l 16(%sp),%a0
	move.l 124(a0),a2				*	move.l 124(%a0),%a2
	cmp.b #80,d3					*	cmp.b #80,%d3
	jbne _?L47					*	jne .L47
_?L81:							*.L81:
	lea (3,a1),a0					*	lea (3,%a1),%a0
	move.l a0,d0					*	move.l %a0,%d0
	moveq #-4,d1					*	moveq #-4,%d1
	and.l d1,d0					*	and.l %d1,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.l (a0)+,d1					*	move.l (%a0)+,%d1
_?L48:							*.L48:
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L51:							*.L51:
	clr.l d1					*	clr.l %d1
	move.b (a1),d1					*	move.b (%a1),%d1
	moveq #24,d0					*	moveq #24,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 3(a1),d1					*	or.b 3(%a1),%d1
	lea (4,a1),a0					*	lea (4,%a1),%a0
_?L59:							*.L59:
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
_?L60:							*.L60:
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbeq _?L83					*	jeq .L83
_?L61:							*.L61:
	add.l a2,d1					*	add.l %a2,%d1
	tst.b d3					*	tst.b %d3
	jbge _?L48					*	jge .L48
	move.l d1,a1					*	move.l %d1,%a1
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L80:							*.L80:
	cmp.b #32,d2					*	cmp.b #32,%d2
	jbhi _?L41					*	jhi .L41
	sub.l a2,a2					*	sub.l %a2,%a2
	jbra _?L45					*	jra .L45
_?L83:							*.L83:
	move.l a1,a2					*	move.l %a1,%a2
	jbra _?L61					*	jra .L61
_?L49:							*.L49:
	clr.l d1					*	clr.l %d1
	move.b 4(a1),d1					*	move.b 4(%a1),%d1
	moveq #24,d0					*	moveq #24,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 5(a1),d0					*	move.b 5(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 6(a1),d1					*	move.b 6(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 7(a1),d1					*	or.b 7(%a1),%d1
	lea (8,a1),a0					*	lea (8,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
	jbra _?L60					*	jra .L60
_?L82:							*.L82:
	sub.l a2,a2					*	sub.l %a2,%a2
	cmp.b #80,d2					*	cmp.b #80,%d2
	jbeq _?L45					*	jeq .L45
_?L41:							*.L41:
	trap #7						*	trap #7
_?L52:							*.L52:
	clr.l d1					*	clr.l %d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	ext.l d1					*	ext.l %d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
	jbra _?L60					*	jra .L60
_?L56:							*.L56:
	clr.l d1					*	clr.l %d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L48					*	jeq .L48
	jbra _?L60					*	jra .L60
_?L63:							*.L63:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d1					*	clr.l %d1
	clr.l d4					*	clr.l %d4
_?L57:							*.L57:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jbge _?L59					*	jge .L59
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L57					*	jlt .L57
	jbra _?L59					*	jra .L59
_?L64:							*.L64:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d1					*	clr.l %d1
	clr.l d4					*	clr.l %d4
_?L53:							*.L53:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L53					*	jlt .L53
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L59					*	jcs .L59
	btst #6,d5					*	btst #6,%d5
	jbeq _?L59					*	jeq .L59
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbne _?L61					*	jne .L61
	jbra _?L83					*	jra .L83
_?L42:							*.L42:
	move.l 16(sp),a0				*	move.l 16(%sp),%a0
	move.l 120(a0),a2				*	move.l 120(%a0),%a2
	jbra _?L45					*	jra .L45
							*	.size	read_encoded_value, .-read_encoded_value
	.align	2					*	.align	2
							*	.type	execute_stack_op, @function
_execute_stack_op:					*execute_stack_op:
	link.w a6,#-260					*	link.w %fp,#-260
	movem.l d3/d4/d5/d6/a3/a4/a5,-(sp)		*	movem.l #7708,-(%sp)
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 12(a6),d3				*	move.l 12(%fp),%d3
	move.l 16(a6),a4				*	move.l 16(%fp),%a4
	move.l 20(a6),-256(a6)				*	move.l 20(%fp),-256(%fp)
	cmp.l a0,d3					*	cmp.l %a0,%d3
	jbls _?L167					*	jls .L167
	moveq #1,d4					*	moveq #1,%d4
	move.l #_?L90,a5				*	move.l #.L90,%a5
	move.l #_?L103,a3				*	move.l #.L103,%a3
_?L166:							*.L166:
	move.l a0,a1					*	move.l %a0,%a1
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	cmp.b #22,d1					*	cmp.b #22,%d1
	jbhi _?L86					*	jhi .L86
	cmp.b #2,d1					*	cmp.b #2,%d1
	jbls _?L88					*	jls .L88
	subq.b #3,d1					*	subq.b #3,%d1
	cmp.b #19,d1					*	cmp.b #19,%d1
	jbhi _?L88					*	jhi .L88
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w (a3,d1.l),d0				*	move.w (%a3,%d1.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&20
_?L103:							*.L103:
	.dc.w _?L112-_?L103				*	.word .L112-.L103
	.dc.w _?L88-_?L103				*	.word .L88-.L103
	.dc.w _?L88-_?L103				*	.word .L88-.L103
	.dc.w _?L118-_?L103				*	.word .L118-.L103
	.dc.w _?L88-_?L103				*	.word .L88-.L103
	.dc.w _?L117-_?L103				*	.word .L117-.L103
	.dc.w _?L116-_?L103				*	.word .L116-.L103
	.dc.w _?L115-_?L103				*	.word .L115-.L103
	.dc.w _?L114-_?L103				*	.word .L114-.L103
	.dc.w _?L112-_?L103				*	.word .L112-.L103
	.dc.w _?L112-_?L103				*	.word .L112-.L103
	.dc.w _?L110-_?L103				*	.word .L110-.L103
	.dc.w _?L110-_?L103				*	.word .L110-.L103
	.dc.w _?L171-_?L103				*	.word .L171-.L103
	.dc.w _?L172-_?L103				*	.word .L172-.L103
	.dc.w _?L107-_?L103				*	.word .L107-.L103
	.dc.w _?L106-_?L103				*	.word .L106-.L103
	.dc.w _?L105-_?L103				*	.word .L105-.L103
	.dc.w _?L104-_?L103				*	.word .L104-.L103
	.dc.w _?L102-_?L103				*	.word .L102-.L103
_?L112:							*.L112:
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	moveq #24,d1					*	moveq #24,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 2(a0),d1					*	move.b 2(%a0),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 3(a0),d0					*	move.b 3(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 4(a0),d0					*	or.b 4(%a0),%d0
	addq.l #5,a0					*	addq.l #5,%a0
	move.l d4,d2					*	move.l %d4,%d2
_?L125:							*.L125:
	moveq #63,d1					*	moveq #63,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L88					*	jcs .L88
	move.l d2,d4					*	move.l %d2,%d4
	addq.l #1,d4					*	addq.l #1,%d4
	move.l d0,-256(a6,d2.l*4)			*	move.l %d0,-256(%fp,%d2.l*4)
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbcs _?L166					*	jcs .L166
_?L231:							*.L231:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	move.l -260(a6,d4.l*4),d0			*	move.l -260(%fp,%d4.l*4),%d0
	movem.l -288(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -288(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L110:							*.L110:
	clr.l d0					*	clr.l %d0
	move.b 5(a0),d0					*	move.b 5(%a0),%d0
	moveq #24,d1					*	moveq #24,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 6(a0),d1					*	move.b 6(%a0),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 7(a0),d0					*	move.b 7(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 8(a0),d0					*	or.b 8(%a0),%d0
	lea (9,a0),a0					*	lea (9,%a0),%a0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L86:							*.L86:
	cmp.b #-106,d1					*	cmp.b #-106,%d1
	jbhi _?L120					*	jhi .L120
	cmp.b #35,d1					*	cmp.b #35,%d1
	jbls _?L230					*	jls .L230
	clr.l d5					*	clr.l %d5
	move.b d1,d5					*	move.b %d1,%d5
	move.b d1,d0					*	move.b %d1,%d0
	add.b #-36,d0					*	add.b #-36,%d0
	cmp.b #114,d0					*	cmp.b #114,%d0
	jbhi _?L88					*	jhi .L88
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w (a5,d0.l),d0				*	move.w (%a5,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&115
_?L90:							*.L90:
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L99-_?L90				*	.word .L99-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L98-_?L90				*	.word .L98-.L90
	.dc.w _?L97-_?L90				*	.word .L97-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L96-_?L90				*	.word .L96-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L95-_?L90				*	.word .L95-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L168-_?L90				*	.word .L168-.L90
	.dc.w _?L169-_?L90				*	.word .L169-.L90
	.dc.w _?L88-_?L90				*	.word .L88-.L90
	.dc.w _?L170-_?L90				*	.word .L170-.L90
	.dc.w _?L88-_?L90				*	.word .L88-.L90
	.dc.w _?L91-_?L90				*	.word .L91-.L90
	.dc.w _?L88-_?L90				*	.word .L88-.L90
	.dc.w _?L177-_?L90				*	.word .L177-.L90
_?L168:							*.L168:
	clr.l d0					*	clr.l %d0
	clr.l d2					*	clr.l %d2
_?L94:							*.L94:
	move.b (a1)+,d6					*	move.b (%a1)+,%d6
	moveq #127,d1					*	moveq #127,%d1
	and.l d6,d1					*	and.l %d6,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d6					*	tst.b %d6
	jblt _?L94					*	jlt .L94
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L130					*	jcs .L130
	btst #6,d6					*	btst #6,%d6
	jbeq _?L130					*	jeq .L130
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
_?L130:							*.L130:
	move.w #-112,a0					*	move.w #-112,%a0
	add.l d5,a0					*	add.l %d5,%a0
	moveq #25,d1					*	moveq #25,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbcs _?L88					*	jcs .L88
	move.b _dwarf_reg_size_table(a0),d1		*	move.b dwarf_reg_size_table(%a0),%d1
	move.l (a4,a0.l*4),a2				*	move.l (%a4,%a0.l*4),%a2
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L131					*	jeq .L131
	tst.b 140(a4,a0.l)				*	tst.b 140(%a4,%a0.l)
	jbeq _?L131					*	jeq .L131
	move.l a2,d1					*	move.l %a2,%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L230:							*.L230:
	move.b d1,d2					*	move.b %d1,%d2
	add.b #-23,d2					*	add.b #-23,%d2
	and.l #255,d2					*	and.l #255,%d2
	moveq #1,d0					*	moveq #1,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	move.l d0,d5					*	move.l %d0,%d5
	and.l #3320,d5					*	and.l #3320,%d5
	jbne _?L98					*	jne .L98
	move.l d0,d2					*	move.l %d0,%d2
	and.l #4868,d2					*	and.l #4868,%d2
	jbne _?L100					*	jne .L100
	btst #0,d0					*	btst #0,%d0
	jbeq _?L88					*	jeq .L88
	moveq #2,d0					*	moveq #2,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbge _?L88					*	jge .L88
	move.l d4,a0					*	move.l %d4,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	move.l -256(a6,a0.l*4),d2			*	move.l -256(%fp,%a0.l*4),%d2
	move.l d4,d1					*	move.l %d4,%d1
	subq.l #3,d1					*	subq.l #3,%d1
	move.l -256(a6,d1.l*4),d5			*	move.l -256(%fp,%d1.l*4),%d5
	move.l d4,d0					*	move.l %d4,%d0
	subq.l #2,d0					*	subq.l #2,%d0
	move.l -256(a6,d0.l*4),-256(a6,a0.l*4)		*	move.l -256(%fp,%d0.l*4),-256(%fp,%a0.l*4)
	move.l d5,-256(a6,d0.l*4)			*	move.l %d5,-256(%fp,%d0.l*4)
	move.l d2,-256(a6,d1.l*4)			*	move.l %d2,-256(%fp,%d1.l*4)
	move.l a1,a0					*	move.l %a1,%a0
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbcs _?L166					*	jcs .L166
	jbra _?L231					*	jra .L231
_?L95:							*.L95:
	move.w #-80,a0					*	move.w #-80,%a0
	add.l d5,a0					*	add.l %d5,%a0
	moveq #25,d0					*	moveq #25,%d0
	cmp.l a0,d0					*	cmp.l %a0,%d0
	jbcs _?L88					*	jcs .L88
	move.b _dwarf_reg_size_table(a0),d0		*	move.b dwarf_reg_size_table(%a0),%d0
	move.l (a4,a0.l*4),a2				*	move.l (%a4,%a0.l*4),%a2
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L127					*	jeq .L127
	tst.b 140(a4,a0.l)				*	tst.b 140(%a4,%a0.l)
	jbeq _?L127					*	jeq .L127
	move.l a2,d0					*	move.l %a2,%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L96:							*.L96:
	moveq #-48,d0					*	moveq #-48,%d0
	add.l d5,d0					*	add.l %d5,%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L106:							*.L106:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	subq.l #1,d4					*	subq.l #1,%d4
	move.l a1,a0					*	move.l %a1,%a0
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbcs _?L166					*	jcs .L166
	jbra _?L231					*	jra .L231
_?L105:							*.L105:
	moveq #1,d0					*	moveq #1,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbge _?L88					*	jge .L88
	move.l -264(a6,d4.l*4),d0			*	move.l -264(%fp,%d4.l*4),%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L104:							*.L104:
	lea (2,a0),a1					*	lea (2,%a0),%a1
	clr.l d1					*	clr.l %d1
	move.b 1(a0),d1					*	move.b 1(%a0),%d1
	move.l d4,d0					*	move.l %d4,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jble _?L88					*	jle .L88
	sub.l d1,d0					*	sub.l %d1,%d0
	move.l -256(a6,d0.l*4),d0			*	move.l -256(%fp,%d0.l*4),%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L114:							*.L114:
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a0),d0					*	or.b 2(%a0),%d0
	ext.l d0					*	ext.l %d0
	addq.l #3,a0					*	addq.l #3,%a0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L115:							*.L115:
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a0),d0					*	or.b 2(%a0),%d0
	addq.l #3,a0					*	addq.l #3,%a0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L116:							*.L116:
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	extb.l d0					*	extb.l %d0
	addq.l #2,a0					*	addq.l #2,%a0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L117:							*.L117:
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	addq.l #2,a0					*	addq.l #2,%a0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L102:							*.L102:
	moveq #1,d1					*	moveq #1,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbge _?L88					*	jge .L88
	move.l d4,d1					*	move.l %d4,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	move.l -256(a6,d1.l*4),a0			*	move.l -256(%fp,%d1.l*4),%a0
	move.l d4,d0					*	move.l %d4,%d0
	subq.l #2,d0					*	subq.l #2,%d0
	move.l -256(a6,d0.l*4),-256(a6,d1.l*4)		*	move.l -256(%fp,%d0.l*4),-256(%fp,%d1.l*4)
	move.l a0,-256(a6,d0.l*4)			*	move.l %a0,-256(%fp,%d0.l*4)
_?L177:							*.L177:
	move.l a1,a0					*	move.l %a1,%a0
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbcs _?L166					*	jcs .L166
	jbra _?L231					*	jra .L231
_?L107:							*.L107:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	move.l -260(a6,d4.l*4),d0			*	move.l -260(%fp,%d4.l*4),%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L172:							*.L172:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d0					*	clr.l %d0
	clr.l d2					*	clr.l %d2
_?L108:							*.L108:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d1					*	moveq #127,%d1
	and.l d5,d1					*	and.l %d5,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d5					*	tst.b %d5
	jblt _?L108					*	jlt .L108
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L174					*	jcs .L174
	btst #6,d5					*	btst #6,%d5
	jbeq _?L174					*	jeq .L174
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L171:							*.L171:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d0					*	clr.l %d0
	clr.l d2					*	clr.l %d2
_?L109:							*.L109:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d1					*	moveq #127,%d1
	and.l d5,d1					*	and.l %d5,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d5					*	tst.b %d5
	jblt _?L109					*	jlt .L109
_?L174:							*.L174:
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L118:							*.L118:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	move.l d4,d2					*	move.l %d4,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	move.l -256(a6,d2.l*4),a0			*	move.l -256(%fp,%d2.l*4),%a0
	clr.l d0					*	clr.l %d0
	move.b (a0),d0					*	move.b (%a0),%d0
	moveq #24,d1					*	moveq #24,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 1(a0),d1					*	move.b 1(%a0),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 2(a0),d0					*	move.b 2(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 3(a0),d0					*	or.b 3(%a0),%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L98:							*.L98:
	moveq #1,d0					*	moveq #1,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbge _?L88					*	jge .L88
	move.l d4,d2					*	move.l %d4,%d2
	subq.l #2,d2					*	subq.l #2,%d2
	move.l -256(a6,d2.l*4),d0			*	move.l -256(%fp,%d2.l*4),%d0
	move.l -260(a6,d4.l*4),d4			*	move.l -260(%fp,%d4.l*4),%d4
	add.b #-26,d1					*	add.b #-26,%d1
	cmp.b #20,d1					*	cmp.b #20,%d1
	jbhi _?L88					*	jhi .L88
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w _?L149(pc,d1.l),d1			*	move.w .L149(%pc,%d1.l),%d1
	jmp 2(pc,d1.w)					*	jmp %pc@(2,%d1:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&21
_?L149:							*.L149:
	.dc.w _?L165-_?L149				*	.word .L165-.L149
	.dc.w _?L164-_?L149				*	.word .L164-.L149
	.dc.w _?L163-_?L149				*	.word .L163-.L149
	.dc.w _?L162-_?L149				*	.word .L162-.L149
	.dc.w _?L161-_?L149				*	.word .L161-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L160-_?L149				*	.word .L160-.L149
	.dc.w _?L159-_?L149				*	.word .L159-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L158-_?L149				*	.word .L158-.L149
	.dc.w _?L157-_?L149				*	.word .L157-.L149
	.dc.w _?L156-_?L149				*	.word .L156-.L149
	.dc.w _?L155-_?L149				*	.word .L155-.L149
	.dc.w _?L88-_?L149				*	.word .L88-.L149
	.dc.w _?L154-_?L149				*	.word .L154-.L149
	.dc.w _?L153-_?L149				*	.word .L153-.L149
	.dc.w _?L152-_?L149				*	.word .L152-.L149
	.dc.w _?L151-_?L149				*	.word .L151-.L149
	.dc.w _?L150-_?L149				*	.word .L150-.L149
	.dc.w _?L148-_?L149				*	.word .L148-.L149
_?L97:							*.L97:
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a0),d0					*	or.b 2(%a0),%d0
	ext.l d0					*	ext.l %d0
	lea 3(a0,d0.l),a0				*	lea 3(%a0,%d0.l),%a0
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbcs _?L166					*	jcs .L166
	jbra _?L231					*	jra .L231
_?L99:							*.L99:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	subq.l #1,d4					*	subq.l #1,%d4
	lea (3,a0),a1					*	lea (3,%a0),%a1
	tst.l -256(a6,d4.l*4)				*	tst.l -256(%fp,%d4.l*4)
	jbeq _?L177					*	jeq .L177
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a0),d0					*	or.b 2(%a0),%d0
	ext.l d0					*	ext.l %d0
	lea (a1,d0.l),a0				*	lea (%a1,%d0.l),%a0
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbcs _?L166					*	jcs .L166
	jbra _?L231					*	jra .L231
_?L120:							*.L120:
	cmp.b #-15,d1					*	cmp.b #-15,%d1
	jbne _?L88					*	jne .L88
	clr.l d0					*	clr.l %d0
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	pea -260(a6)					*	pea -260(%fp)
	pea 2(a0)					*	pea 2(%a0)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a0					*	move.l %d0,%a0
	move.l -260(a6),d0				*	move.l -260(%fp),%d0
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L127:							*.L127:
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbne _?L88					*	jne .L88
	move.l (a2),d0					*	move.l (%a2),%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L131:							*.L131:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L88					*	jne .L88
	move.l (a2),d1					*	move.l (%a2),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d4,d2					*	move.l %d4,%d2
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L167:							*.L167:
	move.l 20(a6),d0				*	move.l 20(%fp),%d0
	movem.l -288(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -288(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L169:							*.L169:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d5					*	clr.l %d5
	clr.l d1					*	clr.l %d1
_?L93:							*.L93:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L93					*	jlt .L93
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jblt _?L88					*	jlt .L88
	move.b _dwarf_reg_size_table(d5.l),d0		*	move.b dwarf_reg_size_table(%d5.l),%d0
	move.l (a4,d5.l*4),a1				*	move.l (%a4,%d5.l*4),%a1
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L129					*	jeq .L129
	tst.b 140(a4,d5.l)				*	tst.b 140(%a4,%d5.l)
	jbeq _?L129					*	jeq .L129
	move.l a1,d0					*	move.l %a1,%d0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L91:							*.L91:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	move.l d4,d2					*	move.l %d4,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	move.l -256(a6,d2.l*4),a1			*	move.l -256(%fp,%d2.l*4),%a1
	move.l a0,d1					*	move.l %a0,%d1
	addq.l #2,d1					*	addq.l #2,%d1
	move.b 1(a0),d0					*	move.b 1(%a0),%d0
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbeq _?L232					*	jeq .L232
	jbhi _?L144					*	jhi .L144
	cmp.b #1,d0					*	cmp.b #1,%d0
	jbeq _?L145					*	jeq .L145
	cmp.b #2,d0					*	cmp.b #2,%d0
	jbne _?L88					*	jne .L88
	clr.l d0					*	clr.l %d0
	move.b (a1),d0					*	move.b (%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 1(a1),d0					*	or.b 1(%a1),%d0
	move.l d1,a0					*	move.l %d1,%a0
	jbra _?L125					*	jra .L125
_?L170:							*.L170:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L92:							*.L92:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L92					*	jlt .L92
	clr.l d0					*	clr.l %d0
	clr.l d2					*	clr.l %d2
_?L133:							*.L133:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d1					*	moveq #127,%d1
	and.l d5,d1					*	and.l %d5,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d5					*	tst.b %d5
	jblt _?L133					*	jlt .L133
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L134					*	jcs .L134
	btst #6,d5					*	btst #6,%d5
	jbeq _?L134					*	jeq .L134
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
_?L134:							*.L134:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jblt _?L88					*	jlt .L88
	move.b _dwarf_reg_size_table(d6.l),d1		*	move.b dwarf_reg_size_table(%d6.l),%d1
	move.l (a4,d6.l*4),a1				*	move.l (%a4,%d6.l*4),%a1
	btst #6,128(a4)					*	btst #6,128(%a4)
	jbeq _?L135					*	jeq .L135
	tst.b 140(a4,d6.l)				*	tst.b 140(%a4,%d6.l)
	jbeq _?L135					*	jeq .L135
	move.l a1,d1					*	move.l %a1,%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L154:							*.L154:
	cmp.l d0,d4					*	cmp.l %d0,%d4
	seq d0						*	seq %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L148:							*.L148:
	cmp.l d0,d4					*	cmp.l %d0,%d4
	sne d0						*	sne %d0
	extb.l d0					*	extb.l %d0
_?L227:							*.L227:
	neg.l d0					*	neg.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L165:							*.L165:
	and.l d4,d0					*	and.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L164:							*.L164:
	divs.l d4,d0					*	divs.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L163:							*.L163:
	sub.l d4,d0					*	sub.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L162:							*.L162:
	move.l d0,d1					*	move.l %d0,%d1
	divul.l d4,d0:d1				*	divul.l %d4,%d0:%d1
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L153:							*.L153:
	cmp.l d0,d4					*	cmp.l %d0,%d4
	sle d0						*	sle %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L152:							*.L152:
	cmp.l d0,d4					*	cmp.l %d0,%d4
	slt d0						*	slt %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L151:							*.L151:
	cmp.l d0,d4					*	cmp.l %d0,%d4
	sge d0						*	sge %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L150:							*.L150:
	cmp.l d0,d4					*	cmp.l %d0,%d4
	sgt d0						*	sgt %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L161:							*.L161:
	muls.l d4,d0					*	muls.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L160:							*.L160:
	or.l d4,d0					*	or.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L159:							*.L159:
	add.l d4,d0					*	add.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L158:							*.L158:
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L157:							*.L157:
	lsr.l d4,d0					*	lsr.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L156:							*.L156:
	asr.l d4,d0					*	asr.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L155:							*.L155:
	eor.l d4,d0					*	eor.l %d4,%d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L135:							*.L135:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L88					*	jne .L88
	move.l (a1),d1					*	move.l (%a1),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L129:							*.L129:
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbne _?L88					*	jne .L88
	move.l (a1),d0					*	move.l (%a1),%d0
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L125					*	jra .L125
_?L100:							*.L100:
	tst.l d4					*	tst.l %d4
	jbeq _?L88					*	jeq .L88
	move.l d4,d2					*	move.l %d4,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	move.l -256(a6,d2.l*4),d0			*	move.l -256(%fp,%d2.l*4),%d0
	add.b #-25,d1					*	add.b #-25,%d1
	cmp.b #10,d1					*	cmp.b #10,%d1
	jbhi _?L88					*	jhi .L88
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w _?L140(pc,d1.l),d1			*	move.w .L140(%pc,%d1.l),%d1
	jmp 2(pc,d1.w)					*	jmp %pc@(2,%d1:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&11
_?L140:							*.L140:
	.dc.w _?L143-_?L140				*	.word .L143-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L227-_?L140				*	.word .L227-.L140
	.dc.w _?L141-_?L140				*	.word .L141-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L88-_?L140				*	.word .L88-.L140
	.dc.w _?L175-_?L140				*	.word .L175-.L140
_?L141:							*.L141:
	not.l d0					*	not.l %d0
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L143:							*.L143:
	tst.l d0					*	tst.l %d0
	jblt _?L227					*	jlt .L227
	move.l a1,a0					*	move.l %a1,%a0
	jbra _?L125					*	jra .L125
_?L175:							*.L175:
	clr.l d4					*	clr.l %d4
	move.l a1,a0					*	move.l %a1,%a0
_?L139:							*.L139:
	move.b (a0)+,d6					*	move.b (%a0)+,%d6
	moveq #127,d1					*	moveq #127,%d1
	and.l d6,d1					*	and.l %d6,%d1
	lsl.l d4,d1					*	lsl.l %d4,%d1
	or.l d1,d5					*	or.l %d1,%d5
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d6					*	tst.b %d6
	jblt _?L139					*	jlt .L139
	add.l d5,d0					*	add.l %d5,%d0
	jbra _?L125					*	jra .L125
_?L145:							*.L145:
	clr.l d0					*	clr.l %d0
	move.b (a1),d0					*	move.b (%a1),%d0
	move.l d1,a0					*	move.l %d1,%a0
	jbra _?L125					*	jra .L125
_?L144:							*.L144:
	cmp.b #8,d0					*	cmp.b #8,%d0
	jbne _?L88					*	jne .L88
	clr.l d0					*	clr.l %d0
	move.b 4(a1),d0					*	move.b 4(%a1),%d0
	moveq #24,d4					*	moveq #24,%d4
	lsl.l d4,d0					*	lsl.l %d4,%d0
	clr.l d4					*	clr.l %d4
	move.b 5(a1),d4					*	move.b 5(%a1),%d4
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.l d0,d4					*	or.l %d0,%d4
	clr.l d0					*	clr.l %d0
	move.b 6(a1),d0					*	move.b 6(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d4,d0					*	or.l %d4,%d0
	or.b 7(a1),d0					*	or.b 7(%a1),%d0
	move.l d1,a0					*	move.l %d1,%a0
	jbra _?L125					*	jra .L125
_?L232:							*.L232:
	clr.l d0					*	clr.l %d0
	move.b (a1),d0					*	move.b (%a1),%d0
	moveq #24,d4					*	moveq #24,%d4
	lsl.l d4,d0					*	lsl.l %d4,%d0
	clr.l d4					*	clr.l %d4
	move.b 1(a1),d4					*	move.b 1(%a1),%d4
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.l d0,d4					*	or.l %d0,%d4
	clr.l d0					*	clr.l %d0
	move.b 2(a1),d0					*	move.b 2(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d4,d0					*	or.l %d4,%d0
	or.b 3(a1),d0					*	or.b 3(%a1),%d0
	move.l d1,a0					*	move.l %d1,%a0
	jbra _?L125					*	jra .L125
_?L88:							*.L88:
	trap #7						*	trap #7
							*	.size	execute_stack_op, .-execute_stack_op
	.align	2					*	.align	2
							*	.type	uw_update_context_1, @function
_uw_update_context_1:					*uw_update_context_1:
	lea (-188,sp),sp				*	lea (-188,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 228(sp),a5				*	move.l 228(%sp),%a5
	move.l 232(sp),a6				*	move.l 232(%sp),%a6
	pea 166.w					*	pea 166.w
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	pea 66(sp)					*	pea 66(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l 198(sp),d0				*	move.l 198(%sp),%d0
	and.l #1073741824,d0				*	and.l #1073741824,%d0
	move.l d0,62(sp)				*	move.l %d0,62(%sp)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	jbeq _?L234					*	jeq .L234
	tst.b 213(sp)					*	tst.b 213(%sp)
	jbne _?L235					*	jne .L235
_?L234:							*.L234:
	tst.l 118(sp)					*	tst.l 118(%sp)
	jbeq _?L293					*	jeq .L293
_?L235:							*.L235:
	move.l 128(a5),46(sp)				*	move.l 128(%a5),46(%sp)
	move.l 46(sp),d1				*	move.l 46(%sp),%d1
	and.l #1073741824,d1				*	and.l #1073741824,%d1
	move.l d1,42(sp)				*	move.l %d1,42(%sp)
	btst #6,46(sp)					*	btst #6,46(%sp)
	jbeq _?L239					*	jeq .L239
	clr.b 155(a5)					*	clr.b 155(%a5)
_?L239:							*.L239:
	clr.l 60(a5)					*	clr.l 60(%a5)
	move.b 130(a6),d0				*	move.b 130(%a6),%d0
	cmp.b #1,d0					*	cmp.b #1,%d0
	jbeq _?L240					*	jeq .L240
	cmp.b #2,d0					*	cmp.b #2,%d0
	jbne _?L287					*	jne .L287
	move.l 144(a6),a0				*	move.l 144(%a6),%a0
	clr.l d3					*	clr.l %d3
	clr.l d1					*	clr.l %d1
_?L246:							*.L246:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L246					*	jlt .L246
	clr.l -(sp)					*	clr.l -(%sp)
	pea 62(sp)					*	pea 62(%sp)
	pea (a0,d3.l)					*	pea (%a0,%d3.l)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr _execute_stack_op				*	jsr execute_stack_op
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d0,d5					*	move.l %d0,%d5
	move.l d5,104(a5)				*	move.l %d5,104(%a5)
	lea (104,a6),a3					*	lea (104,%a6),%a3
	lea (140,a5),a4					*	lea (140,%a5),%a4
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.l a6,d6					*	move.l %a6,%d6
	add.l #130,d6					*	add.l #130,%d6
	clr.l d4					*	clr.l %d4
	move.l #_?L249,d7				*	move.l #.L249,%d7
_?L262:							*.L262:
	move.b (a3)+,d0					*	move.b (%a3)+,%d0
	cmp.b #5,d0					*	cmp.b #5,%d0
	jbhi _?L247					*	jhi .L247
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.w (a0,d7.l),d0				*	move.w (%a0,%d7.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&6
_?L249:							*.L249:
	.dc.w _?L247-_?L249				*	.word .L247-.L249
	.dc.w _?L253-_?L249				*	.word .L253-.L249
	.dc.w _?L252-_?L249				*	.word .L252-.L249
	.dc.w _?L251-_?L249				*	.word .L251-.L249
	.dc.w _?L250-_?L249				*	.word .L250-.L249
	.dc.w _?L248-_?L249				*	.word .L248-.L249
_?L248:							*.L248:
	move.l (a6,d4.l),a0				*	move.l (%a6,%d4.l),%a0
	clr.l d0					*	clr.l %d0
	clr.l d2					*	clr.l %d2
_?L261:							*.L261:
	move.b (a0)+,d3					*	move.b (%a0)+,%d3
	moveq #127,d1					*	moveq #127,%d1
	and.l d3,d1					*	and.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d0					*	or.l %d1,%d0
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d3					*	tst.b %d3
	jblt _?L261					*	jlt .L261
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	pea 62(sp)					*	pea 62(%sp)
	pea (a0,d0.l)					*	pea (%a0,%d0.l)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a1,54(sp)				*	move.l %a1,54(%sp)
	jbsr _execute_stack_op				*	jsr execute_stack_op
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l 38(sp),a1				*	move.l 38(%sp),%a1
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbhi _?L287					*	jhi .L287
_?L289:							*.L289:
	move.b #1,(a4)					*	move.b #1,(%a4)
_?L288:							*.L288:
	move.l d0,(a5,d4.l)				*	move.l %d0,(%a5,%d4.l)
_?L247:							*.L247:
	addq.l #1,a4					*	addq.l #1,%a4
	addq.l #1,a1					*	addq.l #1,%a1
	addq.l #4,d4					*	addq.l #4,%d4
	cmp.l d6,a3					*	cmp.l %d6,%a3
	jbne _?L262					*	jne .L262
_?L297:							*.L297:
	tst.b 171(a6)					*	tst.b 171(%a6)
	jbeq _?L263					*	jeq .L263
	move.l 46(sp),d0				*	move.l 46(%sp),%d0
	bset #31,d0					*	bset #31,%d0
	move.l d0,128(a5)				*	move.l %d0,128(%a5)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (188,sp),sp					*	lea (188,%sp),%sp
	rts						*	rts
_?L250:							*.L250:
	move.l d5,d0					*	move.l %d5,%d0
	add.l (a6,d4.l),d0				*	add.l (%a6,%d4.l),%d0
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbls _?L289					*	jls .L289
_?L287:							*.L287:
	trap #7						*	trap #7
_?L251:							*.L251:
	move.l (a6,d4.l),a0				*	move.l (%a6,%d4.l),%a0
	clr.l d3					*	clr.l %d3
	clr.l d1					*	clr.l %d1
_?L259:							*.L259:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d3					*	or.l %d0,%d3
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L259					*	jlt .L259
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	pea 62(sp)					*	pea 62(%sp)
	pea (a0,d3.l)					*	pea (%a0,%d3.l)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l a1,54(sp)				*	move.l %a1,54(%sp)
	jbsr _execute_stack_op				*	jsr execute_stack_op
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l 38(sp),a1				*	move.l 38(%sp),%a1
	tst.l 42(sp)					*	tst.l 42(%sp)
	jbeq _?L288					*	jeq .L288
	clr.b (a4)					*	clr.b (%a4)
_?L294:							*.L294:
	move.l d0,(a5,d4.l)				*	move.l %d0,(%a5,%d4.l)
	jbra _?L247					*	jra .L247
_?L253:							*.L253:
	move.l d5,d0					*	move.l %d5,%d0
	add.l (a6,d4.l),d0				*	add.l (%a6,%d4.l),%d0
	tst.l 42(sp)					*	tst.l 42(%sp)
	jbeq _?L288					*	jeq .L288
	clr.b (a4)					*	clr.b (%a4)
	jbra _?L294					*	jra .L294
_?L252:							*.L252:
	move.l (a6,d4.l),d0				*	move.l (%a6,%d4.l),%d0
	tst.b 198(sp,d0.l)				*	tst.b 198(%sp,%d0.l)
	jbne _?L295					*	jne .L295
	move.l 58(sp,d0.l*4),d0				*	move.l 58(%sp,%d0.l*4),%d0
	tst.l 42(sp)					*	tst.l 42(%sp)
	jbeq _?L288					*	jeq .L288
	clr.b (a4)					*	clr.b (%a4)
	jbra _?L294					*	jra .L294
_?L295:							*.L295:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L287					*	jlt .L287
	move.b _dwarf_reg_size_table(d0.l),d1		*	move.b dwarf_reg_size_table(%d0.l),%d1
	move.l 58(sp,d0.l*4),a0				*	move.l 58(%sp,%d0.l*4),%a0
	tst.l 50(sp)					*	tst.l 50(%sp)
	jbeq _?L296					*	jeq .L296
_?L257:							*.L257:
	cmp.b #4,(a1)					*	cmp.b #4,(%a1)
	jbhi _?L287					*	jhi .L287
	move.b #1,(a4)					*	move.b #1,(%a4)
	move.l a0,(a5,d4.l)				*	move.l %a0,(%a5,%d4.l)
	addq.l #1,a4					*	addq.l #1,%a4
	addq.l #1,a1					*	addq.l #1,%a1
	addq.l #4,d4					*	addq.l #4,%d4
	cmp.l d6,a3					*	cmp.l %d6,%a3
	jbne _?L262					*	jne .L262
	jbra _?L297					*	jra .L297
_?L296:							*.L296:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L287					*	jne .L287
	move.l (a0),a0					*	move.l (%a0),%a0
	jbra _?L257					*	jra .L257
_?L263:							*.L263:
	move.l 46(sp),d0				*	move.l 46(%sp),%d0
	bclr #31,d0					*	bclr #31,%d0
	move.l d0,128(a5)				*	move.l %d0,128(%a5)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (188,sp),sp					*	lea (188,%sp),%sp
	rts						*	rts
_?L240:							*.L240:
	move.l 140(a6),d0				*	move.l 140(%a6),%d0
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L287					*	jlt .L287
	move.l 58(sp,d0.l*4),a0				*	move.l 58(%sp,%d0.l*4),%a0
	tst.l 50(sp)					*	tst.l 50(%sp)
	jbeq _?L243					*	jeq .L243
	tst.b 198(sp,d0.l)				*	tst.b 198(%sp,%d0.l)
	jbne _?L244					*	jne .L244
_?L243:							*.L243:
	cmp.b #4,_dwarf_reg_size_table(d0.l)		*	cmp.b #4,dwarf_reg_size_table(%d0.l)
	jbne _?L287					*	jne .L287
	move.l (a0),a0					*	move.l (%a0),%a0
_?L244:							*.L244:
	move.l a0,d5					*	move.l %a0,%d5
	add.l 136(a6),d5				*	add.l 136(%a6),%d5
	move.l d5,104(a5)				*	move.l %d5,104(%a5)
	lea (104,a6),a3					*	lea (104,%a6),%a3
	lea (140,a5),a4					*	lea (140,%a5),%a4
	lea _dwarf_reg_size_table,a1			*	lea dwarf_reg_size_table,%a1
	move.l a6,d6					*	move.l %a6,%d6
	add.l #130,d6					*	add.l #130,%d6
	clr.l d4					*	clr.l %d4
	move.l #_?L249,d7				*	move.l #.L249,%d7
	jbra _?L262					*	jra .L262
_?L293:							*.L293:
	move.l 104(a5),d0				*	move.l 104(%a5),%d0
	cmp.b #4,_dwarf_reg_size_table+15		*	cmp.b #4,dwarf_reg_size_table+15
	jbne _?L287					*	jne .L287
	move.l d0,54(sp)				*	move.l %d0,54(%sp)
	tst.l 50(sp)					*	tst.l 50(%sp)
	jbeq _?L238					*	jeq .L238
	clr.b 213(sp)					*	clr.b 213(%sp)
_?L238:							*.L238:
	moveq #54,d1					*	moveq #54,%d1
	add.l sp,d1					*	add.l %sp,%d1
	move.l d1,118(sp)				*	move.l %d1,118(%sp)
	jbra _?L235					*	jra .L235
							*	.size	uw_update_context_1, .-uw_update_context_1
	.align	2					*	.align	2
							*	.type	execute_cfa_program_specialized, @function
_execute_cfa_program_specialized:			*execute_cfa_program_specialized:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a1					*	move.l 8(%fp),%a1
	move.l 12(a6),d4				*	move.l 12(%fp),%d4
	move.l 16(a6),a5				*	move.l 16(%fp),%a5
	move.l 20(a6),a4				*	move.l 20(%fp),%a4
	clr.l 132(a4)					*	clr.l 132(%a4)
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbls _?L298					*	jls .L298
	move.l 128(a5),d3				*	move.l 128(%a5),%d3
	add.l d3,d3					*	add.l %d3,%d3
	subx.l d3,d3					*	subx.l %d3,%d3
	neg.l d3					*	neg.l %d3
	add.l 108(a5),d3				*	add.l 108(%a5),%d3
	sub.l a2,a2					*	sub.l %a2,%a2
	move.l #_?L310,a0				*	move.l #.L310,%a0
_?L300:							*.L300:
	move.l 148(a4),d2				*	move.l 148(%a4),%d2
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbls _?L298					*	jls .L298
	move.l a1,a3					*	move.l %a1,%a3
	move.b (a3)+,d1					*	move.b (%a3)+,%d1
	move.b d1,d0					*	move.b %d1,%d0
	and.b #-64,d0					*	and.b #-64,%d0
	cmp.b #64,d0					*	cmp.b #64,%d0
	jbeq _?L436					*	jeq .L436
	cmp.b #-128,d0					*	cmp.b #-128,%d0
	jbeq _?L437					*	jeq .L437
	cmp.b #-64,d0					*	cmp.b #-64,%d0
	jbeq _?L438					*	jeq .L438
	cmp.b #47,d1					*	cmp.b #47,%d1
	jbhi _?L308					*	jhi .L308
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w (a0,d1.l),d0				*	move.w (%a0,%d1.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&48
_?L310:							*.L310:
	.dc.w _?L305-_?L310				*	.word .L305-.L310
	.dc.w _?L333-_?L310				*	.word .L333-.L310
	.dc.w _?L332-_?L310				*	.word .L332-.L310
	.dc.w _?L331-_?L310				*	.word .L331-.L310
	.dc.w _?L330-_?L310				*	.word .L330-.L310
	.dc.w _?L364-_?L310				*	.word .L364-.L310
	.dc.w _?L365-_?L310				*	.word .L365-.L310
	.dc.w _?L366-_?L310				*	.word .L366-.L310
	.dc.w _?L367-_?L310				*	.word .L367-.L310
	.dc.w _?L368-_?L310				*	.word .L368-.L310
	.dc.w _?L324-_?L310				*	.word .L324-.L310
	.dc.w _?L323-_?L310				*	.word .L323-.L310
	.dc.w _?L369-_?L310				*	.word .L369-.L310
	.dc.w _?L370-_?L310				*	.word .L370-.L310
	.dc.w _?L371-_?L310				*	.word .L371-.L310
	.dc.w _?L319-_?L310				*	.word .L319-.L310
	.dc.w _?L372-_?L310				*	.word .L372-.L310
	.dc.w _?L373-_?L310				*	.word .L373-.L310
	.dc.w _?L374-_?L310				*	.word .L374-.L310
	.dc.w _?L375-_?L310				*	.word .L375-.L310
	.dc.w _?L376-_?L310				*	.word .L376-.L310
	.dc.w _?L377-_?L310				*	.word .L377-.L310
	.dc.w _?L378-_?L310				*	.word .L378-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L308-_?L310				*	.word .L308-.L310
	.dc.w _?L305-_?L310				*	.word .L305-.L310
	.dc.w _?L379-_?L310				*	.word .L379-.L310
	.dc.w _?L380-_?L310				*	.word .L380-.L310
_?L436:							*.L436:
	moveq #63,d0					*	moveq #63,%d0
	and.l d0,d1					*	and.l %d0,%d1
	add.l d1,d2					*	add.l %d1,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
_?L305:							*.L305:
	move.l a3,a1					*	move.l %a3,%a1
_?L307:							*.L307:
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
_?L298:							*.L298:
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L438:							*.L438:
	move.b d1,d0					*	move.b %d1,%d0
	and.b #63,d0					*	and.b #63,%d0
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	cmp.b #25,d0					*	cmp.b #25,%d0
	jbhi _?L305					*	jhi .L305
	clr.b 104(a4,d1.l)				*	clr.b 104(%a4,%d1.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L437:							*.L437:
	move.b d1,d7					*	move.b %d1,%d7
	and.b #63,d7					*	and.b #63,%d7
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	clr.l d5					*	clr.l %d5
	clr.l d2					*	clr.l %d2
_?L304:							*.L304:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d6					*	tst.b %d6
	jblt _?L304					*	jlt .L304
	move.l d5,d0					*	move.l %d5,%d0
	neg.l d0					*	neg.l %d0
	add.l d0,d0					*	add.l %d0,%d0
	cmp.b #25,d7					*	cmp.b #25,%d7
	jbhi _?L305					*	jhi .L305
	move.b #1,104(a4,d1.l)				*	move.b #1,104(%a4,%d1.l)
	move.l d0,(a4,d1.l*4)				*	move.l %d0,(%a4,%d1.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L319:							*.L319:
	move.l a3,144(a4)				*	move.l %a3,144(%a4)
	move.b #2,130(a4)				*	move.b #2,130(%a4)
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L344:							*.L344:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L344					*	jlt .L344
_?L424:							*.L424:
	lea (a3,d6.l),a1				*	lea (%a3,%d6.l),%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L333:							*.L333:
	pea -4(a6)					*	pea -4(%fp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	clr.l d0					*	clr.l %d0
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a1					*	move.l %d0,%a1
	move.l -4(a6),148(a4)				*	move.l -4(%fp),148(%a4)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L332:							*.L332:
	clr.l d0					*	clr.l %d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
	addq.l #2,a1					*	addq.l #2,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L331:							*.L331:
	clr.l d0					*	clr.l %d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.b 2(a1),d0					*	or.b 2(%a1),%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
	addq.l #3,a1					*	addq.l #3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L330:							*.L330:
	clr.l d0					*	clr.l %d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	moveq #24,d1					*	moveq #24,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 3(a1),d0					*	move.b 3(%a1),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 4(a1),d0					*	or.b 4(%a1),%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d2,148(a4)				*	move.l %d2,148(%a4)
	addq.l #5,a1					*	addq.l #5,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L324:							*.L324:
	tst.l a2					*	tst.l %a2
	jbeq _?L341					*	jeq .L341
	move.l a2,d6					*	move.l %a2,%d6
	move.l 132(a2),a2				*	move.l 132(%a2),%a2
	pea 148.w					*	pea 148.w
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a4)				*	move.l %d6,132(%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
_?L442:							*.L442:
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L323:							*.L323:
	move.l 132(a4),d6				*	move.l 132(%a4),%d6
	pea 148.w					*	pea 148.w
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	move.l d6,a1					*	move.l %d6,%a1
	move.l a2,132(a1)				*	move.l %a2,132(%a1)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d6,a2					*	move.l %d6,%a2
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L369:							*.L369:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L322:							*.L322:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L322					*	jlt .L322
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L343:							*.L343:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L343					*	jlt .L343
	move.l d6,136(a4)				*	move.l %d6,136(%a4)
	move.b #1,130(a4)				*	move.b #1,130(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L380:							*.L380:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L309:							*.L309:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L309					*	jlt .L309
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L360:							*.L360:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L360					*	jlt .L360
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L305					*	jcs .L305
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	neg.l d7					*	neg.l %d7
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L372:							*.L372:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L318:							*.L318:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L318					*	jlt .L318
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L345					*	jcs .L345
	move.b #3,104(a4,d6.l)				*	move.b #3,104(%a4,%d6.l)
	move.l a3,(a4,d6.l*4)				*	move.l %a3,(%a4,%d6.l*4)
_?L345:							*.L345:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L346:							*.L346:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L424					*	jge .L424
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L346					*	jlt .L346
	jbra _?L424					*	jra .L424
_?L373:							*.L373:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L317:							*.L317:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L317					*	jlt .L317
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L347:							*.L347:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L347					*	jlt .L347
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L348					*	jcs .L348
	btst #6,d6					*	btst #6,%d6
	jbeq _?L348					*	jeq .L348
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
_?L348:							*.L348:
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L305					*	jcs .L305
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
_?L440:							*.L440:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L374:							*.L374:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L316:							*.L316:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L316					*	jlt .L316
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L350:							*.L350:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L350					*	jlt .L350
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L351					*	jcs .L351
	btst #6,d2					*	btst #6,%d2
	jbeq _?L351					*	jeq .L351
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
_?L351:							*.L351:
	move.b #1,130(a4)				*	move.b #1,130(%a4)
_?L425:							*.L425:
	add.l d6,d6					*	add.l %d6,%d6
	neg.l d6					*	neg.l %d6
_?L423:							*.L423:
	move.l d6,136(a4)				*	move.l %d6,136(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L375:							*.L375:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L315:							*.L315:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L315					*	jlt .L315
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L425					*	jcs .L425
	btst #6,d2					*	btst #6,%d2
	jbeq _?L425					*	jeq .L425
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	add.l d6,d6					*	add.l %d6,%d6
	neg.l d6					*	neg.l %d6
	jbra _?L423					*	jra .L423
_?L377:							*.L377:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L313:							*.L313:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L313					*	jlt .L313
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L355:							*.L355:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L355					*	jlt .L355
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L356					*	jcs .L356
	btst #6,d6					*	btst #6,%d6
	jbne _?L439					*	jne .L439
_?L356:							*.L356:
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L305					*	jcs .L305
	move.b #4,104(a4,d2.l)				*	move.b #4,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L376:							*.L376:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L314:							*.L314:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L314					*	jlt .L314
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L353:							*.L353:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jbge _?L356					*	jge .L356
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L353					*	jlt .L353
	jbra _?L356					*	jra .L356
_?L378:							*.L378:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L312:							*.L312:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L312					*	jlt .L312
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L358					*	jcs .L358
	move.b #5,104(a4,d6.l)				*	move.b #5,104(%a4,%d6.l)
	move.l a3,(a4,d6.l*4)				*	move.l %a3,(%a4,%d6.l*4)
_?L358:							*.L358:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L359:							*.L359:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L424					*	jge .L424
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L359					*	jlt .L359
	jbra _?L424					*	jra .L424
_?L379:							*.L379:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L311:							*.L311:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L311					*	jlt .L311
	move.l d6,136(a5)				*	move.l %d6,136(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L364:							*.L364:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L329:							*.L329:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L329					*	jlt .L329
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L334:							*.L334:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L334					*	jlt .L334
	neg.l d7					*	neg.l %d7
	add.l d7,d7					*	add.l %d7,%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L305					*	jcs .L305
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	jbra _?L440					*	jra .L440
_?L365:							*.L365:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L328:							*.L328:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L328					*	jlt .L328
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcs _?L305					*	jcs .L305
	clr.b 104(a4,d6.l)				*	clr.b 104(%a4,%d6.l)
_?L441:							*.L441:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L370:							*.L370:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L321:							*.L321:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L321					*	jlt .L321
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	move.b #1,130(a4)				*	move.b #1,130(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l d4,a1					*	cmp.l %d4,%a1
	jbcs _?L300					*	jcs .L300
	jbra _?L298					*	jra .L298
_?L371:							*.L371:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L320:							*.L320:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L423					*	jge .L423
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L320					*	jlt .L320
	jbra _?L423					*	jra .L423
_?L366:							*.L366:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L327:							*.L327:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L327					*	jlt .L327
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L305					*	jcs .L305
	move.b #7,104(a4,d6.l)				*	move.b #7,104(%a4,%d6.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L367:							*.L367:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L326:							*.L326:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L326					*	jlt .L326
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L305					*	jcs .L305
	clr.b 104(a4,d6.l)				*	clr.b 104(%a4,%d6.l)
	jbra _?L441					*	jra .L441
_?L368:							*.L368:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L325:							*.L325:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L325					*	jlt .L325
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L339:							*.L339:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L339					*	jlt .L339
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L305					*	jcs .L305
	move.b #2,104(a4,d2.l)				*	move.b #2,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L307					*	jra .L307
_?L439:							*.L439:
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	jbra _?L356					*	jra .L356
_?L341:							*.L341:
	lea (-148,sp),sp				*	lea (-148,%sp),%sp
	move.l sp,d6					*	move.l %sp,%d6
	pea 148.w					*	pea 148.w
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a4)				*	move.l %d6,132(%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	jbra _?L442					*	jra .L442
_?L308:							*.L308:
	trap #7						*	trap #7
							*	.size	execute_cfa_program_specialized, .-execute_cfa_program_specialized
	.align	2					*	.align	2
							*	.type	execute_cfa_program_generic, @function
_execute_cfa_program_generic:				*execute_cfa_program_generic:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a1					*	move.l 8(%fp),%a1
	move.l 12(a6),d4				*	move.l 12(%fp),%d4
	move.l 16(a6),a5				*	move.l 16(%fp),%a5
	move.l 20(a6),a4				*	move.l 20(%fp),%a4
	clr.l 132(a4)					*	clr.l 132(%a4)
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbls _?L443					*	jls .L443
	move.l 128(a5),d3				*	move.l 128(%a5),%d3
	add.l d3,d3					*	add.l %d3,%d3
	subx.l d3,d3					*	subx.l %d3,%d3
	neg.l d3					*	neg.l %d3
	add.l 108(a5),d3				*	add.l 108(%a5),%d3
	sub.l a2,a2					*	sub.l %a2,%a2
	move.l #_?L456,a0				*	move.l #.L456,%a0
_?L445:							*.L445:
	move.l 148(a4),d0				*	move.l 148(%a4),%d0
	cmp.l d0,d3					*	cmp.l %d0,%d3
	jbls _?L443					*	jls .L443
	move.l a1,a3					*	move.l %a1,%a3
	move.b (a3)+,d1					*	move.b (%a3)+,%d1
	move.b d1,d2					*	move.b %d1,%d2
	and.b #-64,d2					*	and.b #-64,%d2
	cmp.b #64,d2					*	cmp.b #64,%d2
	jbeq _?L583					*	jeq .L583
	cmp.b #-128,d2					*	cmp.b #-128,%d2
	jbeq _?L584					*	jeq .L584
	cmp.b #-64,d2					*	cmp.b #-64,%d2
	jbeq _?L585					*	jeq .L585
	cmp.b #47,d1					*	cmp.b #47,%d1
	jbhi _?L454					*	jhi .L454
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.w (a0,d1.l),d1				*	move.w (%a0,%d1.l),%d1
	jmp 2(pc,d1.w)					*	jmp %pc@(2,%d1:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&48
_?L456:							*.L456:
	.dc.w _?L450-_?L456				*	.word .L450-.L456
	.dc.w _?L479-_?L456				*	.word .L479-.L456
	.dc.w _?L478-_?L456				*	.word .L478-.L456
	.dc.w _?L477-_?L456				*	.word .L477-.L456
	.dc.w _?L476-_?L456				*	.word .L476-.L456
	.dc.w _?L510-_?L456				*	.word .L510-.L456
	.dc.w _?L511-_?L456				*	.word .L511-.L456
	.dc.w _?L512-_?L456				*	.word .L512-.L456
	.dc.w _?L513-_?L456				*	.word .L513-.L456
	.dc.w _?L514-_?L456				*	.word .L514-.L456
	.dc.w _?L470-_?L456				*	.word .L470-.L456
	.dc.w _?L469-_?L456				*	.word .L469-.L456
	.dc.w _?L515-_?L456				*	.word .L515-.L456
	.dc.w _?L516-_?L456				*	.word .L516-.L456
	.dc.w _?L517-_?L456				*	.word .L517-.L456
	.dc.w _?L465-_?L456				*	.word .L465-.L456
	.dc.w _?L518-_?L456				*	.word .L518-.L456
	.dc.w _?L519-_?L456				*	.word .L519-.L456
	.dc.w _?L520-_?L456				*	.word .L520-.L456
	.dc.w _?L521-_?L456				*	.word .L521-.L456
	.dc.w _?L522-_?L456				*	.word .L522-.L456
	.dc.w _?L523-_?L456				*	.word .L523-.L456
	.dc.w _?L524-_?L456				*	.word .L524-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L454-_?L456				*	.word .L454-.L456
	.dc.w _?L450-_?L456				*	.word .L450-.L456
	.dc.w _?L525-_?L456				*	.word .L525-.L456
	.dc.w _?L526-_?L456				*	.word .L526-.L456
_?L583:							*.L583:
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	muls.l 160(a4),d1				*	muls.l 160(%a4),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d0,148(a4)				*	move.l %d0,148(%a4)
_?L450:							*.L450:
	move.l a3,a1					*	move.l %a3,%a1
_?L453:							*.L453:
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
_?L443:							*.L443:
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L585:							*.L585:
	move.b d1,d0					*	move.b %d1,%d0
	and.b #63,d0					*	and.b #63,%d0
	moveq #63,d2					*	moveq #63,%d2
	and.l d2,d1					*	and.l %d2,%d1
	cmp.b #25,d0					*	cmp.b #25,%d0
	jbhi _?L450					*	jhi .L450
	clr.b 104(a4,d1.l)				*	clr.b 104(%a4,%d1.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L584:							*.L584:
	move.b d1,d7					*	move.b %d1,%d7
	and.b #63,d7					*	and.b #63,%d7
	moveq #63,d0					*	moveq #63,%d0
	and.l d0,d1					*	and.l %d0,%d1
	clr.l d5					*	clr.l %d5
	clr.l d2					*	clr.l %d2
_?L449:							*.L449:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d2,d0					*	lsl.l %d2,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d6					*	tst.b %d6
	jblt _?L449					*	jlt .L449
	move.l d5,d0					*	move.l %d5,%d0
	muls.l 156(a4),d0				*	muls.l 156(%a4),%d0
	cmp.b #25,d7					*	cmp.b #25,%d7
	jbhi _?L450					*	jhi .L450
	move.b #1,104(a4,d1.l)				*	move.b #1,104(%a4,%d1.l)
	move.l d0,(a4,d1.l*4)				*	move.l %d0,(%a4,%d1.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L465:							*.L465:
	move.l a3,144(a4)				*	move.l %a3,144(%a4)
	move.b #2,130(a4)				*	move.b #2,130(%a4)
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L490:							*.L490:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L490					*	jlt .L490
_?L568:							*.L568:
	lea (a3,d6.l),a1				*	lea (%a3,%d6.l),%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L479:							*.L479:
	pea -4(a6)					*	pea -4(%fp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	clr.l d0					*	clr.l %d0
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a1					*	move.l %d0,%a1
	move.l -4(a6),148(a4)				*	move.l -4(%fp),148(%a4)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L478:							*.L478:
	clr.l d1					*	clr.l %d1
	move.b 1(a1),d1					*	move.b 1(%a1),%d1
	muls.l 160(a4),d1				*	muls.l 160(%a4),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d0,148(a4)				*	move.l %d0,148(%a4)
	addq.l #2,a1					*	addq.l #2,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L477:							*.L477:
	clr.l d1					*	clr.l %d1
	move.b 1(a1),d1					*	move.b 1(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 2(a1),d1					*	or.b 2(%a1),%d1
	muls.l 160(a4),d1				*	muls.l 160(%a4),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d0,148(a4)				*	move.l %d0,148(%a4)
	addq.l #3,a1					*	addq.l #3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L476:							*.L476:
	clr.l d1					*	clr.l %d1
	move.b 1(a1),d1					*	move.b 1(%a1),%d1
	moveq #24,d2					*	moveq #24,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	clr.l d2					*	clr.l %d2
	move.b 2(a1),d2					*	move.b 2(%a1),%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d1,d2					*	or.l %d1,%d2
	clr.l d1					*	clr.l %d1
	move.b 3(a1),d1					*	move.b 3(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d2,d1					*	or.l %d2,%d1
	or.b 4(a1),d1					*	or.b 4(%a1),%d1
	muls.l 160(a4),d1				*	muls.l 160(%a4),%d1
	add.l d1,d0					*	add.l %d1,%d0
	move.l d0,148(a4)				*	move.l %d0,148(%a4)
	addq.l #5,a1					*	addq.l #5,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L470:							*.L470:
	tst.l a2					*	tst.l %a2
	jbeq _?L487					*	jeq .L487
	move.l a2,d6					*	move.l %a2,%d6
	move.l 132(a2),a2				*	move.l 132(%a2),%a2
	pea 148.w					*	pea 148.w
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a4)				*	move.l %d6,132(%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
_?L589:							*.L589:
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L469:							*.L469:
	move.l 132(a4),d6				*	move.l 132(%a4),%d6
	pea 148.w					*	pea 148.w
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	move.l d6,a1					*	move.l %d6,%a1
	move.l a2,132(a1)				*	move.l %a2,132(%a1)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l d6,a2					*	move.l %d6,%a2
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L515:							*.L515:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L468:							*.L468:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L468					*	jlt .L468
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L489:							*.L489:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L489					*	jlt .L489
	move.l d6,136(a4)				*	move.l %d6,136(%a4)
	move.b #1,130(a4)				*	move.b #1,130(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L526:							*.L526:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L455:							*.L455:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L455					*	jlt .L455
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L506:							*.L506:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L506					*	jlt .L506
	muls.l 156(a4),d7				*	muls.l 156(%a4),%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L450					*	jcs .L450
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	neg.l d7					*	neg.l %d7
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L518:							*.L518:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L464:							*.L464:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L464					*	jlt .L464
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L491					*	jcs .L491
	move.b #3,104(a4,d6.l)				*	move.b #3,104(%a4,%d6.l)
	move.l a3,(a4,d6.l*4)				*	move.l %a3,(%a4,%d6.l*4)
_?L491:							*.L491:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L492:							*.L492:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L568					*	jge .L568
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L492					*	jlt .L492
	jbra _?L568					*	jra .L568
_?L519:							*.L519:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L463:							*.L463:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L463					*	jlt .L463
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L493:							*.L493:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L493					*	jlt .L493
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L494					*	jcs .L494
	btst #6,d6					*	btst #6,%d6
	jbne _?L586					*	jne .L586
_?L494:							*.L494:
	muls.l 156(a4),d7				*	muls.l 156(%a4),%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L450					*	jcs .L450
	move.b #1,104(a4,d2.l)				*	move.b #1,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L520:							*.L520:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L462:							*.L462:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L462					*	jlt .L462
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L496:							*.L496:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L496					*	jlt .L496
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L497					*	jcs .L497
	btst #6,d2					*	btst #6,%d2
	jbeq _?L497					*	jeq .L497
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
_?L497:							*.L497:
	move.b #1,130(a4)				*	move.b #1,130(%a4)
_?L570:							*.L570:
	muls.l 156(a4),d6				*	muls.l 156(%a4),%d6
_?L569:							*.L569:
	move.l d6,136(a4)				*	move.l %d6,136(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L521:							*.L521:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L461:							*.L461:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L461					*	jlt .L461
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L570					*	jcs .L570
	btst #6,d2					*	btst #6,%d2
	jbeq _?L570					*	jeq .L570
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	muls.l 156(a4),d6				*	muls.l 156(%a4),%d6
	jbra _?L569					*	jra .L569
_?L523:							*.L523:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L459:							*.L459:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L459					*	jlt .L459
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L501:							*.L501:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L501					*	jlt .L501
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcs _?L502					*	jcs .L502
	btst #6,d6					*	btst #6,%d6
	jbne _?L587					*	jne .L587
_?L502:							*.L502:
	muls.l 156(a4),d7				*	muls.l 156(%a4),%d7
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L450					*	jcs .L450
	move.b #4,104(a4,d2.l)				*	move.b #4,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L522:							*.L522:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L460:							*.L460:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L460					*	jlt .L460
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L499:							*.L499:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jbge _?L502					*	jge .L502
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L499					*	jlt .L499
	jbra _?L502					*	jra .L502
_?L524:							*.L524:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L458:							*.L458:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L458					*	jlt .L458
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L504					*	jcs .L504
	move.b #5,104(a4,d6.l)				*	move.b #5,104(%a4,%d6.l)
	move.l a3,(a4,d6.l*4)				*	move.l %a3,(%a4,%d6.l*4)
_?L504:							*.L504:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L505:							*.L505:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L568					*	jge .L568
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L505					*	jlt .L505
	jbra _?L568					*	jra .L568
_?L525:							*.L525:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L457:							*.L457:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L457					*	jlt .L457
	move.l d6,136(a5)				*	move.l %d6,136(%a5)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L510:							*.L510:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L475:							*.L475:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L475					*	jlt .L475
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L480:							*.L480:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jbge _?L494					*	jge .L494
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L480					*	jlt .L480
	jbra _?L494					*	jra .L494
_?L511:							*.L511:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L474:							*.L474:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L474					*	jlt .L474
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L450					*	jcs .L450
	clr.b 104(a4,d6.l)				*	clr.b 104(%a4,%d6.l)
_?L588:							*.L588:
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L516:							*.L516:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L467:							*.L467:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L467					*	jlt .L467
	move.l d6,140(a4)				*	move.l %d6,140(%a4)
	move.b #1,130(a4)				*	move.b #1,130(%a4)
	move.l a3,a1					*	move.l %a3,%a1
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbhi _?L445					*	jhi .L445
	jbra _?L443					*	jra .L443
_?L517:							*.L517:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L466:							*.L466:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jbge _?L569					*	jge .L569
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L466					*	jlt .L466
	jbra _?L569					*	jra .L569
_?L512:							*.L512:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L473:							*.L473:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L473					*	jlt .L473
	moveq #25,d2					*	moveq #25,%d2
	cmp.l d6,d2					*	cmp.l %d6,%d2
	jbcs _?L450					*	jcs .L450
	move.b #7,104(a4,d6.l)				*	move.b #7,104(%a4,%d6.l)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L513:							*.L513:
	clr.l d6					*	clr.l %d6
	clr.l d1					*	clr.l %d1
_?L472:							*.L472:
	move.b (a3)+,d2					*	move.b (%a3)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d6					*	or.l %d0,%d6
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L472					*	jlt .L472
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcs _?L450					*	jcs .L450
	clr.b 104(a4,d6.l)				*	clr.b 104(%a4,%d6.l)
	jbra _?L588					*	jra .L588
_?L514:							*.L514:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
_?L471:							*.L471:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d2					*	or.l %d0,%d2
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L471					*	jlt .L471
	clr.l d7					*	clr.l %d7
	clr.l d1					*	clr.l %d1
_?L485:							*.L485:
	move.b (a3)+,d6					*	move.b (%a3)+,%d6
	moveq #127,d0					*	moveq #127,%d0
	and.l d6,d0					*	and.l %d6,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d6					*	tst.b %d6
	jblt _?L485					*	jlt .L485
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L450					*	jcs .L450
	move.b #2,104(a4,d2.l)				*	move.b #2,104(%a4,%d2.l)
	move.l d7,(a4,d2.l*4)				*	move.l %d7,(%a4,%d2.l*4)
	move.l a3,a1					*	move.l %a3,%a1
	jbra _?L453					*	jra .L453
_?L587:							*.L587:
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	jbra _?L502					*	jra .L502
_?L586:							*.L586:
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d7					*	or.l %d0,%d7
	jbra _?L494					*	jra .L494
_?L487:							*.L487:
	lea (-148,sp),sp				*	lea (-148,%sp),%sp
	move.l sp,d6					*	move.l %sp,%d6
	pea 148.w					*	pea 148.w
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.l a2,-8(a6)				*	move.l %a2,-8(%fp)
	jbsr _memcpy					*	jsr memcpy
	move.l d6,132(a4)				*	move.l %d6,132(%a4)
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a3,a1					*	move.l %a3,%a1
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l -8(a6),a2				*	move.l -8(%fp),%a2
	jbra _?L589					*	jra .L589
_?L454:							*.L454:
	trap #7						*	trap #7
							*	.size	execute_cfa_program_generic, .-execute_cfa_program_generic
	.align	2					*	.align	2
							*	.type	uw_frame_state_for, @function
_uw_frame_state_for:					*uw_frame_state_for:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/a3/a4/a5,-(sp)		*	movem.l #7708,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 12(a6),a4				*	move.l 12(%fp),%a4
	pea 72.w					*	pea 72.w
	clr.l -(sp)					*	clr.l -(%sp)
	pea 104(a4)					*	pea 104(%a4)
	jbsr _memset					*	jsr memset
	clr.l 136(a3)					*	clr.l 136(%a3)
	clr.l 112(a3)					*	clr.l 112(%a3)
	move.l 108(a3),a0				*	move.l 108(%a3),%a0
	lea (12,sp),sp					*	lea (12,%sp),%sp
	tst.l a0					*	tst.l %a0
	jbeq _?L593					*	jeq .L593
	pea 116(a3)					*	pea 116(%a3)
	move.l 128(a3),d0				*	move.l 128(%a3),%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	pea -1(a0,d0.l)					*	pea -1(%a0,%d0.l)
	jbsr __Unwind_Find_FDE				*	jsr _Unwind_Find_FDE
	move.l d0,a5					*	move.l %d0,%a5
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L593					*	jeq .L593
	move.l 124(a3),148(a4)				*	move.l 124(%a3),148(%a4)
	lea (4,a5),a0					*	lea (4,%a5),%a0
	sub.l 4(a5),a0					*	sub.l 4(%a5),%a0
	move.l a0,-12(a6)				*	move.l %a0,-12(%fp)
	move.w #9,a1					*	move.w #9,%a1
	add.l a0,a1					*	add.l %a0,%a1
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l a1,-8(a6)				*	move.l %a1,-8(%fp)
	jbsr _strlen					*	jsr strlen
	addq.l #4,sp					*	addq.l #4,%sp
	move.l -8(a6),a1				*	move.l -8(%fp),%a1
	lea 1(a1,d0.l),a0				*	lea 1(%a1,%d0.l),%a0
	move.l -12(a6),a2				*	move.l -12(%fp),%a2
	cmp.b #101,9(a2)				*	cmp.b #101,9(%a2)
	jbeq _?L658					*	jeq .L658
_?L594:							*.L594:
	move.l -12(a6),a2				*	move.l -12(%fp),%a2
	move.b 8(a2),d2					*	move.b 8(%a2),%d2
	move.b (a0),d0					*	move.b (%a0),%d0
	cmp.b #3,d2					*	cmp.b #3,%d2
	jbhi _?L659					*	jhi .L659
_?L595:							*.L595:
	clr.l d3					*	clr.l %d3
	clr.l d0					*	clr.l %d0
_?L598:							*.L598:
	move.b (a0)+,d4					*	move.b (%a0)+,%d4
	moveq #127,d1					*	moveq #127,%d1
	and.l d4,d1					*	and.l %d4,%d1
	lsl.l d0,d1					*	lsl.l %d0,%d1
	or.l d1,d3					*	or.l %d1,%d3
	addq.l #7,d0					*	addq.l #7,%d0
	tst.b d4					*	tst.b %d4
	jblt _?L598					*	jlt .L598
	move.l d3,160(a4)				*	move.l %d3,160(%a4)
	clr.l d4					*	clr.l %d4
	clr.l d0					*	clr.l %d0
_?L599:							*.L599:
	move.l a0,a2					*	move.l %a0,%a2
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d1					*	moveq #127,%d1
	and.l d5,d1					*	and.l %d5,%d1
	lsl.l d0,d1					*	lsl.l %d0,%d1
	or.l d1,d4					*	or.l %d1,%d4
	addq.l #7,d0					*	addq.l #7,%d0
	tst.b d5					*	tst.b %d5
	jblt _?L599					*	jlt .L599
	moveq #31,d1					*	moveq #31,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L600					*	jcs .L600
	btst #6,d5					*	btst #6,%d5
	jbeq _?L600					*	jeq .L600
	moveq #-1,d1					*	moveq #-1,%d1
	lsl.l d0,d1					*	lsl.l %d0,%d1
	or.l d1,d4					*	or.l %d1,%d4
_?L600:							*.L600:
	move.l d4,156(a4)				*	move.l %d4,156(%a4)
	clr.l d5					*	clr.l %d5
	cmp.b #1,d2					*	cmp.b #1,%d2
	jbeq _?L660					*	jeq .L660
	clr.l d1					*	clr.l %d1
_?L601:							*.L601:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L601					*	jlt .L601
	move.l d5,164(a4)				*	move.l %d5,164(%a4)
	st 169(a4)					*	st 169(%a4)
	move.b (a1),d1					*	move.b (%a1),%d1
	clr.l d5					*	clr.l %d5
	cmp.b #122,d1					*	cmp.b #122,%d1
	jbeq _?L661					*	jeq .L661
_?L603:							*.L603:
	tst.b d1					*	tst.b %d1
	jbeq _?L662					*	jeq .L662
	addq.l #1,a1					*	addq.l #1,%a1
	move.l #_?L608,d6				*	move.l #.L608,%d6
_?L615:							*.L615:
	add.b #-66,d1					*	add.b #-66,%d1
	cmp.b #17,d1					*	cmp.b #17,%d1
	jbhi _?L606					*	jhi .L606
	and.l #255,d1					*	and.l #255,%d1
	add.l d1,d1					*	add.l %d1,%d1
	move.l d1,a2					*	move.l %d1,%a2
	move.w (a2,d6.l),d0				*	move.w (%a2,%d6.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&18
_?L608:							*.L608:
	.dc.w _?L613-_?L608				*	.word .L613-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L611-_?L608				*	.word .L611-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L610-_?L608				*	.word .L610-.L608
	.dc.w _?L606-_?L608				*	.word .L606-.L608
	.dc.w _?L609-_?L608				*	.word .L609-.L608
	.dc.w _?L607-_?L608				*	.word .L607-.L608
_?L611:							*.L611:
	move.b (a0)+,169(a4)				*	move.b (%a0)+,169(%a4)
_?L613:							*.L613:
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L615					*	jne .L615
_?L666:							*.L666:
	tst.l d5					*	tst.l %d5
	jbne _?L605					*	jne .L605
	move.l a0,d5					*	move.l %a0,%d5
_?L606:							*.L606:
	tst.l d5					*	tst.l %d5
	jbeq _?L597					*	jeq .L597
_?L605:							*.L605:
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	move.l (a0),d0					*	move.l (%a0),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l a0,d0					*	add.l %a0,%d0
	move.l d0,-12(a6)				*	move.l %d0,-12(%fp)
	addq.l #2,d4					*	addq.l #2,%d4
	jbne _?L616					*	jne .L616
	subq.l #1,d3					*	subq.l #1,%d3
	jbeq _?L663					*	jeq .L663
_?L616:							*.L616:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _execute_cfa_program_generic		*	jsr execute_cfa_program_generic
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L631					*	jeq .L631
_?L668:							*.L668:
	and.b #7,d0					*	and.b #7,%d0
	cmp.b #2,d0					*	cmp.b #2,%d0
	jbeq _?L632					*	jeq .L632
	jbls _?L664					*	jls .L664
	cmp.b #3,d0					*	cmp.b #3,%d0
	jbeq _?L634					*	jeq .L634
	moveq #24,d1					*	moveq #24,%d1
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbne _?L620					*	jne .L620
_?L618:							*.L618:
	add.l a5,d1					*	add.l %a5,%d1
	move.l d1,-12(a6)				*	move.l %d1,-12(%fp)
	tst.b 170(a4)					*	tst.b 170(%a4)
	jbeq _?L621					*	jeq .L621
_?L667:							*.L667:
	clr.l d4					*	clr.l %d4
	clr.l d2					*	clr.l %d2
_?L622:							*.L622:
	move.l -12(a6),a0				*	move.l -12(%fp),%a0
	addq.l #1,-12(a6)				*	addq.l #1,-12(%fp)
	move.b (a0)+,d3					*	move.b (%a0)+,%d3
	moveq #127,d1					*	moveq #127,%d1
	and.l d3,d1					*	and.l %d3,%d1
	lsl.l d2,d1					*	lsl.l %d2,%d1
	or.l d1,d4					*	or.l %d1,%d4
	addq.l #7,d2					*	addq.l #7,%d2
	tst.b d3					*	tst.b %d3
	jblt _?L622					*	jlt .L622
	move.b 169(a4),d0				*	move.b 169(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L624					*	jeq .L624
	pea -4(a6)					*	pea -4(%fp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	and.l #255,d0					*	and.l #255,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l -4(a6),112(a3)				*	move.l -4(%fp),112(%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
_?L624:							*.L624:
	add.l d4,-12(a6)				*	add.l %d4,-12(%fp)
_?L628:							*.L628:
	move.l (a5),d0					*	move.l (%a5),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a5					*	add.l %d0,%a5
	moveq #-2,d0					*	moveq #-2,%d0
	cmp.l 156(a4),d0				*	cmp.l 156(%a4),%d0
	jbne _?L626					*	jne .L626
	moveq #1,d1					*	moveq #1,%d1
	cmp.l 160(a4),d1				*	cmp.l 160(%a4),%d1
	jbeq _?L665					*	jeq .L665
_?L626:							*.L626:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	jbsr _execute_cfa_program_generic		*	jsr execute_cfa_program_generic
	lea (16,sp),sp					*	lea (16,%sp),%sp
	clr.l d0					*	clr.l %d0
_?L590:							*.L590:
	movem.l -40(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -40(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L658:							*.L658:
	cmp.b #104,10(a2)				*	cmp.b #104,10(%a2)
	jbne _?L594					*	jne .L594
	clr.l d0					*	clr.l %d0
	move.b (a0),d0					*	move.b (%a0),%d0
	moveq #24,d1					*	moveq #24,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 1(a0),d1					*	move.b 1(%a0),%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 2(a0),d0					*	move.b 2(%a0),%d0
	lsl.l #8,d0					*	lsl.l #8,%d0
	or.l d1,d0					*	or.l %d1,%d0
	or.b 3(a0),d0					*	or.b 3(%a0),%d0
	move.l d0,172(a4)				*	move.l %d0,172(%a4)
	addq.l #4,a0					*	addq.l #4,%a0
	move.w #11,a1					*	move.w #11,%a1
	add.l a2,a1					*	add.l %a2,%a1
	move.l -12(a6),a2				*	move.l -12(%fp),%a2
	move.b 8(a2),d2					*	move.b 8(%a2),%d2
	move.b (a0),d0					*	move.b (%a0),%d0
	cmp.b #3,d2					*	cmp.b #3,%d2
	jbls _?L595					*	jls .L595
	jbra _?L659					*	jra .L659
_?L660:							*.L660:
	move.b (a0),d5					*	move.b (%a0),%d5
	lea (2,a2),a0					*	lea (2,%a2),%a0
	move.l d5,164(a4)				*	move.l %d5,164(%a4)
	st 169(a4)					*	st 169(%a4)
	move.b (a1),d1					*	move.b (%a1),%d1
	clr.l d5					*	clr.l %d5
	cmp.b #122,d1					*	cmp.b #122,%d1
	jbne _?L603					*	jne .L603
_?L661:							*.L661:
	clr.l d1					*	clr.l %d1
_?L604:							*.L604:
	move.b (a0)+,d2					*	move.b (%a0)+,%d2
	moveq #127,d0					*	moveq #127,%d0
	and.l d2,d0					*	and.l %d2,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	or.l d0,d5					*	or.l %d0,%d5
	addq.l #7,d1					*	addq.l #7,%d1
	tst.b d2					*	tst.b %d2
	jblt _?L604					*	jlt .L604
	add.l a0,d5					*	add.l %a0,%d5
	move.b #1,170(a4)				*	move.b #1,170(%a4)
	move.l a1,d0					*	move.l %a1,%d0
	addq.l #1,d0					*	addq.l #1,%d0
	move.b 1(a1),d1					*	move.b 1(%a1),%d1
	jbeq _?L605					*	jeq .L605
	move.l d0,a1					*	move.l %d0,%a1
	addq.l #1,a1					*	addq.l #1,%a1
	move.l #_?L608,d6				*	move.l #.L608,%d6
	jbra _?L615					*	jra .L615
_?L609:							*.L609:
	move.b (a0)+,168(a4)				*	move.b (%a0)+,168(%a4)
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L615					*	jne .L615
	jbra _?L666					*	jra .L666
_?L610:							*.L610:
	clr.l d0					*	clr.l %d0
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	pea -4(a6)					*	pea -4(%fp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a1,-8(a6)				*	move.l %a1,-8(%fp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,a0					*	move.l %d0,%a0
	move.l -4(a6),152(a4)				*	move.l -4(%fp),152(%a4)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l -8(a6),a1				*	move.l -8(%fp),%a1
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L615					*	jne .L615
	jbra _?L666					*	jra .L666
_?L607:							*.L607:
	move.b #1,171(a4)				*	move.b #1,171(%a4)
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	jbne _?L615					*	jne .L615
	jbra _?L666					*	jra .L666
_?L593:							*.L593:
	moveq #5,d0					*	moveq #5,%d0
	movem.l -40(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -40(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L659:							*.L659:
	cmp.b #4,d0					*	cmp.b #4,%d0
	jbeq _?L596					*	jeq .L596
_?L597:							*.L597:
	moveq #3,d0					*	moveq #3,%d0
	movem.l -40(a6),d3/d4/d5/d6/a3/a4/a5		*	movem.l -40(%fp),#14456
	unlk a6						*	unlk %fp
	rts						*	rts
_?L634:							*.L634:
	moveq #16,d1					*	moveq #16,%d1
	add.l a5,d1					*	add.l %a5,%d1
	move.l d1,-12(a6)				*	move.l %d1,-12(%fp)
	tst.b 170(a4)					*	tst.b 170(%a4)
	jbne _?L667					*	jne .L667
_?L621:							*.L621:
	move.b 169(a4),d0				*	move.b 169(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L628					*	jeq .L628
	pea -4(a6)					*	pea -4(%fp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	and.l #255,d0					*	and.l #255,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _read_encoded_value			*	jsr read_encoded_value
	move.l d0,-12(a6)				*	move.l %d0,-12(%fp)
	move.l -4(a6),112(a3)				*	move.l -4(%fp),112(%a3)
	lea (16,sp),sp					*	lea (16,%sp),%sp
	jbra _?L628					*	jra .L628
_?L665:							*.L665:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	jbsr _execute_cfa_program_specialized		*	jsr execute_cfa_program_specialized
	lea (16,sp),sp					*	lea (16,%sp),%sp
	clr.l d0					*	clr.l %d0
	jbra _?L590					*	jra .L590
_?L663:							*.L663:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l -12(a6),-(sp)				*	move.l -12(%fp),-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _execute_cfa_program_specialized		*	jsr execute_cfa_program_specialized
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.b 168(a4),d0				*	move.b 168(%a4),%d0
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L668					*	jne .L668
_?L631:							*.L631:
	moveq #8,d1					*	moveq #8,%d1
	jbra _?L618					*	jra .L618
_?L632:							*.L632:
	moveq #12,d1					*	moveq #12,%d1
	jbra _?L618					*	jra .L618
_?L664:							*.L664:
	moveq #16,d1					*	moveq #16,%d1
	tst.b d0					*	tst.b %d0
	jbeq _?L618					*	jeq .L618
_?L620:							*.L620:
	trap #7						*	trap #7
_?L596:							*.L596:
	tst.b 1(a0)					*	tst.b 1(%a0)
	jbne _?L597					*	jne .L597
	addq.l #2,a0					*	addq.l #2,%a0
	clr.l d3					*	clr.l %d3
	clr.l d0					*	clr.l %d0
	jbra _?L598					*	jra .L598
_?L662:							*.L662:
	move.l a0,d5					*	move.l %a0,%d5
	jbra _?L605					*	jra .L605
							*	.size	uw_frame_state_for, .-uw_frame_state_for
	.align	2					*	.align	2
							*	.type	uw_init_context_1, @function
_uw_init_context_1:					*uw_init_context_1:
	lea (-180,sp),sp				*	lea (-180,%sp),%sp
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 192(sp),a3				*	move.l 192(%sp),%a3
	move.l 188(sp),d3				*	move.l 188(%sp),%d3
	pea 166.w					*	pea 166.w
	clr.l -(sp)					*	clr.l -(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _memset					*	jsr memset
	move.l d3,108(a3)				*	move.l %d3,108(%a3)
	move.l #1073741824,128(a3)			*	move.l #1073741824,128(%a3)
	moveq #24,d3					*	moveq #24,%d3
	add.l sp,d3					*	add.l %sp,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _uw_frame_state_for			*	jsr uw_frame_state_for
	lea (20,sp),sp					*	lea (20,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L672					*	jne .L672
	tst.b _dwarf_reg_size_table			*	tst.b dwarf_reg_size_table
	jbeq _?L679					*	jeq .L679
_?L671:							*.L671:
	cmp.b #4,_dwarf_reg_size_table+15		*	cmp.b #4,dwarf_reg_size_table+15
	jbne _?L672					*	jne .L672
	move.l 196(sp),8(sp)				*	move.l 196(%sp),8(%sp)
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L673					*	jeq .L673
	clr.b 155(a3)					*	clr.b 155(%a3)
_?L673:							*.L673:
	moveq #8,d0					*	moveq #8,%d0
	add.l sp,d0					*	add.l %sp,%d0
	move.l d0,60(a3)				*	move.l %d0,60(%a3)
	move.b #1,142(sp)				*	move.b #1,142(%sp)
	moveq #15,d0					*	moveq #15,%d0
	move.l d0,152(sp)				*	move.l %d0,152(%sp)
	clr.l 148(sp)					*	clr.l 148(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _uw_update_context_1			*	jsr uw_update_context_1
	move.l 208(sp),108(a3)				*	move.l 208(%sp),108(%a3)
	addq.l #8,sp					*	addq.l #8,%sp
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	lea (180,sp),sp					*	lea (180,%sp),%sp
	rts						*	rts
_?L679:							*.L679:
	move.b #4,_dwarf_reg_size_table			*	move.b #4,dwarf_reg_size_table
	move.b #4,_dwarf_reg_size_table+1		*	move.b #4,dwarf_reg_size_table+1
	move.b #4,_dwarf_reg_size_table+2		*	move.b #4,dwarf_reg_size_table+2
	move.b #4,_dwarf_reg_size_table+3		*	move.b #4,dwarf_reg_size_table+3
	move.b #4,_dwarf_reg_size_table+4		*	move.b #4,dwarf_reg_size_table+4
	move.b #4,_dwarf_reg_size_table+5		*	move.b #4,dwarf_reg_size_table+5
	move.b #4,_dwarf_reg_size_table+6		*	move.b #4,dwarf_reg_size_table+6
	move.b #4,_dwarf_reg_size_table+7		*	move.b #4,dwarf_reg_size_table+7
	move.b #4,_dwarf_reg_size_table+8		*	move.b #4,dwarf_reg_size_table+8
	move.b #4,_dwarf_reg_size_table+9		*	move.b #4,dwarf_reg_size_table+9
	move.b #4,_dwarf_reg_size_table+10		*	move.b #4,dwarf_reg_size_table+10
	move.b #4,_dwarf_reg_size_table+11		*	move.b #4,dwarf_reg_size_table+11
	move.b #4,_dwarf_reg_size_table+12		*	move.b #4,dwarf_reg_size_table+12
	move.b #4,_dwarf_reg_size_table+13		*	move.b #4,dwarf_reg_size_table+13
	move.b #4,_dwarf_reg_size_table+14		*	move.b #4,dwarf_reg_size_table+14
	move.b #4,_dwarf_reg_size_table+15		*	move.b #4,dwarf_reg_size_table+15
	move.b #12,_dwarf_reg_size_table+16		*	move.b #12,dwarf_reg_size_table+16
	move.b #12,_dwarf_reg_size_table+17		*	move.b #12,dwarf_reg_size_table+17
	move.b #12,_dwarf_reg_size_table+18		*	move.b #12,dwarf_reg_size_table+18
	move.b #12,_dwarf_reg_size_table+19		*	move.b #12,dwarf_reg_size_table+19
	move.b #12,_dwarf_reg_size_table+20		*	move.b #12,dwarf_reg_size_table+20
	move.b #12,_dwarf_reg_size_table+21		*	move.b #12,dwarf_reg_size_table+21
	move.b #12,_dwarf_reg_size_table+22		*	move.b #12,dwarf_reg_size_table+22
	move.b #12,_dwarf_reg_size_table+23		*	move.b #12,dwarf_reg_size_table+23
	move.b #4,_dwarf_reg_size_table+24		*	move.b #4,dwarf_reg_size_table+24
	move.b #4,_dwarf_reg_size_table+25		*	move.b #4,dwarf_reg_size_table+25
	jbra _?L671					*	jra .L671
_?L672:							*.L672:
	trap #7						*	trap #7
							*	.size	uw_init_context_1, .-uw_init_context_1
	.align	2					*	.align	2
							*	.type	_Unwind_RaiseException_Phase2, @function
__Unwind_RaiseException_Phase2:				*_Unwind_RaiseException_Phase2:
	lea (-176,sp),sp				*	lea (-176,%sp),%sp
	movem.l d3/d4/d5/a3/a4/a5/a6,-(sp)		*	movem.l #7198,-(%sp)
	move.l 208(sp),a4				*	move.l 208(%sp),%a4
	move.l 212(sp),a3				*	move.l 212(%sp),%a3
	moveq #1,d3					*	moveq #1,%d3
	lea _uw_frame_state_for,a5			*	lea uw_frame_state_for,%a5
	lea _uw_update_context_1,a6			*	lea uw_update_context_1,%a6
	move.l #_dwarf_reg_size_table,d4		*	move.l #dwarf_reg_size_table,%d4
	pea 28(sp)					*	pea 28(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l 128(a3),d1				*	move.l 128(%a3),%d1
	add.l d1,d1					*	add.l %d1,%d1
	subx.l d1,d1					*	subx.l %d1,%d1
	neg.l d1					*	neg.l %d1
	move.l 104(a3),a0				*	move.l 104(%a3),%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.l 16(a4),a0					*	cmp.l 16(%a4),%a0
	jbeq _?L681					*	jeq .L681
_?L701:							*.L701:
	tst.l d0					*	tst.l %d0
	jbne _?L682					*	jne .L682
	move.l 180(sp),a0				*	move.l 180(%sp),%a0
	tst.l a0					*	tst.l %a0
	jbeq _?L684					*	jeq .L684
	moveq #2,d0					*	moveq #2,%d0
	clr.l d5					*	clr.l %d5
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L686					*	jeq .L686
_?L702:							*.L702:
	subq.l #8,d0					*	subq.l #8,%d0
	jbne _?L682					*	jne .L682
	tst.l d5					*	tst.l %d5
	jbne _?L685					*	jne .L685
_?L684:							*.L684:
	pea 28(sp)					*	pea 28(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a6)					*	jsr (%a6)
	move.l 200(sp),d0				*	move.l 200(%sp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #7,132(sp,d0.l)				*	cmp.b #7,132(%sp,%d0.l)
	jbeq _?L695					*	jeq .L695
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L685					*	jlt .L685
	move.l d4,a0					*	move.l %d4,%a0
	move.b (a0,d0.l),d1				*	move.b (%a0,%d0.l),%d1
	move.l (a3,d0.l*4),a0				*	move.l (%a3,%d0.l*4),%a0
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L689					*	jeq .L689
	tst.b 140(a3,d0.l)				*	tst.b 140(%a3,%d0.l)
	jbne _?L690					*	jne .L690
_?L689:							*.L689:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L685					*	jne .L685
	move.l (a0),a0					*	move.l (%a0),%a0
_?L690:							*.L690:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d3					*	addq.l #1,%d3
_?L703:							*.L703:
	pea 28(sp)					*	pea 28(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l 128(a3),d1				*	move.l 128(%a3),%d1
	add.l d1,d1					*	add.l %d1,%d1
	subx.l d1,d1					*	subx.l %d1,%d1
	neg.l d1					*	neg.l %d1
	move.l 104(a3),a0				*	move.l 104(%a3),%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.l 16(a4),a0					*	cmp.l 16(%a4),%a0
	jbne _?L701					*	jne .L701
_?L681:							*.L681:
	tst.l d0					*	tst.l %d0
	jbne _?L682					*	jne .L682
	move.l 180(sp),a0				*	move.l 180(%sp),%a0
	tst.l a0					*	tst.l %a0
	jbeq _?L685					*	jeq .L685
	moveq #6,d0					*	moveq #6,%d0
	moveq #4,d5					*	moveq #4,%d5
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L702					*	jne .L702
_?L686:							*.L686:
	move.l 216(sp),a0				*	move.l 216(%sp),%a0
	move.l d3,(a0)					*	move.l %d3,(%a0)
	movem.l (sp)+,d3/d4/d5/a3/a4/a5/a6		*	movem.l (%sp)+,#30776
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L695:							*.L695:
	clr.l d0					*	clr.l %d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d3					*	addq.l #1,%d3
	jbra _?L703					*	jra .L703
_?L682:							*.L682:
	moveq #2,d0					*	moveq #2,%d0
	movem.l (sp)+,d3/d4/d5/a3/a4/a5/a6		*	movem.l (%sp)+,#30776
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L685:							*.L685:
	trap #7						*	trap #7
							*	.size	_Unwind_RaiseException_Phase2, .-_Unwind_RaiseException_Phase2
	.align	2					*	.align	2
							*	.type	_Unwind_ForcedUnwind_Phase2, @function
__Unwind_ForcedUnwind_Phase2:				*_Unwind_ForcedUnwind_Phase2:
	lea (-176,sp),sp				*	lea (-176,%sp),%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 216(sp),a4				*	move.l 216(%sp),%a4
	move.l 220(sp),a3				*	move.l 220(%sp),%a3
	move.l 12(a4),a6				*	move.l 12(%a4),%a6
	move.l 16(a4),d5				*	move.l 16(%a4),%d5
	moveq #1,d4					*	moveq #1,%d4
	lea _uw_frame_state_for,a5			*	lea uw_frame_state_for,%a5
	move.l #_uw_update_context_1,d6			*	move.l #uw_update_context_1,%d6
	move.l #_dwarf_reg_size_table,d7		*	move.l #dwarf_reg_size_table,%d7
	pea 36(sp)					*	pea 36(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #4,d0					*	moveq #4,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbeq _?L705					*	jeq .L705
_?L735:							*.L735:
	moveq #5,d1					*	moveq #5,%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbeq _?L706					*	jeq .L706
	tst.l d3					*	tst.l %d3
	jbne _?L707					*	jne .L707
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 10.w					*	pea 10.w
	pea 1.w						*	pea 1.w
	jbsr (a6)					*	jsr (%a6)
	lea (28,sp),sp					*	lea (28,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L707					*	jne .L707
_?L708:							*.L708:
	move.l 188(sp),a0				*	move.l 188(%sp),%a0
	tst.l a0					*	tst.l %a0
	jbeq _?L714					*	jeq .L714
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 10.w					*	pea 10.w
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	move.l d0,d3					*	move.l %d0,%d3
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d0					*	moveq #7,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbeq _?L712					*	jeq .L712
	subq.l #8,d3					*	subq.l #8,%d3
	jbne _?L707					*	jne .L707
_?L714:							*.L714:
	pea 36(sp)					*	pea 36(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	move.l 208(sp),d0				*	move.l 208(%sp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #7,140(sp,d0.l)				*	cmp.b #7,140(%sp,%d0.l)
	jbne _?L734					*	jne .L734
	clr.l d0					*	clr.l %d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d4					*	addq.l #1,%d4
_?L736:							*.L736:
	pea 36(sp)					*	pea 36(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #4,d0					*	moveq #4,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbne _?L735					*	jne .L735
_?L705:							*.L705:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 26.w					*	pea 26.w
	pea 1.w						*	pea 1.w
	jbsr (a6)					*	jsr (%a6)
	lea (28,sp),sp					*	lea (28,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L708					*	jeq .L708
_?L707:							*.L707:
	moveq #2,d3					*	moveq #2,%d3
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L734:							*.L734:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L718					*	jlt .L718
	move.l d7,a0					*	move.l %d7,%a0
	move.b (a0,d0.l),d1				*	move.b (%a0,%d0.l),%d1
	move.l (a3,d0.l*4),a0				*	move.l (%a3,%d0.l*4),%a0
	btst #6,128(a3)					*	btst #6,128(%a3)
	jbeq _?L716					*	jeq .L716
	tst.b 140(a3,d0.l)				*	tst.b 140(%a3,%d0.l)
	jbne _?L717					*	jne .L717
_?L716:							*.L716:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L718					*	jne .L718
	move.l (a0),a0					*	move.l (%a0),%a0
_?L717:							*.L717:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,108(a3)				*	move.l %d0,108(%a3)
	addq.l #1,d4					*	addq.l #1,%d4
	jbra _?L736					*	jra .L736
_?L706:							*.L706:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l 4(a4),-(sp)				*	move.l 4(%a4),-(%sp)
	move.l (a4),-(sp)				*	move.l (%a4),-(%sp)
	pea 26.w					*	pea 26.w
	pea 1.w						*	pea 1.w
	jbsr (a6)					*	jsr (%a6)
	lea (28,sp),sp					*	lea (28,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L707					*	jne .L707
_?L712:							*.L712:
	move.l 224(sp),a0				*	move.l 224(%sp),%a0
	move.l d4,(a0)					*	move.l %d4,(%a0)
	move.l d3,d0					*	move.l %d3,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	lea (176,sp),sp					*	lea (176,%sp),%sp
	rts						*	rts
_?L718:							*.L718:
	trap #7						*	trap #7
							*	.size	_Unwind_ForcedUnwind_Phase2, .-_Unwind_ForcedUnwind_Phase2
	.align	2					*	.align	2
	.globl	__Unwind_GetGR				*	.globl	_Unwind_GetGR
							*	.hidden	_Unwind_GetGR
							*	.type	_Unwind_GetGR, @function
__Unwind_GetGR:						*_Unwind_GetGR:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	moveq #25,d0					*	moveq #25,%d0
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jblt _?L741					*	jlt .L741
	move.l (a1,d1.l*4),a0				*	move.l (%a1,%d1.l*4),%a0
	btst #6,128(a1)					*	btst #6,128(%a1)
	jbeq _?L739					*	jeq .L739
	tst.b 140(a1,d1.l)				*	tst.b 140(%a1,%d1.l)
	jbne _?L747					*	jne .L747
_?L739:							*.L739:
	cmp.b #4,_dwarf_reg_size_table(d1.l)		*	cmp.b #4,dwarf_reg_size_table(%d1.l)
	jbne _?L741					*	jne .L741
	move.l (a0),d0					*	move.l (%a0),%d0
	rts						*	rts
_?L747:							*.L747:
	move.l a0,d0					*	move.l %a0,%d0
	rts						*	rts
_?L741:							*.L741:
	trap #7						*	trap #7
							*	.size	_Unwind_GetGR, .-_Unwind_GetGR
	.align	2					*	.align	2
	.globl	__Unwind_GetCFA				*	.globl	_Unwind_GetCFA
							*	.hidden	_Unwind_GetCFA
							*	.type	_Unwind_GetCFA, @function
__Unwind_GetCFA:					*_Unwind_GetCFA:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 104(a0),d0				*	move.l 104(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetCFA, .-_Unwind_GetCFA
	.align	2					*	.align	2
	.globl	__Unwind_SetGR				*	.globl	_Unwind_SetGR
							*	.hidden	_Unwind_SetGR
							*	.type	_Unwind_SetGR, @function
__Unwind_SetGR:						*_Unwind_SetGR:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L754					*	jlt .L754
	move.b _dwarf_reg_size_table(d0.l),d1		*	move.b dwarf_reg_size_table(%d0.l),%d1
	btst #6,128(a0)					*	btst #6,128(%a0)
	jbeq _?L752					*	jeq .L752
	tst.b 140(a0,d0.l)				*	tst.b 140(%a0,%d0.l)
	jbne _?L760					*	jne .L760
_?L752:							*.L752:
	move.l (a0,d0.l*4),a0				*	move.l (%a0,%d0.l*4),%a0
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L754					*	jne .L754
	move.l 12(sp),(a0)				*	move.l 12(%sp),(%a0)
	rts						*	rts
_?L760:							*.L760:
	move.l 12(sp),(a0,d0.l*4)			*	move.l 12(%sp),(%a0,%d0.l*4)
	rts						*	rts
_?L754:							*.L754:
	trap #7						*	trap #7
							*	.size	_Unwind_SetGR, .-_Unwind_SetGR
	.align	2					*	.align	2
	.globl	__Unwind_GetIP				*	.globl	_Unwind_GetIP
							*	.hidden	_Unwind_GetIP
							*	.type	_Unwind_GetIP, @function
__Unwind_GetIP:						*_Unwind_GetIP:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 108(a0),d0				*	move.l 108(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetIP, .-_Unwind_GetIP
	.align	2					*	.align	2
	.globl	__Unwind_GetIPInfo			*	.globl	_Unwind_GetIPInfo
							*	.hidden	_Unwind_GetIPInfo
							*	.type	_Unwind_GetIPInfo, @function
__Unwind_GetIPInfo:					*_Unwind_GetIPInfo:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 128(a0),d0				*	move.l 128(%a0),%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	move.l 8(sp),a1					*	move.l 8(%sp),%a1
	move.l d0,(a1)					*	move.l %d0,(%a1)
	move.l 108(a0),d0				*	move.l 108(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetIPInfo, .-_Unwind_GetIPInfo
	.align	2					*	.align	2
	.globl	__Unwind_SetIP				*	.globl	_Unwind_SetIP
							*	.hidden	_Unwind_SetIP
							*	.type	_Unwind_SetIP, @function
__Unwind_SetIP:						*_Unwind_SetIP:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),108(a0)				*	move.l 8(%sp),108(%a0)
	rts						*	rts
							*	.size	_Unwind_SetIP, .-_Unwind_SetIP
	.align	2					*	.align	2
	.globl	__Unwind_GetLanguageSpecificData	*	.globl	_Unwind_GetLanguageSpecificData
							*	.hidden	_Unwind_GetLanguageSpecificData
							*	.type	_Unwind_GetLanguageSpecificData, @function
__Unwind_GetLanguageSpecificData:			*_Unwind_GetLanguageSpecificData:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 112(a0),d0				*	move.l 112(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetLanguageSpecificData, .-_Unwind_GetLanguageSpecificData
	.align	2					*	.align	2
	.globl	__Unwind_GetRegionStart			*	.globl	_Unwind_GetRegionStart
							*	.hidden	_Unwind_GetRegionStart
							*	.type	_Unwind_GetRegionStart, @function
__Unwind_GetRegionStart:				*_Unwind_GetRegionStart:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 124(a0),d0				*	move.l 124(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetRegionStart, .-_Unwind_GetRegionStart
	.align	2					*	.align	2
	.globl	__Unwind_FindEnclosingFunction		*	.globl	_Unwind_FindEnclosingFunction
							*	.hidden	_Unwind_FindEnclosingFunction
							*	.type	_Unwind_FindEnclosingFunction, @function
__Unwind_FindEnclosingFunction:				*_Unwind_FindEnclosingFunction:
	link.w a6,#-12					*	link.w %fp,#-12
	pea -12(a6)					*	pea -12(%fp)
	move.l 8(a6),d0					*	move.l 8(%fp),%d0
	subq.l #1,d0					*	subq.l #1,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr __Unwind_Find_FDE				*	jsr _Unwind_Find_FDE
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L771					*	jeq .L771
	move.l -4(a6),d0				*	move.l -4(%fp),%d0
_?L771:							*.L771:
	unlk a6						*	unlk %fp
	rts						*	rts
							*	.size	_Unwind_FindEnclosingFunction, .-_Unwind_FindEnclosingFunction
	.align	2					*	.align	2
	.globl	__Unwind_GetDataRelBase			*	.globl	_Unwind_GetDataRelBase
							*	.hidden	_Unwind_GetDataRelBase
							*	.type	_Unwind_GetDataRelBase, @function
__Unwind_GetDataRelBase:				*_Unwind_GetDataRelBase:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 120(a0),d0				*	move.l 120(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetDataRelBase, .-_Unwind_GetDataRelBase
	.align	2					*	.align	2
	.globl	__Unwind_GetTextRelBase			*	.globl	_Unwind_GetTextRelBase
							*	.hidden	_Unwind_GetTextRelBase
							*	.type	_Unwind_GetTextRelBase, @function
__Unwind_GetTextRelBase:				*_Unwind_GetTextRelBase:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 116(a0),d0				*	move.l 116(%a0),%d0
	rts						*	rts
							*	.size	_Unwind_GetTextRelBase, .-_Unwind_GetTextRelBase
	.align	2					*	.align	2
	.globl	___frame_state_for			*	.globl	__frame_state_for
							*	.hidden	__frame_state_for
							*	.type	__frame_state_for, @function
___frame_state_for:					*__frame_state_for:
	lea (-344,sp),sp				*	lea (-344,%sp),%sp
	movem.l d3/a3/a4/a5,-(sp)			*	movem.l #4124,-(%sp)
	move.l 368(sp),a5				*	move.l 368(%sp),%a5
	lea (18,sp),a3					*	lea (18,%sp),%a3
	pea 166.w					*	pea 166.w
	clr.l -(sp)					*	clr.l -(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _memset					*	jsr memset
	move.l #1073741824,158(sp)			*	move.l #1073741824,158(%sp)
	move.l 376(sp),d0				*	move.l 376(%sp),%d0
	addq.l #1,d0					*	addq.l #1,%d0
	move.l d0,138(sp)				*	move.l %d0,138(%sp)
	move.l sp,d3					*	move.l %sp,%d3
	add.l #196,d3					*	add.l #196,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _uw_frame_state_for			*	jsr uw_frame_state_for
	lea (20,sp),sp					*	lea (20,%sp),%sp
	tst.l d0					*	tst.l %d0
	jbne _?L788					*	jne .L788
	cmp.b #2,314(sp)				*	cmp.b #2,314(%sp)
	jbeq _?L788					*	jeq .L788
	lea (288,sp),a0					*	lea (288,%sp),%a0
	lea (124,a5),a3					*	lea (124,%a5),%a3
	lea (16,a5),a2					*	lea (16,%a5),%a2
	move.l d3,a1					*	move.l %d3,%a1
	lea (314,sp),a4					*	lea (314,%sp),%a4
_?L786:							*.L786:
	move.b (a0)+,d1					*	move.b (%a0)+,%d1
	move.b d1,(a3)+					*	move.b %d1,(%a3)+
	cmp.b #1,d1					*	cmp.b #1,%d1
	jbeq _?L784					*	jeq .L784
	cmp.b #2,d1					*	cmp.b #2,%d1
	jbeq _?L784					*	jeq .L784
	clr.l d1					*	clr.l %d1
	move.l d1,(a2)+					*	move.l %d1,(%a2)+
	addq.l #4,a1					*	addq.l #4,%a1
	cmp.l a0,a4					*	cmp.l %a0,%a4
	jbne _?L786					*	jne .L786
_?L793:							*.L793:
	move.l 320(sp),8(a5)				*	move.l 320(%sp),8(%a5)
	move.w 326(sp),120(a5)				*	move.w 326(%sp),120(%a5)
	move.w 350(sp),122(a5)				*	move.w 350(%sp),122(%a5)
	move.l 154(sp),12(a5)				*	move.l 154(%sp),12(%a5)
	move.l 356(sp),4(a5)				*	move.l 356(%sp),4(%a5)
	move.l a5,d0					*	move.l %a5,%d0
	movem.l (sp)+,d3/a3/a4/a5			*	movem.l (%sp)+,#14344
	lea (344,sp),sp					*	lea (344,%sp),%sp
	rts						*	rts
_?L784:							*.L784:
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l d1,(a2)+					*	move.l %d1,(%a2)+
	addq.l #4,a1					*	addq.l #4,%a1
	cmp.l a0,a4					*	cmp.l %a0,%a4
	jbne _?L786					*	jne .L786
	jbra _?L793					*	jra .L793
_?L788:							*.L788:
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/a3/a4/a5			*	movem.l (%sp)+,#14344
	lea (344,sp),sp					*	lea (344,%sp),%sp
	rts						*	rts
							*	.size	__frame_state_for, .-__frame_state_for
	.align	2					*	.align	2
							*	.type	_Unwind_DebugHook, @function
__Unwind_DebugHook:					*_Unwind_DebugHook:
	rts						*	rts
							*	.size	_Unwind_DebugHook, .-_Unwind_DebugHook
	.align	2					*	.align	2
	.globl	__Unwind_RaiseException			*	.globl	_Unwind_RaiseException
							*	.hidden	_Unwind_RaiseException
							*	.type	_Unwind_RaiseException, @function
__Unwind_RaiseException:				*_Unwind_RaiseException:
	link.w a6,#-508					*	link.w %fp,#-508
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d5					*	move.l %fp,%d5
	add.l #-508,d5					*	add.l #-508,%d5
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-342,d3					*	add.l #-342,%d3
	pea 166.w					*	pea 166.w
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l #_memcpy,d6				*	move.l #memcpy,%d6
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-176,d4					*	add.l #-176,%d4
	lea _uw_frame_state_for,a4			*	lea uw_frame_state_for,%a4
	lea _uw_update_context_1,a5			*	lea uw_update_context_1,%a5
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #5,d1					*	moveq #5,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L796					*	jeq .L796
_?L824:							*.L824:
	tst.l d0					*	tst.l %d0
	jbne _?L803					*	jne .L803
	move.l -24(a6),a0				*	move.l -24(%fp),%a0
	tst.l a0					*	tst.l %a0
	jbeq _?L804					*	jeq .L804
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 4(a3),-(sp)				*	move.l 4(%a3),-(%sp)
	move.l (a3),-(sp)				*	move.l (%a3),-(%sp)
	pea 1.w						*	pea 1.w
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #6,d1					*	moveq #6,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L802					*	jeq .L802
	subq.l #8,d0					*	subq.l #8,%d0
	jbne _?L803					*	jne .L803
_?L804:							*.L804:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -12(a6),d0				*	move.l -12(%fp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #7,-72(a6,d0.l)				*	cmp.b #7,-72(%fp,%d0.l)
	jbne _?L823					*	jne .L823
	clr.l d0					*	clr.l %d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
_?L825:							*.L825:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #5,d1					*	moveq #5,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L824					*	jne .L824
_?L796:							*.L796:
	sub.l a0,a0					*	sub.l %a0,%a0
_?L812:							*.L812:
	movem.l -620(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -620(%fp),#14587
	fmovem -580(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -580(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L823:							*.L823:
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L808					*	jlt .L808
	move.b _dwarf_reg_size_table(d0.l),d1		*	move.b dwarf_reg_size_table(%d0.l),%d1
	move.l -342(a6,d0.l*4),a0			*	move.l -342(%fp,%d0.l*4),%a0
	btst #6,-214(a6)				*	btst #6,-214(%fp)
	jbeq _?L806					*	jeq .L806
	tst.b -202(a6,d0.l)				*	tst.b -202(%fp,%d0.l)
	jbne _?L807					*	jne .L807
_?L806:							*.L806:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L808					*	jne .L808
	move.l (a0),a0					*	move.l (%a0),%a0
_?L807:							*.L807:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
	jbra _?L825					*	jra .L825
_?L803:							*.L803:
	moveq #3,d0					*	moveq #3,%d0
	sub.l a0,a0					*	sub.l %a0,%a0
	jbra _?L812					*	jra .L812
_?L802:							*.L802:
	clr.l 12(a3)					*	clr.l 12(%a3)
	move.l -214(a6),d0				*	move.l -214(%fp),%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	neg.l d0					*	neg.l %d0
	move.l -238(a6),d1				*	move.l -238(%fp),%d1
	sub.l d0,d1					*	sub.l %d0,%d1
	move.l d1,16(a3)				*	move.l %d1,16(%a3)
	pea 166.w					*	pea 166.w
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_RaiseException_Phase2		*	jsr _Unwind_RaiseException_Phase2
	lea (24,sp),sp					*	lea (24,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbne _?L796					*	jne .L796
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,d3					*	move.l %d0,%d3
	move.l -234(a6),d4				*	move.l -234(%fp),%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l -238(a6),-(sp)				*	move.l -238(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d3,a0					*	move.l %d3,%a0
	move.l d4,4(a6,d3.l)				*	move.l %d4,4(%fp,%d3.l)
	movem.l -620(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -620(%fp),#14587
	fmovem -580(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -580(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L808:							*.L808:
	trap #7						*	trap #7
							*	.size	_Unwind_RaiseException, .-_Unwind_RaiseException
	.align	2					*	.align	2
	.globl	__Unwind_ForcedUnwind			*	.globl	_Unwind_ForcedUnwind
							*	.hidden	_Unwind_ForcedUnwind
							*	.type	_Unwind_ForcedUnwind, @function
__Unwind_ForcedUnwind:					*_Unwind_ForcedUnwind:
	link.w a6,#-336					*	link.w %fp,#-336
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-332,d3					*	add.l #-332,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-166,d4					*	add.l #-166,%d4
	pea 166.w					*	pea 166.w
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	move.l 12(a6),12(a3)				*	move.l 12(%fp),12(%a3)
	move.l 16(a6),16(a3)				*	move.l 16(%fp),16(%a3)
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_ForcedUnwind_Phase2		*	jsr _Unwind_ForcedUnwind_Phase2
	lea (36,sp),sp					*	lea (36,%sp),%sp
	moveq #7,d1					*	moveq #7,%d1
	sub.l a0,a0					*	sub.l %a0,%a0
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L833					*	jeq .L833
	movem.l -448(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -448(%fp),#14587
	fmovem -408(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -408(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L833:							*.L833:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,d3					*	move.l %d0,%d3
	move.l -58(a6),d4				*	move.l -58(%fp),%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l -62(a6),-(sp)				*	move.l -62(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d3,a0					*	move.l %d3,%a0
	move.l d4,4(a6,d3.l)				*	move.l %d4,4(%fp,%d3.l)
	movem.l -448(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -448(%fp),#14587
	fmovem -408(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -408(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
							*	.size	_Unwind_ForcedUnwind, .-_Unwind_ForcedUnwind
	.align	2					*	.align	2
	.globl	__Unwind_Resume				*	.globl	_Unwind_Resume
							*	.hidden	_Unwind_Resume
							*	.type	_Unwind_Resume, @function
__Unwind_Resume:					*_Unwind_Resume:
	link.w a6,#-336					*	link.w %fp,#-336
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-332,d3					*	add.l #-332,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-166,d4					*	add.l #-166,%d4
	pea 166.w					*	pea 166.w
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	lea (24,sp),sp					*	lea (24,%sp),%sp
	tst.l 12(a3)					*	tst.l 12(%a3)
	jbne _?L835					*	jne .L835
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_RaiseException_Phase2		*	jsr _Unwind_RaiseException_Phase2
	lea (12,sp),sp					*	lea (12,%sp),%sp
_?L836:							*.L836:
	subq.l #7,d0					*	subq.l #7,%d0
	jbne _?L842					*	jne .L842
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,d3					*	move.l %d0,%d3
	move.l -58(a6),d4				*	move.l -58(%fp),%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l -62(a6),-(sp)				*	move.l -62(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l d3,a0					*	move.l %d3,%a0
	move.l d4,4(a6,d3.l)				*	move.l %d4,4(%fp,%d3.l)
	movem.l -448(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -448(%fp),#14587
	fmovem -408(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -408(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L835:							*.L835:
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_ForcedUnwind_Phase2		*	jsr _Unwind_ForcedUnwind_Phase2
	lea (12,sp),sp					*	lea (12,%sp),%sp
	jbra _?L836					*	jra .L836
_?L842:							*.L842:
	trap #7						*	trap #7
							*	.size	_Unwind_Resume, .-_Unwind_Resume
	.align	2					*	.align	2
	.globl	__Unwind_Resume_or_Rethrow		*	.globl	_Unwind_Resume_or_Rethrow
							*	.hidden	_Unwind_Resume_or_Rethrow
							*	.type	_Unwind_Resume_or_Rethrow, @function
__Unwind_Resume_or_Rethrow:				*_Unwind_Resume_or_Rethrow:
	link.w a6,#-336					*	link.w %fp,#-336
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	movem.l d0/d1/d3/d4/d5/d6/d7/a3/a4/a5,-(sp)	*	movem.l #57116,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	tst.l 12(a3)					*	tst.l 12(%a3)
	jbne _?L844					*	jne .L844
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_RaiseException			*	jsr _Unwind_RaiseException
	addq.l #4,sp					*	addq.l #4,%sp
	sub.l a0,a0					*	sub.l %a0,%a0
	movem.l -448(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -448(%fp),#14587
	fmovem -408(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -408(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L844:							*.L844:
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d3					*	move.l %fp,%d3
	add.l #-332,d3					*	add.l #-332,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-166,d4					*	add.l #-166,%d4
	pea 166.w					*	pea 166.w
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _memcpy					*	jsr memcpy
	pea -336(a6)					*	pea -336(%fp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr __Unwind_ForcedUnwind_Phase2		*	jsr _Unwind_ForcedUnwind_Phase2
	lea (36,sp),sp					*	lea (36,%sp),%sp
	subq.l #7,d0					*	subq.l #7,%d0
	jbne _?L850					*	jne .L850
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr _uw_install_context_1			*	jsr uw_install_context_1
	move.l d0,a3					*	move.l %d0,%a3
	move.l -58(a6),d3				*	move.l -58(%fp),%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l -62(a6),-(sp)				*	move.l -62(%fp),-(%sp)
	jbsr __Unwind_DebugHook				*	jsr _Unwind_DebugHook
	lea (16,sp),sp					*	lea (16,%sp),%sp
	move.l a3,a0					*	move.l %a3,%a0
	move.l d3,4(a6,a3.l)				*	move.l %d3,4(%fp,%a3.l)
	movem.l -448(a6),d0/d1/d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -448(%fp),#14587
	fmovem -408(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -408(%fp),#63
	unlk a6						*	unlk %fp
	add.l a0,sp					*	add.l %a0,%sp
	rts						*	rts
_?L850:							*.L850:
	trap #7						*	trap #7
							*	.size	_Unwind_Resume_or_Rethrow, .-_Unwind_Resume_or_Rethrow
	.align	2					*	.align	2
	.globl	__Unwind_DeleteException		*	.globl	_Unwind_DeleteException
							*	.hidden	_Unwind_DeleteException
							*	.type	_Unwind_DeleteException, @function
__Unwind_DeleteException:				*_Unwind_DeleteException:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(a1),a0					*	move.l 8(%a1),%a0
	tst.l a0					*	tst.l %a0
	jbeq _?L851					*	jeq .L851
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	pea 1.w						*	pea 1.w
	jbsr (a0)					*	jsr (%a0)
	addq.l #8,sp					*	addq.l #8,%sp
_?L851:							*.L851:
	rts						*	rts
							*	.size	_Unwind_DeleteException, .-_Unwind_DeleteException
	.align	2					*	.align	2
	.globl	__Unwind_Backtrace			*	.globl	_Unwind_Backtrace
							*	.hidden	_Unwind_Backtrace
							*	.type	_Unwind_Backtrace, @function
__Unwind_Backtrace:					*_Unwind_Backtrace:
	link.w a6,#-344					*	link.w %fp,#-344
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a4					*	move.l 8(%fp),%a4
	move.l 12(a6),d6				*	move.l 12(%fp),%d6
	move.l 4(a6),-(sp)				*	move.l 4(%fp),-(%sp)
	pea 8(a6)					*	pea 8(%fp)
	move.l a6,d4					*	move.l %fp,%d4
	add.l #-342,d4					*	add.l #-342,%d4
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr _uw_init_context_1				*	jsr uw_init_context_1
	lea (12,sp),sp					*	lea (12,%sp),%sp
	move.l a6,d5					*	move.l %fp,%d5
	add.l #-176,d5					*	add.l #-176,%d5
	lea _uw_frame_state_for,a3			*	lea uw_frame_state_for,%a3
	lea _uw_update_context_1,a5			*	lea uw_update_context_1,%a5
_?L867:							*.L867:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l d0,d3					*	move.l %d0,%d3
	addq.l #8,sp					*	addq.l #8,%sp
	jbeq _?L859					*	jeq .L859
	moveq #5,d0					*	moveq #5,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbeq _?L860					*	jeq .L860
	subq.l #4,d3					*	subq.l #4,%d3
	jbne _?L861					*	jne .L861
_?L859:							*.L859:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbne _?L861					*	jne .L861
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -12(a6),d0				*	move.l -12(%fp),%d0
	addq.l #8,sp					*	addq.l #8,%sp
	cmp.b #7,-72(a6,d0.l)				*	cmp.b #7,-72(%fp,%d0.l)
	jbeq _?L870					*	jeq .L870
	moveq #25,d1					*	moveq #25,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jblt _?L866					*	jlt .L866
	move.b _dwarf_reg_size_table(d0.l),d1		*	move.b dwarf_reg_size_table(%d0.l),%d1
	move.l -342(a6,d0.l*4),a0			*	move.l -342(%fp,%d0.l*4),%a0
	btst #6,-214(a6)				*	btst #6,-214(%fp)
	jbeq _?L864					*	jeq .L864
	tst.b -202(a6,d0.l)				*	tst.b -202(%fp,%d0.l)
	jbne _?L865					*	jne .L865
_?L864:							*.L864:
	cmp.b #4,d1					*	cmp.b #4,%d1
	jbne _?L866					*	jne .L866
	move.l (a0),a0					*	move.l (%a0),%a0
_?L865:							*.L865:
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
	jbra _?L867					*	jra .L867
_?L860:							*.L860:
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L858					*	jeq .L858
_?L861:							*.L861:
	moveq #3,d3					*	moveq #3,%d3
_?L858:							*.L858:
	move.l d3,d0					*	move.l %d3,%d0
	movem.l -448(a6),d3/d4/d5/d6/d7/a3/a4/a5	*	movem.l -448(%fp),#14584
	fmovem -416(a6),fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem -416(%fp),#63
	unlk a6						*	unlk %fp
	rts						*	rts
_?L870:							*.L870:
	clr.l d0					*	clr.l %d0
	move.l d0,-234(a6)				*	move.l %d0,-234(%fp)
	jbra _?L867					*	jra .L867
_?L866:							*.L866:
	trap #7						*	trap #7
							*	.size	_Unwind_Backtrace, .-_Unwind_Backtrace
							*	.local	dwarf_reg_size_table
	.comm	_dwarf_reg_size_table,26		*	.comm	dwarf_reg_size_table,26,1
							*	.ident	"GCC: (GNU) 13.4.0"
