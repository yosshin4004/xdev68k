* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	2147418112				*	.long	2147418112
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC1:							*.LC1:
	.dc.l	2147287040				*	.long	2147287040
	.dc.l	-1					*	.long	-1
	.dc.l	-1					*	.long	-1
	.align	2					*	.align	2
_?LC2:							*.LC2:
	.dc.l	1073610752				*	.long	1073610752
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC3:							*.LC3:
	.dc.l	1069547520				*	.long	1069547520
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC4:							*.LC4:
	.dc.l	1077805056				*	.long	1077805056
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC5:							*.LC5:
	.dc.l	0					*	.long	0
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC6:							*.LC6:
	.dc.l	2143158272				*	.long	2143158272
	.dc.l	-1					*	.long	-1
	.dc.l	-1					*	.long	-1
	.align	2					*	.align	2
_?LC7:							*.LC7:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC8:							*.LC8:
	.dc.l	2147352576				*	.long	2147352576
	.dc.l	-1					*	.long	-1
	.dc.l	-1					*	.long	-1
	.align	2					*	.align	2
_?LC9:							*.LC9:
	.dc.l	-65536					*	.long	-65536
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divxc3				*	.globl	__divxc3
							*	.hidden	__divxc3
							*	.type	__divxc3, @function
___divxc3:						*__divxc3:
	fmovem fp2/fp3/fp4/fp5/fp6,-(sp)		*	fmovem #124,-(%sp)
	fabs.x 88(sp),fp1				*	fabs.x 88(%sp),%fp1
	fabs.x 100(sp),fp2				*	fabs.x 100(%sp),%fp2
	fcmp.x fp2,fp1					*	fcmp.x %fp2,%fp1
	fbnlt _?L77					*	fjnlt .L77
	fcmp.x _?LC1,fp2				*	fcmp.x .LC1,%fp2
	fbnge _?L4					*	fjnge .L4
	fmove.x _?LC2,fp2				*	fmove.x .LC2,%fp2
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,64(sp)				*	fmove.x %fp0,64(%sp)
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,76(sp)				*	fmove.x %fp0,76(%sp)
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,88(sp)				*	fmove.x %fp0,88(%sp)
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fmove.x fp2,100(sp)				*	fmove.x %fp2,100(%sp)
	fabs.x fp2,fp2					*	fabs.x %fp2,%fp2
_?L4:							*.L4:
	fcmp.x _?LC3,fp2				*	fcmp.x .LC3,%fp2
	fbnlt _?L78					*	fjnlt .L78
	fmove.x _?LC4,fp2				*	fmove.x .LC4,%fp2
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,64(sp)				*	fmove.x %fp0,64(%sp)
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,76(sp)				*	fmove.x %fp0,76(%sp)
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,88(sp)				*	fmove.x %fp0,88(%sp)
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fmove.x fp2,100(sp)				*	fmove.x %fp2,100(%sp)
	fmove.x _?LC5,fp5				*	fmove.x .LC5,%fp5
_?L8:							*.L8:
	fmove.x 88(sp),fp1				*	fmove.x 88(%sp),%fp1
	fdiv.x 100(sp),fp1				*	fdiv.x 100(%sp),%fp1
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fadd.x 100(sp),fp0				*	fadd.x 100(%sp),%fp0
	fabs.x fp1,fp2					*	fabs.x %fp1,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fbngt _?L80					*	fjngt .L80
_?L96:							*.L96:
	fmove.x 64(sp),fp2				*	fmove.x 64(%sp),%fp2
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fadd.x 76(sp),fp2				*	fadd.x 76(%sp),%fp2
	fdiv.x fp0,fp2					*	fdiv.x %fp0,%fp2
	fmove.x 76(sp),fp5				*	fmove.x 76(%sp),%fp5
	fmul.x fp1,fp5					*	fmul.x %fp1,%fp5
	fsub.x 64(sp),fp5				*	fsub.x 64(%sp),%fp5
	fdiv.x fp0,fp5					*	fdiv.x %fp0,%fp5
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbun _?L92					*	fjun .L92
_?L31:							*.L31:
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L77:							*.L77:
	fcmp.x _?LC1,fp1				*	fcmp.x .LC1,%fp1
	fbnge _?L18					*	fjnge .L18
	fmove.x _?LC2,fp2				*	fmove.x .LC2,%fp2
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,64(sp)				*	fmove.x %fp0,64(%sp)
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,76(sp)				*	fmove.x %fp0,76(%sp)
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,88(sp)				*	fmove.x %fp0,88(%sp)
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fmove.x fp2,100(sp)				*	fmove.x %fp2,100(%sp)
	fabs.x fp0,fp1					*	fabs.x %fp0,%fp1
_?L18:							*.L18:
	fcmp.x _?LC3,fp1				*	fcmp.x .LC3,%fp1
	fbnlt _?L81					*	fjnlt .L81
	fmove.x _?LC4,fp2				*	fmove.x .LC4,%fp2
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,64(sp)				*	fmove.x %fp0,64(%sp)
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,76(sp)				*	fmove.x %fp0,76(%sp)
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,88(sp)				*	fmove.x %fp0,88(%sp)
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fmove.x fp2,100(sp)				*	fmove.x %fp2,100(%sp)
	fmove.x _?LC5,fp5				*	fmove.x .LC5,%fp5
_?L22:							*.L22:
	fmove.x 100(sp),fp1				*	fmove.x 100(%sp),%fp1
	fdiv.x 88(sp),fp1				*	fdiv.x 88(%sp),%fp1
	fmove.x 100(sp),fp0				*	fmove.x 100(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fadd.x 88(sp),fp0				*	fadd.x 88(%sp),%fp0
	fabs.x fp1,fp2					*	fabs.x %fp1,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fbngt _?L83					*	fjngt .L83
_?L94:							*.L94:
	fmove.x 76(sp),fp2				*	fmove.x 76(%sp),%fp2
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fadd.x 64(sp),fp2				*	fadd.x 64(%sp),%fp2
	fdiv.x fp0,fp2					*	fdiv.x %fp0,%fp2
	fmul.x 64(sp),fp1				*	fmul.x 64(%sp),%fp1
	fmove.x 76(sp),fp5				*	fmove.x 76(%sp),%fp5
	fsub.x fp1,fp5					*	fsub.x %fp1,%fp5
	fdiv.x fp0,fp5					*	fdiv.x %fp0,%fp5
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbor _?L31					*	fjor .L31
	jbra _?L92					*	jra .L92
_?L81:							*.L81:
	fabs.x 64(sp),fp2				*	fabs.x 64(%sp),%fp2
	fabs.x 76(sp),fp3				*	fabs.x 76(%sp),%fp3
	fmove.x _?LC5,fp5				*	fmove.x .LC5,%fp5
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fblt _?L93					*	fjlt .L93
	fcmp.x fp5,fp3					*	fcmp.x %fp5,%fp3
	fbnlt _?L22					*	fjnlt .L22
	fmove.x _?LC6,fp0				*	fmove.x .LC6,%fp0
	fcmp.x fp0,fp2					*	fcmp.x %fp0,%fp2
	fbnlt _?L22					*	fjnlt .L22
_?L25:							*.L25:
	fcmp.x fp0,fp1					*	fcmp.x %fp0,%fp1
	fbnlt _?L22					*	fjnlt .L22
	fmove.x _?LC4,fp2				*	fmove.x .LC4,%fp2
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,64(sp)				*	fmove.x %fp0,64(%sp)
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,76(sp)				*	fmove.x %fp0,76(%sp)
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,88(sp)				*	fmove.x %fp0,88(%sp)
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fmove.x fp2,100(sp)				*	fmove.x %fp2,100(%sp)
	fmove.x 100(sp),fp1				*	fmove.x 100(%sp),%fp1
	fdiv.x 88(sp),fp1				*	fdiv.x 88(%sp),%fp1
	fmove.x 100(sp),fp0				*	fmove.x 100(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fadd.x 88(sp),fp0				*	fadd.x 88(%sp),%fp0
	fabs.x fp1,fp2					*	fabs.x %fp1,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fbgt _?L94					*	fjgt .L94
_?L83:							*.L83:
	fmove.x 76(sp),fp2				*	fmove.x 76(%sp),%fp2
	fdiv.x 88(sp),fp2				*	fdiv.x 88(%sp),%fp2
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fadd.x 64(sp),fp2				*	fadd.x 64(%sp),%fp2
	fdiv.x fp0,fp2					*	fdiv.x %fp0,%fp2
	fmove.x 64(sp),fp5				*	fmove.x 64(%sp),%fp5
	fdiv.x 88(sp),fp5				*	fdiv.x 88(%sp),%fp5
	fmove.x 100(sp),fp1				*	fmove.x 100(%sp),%fp1
	fmul.x fp5,fp1					*	fmul.x %fp5,%fp1
	fmove.x 76(sp),fp5				*	fmove.x 76(%sp),%fp5
	fsub.x fp1,fp5					*	fsub.x %fp1,%fp5
	fdiv.x fp0,fp5					*	fdiv.x %fp0,%fp5
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbor _?L31					*	fjor .L31
	jbra _?L92					*	jra .L92
_?L78:							*.L78:
	fabs.x 64(sp),fp1				*	fabs.x 64(%sp),%fp1
	fabs.x 76(sp),fp3				*	fabs.x 76(%sp),%fp3
	fmove.x _?LC5,fp5				*	fmove.x .LC5,%fp5
	fcmp.x fp5,fp1					*	fcmp.x %fp5,%fp1
	fblt _?L95					*	fjlt .L95
	fcmp.x fp5,fp3					*	fcmp.x %fp5,%fp3
	fbnlt _?L8					*	fjnlt .L8
	fmove.x _?LC6,fp0				*	fmove.x .LC6,%fp0
	fcmp.x fp0,fp1					*	fcmp.x %fp0,%fp1
	fbnlt _?L8					*	fjnlt .L8
_?L11:							*.L11:
	fcmp.x fp0,fp2					*	fcmp.x %fp0,%fp2
	fbnlt _?L8					*	fjnlt .L8
	fmove.x _?LC4,fp2				*	fmove.x .LC4,%fp2
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,64(sp)				*	fmove.x %fp0,64(%sp)
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,76(sp)				*	fmove.x %fp0,76(%sp)
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp2,fp0					*	fmul.x %fp2,%fp0
	fmove.x fp0,88(sp)				*	fmove.x %fp0,88(%sp)
	fmul.x 100(sp),fp2				*	fmul.x 100(%sp),%fp2
	fmove.x fp2,100(sp)				*	fmove.x %fp2,100(%sp)
	fmove.x 88(sp),fp1				*	fmove.x 88(%sp),%fp1
	fdiv.x 100(sp),fp1				*	fdiv.x 100(%sp),%fp1
	fmove.x 88(sp),fp0				*	fmove.x 88(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fadd.x 100(sp),fp0				*	fadd.x 100(%sp),%fp0
	fabs.x fp1,fp2					*	fabs.x %fp1,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fbgt _?L96					*	fjgt .L96
_?L80:							*.L80:
	fmove.x 64(sp),fp2				*	fmove.x 64(%sp),%fp2
	fdiv.x 100(sp),fp2				*	fdiv.x 100(%sp),%fp2
	fmul.x 88(sp),fp2				*	fmul.x 88(%sp),%fp2
	fadd.x 76(sp),fp2				*	fadd.x 76(%sp),%fp2
	fdiv.x fp0,fp2					*	fdiv.x %fp0,%fp2
	fmove.x 76(sp),fp5				*	fmove.x 76(%sp),%fp5
	fdiv.x 100(sp),fp5				*	fdiv.x 100(%sp),%fp5
	fmul.x 88(sp),fp5				*	fmul.x 88(%sp),%fp5
	fsub.x 64(sp),fp5				*	fsub.x 64(%sp),%fp5
	fdiv.x fp0,fp5					*	fdiv.x %fp0,%fp5
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbor _?L31					*	fjor .L31
	jbra _?L92					*	jra .L92
_?L95:							*.L95:
	fmove.x _?LC6,fp0				*	fmove.x .LC6,%fp0
	fcmp.x fp0,fp3					*	fcmp.x %fp0,%fp3
	fblt _?L11					*	fjlt .L11
	jbra _?L8					*	jra .L8
_?L93:							*.L93:
	fmove.x _?LC6,fp0				*	fmove.x .LC6,%fp0
	fcmp.x fp0,fp3					*	fcmp.x %fp0,%fp3
	fblt _?L25					*	fjlt .L25
	jbra _?L22					*	jra .L22
_?L92:							*.L92:
	fcmp.x fp5,fp5					*	fcmp.x %fp5,%fp5
	fbor _?L31					*	fjor .L31
	fmove.x _?LC7,fp4				*	fmove.x .LC7,%fp4
	fcmp.x 88(sp),fp4				*	fcmp.x 88(%sp),%fp4
	fbne _?L32					*	fjne .L32
	fcmp.x 100(sp),fp4				*	fcmp.x 100(%sp),%fp4
	fbeq _?L33					*	fjeq .L33
	fabs.x 64(sp),fp6				*	fabs.x 64(%sp),%fp6
	fmove.x _?LC8,fp3				*	fmove.x .LC8,%fp3
	fcmp.x fp3,fp6					*	fcmp.x %fp3,%fp6
	fbule _?L34					*	fjule .L34
_?L86:							*.L86:
	clr.b d0					*	clr.b %d0
	fmove.x _?LC0,fp6				*	fmove.x .LC0,%fp6
_?L35:							*.L35:
	fabs.x 100(sp),fp0				*	fabs.x 100(%sp),%fp0
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbugt _?L40					*	fjugt .L40
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 64(sp)					*	tst.l 64(%sp)
	jbge _?L41					*	jge .L41
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L41:							*.L41:
	fabs.x 76(sp),fp2				*	fabs.x 76(%sp),%fp2
	fcmp.x fp3,fp2					*	fcmp.x %fp3,%fp2
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp5					*	fmove.l %d0,%fp5
	fabs.x fp5,fp5					*	fabs.x %fp5,%fp5
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L42					*	jge .L42
	fneg.x fp5,fp5					*	fneg.x %fp5,%fp5
_?L42:							*.L42:
	fmove.x 88(sp),fp2				*	fmove.x 88(%sp),%fp2
	fmul.x fp0,fp2					*	fmul.x %fp0,%fp2
	fmove.x 100(sp),fp1				*	fmove.x 100(%sp),%fp1
	fmul.x fp5,fp1					*	fmul.x %fp5,%fp1
	fadd.x fp1,fp2					*	fadd.x %fp1,%fp2
	fmove.x _?LC0,fp1				*	fmove.x .LC0,%fp1
	fmul.x fp1,fp2					*	fmul.x %fp1,%fp2
	fmul.x 88(sp),fp5				*	fmul.x 88(%sp),%fp5
	fmul.x 100(sp),fp0				*	fmul.x 100(%sp),%fp0
	fsub.x fp0,fp5					*	fsub.x %fp0,%fp5
	fmul.x fp1,fp5					*	fmul.x %fp1,%fp5
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L34:							*.L34:
	fabs.x 76(sp),fp0				*	fabs.x 76(%sp),%fp0
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbule _?L47					*	fjule .L47
_?L87:							*.L87:
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L35					*	jra .L35
_?L47:							*.L47:
	fabs.x 100(sp),fp0				*	fabs.x 100(%sp),%fp0
_?L40:							*.L40:
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbule _?L31					*	fjule .L31
	moveq #1,d0					*	moveq #1,%d0
_?L43:							*.L43:
	fcmp.x fp3,fp6					*	fcmp.x %fp3,%fp6
	fbugt _?L31					*	fjugt .L31
	fabs.x 76(sp),fp0				*	fabs.x 76(%sp),%fp0
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbugt _?L31					*	fjugt .L31
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 88(sp)					*	tst.l 88(%sp)
	jbge _?L45					*	jge .L45
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L45:							*.L45:
	fabs.x 100(sp),fp2				*	fabs.x 100(%sp),%fp2
	fcmp.x fp3,fp2					*	fcmp.x %fp3,%fp2
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp1					*	fmove.l %d0,%fp1
	fabs.x fp1,fp1					*	fabs.x %fp1,%fp1
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L46					*	jge .L46
	fneg.x fp1,fp1					*	fneg.x %fp1,%fp1
_?L46:							*.L46:
	fmove.x 64(sp),fp2				*	fmove.x 64(%sp),%fp2
	fmul.x fp0,fp2					*	fmul.x %fp0,%fp2
	fmove.x 76(sp),fp3				*	fmove.x 76(%sp),%fp3
	fmul.x fp1,fp3					*	fmul.x %fp1,%fp3
	fadd.x fp3,fp2					*	fadd.x %fp3,%fp2
	fmul.x fp4,fp2					*	fmul.x %fp4,%fp2
	fmove.x 76(sp),fp5				*	fmove.x 76(%sp),%fp5
	fmul.x fp0,fp5					*	fmul.x %fp0,%fp5
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fmul.x fp1,fp0					*	fmul.x %fp1,%fp0
	fsub.x fp0,fp5					*	fsub.x %fp0,%fp5
	fmul.x fp4,fp5					*	fmul.x %fp4,%fp5
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L32:							*.L32:
	fabs.x 64(sp),fp6				*	fabs.x 64(%sp),%fp6
	fabs.x 88(sp),fp0				*	fabs.x 88(%sp),%fp0
	fmove.x _?LC8,fp3				*	fmove.x .LC8,%fp3
	fcmp.x fp3,fp6					*	fcmp.x %fp3,%fp6
	fbule _?L38					*	fjule .L38
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbole _?L86					*	fjole .L86
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L33:							*.L33:
	fmove.x 64(sp),fp0				*	fmove.x 64(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L97					*	fjun .L97
_?L36:							*.L36:
	fmove.x _?LC0,fp5				*	fmove.x .LC0,%fp5
	tst.l 88(sp)					*	tst.l 88(%sp)
	jbge _?L37					*	jge .L37
	fmove.x _?LC9,fp5				*	fmove.x .LC9,%fp5
_?L37:							*.L37:
	fmove.x 64(sp),fp2				*	fmove.x 64(%sp),%fp2
	fmul.x fp5,fp2					*	fmul.x %fp5,%fp2
	fmul.x 76(sp),fp5				*	fmul.x 76(%sp),%fp5
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L97:							*.L97:
	fmove.x 76(sp),fp0				*	fmove.x 76(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L36					*	fjor .L36
	fmove.x fp2,(a0)				*	fmove.x %fp2,(%a0)
	fmove.x fp5,12(a0)				*	fmove.x %fp5,12(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L38:							*.L38:
	fabs.x 76(sp),fp1				*	fabs.x 76(%sp),%fp1
	fcmp.x fp3,fp1					*	fcmp.x %fp3,%fp1
	fbule _?L39					*	fjule .L39
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbole _?L87					*	fjole .L87
_?L39:							*.L39:
	fcmp.x fp3,fp0					*	fcmp.x %fp3,%fp0
	fbule _?L47					*	fjule .L47
	clr.b d0					*	clr.b %d0
	jbra _?L43					*	jra .L43
							*	.size	__divxc3, .-__divxc3
							*	.ident	"GCC: (GNU) 13.4.0"
