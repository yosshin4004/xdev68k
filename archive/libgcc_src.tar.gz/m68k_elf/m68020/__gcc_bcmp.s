* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___gcc_bcmp				*	.globl	__gcc_bcmp
							*	.hidden	__gcc_bcmp
							*	.type	__gcc_bcmp, @function
___gcc_bcmp:						*__gcc_bcmp:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),a1					*	move.l 8(%sp),%a1
	tst.l 12(sp)					*	tst.l 12(%sp)
	jbeq _?L5					*	jeq .L5
	move.l 12(sp),d2				*	move.l 12(%sp),%d2
	add.l a0,d2					*	add.l %a0,%d2
_?L4:							*.L4:
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	move.b (a1)+,d1					*	move.b (%a1)+,%d1
	cmp.b d0,d1					*	cmp.b %d0,%d1
	jbne _?L9					*	jne .L9
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbne _?L4					*	jne .L4
_?L5:							*.L5:
	clr.l d0					*	clr.l %d0
	rts						*	rts
_?L9:							*.L9:
	and.l #255,d0					*	and.l #255,%d0
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
							*	.size	__gcc_bcmp, .-__gcc_bcmp
							*	.ident	"GCC: (GNU) 13.4.0"
