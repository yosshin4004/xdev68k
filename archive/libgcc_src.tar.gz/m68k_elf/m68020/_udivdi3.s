* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___udivdi3				*	.globl	__udivdi3
							*	.hidden	__udivdi3
							*	.type	__udivdi3, @function
___udivdi3:						*__udivdi3:
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 24(sp),d0				*	move.l 24(%sp),%d0
	move.l 28(sp),d4				*	move.l 28(%sp),%d4
	move.l 32(sp),d2				*	move.l 32(%sp),%d2
	move.l 36(sp),d3				*	move.l 36(%sp),%d3
	tst.l d2					*	tst.l %d2
	jbne _?L2					*	jne .L2
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L3					*	jcc .L3
	move.l d4,d1					*	move.l %d4,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1016 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d0:d1					*	divu.l %d3,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L2:							*.L2:
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcc _?L14					*	jcc .L14
_?L10:							*.L10:
	clr.l d1					*	clr.l %d1
_?L11:							*.L11:
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L3:							*.L3:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1028 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d2:d0					*	divu.l %d3,%d2:%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d4,d1					*	move.l %d4,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1029 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d2:d1					*	divu.l %d3,%d2:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L14:							*.L14:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1139 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d2{#0:#32},d5				*	bfffo %d2{#0:#0},%d5
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	tst.l d5					*	tst.l %d5
	jbne _?L5					*	jne .L5
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbhi _?L6					*	jhi .L6
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbcs _?L10					*	jcs .L10
_?L6:							*.L6:
	moveq #1,d1					*	moveq #1,%d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L5:							*.L5:
	lsl.l d5,d2					*	lsl.l %d5,%d2
	moveq #32,d6					*	moveq #32,%d6
	sub.l d5,d6					*	sub.l %d5,%d6
	move.l d3,d7					*	move.l %d3,%d7
	lsr.l d6,d7					*	lsr.l %d6,%d7
	or.l d2,d7					*	or.l %d2,%d7
	lsl.l d5,d3					*	lsl.l %d5,%d3
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d6,d2					*	lsr.l %d6,%d2
	lsl.l d5,d0					*	lsl.l %d5,%d0
	move.l d4,d1					*	move.l %d4,%d1
	lsr.l d6,d1					*	lsr.l %d6,%d1
	or.l d0,d1					*	or.l %d0,%d1
	move.l d2,d0					*	move.l %d2,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1180 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d7,d0:d1					*	divu.l %d7,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,d2					*	move.l %d1,%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d3,d3:d2					*	mulu.l %d3,%d3:%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	cmp.l d0,d3					*	cmp.l %d0,%d3
	jbhi _?L7					*	jhi .L7
	jbne _?L11					*	jne .L11
	lsl.l d5,d4					*	lsl.l %d5,%d4
	cmp.l d4,d2					*	cmp.l %d4,%d2
	jbls _?L11					*	jls .L11
_?L7:							*.L7:
	subq.l #1,d1					*	subq.l #1,%d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
							*	.size	__udivdi3, .-__udivdi3
							*	.ident	"GCC: (GNU) 13.4.0"
