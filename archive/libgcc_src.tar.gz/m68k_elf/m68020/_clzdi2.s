* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clzdi2				*	.globl	__clzdi2
							*	.hidden	__clzdi2
							*	.type	__clzdi2, @function
___clzdi2:						*__clzdi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	tst.l d1					*	tst.l %d1
	jbeq _?L2					*	jeq .L2
	move.l d1,d0					*	move.l %d1,%d0
	clr.l d1					*	clr.l %d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 710 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d0				*	bfffo %d0{#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	add.l d1,d0					*	add.l %d1,%d0
	rts						*	rts
_?L2:							*.L2:
	moveq #32,d1					*	moveq #32,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 710 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d0				*	bfffo %d0{#0:#0},%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	add.l d1,d0					*	add.l %d1,%d0
	rts						*	rts
							*	.size	__clzdi2, .-__clzdi2
							*	.ident	"GCC: (GNU) 13.4.0"
