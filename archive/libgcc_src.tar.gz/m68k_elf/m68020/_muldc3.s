* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___muldc3				*	.globl	__muldc3
							*	.hidden	__muldc3
							*	.type	__muldc3, @function
___muldc3:						*__muldc3:
	lea (-32,sp),sp					*	lea (-32,%sp),%sp
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fmul.d 124(sp),fp0				*	fmul.d 124(%sp),%fp0
	fmove.d fp0,72(sp)				*	fmove.d %fp0,72(%sp)
	fmove.d 116(sp),fp3				*	fmove.d 116(%sp),%fp3
	fmul.d 132(sp),fp3				*	fmul.d 132(%sp),%fp3
	fmove.d fp3,80(sp)				*	fmove.d %fp3,80(%sp)
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fmul.d 132(sp),fp0				*	fmul.d 132(%sp),%fp0
	fmove.d fp0,88(sp)				*	fmove.d %fp0,88(%sp)
	fmove.d 124(sp),fp3				*	fmove.d 124(%sp),%fp3
	fmul.d 116(sp),fp3				*	fmul.d 116(%sp),%fp3
	fmove.d fp3,96(sp)				*	fmove.d %fp3,96(%sp)
	fmove.d 72(sp),fp2				*	fmove.d 72(%sp),%fp2
	fmove.d 80(sp),fp4				*	fmove.d 80(%sp),%fp4
	fmove.x fp2,fp0					*	fmove.x %fp2,%fp0
	fsub.x fp4,fp0					*	fsub.x %fp4,%fp0
	fmove.d 88(sp),fp6				*	fmove.d 88(%sp),%fp6
	fmove.d 96(sp),fp5				*	fmove.d 96(%sp),%fp5
	fmove.x fp6,fp1					*	fmove.x %fp6,%fp1
	fadd.x fp5,fp1					*	fadd.x %fp5,%fp1
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L76					*	fjun .L76
_?L2:							*.L2:
	fmove.d fp0,(a0)				*	fmove.d %fp0,(%a0)
	fmove.d fp1,8(a0)				*	fmove.d %fp1,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	lea (32,sp),sp					*	lea (32,%sp),%sp
	rts						*	rts
_?L76:							*.L76:
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L2					*	fjor .L2
	fabs.d 108(sp),fp3				*	fabs.d 108(%sp),%fp3
	fabs.d 116(sp),fp7				*	fabs.d 116(%sp),%fp7
	fcmp.d #0x7fefffff,#0xffffffff,fp3		*	fcmp.d #0x7fefffffffffffff,%fp3
	fbogt _?L3					*	fjogt .L3
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fbogt _?L3					*	fjogt .L3
	clr.b d0					*	clr.b %d0
_?L5:							*.L5:
	fabs.d 124(sp),fp3				*	fabs.d 124(%sp),%fp3
	fabs.d 132(sp),fp7				*	fabs.d 132(%sp),%fp7
	fcmp.d #0x7fefffff,#0xffffffff,fp3		*	fcmp.d #0x7fefffffffffffff,%fp3
	fbogt _?L11					*	fjogt .L11
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fbogt _?L11					*	fjogt .L11
	tst.b d0					*	tst.b %d0
	jbne _?L18					*	jne .L18
	fabs.x fp2,fp2					*	fabs.x %fp2,%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fabs.x fp4,fp4					*	fabs.x %fp4,%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbogt _?L20					*	fjogt .L20
	fabs.x fp6,fp6					*	fabs.x %fp6,%fp6
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fbogt _?L20					*	fjogt .L20
	fabs.x fp5,fp5					*	fabs.x %fp5,%fp5
	fcmp.d #0x7fefffff,#0xffffffff,fp5		*	fcmp.d #0x7fefffffffffffff,%fp5
	fbule _?L2					*	fjule .L2
_?L20:							*.L20:
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L77					*	fjun .L77
	fmove.d 116(sp),fp3				*	fmove.d 116(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbun _?L78					*	fjun .L78
_?L26:							*.L26:
	fmove.d 124(sp),fp0				*	fmove.d 124(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L79					*	fjun .L79
_?L28:							*.L28:
	fmove.d 132(sp),fp3				*	fmove.d 132(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbun _?L80					*	fjun .L80
_?L18:							*.L18:
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fmul.d 124(sp),fp0				*	fmul.d 124(%sp),%fp0
	fmove.d 116(sp),fp1				*	fmove.d 116(%sp),%fp1
	fmul.d 132(sp),fp1				*	fmul.d 132(%sp),%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fmul.d #0x7ff00000,#0x00000000,fp0		*	fmul.d #0x7ff0000000000000,%fp0
	fmove.d 108(sp),fp2				*	fmove.d 108(%sp),%fp2
	fmul.d 132(sp),fp2				*	fmul.d 132(%sp),%fp2
	fmove.d 116(sp),fp1				*	fmove.d 116(%sp),%fp1
	fmul.d 124(sp),fp1				*	fmul.d 124(%sp),%fp1
	fadd.x fp1,fp2					*	fadd.x %fp1,%fp2
	fmove.x fp2,fp1					*	fmove.x %fp2,%fp1
	fmul.d #0x7ff00000,#0x00000000,fp1		*	fmul.d #0x7ff0000000000000,%fp1
_?L81:							*.L81:
	fmove.d fp0,(a0)				*	fmove.d %fp0,(%a0)
	fmove.d fp1,8(a0)				*	fmove.d %fp1,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	lea (32,sp),sp					*	lea (32,%sp),%sp
	rts						*	rts
_?L80:							*.L80:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 132(sp)					*	tst.l 132(%sp)
	jbge _?L30					*	jge .L30
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L30:							*.L30:
	move.l d0,132(sp)				*	move.l %d0,132(%sp)
	move.l d1,136(sp)				*	move.l %d1,136(%sp)
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fmul.d 124(sp),fp0				*	fmul.d 124(%sp),%fp0
	fmove.d 116(sp),fp1				*	fmove.d 116(%sp),%fp1
	fmul.d 132(sp),fp1				*	fmul.d 132(%sp),%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fmul.d #0x7ff00000,#0x00000000,fp0		*	fmul.d #0x7ff0000000000000,%fp0
	fmove.d 108(sp),fp2				*	fmove.d 108(%sp),%fp2
	fmul.d 132(sp),fp2				*	fmul.d 132(%sp),%fp2
	fmove.d 116(sp),fp1				*	fmove.d 116(%sp),%fp1
	fmul.d 124(sp),fp1				*	fmul.d 124(%sp),%fp1
	fadd.x fp1,fp2					*	fadd.x %fp1,%fp2
	fmove.x fp2,fp1					*	fmove.x %fp2,%fp1
	fmul.d #0x7ff00000,#0x00000000,fp1		*	fmul.d #0x7ff0000000000000,%fp1
	jbra _?L81					*	jra .L81
_?L77:							*.L77:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 108(sp)					*	tst.l 108(%sp)
	jbge _?L25					*	jge .L25
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L25:							*.L25:
	move.l d0,108(sp)				*	move.l %d0,108(%sp)
	move.l d1,112(sp)				*	move.l %d1,112(%sp)
	fmove.d 116(sp),fp3				*	fmove.d 116(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L26					*	fjor .L26
	jbra _?L78					*	jra .L78
_?L79:							*.L79:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 124(sp)					*	tst.l 124(%sp)
	jbge _?L29					*	jge .L29
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L29:							*.L29:
	move.l d0,124(sp)				*	move.l %d0,124(%sp)
	move.l d1,128(sp)				*	move.l %d1,128(%sp)
	fmove.d 132(sp),fp3				*	fmove.d 132(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L18					*	fjor .L18
	jbra _?L80					*	jra .L80
_?L78:							*.L78:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 116(sp)					*	tst.l 116(%sp)
	jbge _?L27					*	jge .L27
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L27:							*.L27:
	move.l d0,116(sp)				*	move.l %d0,116(%sp)
	move.l d1,120(sp)				*	move.l %d1,120(%sp)
	fmove.d 124(sp),fp0				*	fmove.d 124(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L28					*	fjor .L28
	jbra _?L79					*	jra .L79
_?L11:							*.L11:
	fcmp.d #0x7fefffff,#0xffffffff,fp3		*	fcmp.d #0x7fefffffffffffff,%fp3
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 124(sp)					*	tst.l 124(%sp)
	jbge _?L14					*	jge .L14
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L14:							*.L14:
	fmove.d fp0,124(sp)				*	fmove.d %fp0,124(%sp)
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 132(sp)					*	tst.l 132(%sp)
	jbge _?L15					*	jge .L15
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L15:							*.L15:
	fmove.d fp0,132(sp)				*	fmove.d %fp0,132(%sp)
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L82					*	fjun .L82
_?L16:							*.L16:
	fmove.d 116(sp),fp3				*	fmove.d 116(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L18					*	fjor .L18
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 116(sp)					*	tst.l 116(%sp)
	jbge _?L19					*	jge .L19
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L19:							*.L19:
	move.l d0,116(sp)				*	move.l %d0,116(%sp)
	move.l d1,120(sp)				*	move.l %d1,120(%sp)
	fmove.d 108(sp),fp0				*	fmove.d 108(%sp),%fp0
	fmul.d 124(sp),fp0				*	fmul.d 124(%sp),%fp0
	fmove.d 116(sp),fp1				*	fmove.d 116(%sp),%fp1
	fmul.d 132(sp),fp1				*	fmul.d 132(%sp),%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fmul.d #0x7ff00000,#0x00000000,fp0		*	fmul.d #0x7ff0000000000000,%fp0
	fmove.d 108(sp),fp2				*	fmove.d 108(%sp),%fp2
	fmul.d 132(sp),fp2				*	fmul.d 132(%sp),%fp2
	fmove.d 116(sp),fp1				*	fmove.d 116(%sp),%fp1
	fmul.d 124(sp),fp1				*	fmul.d 124(%sp),%fp1
	fadd.x fp1,fp2					*	fadd.x %fp1,%fp2
	fmove.x fp2,fp1					*	fmove.x %fp2,%fp1
	fmul.d #0x7ff00000,#0x00000000,fp1		*	fmul.d #0x7ff0000000000000,%fp1
	jbra _?L81					*	jra .L81
_?L82:							*.L82:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 108(sp)					*	tst.l 108(%sp)
	jbge _?L17					*	jge .L17
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L17:							*.L17:
	move.l d0,108(sp)				*	move.l %d0,108(%sp)
	move.l d1,112(sp)				*	move.l %d1,112(%sp)
	jbra _?L16					*	jra .L16
_?L3:							*.L3:
	fcmp.d #0x7fefffff,#0xffffffff,fp3		*	fcmp.d #0x7fefffffffffffff,%fp3
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp3					*	fmove.l %d0,%fp3
	fabs.x fp3,fp3					*	fabs.x %fp3,%fp3
	tst.l 108(sp)					*	tst.l 108(%sp)
	jbge _?L6					*	jge .L6
	fneg.x fp3,fp3					*	fneg.x %fp3,%fp3
_?L6:							*.L6:
	fmove.d fp3,108(sp)				*	fmove.d %fp3,108(%sp)
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp3					*	fmove.l %d0,%fp3
	fabs.x fp3,fp3					*	fabs.x %fp3,%fp3
	tst.l 116(sp)					*	tst.l 116(%sp)
	jbge _?L7					*	jge .L7
	fneg.x fp3,fp3					*	fneg.x %fp3,%fp3
_?L7:							*.L7:
	fmove.d fp3,116(sp)				*	fmove.d %fp3,116(%sp)
	fmove.d 124(sp),fp3				*	fmove.d 124(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbun _?L83					*	fjun .L83
_?L8:							*.L8:
	moveq #1,d0					*	moveq #1,%d0
	fmove.d 132(sp),fp3				*	fmove.d 132(%sp),%fp3
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L5					*	fjor .L5
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 132(sp)					*	tst.l 132(%sp)
	jbge _?L10					*	jge .L10
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L10:							*.L10:
	move.l d0,132(sp)				*	move.l %d0,132(%sp)
	move.l d1,136(sp)				*	move.l %d1,136(%sp)
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L5					*	jra .L5
_?L83:							*.L83:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 124(sp)					*	tst.l 124(%sp)
	jbge _?L9					*	jge .L9
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L9:							*.L9:
	move.l d0,124(sp)				*	move.l %d0,124(%sp)
	move.l d1,128(sp)				*	move.l %d1,128(%sp)
	jbra _?L8					*	jra .L8
							*	.size	__muldc3, .-__muldc3
							*	.ident	"GCC: (GNU) 13.4.0"
