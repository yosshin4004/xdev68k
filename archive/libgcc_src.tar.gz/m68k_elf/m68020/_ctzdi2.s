* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ctzdi2				*	.globl	__ctzdi2
							*	.hidden	__ctzdi2
							*	.type	__ctzdi2, @function
___ctzdi2:						*__ctzdi2:
	move.l 4(sp),d2					*	move.l 4(%sp),%d2
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	jbeq _?L2					*	jeq .L2
	move.l d0,d2					*	move.l %d0,%d2
	clr.l d0					*	clr.l %d0
	move.l d2,d1					*	move.l %d2,%d1
	neg.l d1					*	neg.l %d1
	and.l d2,d1					*	and.l %d2,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 742 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d1{#0:#32},d1				*	bfffo %d1{#0:#0},%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.w #31,a0					*	move.w #31,%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L2:							*.L2:
	moveq #32,d0					*	moveq #32,%d0
	move.l d2,d1					*	move.l %d2,%d1
	neg.l d1					*	neg.l %d1
	and.l d2,d1					*	and.l %d2,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 742 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d1{#0:#32},d1				*	bfffo %d1{#0:#0},%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.w #31,a0					*	move.w #31,%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
							*	.size	__ctzdi2, .-__ctzdi2
							*	.ident	"GCC: (GNU) 13.4.0"
