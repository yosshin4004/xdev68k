* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"enable-execute-stack-empty.c"		*	.file	"enable-execute-stack-empty.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___enable_execute_stack			*	.globl	__enable_execute_stack
							*	.hidden	__enable_execute_stack
							*	.type	__enable_execute_stack, @function
___enable_execute_stack:				*__enable_execute_stack:
	rts						*	rts
							*	.size	__enable_execute_stack, .-__enable_execute_stack
							*	.ident	"GCC: (GNU) 13.4.0"
