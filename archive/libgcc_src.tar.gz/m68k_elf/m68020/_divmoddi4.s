* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divmoddi4				*	.globl	__divmoddi4
							*	.hidden	__divmoddi4
							*	.type	__divmoddi4, @function
___divmoddi4:						*__divmoddi4:
	subq.l #4,sp					*	subq.l #4,%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 44(sp),d6				*	move.l 44(%sp),%d6
	move.l 48(sp),d7				*	move.l 48(%sp),%d7
	move.l 52(sp),d2				*	move.l 52(%sp),%d2
	move.l 56(sp),d3				*	move.l 56(%sp),%d3
	move.l d6,d1					*	move.l %d6,%d1
	jbmi _?L27					*	jmi .L27
	clr.l d4					*	clr.l %d4
	move.l d2,d0					*	move.l %d2,%d0
	move.l d4,d5					*	move.l %d4,%d5
	tst.l d2					*	tst.l %d2
	jblt _?L28					*	jlt .L28
_?L3:							*.L3:
	move.l d3,d2					*	move.l %d3,%d2
	move.l d7,a0					*	move.l %d7,%a0
	tst.l d0					*	tst.l %d0
	jbne _?L4					*	jne .L4
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcc _?L5					*	jcc .L5
	move.l d1,d0					*	move.l %d1,%d0
	move.l d7,d1					*	move.l %d7,%d1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1016 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d0:d1					*	divu.l %d3,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a0					*	move.l %d1,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	clr.l d2					*	clr.l %d2
	move.l d0,d3					*	move.l %d0,%d3
_?L7:							*.L7:
	move.l a1,d0					*	move.l %a1,%d0
	move.l a0,d1					*	move.l %a0,%d1
	tst.l d5					*	tst.l %d5
	jbeq _?L14					*	jeq .L14
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
_?L14:							*.L14:
	tst.l d4					*	tst.l %d4
	jbeq _?L15					*	jeq .L15
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
_?L15:							*.L15:
	move.l 60(sp),a0				*	move.l 60(%sp),%a0
	move.l d2,(a0)					*	move.l %d2,(%a0)
	move.l d3,4(a0)					*	move.l %d3,4(%a0)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L4:							*.L4:
	move.l d7,a1					*	move.l %d7,%a1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L8					*	jcc .L8
	move.l d1,d2					*	move.l %d1,%d2
	move.l d7,d3					*	move.l %d7,%d3
	sub.l a0,a0					*	sub.l %a0,%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	jbra _?L7					*	jra .L7
_?L28:							*.L28:
	not.l d5					*	not.l %d5
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
	move.l d2,d0					*	move.l %d2,%d0
	jbra _?L3					*	jra .L3
_?L8:							*.L8:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1139 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	bfffo d0{#0:#32},d6				*	bfffo %d0{#0:#0},%d6
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	tst.l d6					*	tst.l %d6
	jbne _?L9					*	jne .L9
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbhi _?L10					*	jhi .L10
	cmp.l d3,d7					*	cmp.l %d3,%d7
	jbcs _?L18					*	jcs .L18
_?L10:							*.L10:
	move.l a0,d3					*	move.l %a0,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d3					*	sub.l %d2,%d3
	subx.l d0,d1					*	subx.l %d0,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d3,a1					*	move.l %d3,%a1
	move.w #1,a0					*	move.w #1,%a0
	move.l d1,d2					*	move.l %d1,%d2
	move.l a1,d3					*	move.l %a1,%d3
	sub.l a1,a1					*	sub.l %a1,%a1
	jbra _?L7					*	jra .L7
_?L5:							*.L5:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1028 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d3,d0:d1					*	divu.l %d3,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d7,d3					*	move.l %d7,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1029 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d2,d0:d3					*	divu.l %d2,%d0:%d3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d3,a0					*	move.l %d3,%a0
	move.l d1,a1					*	move.l %d1,%a1
	clr.l d2					*	clr.l %d2
	move.l d0,d3					*	move.l %d0,%d3
	jbra _?L7					*	jra .L7
_?L27:							*.L27:
	neg.l d7					*	neg.l %d7
	negx.l d6					*	negx.l %d6
	move.l d6,d1					*	move.l %d6,%d1
	moveq #-1,d4					*	moveq #-1,%d4
	move.l d2,d0					*	move.l %d2,%d0
	move.l d4,d5					*	move.l %d4,%d5
	tst.l d2					*	tst.l %d2
	jbge _?L3					*	jge .L3
	jbra _?L28					*	jra .L28
_?L9:							*.L9:
	moveq #32,d3					*	moveq #32,%d3
	sub.l d6,d3					*	sub.l %d6,%d3
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d2,d7					*	move.l %d2,%d7
	lsr.l d3,d7					*	lsr.l %d3,%d7
	or.l d0,d7					*	or.l %d0,%d7
	move.l d7,a2					*	move.l %d7,%a2
	lsl.l d6,d2					*	lsl.l %d6,%d2
	move.l d2,a6					*	move.l %d2,%a6
	move.l d1,d0					*	move.l %d1,%d0
	lsr.l d3,d0					*	lsr.l %d3,%d0
	lsl.l d6,d1					*	lsl.l %d6,%d1
	move.l a0,d7					*	move.l %a0,%d7
	lsr.l d3,d7					*	lsr.l %d3,%d7
	or.l d1,d7					*	or.l %d1,%d7
	move.l d7,36(sp)				*	move.l %d7,36(%sp)
	move.l a0,d7					*	move.l %a0,%d7
	lsl.l d6,d7					*	lsl.l %d6,%d7
	move.l d7,a0					*	move.l %d7,%a0
	move.l 36(sp),a5				*	move.l 36(%sp),%a5
	move.l a5,d1					*	move.l %a5,%d1
	move.l a2,d2					*	move.l %a2,%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1180 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	divu.l d2,d0:d1					*	divu.l %d2,%d0:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a5					*	move.l %d1,%a5
	move.l d1,36(sp)				*	move.l %d1,36(%sp)
	move.l a6,d7					*	move.l %a6,%d7
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	mulu.l d7,d7:d1					*	mulu.l %d7,%d7:%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d7,a1					*	move.l %d7,%a1
	move.l d1,a4					*	move.l %d1,%a4
	move.l d7,a3					*	move.l %d7,%a3
	cmp.l d0,d7					*	cmp.l %d0,%d7
	jbhi _?L12					*	jhi .L12
	jbeq _?L29					*	jeq .L29
_?L13:							*.L13:
	move.l a0,d1					*	move.l %a0,%d1
	move.l a3,d2					*	move.l %a3,%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a4,d1					*	sub.l %a4,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d7					*	move.l %d0,%d7
	lsl.l d3,d7					*	lsl.l %d3,%d7
	lsr.l d6,d1					*	lsr.l %d6,%d1
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d6,d2					*	lsr.l %d6,%d2
	move.l d7,d3					*	move.l %d7,%d3
	or.l d1,d3					*	or.l %d1,%d3
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	jbra _?L7					*	jra .L7
_?L29:							*.L29:
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbls _?L13					*	jls .L13
_?L12:							*.L12:
	subq.l #1,a5					*	subq.l #1,%a5
	move.l a5,36(sp)				*	move.l %a5,36(%sp)
	move.l d1,a4					*	move.l %d1,%a4
	move.l a1,d1					*	move.l %a1,%d1
	move.l a4,d2					*	move.l %a4,%d2
	move.l a2,d7					*	move.l %a2,%d7
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a6,d2					*	sub.l %a6,%d2
	subx.l d7,d1					*	subx.l %d7,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d2,a4					*	move.l %d2,%a4
	move.l d1,a3					*	move.l %d1,%a3
	move.l a0,d1					*	move.l %a0,%d1
	move.l a3,d2					*	move.l %a3,%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a4,d1					*	sub.l %a4,%d1
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d7					*	move.l %d0,%d7
	lsl.l d3,d7					*	lsl.l %d3,%d7
	lsr.l d6,d1					*	lsr.l %d6,%d1
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d6,d2					*	lsr.l %d6,%d2
	move.l d7,d3					*	move.l %d7,%d3
	or.l d1,d3					*	or.l %d1,%d3
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	sub.l a1,a1					*	sub.l %a1,%a1
	jbra _?L7					*	jra .L7
_?L18:							*.L18:
	sub.l a0,a0					*	sub.l %a0,%a0
	move.l d1,d2					*	move.l %d1,%d2
	move.l a1,d3					*	move.l %a1,%d3
	sub.l a1,a1					*	sub.l %a1,%a1
	jbra _?L7					*	jra .L7
							*	.size	__divmoddi4, .-__divmoddi4
							*	.ident	"GCC: (GNU) 13.4.0"
