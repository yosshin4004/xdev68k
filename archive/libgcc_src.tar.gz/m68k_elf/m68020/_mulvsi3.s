* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___mulvsi3				*	.globl	__mulvsi3
							*	.hidden	__mulvsi3
							*	.type	__mulvsi3, @function
___mulvsi3:						*__mulvsi3:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	muls.l 8(sp),d1:d0				*	muls.l 8(%sp),%d1:%d0
	move.l d0,d2					*	move.l %d0,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbne _?L7					*	jne .L7
	rts						*	rts
_?L7:							*.L7:
	trap #7						*	trap #7
							*	.size	__mulvsi3, .-__mulvsi3
							*	.ident	"GCC: (GNU) 13.4.0"
