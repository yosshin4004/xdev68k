* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
							*# 0 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 0 "<built-in>"
							*# 0 "<command-line>"
							*# 1 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*# 104 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
PICCALL .macro addr					* .macro PICCALL addr
 jbsr addr						* jbsr \addr
 .endm							* .endm
							*
PICJUMP .macro addr					* .macro PICJUMP addr
 jmp addr						* jmp \addr
 .endm							* .endm
							*
PICLEA .macro sym, reg					* .macro PICLEA sym, reg
 lea sym,reg						* lea \sym, \reg
 .endm							* .endm
							*
PICPEA .macro sym, areg					* .macro PICPEA sym, areg
 pea sym						* pea \sym
 .endm							* .endm
							*# 581 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
 .text							* .text
							* .type __umodsi3,function
 .globl ___umodsi3					* .globl __umodsi3
___umodsi3:						*__umodsi3:
 move.l 8(sp),d1					* movel %sp@(8), %d1
 move.l 4(sp),d0					* movel %sp@(4), %d0
 move.l d1,-(sp)					* movel %d1, %sp@-
 move.l d0,-(sp)					* movel %d0, %sp@-
 PICCALL ___udivsi3_internal				* PICCALL __udivsi3_internal
 addq.l #8,sp						* addql #8, %sp
 move.l 8(sp),d1					* movel %sp@(8), %d1
							*
 move.l d1,-(sp)					* movel %d1, %sp@-
 move.l d0,-(sp)					* movel %d0, %sp@-
 PICCALL ___mulsi3_internal				* PICCALL __mulsi3_internal
 addq.l #8,sp						* addql #8, %sp
							*
							*
							*
 move.l 4(sp),d1					* movel %sp@(4), %d1
 sub.l d0,d1						* subl %d0, %d1
 move.l d1,d0						* movel %d1, %d0
 rts							* rts
							*# 3930 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| gcc expects the routines __eqdf2, __nedf2, __gtdf2, __gedf2,
							*| __ledf2, __ltdf2 to all return the same value as a direct call to
							*| __cmpdf2 would. In this implementation, each of these routines
							*| simply calls __cmpdf2. It would be more efficient to give the
							*| __cmpdf2 routine several names, but separating them out will make it
							*| easier to write efficient versions of these routines someday.
							*| If the operands recompare unordered unordered __gtdf2 and __gedf2 return -1.
							*| The other routines return 1.
							*# 4035 "build_gcc/src/gcc-13.4.0/libgcc/config/m68k/lb1sf68.S"
							*| The comments above about __eqdf2, et. al., also apply to __eqsf2,
							*| et. al., except that the latter call __cmpsf2 rather than __cmpdf2.
