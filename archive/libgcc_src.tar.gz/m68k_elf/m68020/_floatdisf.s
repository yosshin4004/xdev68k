* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___floatdisf				*	.globl	__floatdisf
							*	.hidden	__floatdisf
							*	.type	__floatdisf, @function
___floatdisf:						*__floatdisf:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d0				*	move.l 16(%sp),%d0
	move.l 20(sp),d1				*	move.l 20(%sp),%d1
	move.l #2097151,d2				*	move.l #2097151,%d2
	moveq #-1,d3					*	moveq #-1,%d3
	add.l d1,d3					*	add.l %d1,%d3
	addx.l d0,d2					*	addx.l %d0,%d2
	move.l #4194303,d4				*	move.l #4194303,%d4
	moveq #-2,d5					*	moveq #-2,%d5
	sub.l d3,d5					*	sub.l %d3,%d5
	subx.l d2,d4					*	subx.l %d2,%d4
	jbcc _?L2					*	jcc .L2
	clr.l d2					*	clr.l %d2
	clr.l d3					*	clr.l %d3
	move.l d1,d3					*	move.l %d1,%d3
	and.l #2047,d3					*	and.l #2047,%d3
	move.l d2,d5					*	move.l %d2,%d5
	or.l d3,d5					*	or.l %d3,%d5
	jbeq _?L2					*	jeq .L2
	move.l d1,d2					*	move.l %d1,%d2
	and.w #63488,d2					*	and.w #63488,%d2
	move.l d2,d1					*	move.l %d2,%d1
	or.w #2048,d1					*	or.w #2048,%d1
_?L2:							*.L2:
	fmove.d #0x41f00000,#0x00000000,fp1		*	fmove.d #0x41f0000000000000,%fp1
	fmul.l d0,fp1					*	fmul.l %d0,%fp1
	fmove.l d1,fp0					*	fmove.l %d1,%fp0
	tst.l d1					*	tst.l %d1
	jblt _?L9					*	jlt .L9
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	fmove.s fp0,d0					*	fmove.s %fp0,%d0
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L9:							*.L9:
	fadd.d #0x41f00000,#0x00000000,fp0		*	fadd.d #0x41f0000000000000,%fp0
	fadd.x fp1,fp0					*	fadd.x %fp1,%fp0
	fmove.s fp0,d0					*	fmove.s %fp0,%d0
	fmove.s d0,fp0					*	fmove.s %d0,%fp0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
							*	.size	__floatdisf, .-__floatdisf
							*	.ident	"GCC: (GNU) 13.4.0"
