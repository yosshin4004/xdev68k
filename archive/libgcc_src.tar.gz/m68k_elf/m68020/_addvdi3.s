* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___addvdi3				*	.globl	__addvdi3
							*	.hidden	__addvdi3
							*	.type	__addvdi3, @function
___addvdi3:						*__addvdi3:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 24(sp),d2				*	move.l 24(%sp),%d2
	move.l 28(sp),d3				*	move.l 28(%sp),%d3
	move.l 16(sp),d4				*	move.l 16(%sp),%d4
	move.l 20(sp),d5				*	move.l 20(%sp),%d5
	add.l d3,d5					*	add.l %d3,%d5
	addx.l d2,d4					*	addx.l %d2,%d4
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	eor.l d2,d1					*	eor.l %d2,%d1
	eor.l d4,d2					*	eor.l %d4,%d2
	not.l d1					*	not.l %d1
	and.l d1,d2					*	and.l %d1,%d2
	jbmi _?L8					*	jmi .L8
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L8:							*.L8:
	trap #7						*	trap #7
							*	.size	__addvdi3, .-__addvdi3
							*	.ident	"GCC: (GNU) 13.4.0"
