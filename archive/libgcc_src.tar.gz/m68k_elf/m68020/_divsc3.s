* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divsc3				*	.globl	__divsc3
							*	.hidden	__divsc3
							*	.type	__divsc3, @function
___divsc3:						*__divsc3:
	fmovem fp2/fp3/fp4/fp5/fp6,-(sp)		*	fmovem #124,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	fmove.s 68(sp),fp3				*	fmove.s 68(%sp),%fp3
	fmove.s 72(sp),fp0				*	fmove.s 72(%sp),%fp0
	fmove.s 76(sp),fp5				*	fmove.s 76(%sp),%fp5
	fmove.s 80(sp),fp4				*	fmove.s 80(%sp),%fp4
	fmove.x fp5,fp1					*	fmove.x %fp5,%fp1
	fmul.x fp5,fp1					*	fmul.x %fp5,%fp1
	fmove.x fp4,fp2					*	fmove.x %fp4,%fp2
	fmul.x fp4,fp2					*	fmul.x %fp4,%fp2
	fadd.x fp2,fp1					*	fadd.x %fp2,%fp1
	fmove.x fp3,fp2					*	fmove.x %fp3,%fp2
	fmul.x fp5,fp2					*	fmul.x %fp5,%fp2
	fmove.x fp0,fp6					*	fmove.x %fp0,%fp6
	fmul.x fp4,fp6					*	fmul.x %fp4,%fp6
	fadd.x fp6,fp2					*	fadd.x %fp6,%fp2
	fdiv.x fp1,fp2					*	fdiv.x %fp1,%fp2
	fmove.s fp2,d2					*	fmove.s %fp2,%d2
	fmul.x fp5,fp0					*	fmul.x %fp5,%fp0
	fmul.x fp4,fp3					*	fmul.x %fp4,%fp3
	fsub.x fp3,fp0					*	fsub.x %fp3,%fp0
	fdiv.x fp1,fp0					*	fdiv.x %fp1,%fp0
	fmove.s fp0,d3					*	fmove.s %fp0,%d3
	fmove.s d2,fp0					*	fmove.s %d2,%fp0
	fcmp.s d2,fp0					*	fcmp.s %d2,%fp0
	fbun _?L37					*	fjun .L37
_?L2:							*.L2:
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L37:							*.L37:
	fmove.s d3,fp1					*	fmove.s %d3,%fp1
	fcmp.s d3,fp1					*	fcmp.s %d3,%fp1
	fbor _?L2					*	fjor .L2
	ftst.s 76(sp)					*	ftst.s 76(%sp)
	fbne _?L3					*	fjne .L3
	ftst.s 80(sp)					*	ftst.s 80(%sp)
	fbne _?L3					*	fjne .L3
	fmove.s 68(sp),fp0				*	fmove.s 68(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L38					*	fjun .L38
_?L4:							*.L4:
	fmove.s #0x7f800000,fp0				*	fmove.s #0x7f800000,%fp0
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L5					*	jge .L5
	fmove.s #0xff800000,fp0				*	fmove.s #0xff800000,%fp0
_?L5:							*.L5:
	fmove.s 68(sp),fp1				*	fmove.s 68(%sp),%fp1
	fsglmul.x fp0,fp1				*	fsglmul.x %fp0,%fp1
	fmove.s fp1,d2					*	fmove.s %fp1,%d2
	fsglmul.s 72(sp),fp0				*	fsglmul.s 72(%sp),%fp0
	fmove.s fp0,d3					*	fmove.s %fp0,%d3
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L38:							*.L38:
	fmove.s 72(sp),fp1				*	fmove.s 72(%sp),%fp1
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L4					*	fjor .L4
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L3:							*.L3:
	fabs.s 68(sp),fp0				*	fabs.s 68(%sp),%fp0
	fabs.s 76(sp),fp1				*	fabs.s 76(%sp),%fp1
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fbule _?L6					*	fjule .L6
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbugt _?L2					*	fjugt .L2
	clr.b d0					*	clr.b %d0
	fmove.s #0x7f800000,fp0				*	fmove.s #0x7f800000,%fp0
_?L7:							*.L7:
	fabs.s 80(sp),fp1				*	fabs.s 80(%sp),%fp1
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbugt _?L9					*	fjugt .L9
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp1					*	fmove.l %d0,%fp1
	fabs.x fp1,fp1					*	fabs.x %fp1,%fp1
	tst.l 68(sp)					*	tst.l 68(%sp)
	jbge _?L10					*	jge .L10
	fneg.x fp1,fp1					*	fneg.x %fp1,%fp1
_?L10:							*.L10:
	fabs.s 72(sp),fp0				*	fabs.s 72(%sp),%fp0
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 72(sp)					*	tst.l 72(%sp)
	jbge _?L11					*	jge .L11
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L11:							*.L11:
	fmove.s 76(sp),fp2				*	fmove.s 76(%sp),%fp2
	fsglmul.x fp1,fp2				*	fsglmul.x %fp1,%fp2
	fmove.s 80(sp),fp3				*	fmove.s 80(%sp),%fp3
	fsglmul.x fp0,fp3				*	fsglmul.x %fp0,%fp3
	fadd.x fp3,fp2					*	fadd.x %fp3,%fp2
	fsglmul.s #0x7f800000,fp2			*	fsglmul.s #0x7f800000,%fp2
	fmove.s fp2,d2					*	fmove.s %fp2,%d2
	fsglmul.s 76(sp),fp0				*	fsglmul.s 76(%sp),%fp0
	fsglmul.s 80(sp),fp1				*	fsglmul.s 80(%sp),%fp1
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fsglmul.s #0x7f800000,fp0			*	fsglmul.s #0x7f800000,%fp0
	fmove.s fp0,d3					*	fmove.s %fp0,%d3
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L6:							*.L6:
	fabs.s 72(sp),fp2				*	fabs.s 72(%sp),%fp2
	fcmp.s #0x7f7fffff,fp2				*	fcmp.s #0x7f7fffff,%fp2
	fbule _?L8					*	fjule .L8
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbugt _?L8					*	fjugt .L8
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L7					*	jra .L7
_?L8:							*.L8:
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbule _?L39					*	fjule .L39
	clr.b d0					*	clr.b %d0
_?L12:							*.L12:
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fbugt _?L2					*	fjugt .L2
	fabs.s 72(sp),fp0				*	fabs.s 72(%sp),%fp0
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fbugt _?L2					*	fjugt .L2
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp1					*	fmove.l %d0,%fp1
	fabs.x fp1,fp1					*	fabs.x %fp1,%fp1
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L14					*	jge .L14
	fneg.x fp1,fp1					*	fneg.x %fp1,%fp1
_?L14:							*.L14:
	fabs.s 80(sp),fp0				*	fabs.s 80(%sp),%fp0
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fmove.l d0,fp0					*	fmove.l %d0,%fp0
	fabs.x fp0,fp0					*	fabs.x %fp0,%fp0
	tst.l 80(sp)					*	tst.l 80(%sp)
	jbge _?L15					*	jge .L15
	fneg.x fp0,fp0					*	fneg.x %fp0,%fp0
_?L15:							*.L15:
	fmove.s 68(sp),fp2				*	fmove.s 68(%sp),%fp2
	fsglmul.x fp1,fp2				*	fsglmul.x %fp1,%fp2
	fmove.s 72(sp),fp3				*	fmove.s 72(%sp),%fp3
	fsglmul.x fp0,fp3				*	fsglmul.x %fp0,%fp3
	fadd.x fp3,fp2					*	fadd.x %fp3,%fp2
	fsglmul.s #0x0,fp2				*	fsglmul.s #0x0,%fp2
	fmove.s fp2,d2					*	fmove.s %fp2,%d2
	fsglmul.s 72(sp),fp1				*	fsglmul.s 72(%sp),%fp1
	fsglmul.s 68(sp),fp0				*	fsglmul.s 68(%sp),%fp0
	fsub.x fp0,fp1					*	fsub.x %fp0,%fp1
	fsglmul.s #0x0,fp1				*	fsglmul.s #0x0,%fp1
	fmove.s fp1,d3					*	fmove.s %fp1,%d3
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L39:							*.L39:
	fabs.s 80(sp),fp1				*	fabs.s 80(%sp),%fp1
_?L9:							*.L9:
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbule _?L2					*	fjule .L2
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L12					*	jra .L12
							*	.size	__divsc3, .-__divsc3
							*	.ident	"GCC: (GNU) 13.4.0"
