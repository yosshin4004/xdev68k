* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68020
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsdfdi				*	.globl	__fixunsdfdi
							*	.hidden	__fixunsdfdi
							*	.type	__fixunsdfdi, @function
___fixunsdfdi:						*__fixunsdfdi:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.d 16(sp),fp0				*	fmove.d 16(%sp),%fp0
	fmove.x fp0,fp2					*	fmove.x %fp0,%fp2
	fmul.d #0x3df00000,#0x00000000,fp2		*	fmul.d #0x3df0000000000000,%fp2
	fcmp.d #0x41e00000,#0x00000000,fp2		*	fcmp.d #0x41e0000000000000,%fp2
	fbge _?L2					*	fjge .L2
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	fmove.l d0,fp2					*	fmove.l %d0,%fp2
	tst.l d0					*	tst.l %d0
	jblt _?L9					*	jlt .L9
_?L4:							*.L4:
	fmul.d #0x41f00000,#0x00000000,fp2		*	fmul.d #0x41f0000000000000,%fp2
	fsub.x fp2,fp0					*	fsub.x %fp2,%fp0
	fcmp.d #0x41e00000,#0x00000000,fp0		*	fcmp.d #0x41e0000000000000,%fp0
	fbge _?L5					*	fjge .L5
	fintrz.x fp0,fp0				*	fintrz.x %fp0,%fp0
	fmove.l fp0,d1					*	fmove.l %fp0,%d1
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L5:							*.L5:
	fsub.d #0x41e00000,#0x00000000,fp0		*	fsub.d #0x41e0000000000000,%fp0
	fintrz.x fp0,fp0				*	fintrz.x %fp0,%fp0
	fmove.l fp0,d1					*	fmove.l %fp0,%d1
	add.l #-2147483648,d1				*	add.l #-2147483648,%d1
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L2:							*.L2:
	fsub.d #0x41e00000,#0x00000000,fp2		*	fsub.d #0x41e0000000000000,%fp2
	fintrz.x fp2,fp2				*	fintrz.x %fp2,%fp2
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	fmove.l d0,fp2					*	fmove.l %d0,%fp2
	tst.l d0					*	tst.l %d0
	jbge _?L4					*	jge .L4
_?L9:							*.L9:
	fadd.d #0x41f00000,#0x00000000,fp2		*	fadd.d #0x41f0000000000000,%fp2
	jbra _?L4					*	jra .L4
							*	.size	__fixunsdfdi, .-__fixunsdfdi
							*	.ident	"GCC: (GNU) 13.4.0"
