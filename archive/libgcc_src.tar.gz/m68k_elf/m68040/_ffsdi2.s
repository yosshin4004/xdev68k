* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ffsdi2				*	.globl	__ffsdi2
							*	.hidden	__ffsdi2
							*	.type	__ffsdi2, @function
___ffsdi2:						*__ffsdi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	jbeq _?L2					*	jeq .L2
	move.l d0,d1					*	move.l %d0,%d1
	lea 0.w,a0					*	lea 0.w,%a0
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	and.l d1,d0					*	and.l %d1,%d0
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbls _?L13					*	jls .L13
_?L5:							*.L5:
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbhi _?L7					*	jhi .L7
	moveq #16,d1					*	moveq #16,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l a0,d1					*	add.l %a0,%d1
	add.l d1,d0					*	add.l %d1,%d0
_?L1:							*.L1:
	rts						*	rts
_?L2:							*.L2:
	move.l d1,d0					*	move.l %d1,%d0
	jbeq _?L1					*	jeq .L1
	move.w #32,a0					*	move.w #32,%a0
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	and.l d1,d0					*	and.l %d1,%d0
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbhi _?L5					*	jhi .L5
_?L13:							*.L13:
	cmp.l #255,d0					*	cmp.l #255,%d0
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l a0,d1					*	add.l %a0,%d1
	add.l d1,d0					*	add.l %d1,%d0
	jbra _?L1					*	jra .L1
_?L7:							*.L7:
	moveq #24,d1					*	moveq #24,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l a0,d1					*	add.l %a0,%d1
	add.l d1,d0					*	add.l %d1,%d0
	jbra _?L1					*	jra .L1
							*	.size	__ffsdi2, .-__ffsdi2
							*	.ident	"GCC: (GNU) 13.4.0"
