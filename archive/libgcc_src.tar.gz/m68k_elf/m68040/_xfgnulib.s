* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"_xfgnulib.c"				*	.file	"_xfgnulib.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___unordxf2				*	.globl	__unordxf2
							*	.hidden	__unordxf2
							*	.type	__unordxf2, @function
___unordxf2:						*__unordxf2:
	add.w #-72,sp					*	add.w #-72,%sp
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 84(sp),d0				*	move.l 84(%sp),%d0
	move.l 88(sp),d1				*	move.l 88(%sp),%d1
	move.l 92(sp),d2				*	move.l 92(%sp),%d2
	move.l 96(sp),a1				*	move.l 96(%sp),%a1
	move.l 100(sp),a2				*	move.l 100(%sp),%a2
	move.l 104(sp),a3				*	move.l 104(%sp),%a3
	move.l d0,68(sp)				*	move.l %d0,68(%sp)
	move.l d1,72(sp)				*	move.l %d1,72(%sp)
	move.l d2,76(sp)				*	move.l %d2,76(%sp)
	move.l 68(sp),d3				*	move.l 68(%sp),%d3
	and.l #2147418112,d3				*	and.l #2147418112,%d3
	cmp.l #2147418112,d3				*	cmp.l #2147418112,%d3
	jbeq _?L8					*	jeq .L8
_?L2:							*.L2:
	move.l a1,32(sp)				*	move.l %a1,32(%sp)
	move.l a2,36(sp)				*	move.l %a2,36(%sp)
	move.l a3,40(sp)				*	move.l %a3,40(%sp)
	move.l 32(sp),d0				*	move.l 32(%sp),%d0
	and.l #2147418112,d0				*	and.l #2147418112,%d0
	cmp.l #2147418112,d0				*	cmp.l #2147418112,%d0
	jbeq _?L9					*	jeq .L9
	clr.l d0					*	clr.l %d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	add.w #72,sp					*	add.w #72,%sp
	rts						*	rts
_?L8:							*.L8:
	move.l d0,56(sp)				*	move.l %d0,56(%sp)
	move.l d1,60(sp)				*	move.l %d1,60(%sp)
	move.l d2,64(sp)				*	move.l %d2,64(%sp)
	move.l 60(sp),d3				*	move.l 60(%sp),%d3
	bclr #31,d3					*	bclr #31,%d3
	move.l d0,44(sp)				*	move.l %d0,44(%sp)
	move.l d1,48(sp)				*	move.l %d1,48(%sp)
	move.l d2,52(sp)				*	move.l %d2,52(%sp)
	or.l 52(sp),d3					*	or.l 52(%sp),%d3
	jbeq _?L2					*	jeq .L2
	moveq #1,d0					*	moveq #1,%d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	add.w #72,sp					*	add.w #72,%sp
	rts						*	rts
_?L9:							*.L9:
	move.l a1,20(sp)				*	move.l %a1,20(%sp)
	move.l a2,24(sp)				*	move.l %a2,24(%sp)
	move.l a3,28(sp)				*	move.l %a3,28(%sp)
	move.l 24(sp),d0				*	move.l 24(%sp),%d0
	bclr #31,d0					*	bclr #31,%d0
	move.l a1,8(sp)					*	move.l %a1,8(%sp)
	move.l a2,12(sp)				*	move.l %a2,12(%sp)
	move.l a3,16(sp)				*	move.l %a3,16(%sp)
	or.l 16(sp),d0					*	or.l 16(%sp),%d0
	sne d0						*	sne %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	add.w #72,sp					*	add.w #72,%sp
	rts						*	rts
							*	.size	__unordxf2, .-__unordxf2
	.align	2					*	.align	2
	.globl	___extenddfxf2				*	.globl	__extenddfxf2
							*	.hidden	__extenddfxf2
							*	.type	__extenddfxf2, @function
___extenddfxf2:						*__extenddfxf2:
	add.w #-12,sp					*	add.w #-12,%sp
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 24(sp),d2				*	move.l 24(%sp),%d2
	move.l 28(sp),d3				*	move.l 28(%sp),%d3
	move.l d2,d0					*	move.l %d2,%d0
	move.l d0,d1					*	move.l %d0,%d1
	and.l #-2147483648,d1				*	and.l #-2147483648,%d1
	move.l d1,8(sp)					*	move.l %d1,8(%sp)
	bclr #31,d0					*	bclr #31,%d0
	or.l d3,d0					*	or.l %d3,%d0
	jbeq _?L15					*	jeq .L15
	bfextu d2{#1:#11},d0				*	bfextu %d2{#1:#11},%d0
	add.l #15360,d0					*	add.l #15360,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	move.l d0,8(sp)					*	move.l %d0,8(%sp)
	move.l d2,d0					*	move.l %d2,%d0
	moveq #11,d1					*	moveq #11,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	and.l #2147481600,d0				*	and.l #2147481600,%d0
	move.l d3,d1					*	move.l %d3,%d1
	moveq #21,d4					*	moveq #21,%d4
	lsr.l d4,d1					*	lsr.l %d4,%d1
	or.l d1,d0					*	or.l %d1,%d0
	bset #31,d0					*	bset #31,%d0
	move.l d0,12(sp)				*	move.l %d0,12(%sp)
	move.l d3,d0					*	move.l %d3,%d0
	moveq #11,d1					*	moveq #11,%d1
	lsl.l d1,d0					*	lsl.l %d1,%d0
	move.l d0,16(sp)				*	move.l %d0,16(%sp)
	fmove.x 8(sp),fp0				*	fmove.x 8(%sp),%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	add.w #12,sp					*	add.w #12,%sp
	rts						*	rts
_?L15:							*.L15:
	clr.l 12(sp)					*	clr.l 12(%sp)
	clr.l 16(sp)					*	clr.l 16(%sp)
	fmove.x 8(sp),fp0				*	fmove.x 8(%sp),%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	add.w #12,sp					*	add.w #12,%sp
	rts						*	rts
							*	.size	__extenddfxf2, .-__extenddfxf2
	.align	2					*	.align	2
	.globl	___truncxfdf2				*	.globl	__truncxfdf2
							*	.hidden	__truncxfdf2
							*	.type	__truncxfdf2, @function
___truncxfdf2:						*__truncxfdf2:
	add.w #-36,sp					*	add.w #-36,%sp
	movem.l d3/d4/d5/d6/d7/a3,-(sp)			*	movem.l #7952,-(%sp)
	move.l 64(sp),a1				*	move.l 64(%sp),%a1
	move.l 68(sp),a2				*	move.l 68(%sp),%a2
	move.l 72(sp),a3				*	move.l 72(%sp),%a3
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	move.l a2,52(sp)				*	move.l %a2,52(%sp)
	move.l a3,56(sp)				*	move.l %a3,56(%sp)
	move.l 48(sp),d0				*	move.l 48(%sp),%d0
	move.l d0,d6					*	move.l %d0,%d6
	and.l #-2147483648,d6				*	and.l #-2147483648,%d6
	move.l d6,d2					*	move.l %d6,%d2
	move.l a1,36(sp)				*	move.l %a1,36(%sp)
	move.l a2,40(sp)				*	move.l %a2,40(%sp)
	move.l a3,44(sp)				*	move.l %a3,44(%sp)
	move.l 40(sp),d1				*	move.l 40(%sp),%d1
	move.l a1,24(sp)				*	move.l %a1,24(%sp)
	move.l a2,28(sp)				*	move.l %a2,28(%sp)
	move.l a3,32(sp)				*	move.l %a3,32(%sp)
	move.l 32(sp),d4				*	move.l 32(%sp),%d4
	move.l d0,d5					*	move.l %d0,%d5
	bclr #31,d5					*	bclr #31,%d5
	move.l d1,d7					*	move.l %d1,%d7
	or.l d4,d7					*	or.l %d4,%d7
	or.l d7,d5					*	or.l %d7,%d5
	jbeq _?L22					*	jeq .L22
	bfextu d0{#1:#15},d0				*	bfextu %d0{#1:#15},%d0
	add.l #-15360,d0				*	add.l #-15360,%d0
	cmp.l #2046,d0					*	cmp.l #2046,%d0
	jbgt _?L23					*	jgt .L23
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	bfextu d1{#1:#20},d5				*	bfextu %d1{#1:#20},%d5
	or.l d6,d5					*	or.l %d6,%d5
	move.l d0,d2					*	move.l %d0,%d2
	or.l d5,d2					*	or.l %d5,%d2
	moveq #21,d0					*	moveq #21,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	moveq #11,d0					*	moveq #11,%d0
	lsr.l d0,d4					*	lsr.l %d0,%d4
	move.l d1,d3					*	move.l %d1,%d3
	or.l d4,d3					*	or.l %d4,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
_?L18:							*.L18:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2296
	add.w #36,sp					*	add.w #36,%sp
	rts						*	rts
_?L23:							*.L23:
	move.l #2046,d0					*	move.l #2046,%d0
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	bfextu d1{#1:#20},d5				*	bfextu %d1{#1:#20},%d5
	or.l d6,d5					*	or.l %d6,%d5
	move.l d0,d2					*	move.l %d0,%d2
	or.l d5,d2					*	or.l %d5,%d2
	moveq #21,d0					*	moveq #21,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	moveq #11,d0					*	moveq #11,%d0
	lsr.l d0,d4					*	lsr.l %d0,%d4
	move.l d1,d3					*	move.l %d1,%d3
	or.l d4,d3					*	or.l %d4,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	jbra _?L18					*	jra .L18
_?L22:							*.L22:
	clr.l d3					*	clr.l %d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2296
	add.w #36,sp					*	add.w #36,%sp
	rts						*	rts
							*	.size	__truncxfdf2, .-__truncxfdf2
	.align	2					*	.align	2
	.globl	___extendsfxf2				*	.globl	__extendsfxf2
							*	.hidden	__extendsfxf2
							*	.type	__extendsfxf2, @function
___extendsfxf2:						*__extendsfxf2:
	add.w #-12,sp					*	add.w #-12,%sp
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 24(sp),-(sp)				*	move.l 24(%sp),-(%sp)
	jbsr ___extendsfdf2				*	jsr __extendsfdf2
	fmove.d fp0,-(sp)				*	fmove.d %fp0,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d0,d2					*	move.l %d0,%d2
	move.l d2,d3					*	move.l %d2,%d3
	and.l #-2147483648,d3				*	and.l #-2147483648,%d3
	move.l d3,12(sp)				*	move.l %d3,12(%sp)
	bclr #31,d2					*	bclr #31,%d2
	or.l d1,d2					*	or.l %d1,%d2
	addq.l #4,sp					*	addq.l #4,%sp
	jbeq _?L29					*	jeq .L29
	bfextu d0{#1:#11},d2				*	bfextu %d0{#1:#11},%d2
	add.l #15360,d2					*	add.l #15360,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d3,d2					*	or.l %d3,%d2
	move.l d2,8(sp)					*	move.l %d2,8(%sp)
	moveq #11,d2					*	moveq #11,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	and.l #2147481600,d0				*	and.l #2147481600,%d0
	move.l d1,d2					*	move.l %d1,%d2
	moveq #21,d3					*	moveq #21,%d3
	lsr.l d3,d2					*	lsr.l %d3,%d2
	or.l d2,d0					*	or.l %d2,%d0
	bset #31,d0					*	bset #31,%d0
	move.l d0,12(sp)				*	move.l %d0,12(%sp)
	move.l d1,d0					*	move.l %d1,%d0
	moveq #11,d2					*	moveq #11,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	move.l d0,16(sp)				*	move.l %d0,16(%sp)
	fmove.x 8(sp),fp0				*	fmove.x 8(%sp),%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	add.w #12,sp					*	add.w #12,%sp
	rts						*	rts
_?L29:							*.L29:
	clr.l 12(sp)					*	clr.l 12(%sp)
	clr.l 16(sp)					*	clr.l 16(%sp)
	fmove.x 8(sp),fp0				*	fmove.x 8(%sp),%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	add.w #12,sp					*	add.w #12,%sp
	rts						*	rts
							*	.size	__extendsfxf2, .-__extendsfxf2
	.align	2					*	.align	2
	.globl	___truncxfsf2				*	.globl	__truncxfsf2
							*	.hidden	__truncxfsf2
							*	.type	__truncxfsf2, @function
___truncxfsf2:						*__truncxfsf2:
	add.w #-36,sp					*	add.w #-36,%sp
	movem.l d3/d4/d5/d6/d7/a3,-(sp)			*	movem.l #7952,-(%sp)
	move.l 64(sp),a1				*	move.l 64(%sp),%a1
	move.l 68(sp),a2				*	move.l 68(%sp),%a2
	move.l 72(sp),a3				*	move.l 72(%sp),%a3
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	move.l a2,52(sp)				*	move.l %a2,52(%sp)
	move.l a3,56(sp)				*	move.l %a3,56(%sp)
	move.l 48(sp),d0				*	move.l 48(%sp),%d0
	move.l d0,d6					*	move.l %d0,%d6
	and.l #-2147483648,d6				*	and.l #-2147483648,%d6
	move.l d6,d2					*	move.l %d6,%d2
	move.l a1,36(sp)				*	move.l %a1,36(%sp)
	move.l a2,40(sp)				*	move.l %a2,40(%sp)
	move.l a3,44(sp)				*	move.l %a3,44(%sp)
	move.l 40(sp),d1				*	move.l 40(%sp),%d1
	move.l a1,24(sp)				*	move.l %a1,24(%sp)
	move.l a2,28(sp)				*	move.l %a2,28(%sp)
	move.l a3,32(sp)				*	move.l %a3,32(%sp)
	move.l 32(sp),d4				*	move.l 32(%sp),%d4
	move.l d0,d5					*	move.l %d0,%d5
	bclr #31,d5					*	bclr #31,%d5
	move.l d1,d7					*	move.l %d1,%d7
	or.l d4,d7					*	or.l %d4,%d7
	or.l d7,d5					*	or.l %d7,%d5
	jbeq _?L36					*	jeq .L36
	bfextu d0{#1:#15},d0				*	bfextu %d0{#1:#15},%d0
	add.l #-15360,d0				*	add.l #-15360,%d0
	cmp.l #2046,d0					*	cmp.l #2046,%d0
	jbgt _?L37					*	jgt .L37
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	bfextu d1{#1:#20},d5				*	bfextu %d1{#1:#20},%d5
	or.l d6,d5					*	or.l %d6,%d5
	move.l d0,d2					*	move.l %d0,%d2
	or.l d5,d2					*	or.l %d5,%d2
	moveq #21,d0					*	moveq #21,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	moveq #11,d0					*	moveq #11,%d0
	lsr.l d0,d4					*	lsr.l %d0,%d4
	move.l d1,d3					*	move.l %d1,%d3
	or.l d4,d3					*	or.l %d4,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
_?L32:							*.L32:
	fmove.d fp0,64(sp)				*	fmove.d %fp0,64(%sp)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2296
	add.w #36,sp					*	add.w #36,%sp
	jbra ___truncdfsf2				*	jra __truncdfsf2
_?L37:							*.L37:
	move.l #2046,d0					*	move.l #2046,%d0
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d0					*	lsl.l %d2,%d0
	bfextu d1{#1:#20},d5				*	bfextu %d1{#1:#20},%d5
	or.l d6,d5					*	or.l %d6,%d5
	move.l d0,d2					*	move.l %d0,%d2
	or.l d5,d2					*	or.l %d5,%d2
	moveq #21,d0					*	moveq #21,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	moveq #11,d0					*	moveq #11,%d0
	lsr.l d0,d4					*	lsr.l %d0,%d4
	move.l d1,d3					*	move.l %d1,%d3
	or.l d4,d3					*	or.l %d4,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	jbra _?L32					*	jra .L32
_?L36:							*.L36:
	clr.l d3					*	clr.l %d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fmove.d fp0,64(sp)				*	fmove.d %fp0,64(%sp)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2296
	add.w #36,sp					*	add.w #36,%sp
	jbra ___truncdfsf2				*	jra __truncdfsf2
							*	.size	__truncxfsf2, .-__truncxfsf2
	.align	2					*	.align	2
	.globl	___floatsixf				*	.globl	__floatsixf
							*	.hidden	__floatsixf
							*	.type	__floatsixf, @function
___floatsixf:						*__floatsixf:
	move.l 4(sp),-(sp)				*	move.l 4(%sp),-(%sp)
	jbsr ___floatsidf				*	jsr __floatsidf
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	__floatsixf, .-__floatsixf
	.align	2					*	.align	2
	.globl	___floatunsixf				*	.globl	__floatunsixf
							*	.hidden	__floatunsixf
							*	.type	__floatunsixf, @function
___floatunsixf:						*__floatunsixf:
	move.l 4(sp),-(sp)				*	move.l 4(%sp),-(%sp)
	jbsr ___floatunsidf				*	jsr __floatunsidf
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	__floatunsixf, .-__floatunsixf
	.align	2					*	.align	2
	.globl	___fixxfsi				*	.globl	__fixxfsi
							*	.hidden	__fixxfsi
							*	.type	__fixxfsi, @function
___fixxfsi:						*__fixxfsi:
	fmove.x 4(sp),fp0				*	fmove.x 4(%sp),%fp0
	fmove.d fp0,4(sp)				*	fmove.d %fp0,4(%sp)
	jbra ___fixdfsi					*	jra __fixdfsi
							*	.size	__fixxfsi, .-__fixxfsi
	.align	2					*	.align	2
	.globl	___addxf3				*	.globl	__addxf3
							*	.hidden	__addxf3
							*	.type	__addxf3, @function
___addxf3:						*__addxf3:
	fmove.x 4(sp),fp1				*	fmove.x 4(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fmove.x 16(sp),fp1				*	fmove.x 16(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp1				*	fdmove.d (%sp)+,%fp1
	fdadd.x fp1,fp0					*	fdadd.x %fp1,%fp0
	rts						*	rts
							*	.size	__addxf3, .-__addxf3
	.align	2					*	.align	2
	.globl	___subxf3				*	.globl	__subxf3
							*	.hidden	__subxf3
							*	.type	__subxf3, @function
___subxf3:						*__subxf3:
	fmove.x 4(sp),fp1				*	fmove.x 4(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fmove.x 16(sp),fp1				*	fmove.x 16(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp1				*	fdmove.d (%sp)+,%fp1
	fdsub.x fp1,fp0					*	fdsub.x %fp1,%fp0
	rts						*	rts
							*	.size	__subxf3, .-__subxf3
	.align	2					*	.align	2
	.globl	___mulxf3				*	.globl	__mulxf3
							*	.hidden	__mulxf3
							*	.type	__mulxf3, @function
___mulxf3:						*__mulxf3:
	fmove.x 4(sp),fp1				*	fmove.x 4(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fmove.x 16(sp),fp1				*	fmove.x 16(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp1				*	fdmove.d (%sp)+,%fp1
	fdmul.x fp1,fp0					*	fdmul.x %fp1,%fp0
	rts						*	rts
							*	.size	__mulxf3, .-__mulxf3
	.align	2					*	.align	2
	.globl	___divxf3				*	.globl	__divxf3
							*	.hidden	__divxf3
							*	.type	__divxf3, @function
___divxf3:						*__divxf3:
	fmove.x 4(sp),fp1				*	fmove.x 4(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fmove.x 16(sp),fp1				*	fmove.x 16(%sp),%fp1
	fmove.d fp1,-(sp)				*	fmove.d %fp1,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp1				*	fdmove.d (%sp)+,%fp1
	fddiv.x fp1,fp0					*	fddiv.x %fp1,%fp0
	rts						*	rts
							*	.size	__divxf3, .-__divxf3
	.align	2					*	.align	2
	.globl	___negxf2				*	.globl	__negxf2
							*	.hidden	__negxf2
							*	.type	__negxf2, @function
___negxf2:						*__negxf2:
	fmove.x 4(sp),fp0				*	fmove.x 4(%sp),%fp0
	fmove.d fp0,-(sp)				*	fmove.d %fp0,-(%sp)
	move.l (sp)+,d0					*	move.l (%sp)+,%d0
	move.l (sp)+,d1					*	move.l (%sp)+,%d1
	bchg #31,d0					*	bchg #31,%d0
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	rts						*	rts
							*	.size	__negxf2, .-__negxf2
	.align	2					*	.align	2
	.globl	___cmpxf2				*	.globl	__cmpxf2
							*	.hidden	__cmpxf2
							*	.type	__cmpxf2, @function
___cmpxf2:						*__cmpxf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__cmpxf2, .-__cmpxf2
	.align	2					*	.align	2
	.globl	___eqxf2				*	.globl	__eqxf2
							*	.hidden	__eqxf2
							*	.type	__eqxf2, @function
___eqxf2:						*__eqxf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__eqxf2, .-__eqxf2
	.align	2					*	.align	2
	.globl	___nexf2				*	.globl	__nexf2
							*	.hidden	__nexf2
							*	.type	__nexf2, @function
___nexf2:						*__nexf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__nexf2, .-__nexf2
	.align	2					*	.align	2
	.globl	___ltxf2				*	.globl	__ltxf2
							*	.hidden	__ltxf2
							*	.type	__ltxf2, @function
___ltxf2:						*__ltxf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__ltxf2, .-__ltxf2
	.align	2					*	.align	2
	.globl	___lexf2				*	.globl	__lexf2
							*	.hidden	__lexf2
							*	.type	__lexf2, @function
___lexf2:						*__lexf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__lexf2, .-__lexf2
	.align	2					*	.align	2
	.globl	___gtxf2				*	.globl	__gtxf2
							*	.hidden	__gtxf2
							*	.type	__gtxf2, @function
___gtxf2:						*__gtxf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__gtxf2, .-__gtxf2
	.align	2					*	.align	2
	.globl	___gexf2				*	.globl	__gexf2
							*	.hidden	__gexf2
							*	.type	__gexf2, @function
___gexf2:						*__gexf2:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	fmove.x 16(sp),fp2				*	fmove.x 16(%sp),%fp2
	fmove.x 28(sp),fp0				*	fmove.x 28(%sp),%fp0
	fmove.d fp0,24(sp)				*	fmove.d %fp0,24(%sp)
	fmove.d fp2,16(sp)				*	fmove.d %fp2,16(%sp)
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	jbra ___cmpdf2					*	jra __cmpdf2
							*	.size	__gexf2, .-__gexf2
							*	.ident	"GCC: (GNU) 13.4.0"
