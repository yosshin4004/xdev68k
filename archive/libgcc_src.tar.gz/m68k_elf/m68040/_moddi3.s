* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___moddi3				*	.globl	__moddi3
							*	.hidden	__moddi3
							*	.type	__moddi3, @function
___moddi3:						*__moddi3:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d4				*	move.l 40(%sp),%d4
	move.l 44(sp),d5				*	move.l 44(%sp),%d5
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l 52(sp),d3				*	move.l 52(%sp),%d3
	move.l d4,d1					*	move.l %d4,%d1
	jbmi _?L55					*	jmi .L55
	lea 0.w,a0					*	lea 0.w,%a0
	move.l d2,d0					*	move.l %d2,%d0
	jbmi _?L56					*	jmi .L56
_?L3:							*.L3:
	move.l d3,d2					*	move.l %d3,%d2
	move.l d5,d3					*	move.l %d5,%d3
	move.l d1,d6					*	move.l %d1,%d6
	tst.l d0					*	tst.l %d0
	jbne _?L4					*	jne .L4
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcc _?L5					*	jcc .L5
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbls _?L57					*	jls .L57
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L34					*	jhi .L34
	moveq #16,d0					*	moveq #16,%d0
_?L7:							*.L7:
	move.l d2,d4					*	move.l %d2,%d4
	lsr.l d0,d4					*	lsr.l %d0,%d4
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d4,d0					*	add.l %d4,%d0
	moveq #32,d5					*	moveq #32,%d5
	sub.l d0,d5					*	sub.l %d0,%d5
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d0,d4					*	cmp.l %d0,%d4
	jbeq _?L8					*	jeq .L8
	lsl.l d5,d2					*	lsl.l %d5,%d2
	move.l d1,d6					*	move.l %d1,%d6
	lsl.l d5,d6					*	lsl.l %d5,%d6
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l d0,d1					*	lsr.l %d0,%d1
	or.l d1,d6					*	or.l %d1,%d6
	lsl.l d5,d3					*	lsl.l %d5,%d3
_?L8:							*.L8:
	move.l d2,d0					*	move.l %d2,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d2,d7					*	move.l %d2,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	move.l d6,d1					*	move.l %d6,%d1
	divul.l d0,d6:d1				*	divul.l %d0,%d6:%d1
	muls.l d7,d1					*	muls.l %d7,%d1
	swap d6						*	swap %d6
	clr.w d6					*	clr.w %d6
	move.l d3,d4					*	move.l %d3,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	or.l d6,d4					*	or.l %d6,%d4
	cmp.l d1,d4					*	cmp.l %d1,%d4
	jbcc _?L9					*	jcc .L9
	add.l d2,d4					*	add.l %d2,%d4
	cmp.l d2,d4					*	cmp.l %d2,%d4
	jbcs _?L9					*	jcs .L9
	cmp.l d1,d4					*	cmp.l %d1,%d4
	jbcc _?L9					*	jcc .L9
	add.l d2,d4					*	add.l %d2,%d4
_?L9:							*.L9:
	sub.l d1,d4					*	sub.l %d1,%d4
	divul.l d0,d0:d4				*	divul.l %d0,%d0:%d4
	muls.l d7,d4					*	muls.l %d7,%d4
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d3,d0					*	or.w %d3,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcc _?L20					*	jcc .L20
_?L51:							*.L51:
	add.l d2,d0					*	add.l %d2,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L20					*	jcs .L20
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcc _?L20					*	jcc .L20
	add.l d2,d0					*	add.l %d2,%d0
_?L20:							*.L20:
	sub.l d4,d0					*	sub.l %d4,%d0
	clr.l d2					*	clr.l %d2
	move.l d0,d3					*	move.l %d0,%d3
	lsr.l d5,d3					*	lsr.l %d5,%d3
_?L21:							*.L21:
	tst.l a0					*	tst.l %a0
	jbeq _?L1					*	jeq .L1
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
_?L1:							*.L1:
	move.l d2,d0					*	move.l %d2,%d0
	move.l d3,d1					*	move.l %d3,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L4:							*.L4:
	move.l d5,a1					*	move.l %d5,%a1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L22					*	jcc .L22
	move.l d1,d2					*	move.l %d1,%d2
	jbra _?L21					*	jra .L21
_?L56:							*.L56:
	neg.l d3					*	neg.l %d3
	negx.l d2					*	negx.l %d2
	move.l d2,d0					*	move.l %d2,%d0
	jbra _?L3					*	jra .L3
_?L22:							*.L22:
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbls _?L58					*	jls .L58
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbhi _?L36					*	jhi .L36
	moveq #16,d4					*	moveq #16,%d4
_?L24:							*.L24:
	move.l d0,d5					*	move.l %d0,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	move.b ___clz_tab(d5.l),d5			*	move.b __clz_tab(%d5.l),%d5
	and.l #255,d5					*	and.l #255,%d5
	add.l d4,d5					*	add.l %d4,%d5
	moveq #32,d6					*	moveq #32,%d6
	sub.l d5,d6					*	sub.l %d5,%d6
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbne _?L25					*	jne .L25
_?L59:							*.L59:
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbhi _?L26					*	jhi .L26
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbcs _?L27					*	jcs .L27
_?L26:							*.L26:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d3					*	sub.l %d2,%d3
	subx.l d0,d1					*	subx.l %d0,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d3,a1					*	move.l %d3,%a1
_?L27:							*.L27:
	move.l d1,d2					*	move.l %d1,%d2
	move.l a1,d3					*	move.l %a1,%d3
	jbra _?L21					*	jra .L21
_?L5:							*.L5:
	tst.l d2					*	tst.l %d2
	jbeq _?L35					*	jeq .L35
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbhi _?L13					*	jhi .L13
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	lsl.l #3,d0					*	lsl.l #3,%d0
	move.l d2,d4					*	move.l %d2,%d4
	lsr.l d0,d4					*	lsr.l %d0,%d4
_?L12:							*.L12:
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d0,d4					*	add.l %d0,%d4
	moveq #32,d5					*	moveq #32,%d5
	sub.l d4,d5					*	sub.l %d4,%d5
	moveq #32,d0					*	moveq #32,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbne _?L15					*	jne .L15
_?L61:							*.L61:
	sub.l d2,d1					*	sub.l %d2,%d1
	move.l d2,d0					*	move.l %d2,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d2,d6					*	move.l %d2,%d6
	and.l #65535,d6					*	and.l #65535,%d6
_?L16:							*.L16:
	divul.l d0,d7:d1				*	divul.l %d0,%d7:%d1
	muls.l d6,d1					*	muls.l %d6,%d1
	swap d7						*	swap %d7
	clr.w d7					*	clr.w %d7
	move.l d3,d4					*	move.l %d3,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	or.l d7,d4					*	or.l %d7,%d4
	cmp.l d1,d4					*	cmp.l %d1,%d4
	jbcc _?L19					*	jcc .L19
	add.l d2,d4					*	add.l %d2,%d4
	cmp.l d2,d4					*	cmp.l %d2,%d4
	jbcs _?L19					*	jcs .L19
	cmp.l d1,d4					*	cmp.l %d1,%d4
	jbcc _?L19					*	jcc .L19
	add.l d2,d4					*	add.l %d2,%d4
_?L19:							*.L19:
	sub.l d1,d4					*	sub.l %d1,%d4
	divul.l d0,d0:d4				*	divul.l %d0,%d0:%d4
	muls.l d6,d4					*	muls.l %d6,%d4
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d3,d0					*	or.w %d3,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L51					*	jcs .L51
	sub.l d4,d0					*	sub.l %d4,%d0
	clr.l d2					*	clr.l %d2
	move.l d0,d3					*	move.l %d0,%d3
	lsr.l d5,d3					*	lsr.l %d5,%d3
	jbra _?L21					*	jra .L21
_?L55:							*.L55:
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
	move.l d4,d1					*	move.l %d4,%d1
	move.w #-1,a0					*	move.w #-1,%a0
	move.l d2,d0					*	move.l %d2,%d0
	jbpl _?L3					*	jpl .L3
	jbra _?L56					*	jra .L56
_?L57:							*.L57:
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	lsl.l #3,d0					*	lsl.l #3,%d0
	jbra _?L7					*	jra .L7
_?L58:							*.L58:
	cmp.l #255,d0					*	cmp.l #255,%d0
	shi d4						*	shi %d4
	extb.l d4					*	extb.l %d4
	neg.l d4					*	neg.l %d4
	lsl.l #3,d4					*	lsl.l #3,%d4
	move.l d0,d5					*	move.l %d0,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	move.b ___clz_tab(d5.l),d5			*	move.b __clz_tab(%d5.l),%d5
	and.l #255,d5					*	and.l #255,%d5
	add.l d4,d5					*	add.l %d4,%d5
	moveq #32,d6					*	moveq #32,%d6
	sub.l d5,d6					*	sub.l %d5,%d6
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbeq _?L59					*	jeq .L59
_?L25:							*.L25:
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d2,d7					*	move.l %d2,%d7
	lsr.l d5,d7					*	lsr.l %d5,%d7
	or.l d0,d7					*	or.l %d0,%d7
	lsl.l d6,d2					*	lsl.l %d6,%d2
	move.l d2,a2					*	move.l %d2,%a2
	move.l d1,d0					*	move.l %d1,%d0
	lsl.l d6,d0					*	lsl.l %d6,%d0
	move.l d3,d4					*	move.l %d3,%d4
	lsr.l d5,d4					*	lsr.l %d5,%d4
	or.l d0,d4					*	or.l %d0,%d4
	lsl.l d6,d3					*	lsl.l %d6,%d3
	move.l d3,a3					*	move.l %d3,%a3
	move.l d7,d0					*	move.l %d7,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d0,a6					*	move.l %d0,%a6
	move.l d7,d3					*	move.l %d7,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	lsr.l d5,d1					*	lsr.l %d5,%d1
	divul.l d0,d0:d1				*	divul.l %d0,%d0:%d1
	move.l d3,d2					*	move.l %d3,%d2
	muls.l d1,d2					*	muls.l %d1,%d2
	move.l d2,a4					*	move.l %d2,%a4
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d4,d2					*	move.l %d4,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d0,d2					*	or.l %d0,%d2
	move.l d2,a5					*	move.l %d2,%a5
	cmp.l a4,d2					*	cmp.l %a4,%d2
	jbcc _?L28					*	jcc .L28
	move.l d1,a1					*	move.l %d1,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d7,a5					*	add.l %d7,%a5
	cmp.l d7,a5					*	cmp.l %d7,%a5
	jbcs _?L38					*	jcs .L38
	cmp.l a4,a5					*	cmp.l %a4,%a5
	jbcc _?L38					*	jcc .L38
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d7,a5					*	add.l %d7,%a5
_?L28:							*.L28:
	move.l a5,d2					*	move.l %a5,%d2
	sub.l a4,d2					*	sub.l %a4,%d2
	move.l a6,d0					*	move.l %a6,%d0
	divul.l d0,d0:d2				*	divul.l %d0,%d0:%d2
	muls.l d2,d3					*	muls.l %d2,%d3
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d4,d0					*	or.w %d4,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L29					*	jcc .L29
	move.l d2,a1					*	move.l %d2,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d7,d0					*	add.l %d7,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcs _?L40					*	jcs .L40
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L40					*	jcc .L40
	subq.l #2,d2					*	subq.l #2,%d2
	add.l d7,d0					*	add.l %d7,%d0
_?L29:							*.L29:
	move.l d0,a4					*	move.l %d0,%a4
	sub.l d3,a4					*	sub.l %d3,%a4
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d2,d1					*	or.l %d2,%d1
	move.l d1,a1					*	move.l %d1,%a1
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	a1,d0					*	move.l	%a1,%d0
	move.l	a2,d1					*	move.l	%a2,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a5					*	move.l	%d2,%a5
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a1					*	move.l	%d0,%a1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a1,d1					*	move.l %a1,%d1
	move.l a5,d2					*	move.l %a5,%d2
	cmp.l a4,a1					*	cmp.l %a4,%a1
	jbhi _?L30					*	jhi .L30
	jbeq _?L60					*	jeq .L60
_?L31:							*.L31:
	move.l a4,d0					*	move.l %a4,%d0
	move.l a3,d3					*	move.l %a3,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d3					*	sub.l %d2,%d3
	subx.l d1,d0					*	subx.l %d1,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d4					*	move.l %d0,%d4
	lsl.l d5,d4					*	lsl.l %d5,%d4
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l d6,d1					*	lsr.l %d6,%d1
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d6,d2					*	lsr.l %d6,%d2
	move.l d4,d3					*	move.l %d4,%d3
	or.l d1,d3					*	or.l %d1,%d3
	jbra _?L21					*	jra .L21
_?L35:							*.L35:
	clr.l d4					*	clr.l %d4
	clr.l d0					*	clr.l %d0
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d0,d4					*	add.l %d0,%d4
	moveq #32,d5					*	moveq #32,%d5
	sub.l d4,d5					*	sub.l %d4,%d5
	moveq #32,d0					*	moveq #32,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbeq _?L61					*	jeq .L61
_?L15:							*.L15:
	lsl.l d5,d2					*	lsl.l %d5,%d2
	move.l d1,d0					*	move.l %d1,%d0
	lsl.l d5,d0					*	lsl.l %d5,%d0
	move.l d3,d7					*	move.l %d3,%d7
	lsr.l d4,d7					*	lsr.l %d4,%d7
	or.l d0,d7					*	or.l %d0,%d7
	lsl.l d5,d3					*	lsl.l %d5,%d3
	move.l d2,d0					*	move.l %d2,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d2,d6					*	move.l %d2,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	lsr.l d4,d1					*	lsr.l %d4,%d1
	divul.l d0,d4:d1				*	divul.l %d0,%d4:%d1
	muls.l d6,d1					*	muls.l %d6,%d1
	move.l d1,a3					*	move.l %d1,%a3
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	move.l d7,d1					*	move.l %d7,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d4,d1					*	or.l %d4,%d1
	move.l d1,a1					*	move.l %d1,%a1
	cmp.l a3,d1					*	cmp.l %a3,%d1
	jbcc _?L17					*	jcc .L17
	add.l d2,a1					*	add.l %d2,%a1
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbcs _?L17					*	jcs .L17
	cmp.l a3,a1					*	cmp.l %a3,%a1
	jbcc _?L17					*	jcc .L17
	add.l d2,a1					*	add.l %d2,%a1
_?L17:							*.L17:
	move.l a1,d4					*	move.l %a1,%d4
	sub.l a3,d4					*	sub.l %a3,%d4
	divul.l d0,d1:d4				*	divul.l %d0,%d1:%d4
	muls.l d6,d4					*	muls.l %d6,%d4
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d7,d1					*	or.w %d7,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L18					*	jcc .L18
	add.l d2,d1					*	add.l %d2,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L18					*	jcs .L18
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L18					*	jcc .L18
	add.l d2,d1					*	add.l %d2,%d1
_?L18:							*.L18:
	sub.l d4,d1					*	sub.l %d4,%d1
	jbra _?L16					*	jra .L16
_?L60:							*.L60:
	cmp.l a3,a5					*	cmp.l %a3,%a5
	jbls _?L31					*	jls .L31
_?L30:							*.L30:
	move.l a1,d1					*	move.l %a1,%d1
	move.l a5,d2					*	move.l %a5,%d2
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a2,d2					*	sub.l %a2,%d2
	subx.l d7,d1					*	subx.l %d7,%d1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a4,d0					*	move.l %a4,%d0
	move.l a3,d3					*	move.l %a3,%d3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d3					*	sub.l %d2,%d3
	subx.l d1,d0					*	subx.l %d1,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d4					*	move.l %d0,%d4
	lsl.l d5,d4					*	lsl.l %d5,%d4
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l d6,d1					*	lsr.l %d6,%d1
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l d6,d2					*	lsr.l %d6,%d2
	move.l d4,d3					*	move.l %d4,%d3
	or.l d1,d3					*	or.l %d1,%d3
	jbra _?L21					*	jra .L21
_?L13:							*.L13:
	move.l d2,d4					*	move.l %d2,%d4
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L14					*	jhi .L14
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	moveq #16,d0					*	moveq #16,%d0
	jbra _?L12					*	jra .L12
_?L34:							*.L34:
	moveq #24,d0					*	moveq #24,%d0
	jbra _?L7					*	jra .L7
_?L36:							*.L36:
	moveq #24,d4					*	moveq #24,%d4
	jbra _?L24					*	jra .L24
_?L40:							*.L40:
	move.l a1,d2					*	move.l %a1,%d2
	jbra _?L29					*	jra .L29
_?L38:							*.L38:
	move.l a1,d1					*	move.l %a1,%d1
	jbra _?L28					*	jra .L28
_?L14:							*.L14:
	moveq #24,d0					*	moveq #24,%d0
	lsr.l d0,d4					*	lsr.l %d0,%d4
	jbra _?L12					*	jra .L12
							*	.size	__moddi3, .-__moddi3
							*	.ident	"GCC: (GNU) 13.4.0"
