* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___floatundisf				*	.globl	__floatundisf
							*	.hidden	__floatundisf
							*	.type	__floatundisf, @function
___floatundisf:						*__floatundisf:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	move.l #2097151,d2				*	move.l #2097151,%d2
	moveq #-1,d3					*	moveq #-1,%d3
	sub.l d1,d3					*	sub.l %d1,%d3
	subx.l d0,d2					*	subx.l %d0,%d2
	jbcc _?L2					*	jcc .L2
	clr.l d2					*	clr.l %d2
	clr.l d3					*	clr.l %d3
	move.l d1,d3					*	move.l %d1,%d3
	and.l #2047,d3					*	and.l #2047,%d3
	move.l d2,d4					*	move.l %d2,%d4
	or.l d3,d4					*	or.l %d3,%d4
	jbeq _?L2					*	jeq .L2
	move.l d1,d2					*	move.l %d1,%d2
	and.w #63488,d2					*	and.w #63488,%d2
	move.l d2,d1					*	move.l %d2,%d1
	or.w #2048,d1					*	or.w #2048,%d1
_?L2:							*.L2:
	fdmove.l d0,fp0					*	fdmove.l %d0,%fp0
	tst.l d0					*	tst.l %d0
	jblt _?L10					*	jlt .L10
	fdmove.x fp0,fp1				*	fdmove.x %fp0,%fp1
	fdmul.d #0x41f00000,#0x00000000,fp1		*	fdmul.d #0x41f0000000000000,%fp1
	fdmove.l d1,fp0					*	fdmove.l %d1,%fp0
	tst.l d1					*	tst.l %d1
	jblt _?L11					*	jlt .L11
_?L4:							*.L4:
	fdadd.x fp1,fp0					*	fdadd.x %fp1,%fp0
	fsmove.x fp0,fp0				*	fsmove.x %fp0,%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L11:							*.L11:
	fdadd.d #0x41f00000,#0x00000000,fp0		*	fdadd.d #0x41f0000000000000,%fp0
	fdadd.x fp1,fp0					*	fdadd.x %fp1,%fp0
	fsmove.x fp0,fp0				*	fsmove.x %fp0,%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L10:							*.L10:
	fdadd.d #0x41f00000,#0x00000000,fp0		*	fdadd.d #0x41f0000000000000,%fp0
	fdmove.x fp0,fp1				*	fdmove.x %fp0,%fp1
	fdmul.d #0x41f00000,#0x00000000,fp1		*	fdmul.d #0x41f0000000000000,%fp1
	fdmove.l d1,fp0					*	fdmove.l %d1,%fp0
	tst.l d1					*	tst.l %d1
	jbge _?L4					*	jge .L4
	jbra _?L11					*	jra .L11
							*	.size	__floatundisf, .-__floatundisf
							*	.ident	"GCC: (GNU) 13.4.0"
