* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___negdi2				*	.globl	__negdi2
							*	.hidden	__negdi2
							*	.type	__negdi2, @function
___negdi2:						*__negdi2:
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	sne d0						*	sne %d0
	extb.l d0					*	extb.l %d0
	sub.l 4(sp),d0					*	sub.l 4(%sp),%d0
	neg.l d1					*	neg.l %d1
	rts						*	rts
							*	.size	__negdi2, .-__negdi2
							*	.ident	"GCC: (GNU) 13.4.0"
