* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___floatdidf				*	.globl	__floatdidf
							*	.hidden	__floatdidf
							*	.type	__floatdidf, @function
___floatdidf:						*__floatdidf:
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	fmove.d #0x41f00000,#0x00000000,fp1		*	fmove.d #0x41f0000000000000,%fp1
	fdmul.l 4(sp),fp1				*	fdmul.l 4(%sp),%fp1
	fdmove.l d0,fp0					*	fdmove.l %d0,%fp0
	tst.l d0					*	tst.l %d0
	jblt _?L5					*	jlt .L5
	fdadd.x fp1,fp0					*	fdadd.x %fp1,%fp0
	rts						*	rts
_?L5:							*.L5:
	fdadd.d #0x41f00000,#0x00000000,fp0		*	fdadd.d #0x41f0000000000000,%fp0
	fdadd.x fp1,fp0					*	fdadd.x %fp1,%fp0
	rts						*	rts
							*	.size	__floatdidf, .-__floatdidf
							*	.ident	"GCC: (GNU) 13.4.0"
