* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clrsbsi2				*	.globl	__clrsbsi2
							*	.hidden	__clrsbsi2
							*	.type	__clrsbsi2, @function
___clrsbsi2:						*__clrsbsi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l d0,d2					*	move.l %d0,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	move.l d0,d1					*	move.l %d0,%d1
	eor.l d2,d1					*	eor.l %d2,%d1
	cmp.l d0,d2					*	cmp.l %d0,%d2
	jbeq _?L5					*	jeq .L5
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbgt _?L3					*	jgt .L3
	cmp.l #255,d1					*	cmp.l #255,%d1
	sgt d2						*	sgt %d2
	extb.l d2					*	extb.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	moveq #31,d0					*	moveq #31,%d0
	sub.l d2,d0					*	sub.l %d2,%d0
	lsr.l d2,d1					*	lsr.l %d2,%d1
	move.b ___clz_tab(d1.l),d1			*	move.b __clz_tab(%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
_?L1:							*.L1:
	rts						*	rts
_?L3:							*.L3:
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbgt _?L6					*	jgt .L6
	moveq #15,d0					*	moveq #15,%d0
	moveq #16,d2					*	moveq #16,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	move.b ___clz_tab(d1.l),d1			*	move.b __clz_tab(%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	jbra _?L1					*	jra .L1
_?L5:							*.L5:
	moveq #31,d0					*	moveq #31,%d0
	rts						*	rts
_?L6:							*.L6:
	moveq #7,d0					*	moveq #7,%d0
	moveq #24,d2					*	moveq #24,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	move.b ___clz_tab(d1.l),d1			*	move.b __clz_tab(%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	jbra _?L1					*	jra .L1
							*	.size	__clrsbsi2, .-__clrsbsi2
							*	.ident	"GCC: (GNU) 13.4.0"
