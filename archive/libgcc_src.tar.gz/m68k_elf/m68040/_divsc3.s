* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divsc3				*	.globl	__divsc3
							*	.hidden	__divsc3
							*	.type	__divsc3, @function
___divsc3:						*__divsc3:
	fmovem fp2/fp3/fp4/fp5/fp6,-(sp)		*	fmovem #124,-(%sp)
	fdmove.s 64(sp),fp3				*	fdmove.s 64(%sp),%fp3
	fdmove.s 68(sp),fp0				*	fdmove.s 68(%sp),%fp0
	fdmove.s 72(sp),fp5				*	fdmove.s 72(%sp),%fp5
	fdmove.s 76(sp),fp4				*	fdmove.s 76(%sp),%fp4
	fdmove.x fp5,fp1				*	fdmove.x %fp5,%fp1
	fdmul.x fp5,fp1					*	fdmul.x %fp5,%fp1
	fdmove.x fp4,fp2				*	fdmove.x %fp4,%fp2
	fdmul.x fp4,fp2					*	fdmul.x %fp4,%fp2
	fdadd.x fp2,fp1					*	fdadd.x %fp2,%fp1
	fdmove.x fp3,fp2				*	fdmove.x %fp3,%fp2
	fdmul.x fp5,fp2					*	fdmul.x %fp5,%fp2
	fdmove.x fp0,fp6				*	fdmove.x %fp0,%fp6
	fdmul.x fp4,fp6					*	fdmul.x %fp4,%fp6
	fdadd.x fp6,fp2					*	fdadd.x %fp6,%fp2
	fddiv.x fp1,fp2					*	fddiv.x %fp1,%fp2
	fsmove.x fp2,fp2				*	fsmove.x %fp2,%fp2
	fdmul.x fp5,fp0					*	fdmul.x %fp5,%fp0
	fdmul.x fp4,fp3					*	fdmul.x %fp4,%fp3
	fdsub.x fp3,fp0					*	fdsub.x %fp3,%fp0
	fddiv.x fp1,fp0					*	fddiv.x %fp1,%fp0
	fsmove.x fp0,fp0				*	fsmove.x %fp0,%fp0
	fcmp.x fp2,fp2					*	fcmp.x %fp2,%fp2
	fbun _?L37					*	fjun .L37
_?L2:							*.L2:
	fmove.s fp2,d0					*	fmove.s %fp2,%d0
	fmove.s fp0,d1					*	fmove.s %fp0,%d1
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L37:							*.L37:
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L2					*	fjor .L2
	ftst.s 72(sp)					*	ftst.s 72(%sp)
	fbne _?L3					*	fjne .L3
	ftst.s 76(sp)					*	ftst.s 76(%sp)
	fbne _?L3					*	fjne .L3
	fsmove.s 64(sp),fp1				*	fsmove.s 64(%sp),%fp1
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbun _?L38					*	fjun .L38
_?L4:							*.L4:
	fmove.s #0x7f800000,fp0				*	fmove.s #0x7f800000,%fp0
	tst.l 72(sp)					*	tst.l 72(%sp)
	jbge _?L5					*	jge .L5
	fmove.s #0xff800000,fp0				*	fmove.s #0xff800000,%fp0
_?L5:							*.L5:
	fsmove.s 64(sp),fp2				*	fsmove.s 64(%sp),%fp2
	fsmul.x fp0,fp2					*	fsmul.x %fp0,%fp2
	fsmul.s 68(sp),fp0				*	fsmul.s 68(%sp),%fp0
	fmove.s fp2,d0					*	fmove.s %fp2,%d0
	fmove.s fp0,d1					*	fmove.s %fp0,%d1
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L38:							*.L38:
	fsmove.s 68(sp),fp1				*	fsmove.s 68(%sp),%fp1
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L4					*	fjor .L4
	fmove.s fp2,d0					*	fmove.s %fp2,%d0
	fmove.s fp0,d1					*	fmove.s %fp0,%d1
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L3:							*.L3:
	fsabs.s 64(sp),fp1				*	fsabs.s 64(%sp),%fp1
	fsabs.s 72(sp),fp3				*	fsabs.s 72(%sp),%fp3
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbule _?L6					*	fjule .L6
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbugt _?L2					*	fjugt .L2
	clr.b d0					*	clr.b %d0
	fmove.s #0x7f800000,fp1				*	fmove.s #0x7f800000,%fp1
_?L7:							*.L7:
	fsabs.s 76(sp),fp3				*	fsabs.s 76(%sp),%fp3
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbugt _?L9					*	fjugt .L9
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fsmove.l d0,fp1					*	fsmove.l %d0,%fp1
	fsabs.x fp1,fp1					*	fsabs.x %fp1,%fp1
	tst.l 64(sp)					*	tst.l 64(%sp)
	jbge _?L10					*	jge .L10
	fsneg.x fp1,fp1					*	fsneg.x %fp1,%fp1
_?L10:							*.L10:
	fsabs.s 68(sp),fp0				*	fsabs.s 68(%sp),%fp0
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fsmove.l d0,fp0					*	fsmove.l %d0,%fp0
	fsabs.x fp0,fp0					*	fsabs.x %fp0,%fp0
	tst.l 68(sp)					*	tst.l 68(%sp)
	jbge _?L11					*	jge .L11
	fsneg.x fp0,fp0					*	fsneg.x %fp0,%fp0
_?L11:							*.L11:
	fsmove.s 72(sp),fp2				*	fsmove.s 72(%sp),%fp2
	fsmul.x fp1,fp2					*	fsmul.x %fp1,%fp2
	fsmove.s 76(sp),fp3				*	fsmove.s 76(%sp),%fp3
	fsmul.x fp0,fp3					*	fsmul.x %fp0,%fp3
	fsadd.x fp3,fp2					*	fsadd.x %fp3,%fp2
	fsmul.s #0x7f800000,fp2				*	fsmul.s #0x7f800000,%fp2
	fsmul.s 72(sp),fp0				*	fsmul.s 72(%sp),%fp0
	fsmul.s 76(sp),fp1				*	fsmul.s 76(%sp),%fp1
	fssub.x fp1,fp0					*	fssub.x %fp1,%fp0
	fsmul.s #0x7f800000,fp0				*	fsmul.s #0x7f800000,%fp0
	fmove.s fp2,d0					*	fmove.s %fp2,%d0
	fmove.s fp0,d1					*	fmove.s %fp0,%d1
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L6:							*.L6:
	fsabs.s 68(sp),fp4				*	fsabs.s 68(%sp),%fp4
	fcmp.s #0x7f7fffff,fp4				*	fcmp.s #0x7f7fffff,%fp4
	fbule _?L8					*	fjule .L8
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbugt _?L8					*	fjugt .L8
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L7					*	jra .L7
_?L8:							*.L8:
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbule _?L39					*	fjule .L39
	clr.b d0					*	clr.b %d0
_?L12:							*.L12:
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbugt _?L2					*	fjugt .L2
	fsabs.s 68(sp),fp1				*	fsabs.s 68(%sp),%fp1
	fcmp.s #0x7f7fffff,fp1				*	fcmp.s #0x7f7fffff,%fp1
	fbugt _?L2					*	fjugt .L2
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fsmove.l d0,fp1					*	fsmove.l %d0,%fp1
	fsabs.x fp1,fp1					*	fsabs.x %fp1,%fp1
	tst.l 72(sp)					*	tst.l 72(%sp)
	jbge _?L14					*	jge .L14
	fsneg.x fp1,fp1					*	fsneg.x %fp1,%fp1
_?L14:							*.L14:
	fsabs.s 76(sp),fp0				*	fsabs.s 76(%sp),%fp0
	fcmp.s #0x7f7fffff,fp0				*	fcmp.s #0x7f7fffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fsmove.l d0,fp0					*	fsmove.l %d0,%fp0
	fsabs.x fp0,fp0					*	fsabs.x %fp0,%fp0
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L15					*	jge .L15
	fsneg.x fp0,fp0					*	fsneg.x %fp0,%fp0
_?L15:							*.L15:
	fsmove.s 64(sp),fp2				*	fsmove.s 64(%sp),%fp2
	fsmul.x fp1,fp2					*	fsmul.x %fp1,%fp2
	fsmove.s 68(sp),fp3				*	fsmove.s 68(%sp),%fp3
	fsmul.x fp0,fp3					*	fsmul.x %fp0,%fp3
	fsadd.x fp3,fp2					*	fsadd.x %fp3,%fp2
	fsmul.s #0x0,fp2				*	fsmul.s #0x0,%fp2
	fsmul.s 68(sp),fp1				*	fsmul.s 68(%sp),%fp1
	fsmul.s 64(sp),fp0				*	fsmul.s 64(%sp),%fp0
	fssub.x fp0,fp1					*	fssub.x %fp0,%fp1
	fsmove.x fp1,fp0				*	fsmove.x %fp1,%fp0
	fsmul.s #0x0,fp0				*	fsmul.s #0x0,%fp0
	fmove.s fp2,d0					*	fmove.s %fp2,%d0
	fmove.s fp0,d1					*	fmove.s %fp0,%d1
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6		*	fmovem (%sp)+,#62
	rts						*	rts
_?L39:							*.L39:
	fsabs.s 76(sp),fp3				*	fsabs.s 76(%sp),%fp3
_?L9:							*.L9:
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbule _?L2					*	fjule .L2
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L12					*	jra .L12
							*	.size	__divsc3, .-__divsc3
							*	.ident	"GCC: (GNU) 13.4.0"
