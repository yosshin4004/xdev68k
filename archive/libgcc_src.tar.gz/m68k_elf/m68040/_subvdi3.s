* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___subvdi3				*	.globl	__subvdi3
							*	.hidden	__subvdi3
							*	.type	__subvdi3, @function
___subvdi3:						*__subvdi3:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 24(sp),d2				*	move.l 24(%sp),%d2
	move.l 28(sp),d3				*	move.l 28(%sp),%d3
	move.l 16(sp),d4				*	move.l 16(%sp),%d4
	move.l 20(sp),d5				*	move.l 20(%sp),%d5
	sub.l d3,d5					*	sub.l %d3,%d5
	subx.l d2,d4					*	subx.l %d2,%d4
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	eor.l d2,d1					*	eor.l %d2,%d1
	eor.l d4,d2					*	eor.l %d4,%d2
	not.l d2					*	not.l %d2
	and.l d2,d1					*	and.l %d2,%d1
	jbmi _?L8					*	jmi .L8
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L8:							*.L8:
	trap #7						*	trap #7
							*	.size	__subvdi3, .-__subvdi3
							*	.ident	"GCC: (GNU) 13.4.0"
