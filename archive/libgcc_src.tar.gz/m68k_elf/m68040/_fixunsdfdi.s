* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsdfdi				*	.globl	__fixunsdfdi
							*	.hidden	__fixunsdfdi
							*	.type	__fixunsdfdi, @function
___fixunsdfdi:						*__fixunsdfdi:
	fmovem fp2,-(sp)				*	fmovem #4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	fdmove.d 20(sp),fp0				*	fdmove.d 20(%sp),%fp0
	fdmove.x fp0,fp2				*	fdmove.x %fp0,%fp2
	fdmul.d #0x3df00000,#0x00000000,fp2		*	fdmul.d #0x3df0000000000000,%fp2
	fcmp.d #0x41e00000,#0x00000000,fp2		*	fcmp.d #0x41e0000000000000,%fp2
	fbge _?L2					*	fjge .L2
	fmovem.l fpcr,d1				*	fmovem.l %fpcr,%d1
	moveq #16,d2					*	moveq #16,%d2
	or.l d1,d2					*	or.l %d1,%d2
	and.w #-33,d2					*	and.w #-33,%d2
	fmovem.l d2,fpcr				*	fmovem.l %d2,%fpcr
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	fmovem.l d1,fpcr				*	fmovem.l %d1,%fpcr
	fdmove.l d0,fp2					*	fdmove.l %d0,%fp2
	tst.l d0					*	tst.l %d0
	jblt _?L9					*	jlt .L9
_?L4:							*.L4:
	fdmul.d #0x41f00000,#0x00000000,fp2		*	fdmul.d #0x41f0000000000000,%fp2
	fdsub.x fp2,fp0					*	fdsub.x %fp2,%fp0
	fcmp.d #0x41e00000,#0x00000000,fp0		*	fcmp.d #0x41e0000000000000,%fp0
	fbge _?L5					*	fjge .L5
	fmovem.l fpcr,d2				*	fmovem.l %fpcr,%d2
	moveq #16,d3					*	moveq #16,%d3
	or.l d2,d3					*	or.l %d2,%d3
	and.w #-33,d3					*	and.w #-33,%d3
	fmovem.l d3,fpcr				*	fmovem.l %d3,%fpcr
	fmove.l fp0,d1					*	fmove.l %fp0,%d1
	fmovem.l d2,fpcr				*	fmovem.l %d2,%fpcr
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L5:							*.L5:
	fdsub.d #0x41e00000,#0x00000000,fp0		*	fdsub.d #0x41e0000000000000,%fp0
	fmovem.l fpcr,d2				*	fmovem.l %fpcr,%d2
	moveq #16,d3					*	moveq #16,%d3
	or.l d2,d3					*	or.l %d2,%d3
	and.w #-33,d3					*	and.w #-33,%d3
	fmovem.l d3,fpcr				*	fmovem.l %d3,%fpcr
	fmove.l fp0,d1					*	fmove.l %fp0,%d1
	fmovem.l d2,fpcr				*	fmovem.l %d2,%fpcr
	add.l #-2147483648,d1				*	add.l #-2147483648,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	fmovem (sp)+,fp2				*	fmovem (%sp)+,#32
	rts						*	rts
_?L2:							*.L2:
	fdsub.d #0x41e00000,#0x00000000,fp2		*	fdsub.d #0x41e0000000000000,%fp2
	fmovem.l fpcr,d3				*	fmovem.l %fpcr,%d3
	moveq #16,d1					*	moveq #16,%d1
	or.l d3,d1					*	or.l %d3,%d1
	and.w #-33,d1					*	and.w #-33,%d1
	fmovem.l d1,fpcr				*	fmovem.l %d1,%fpcr
	fmove.l fp2,d0					*	fmove.l %fp2,%d0
	fmovem.l d3,fpcr				*	fmovem.l %d3,%fpcr
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	fdmove.l d0,fp2					*	fdmove.l %d0,%fp2
	tst.l d0					*	tst.l %d0
	jbge _?L4					*	jge .L4
_?L9:							*.L9:
	fdadd.d #0x41f00000,#0x00000000,fp2		*	fdadd.d #0x41f0000000000000,%fp2
	jbra _?L4					*	jra .L4
							*	.size	__fixunsdfdi, .-__fixunsdfdi
							*	.ident	"GCC: (GNU) 13.4.0"
