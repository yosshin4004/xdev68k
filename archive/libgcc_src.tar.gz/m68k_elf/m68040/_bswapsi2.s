* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___bswapsi2				*	.globl	__bswapsi2
							*	.hidden	__bswapsi2
							*	.type	__bswapsi2, @function
___bswapsi2:						*__bswapsi2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	ror.w #8,d0					*	ror.w #8,%d0
	swap d0						*	swap %d0
	ror.w #8,d0					*	ror.w #8,%d0
	rts						*	rts
							*	.size	__bswapsi2, .-__bswapsi2
							*	.ident	"GCC: (GNU) 13.4.0"
