* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___transfer_from_trampoline		*	.globl	__transfer_from_trampoline
							*	.hidden	__transfer_from_trampoline
							*	.type	__transfer_from_trampoline, @function
___transfer_from_trampoline:				*__transfer_from_trampoline:
* APP ON (APP) asm_mode=gas				*#APP
							*| 2320 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
		.globl	____trampoline			*		.globl	___trampoline
							*| 0 "" 2
							*| 2320 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	____trampoline:					*	___trampoline:
							*| 0 "" 2
							*| 2320 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	move.l 22(a1),(sp)				*	move.l 22(%a1),(%sp)
							*| 0 "" 2
							*| 2320 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	move.l 18(a1),a1				*	move.l 18(%a1),%a1
							*| 0 "" 2
							*| 2320 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	rts						*	rts
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	rts						*	rts
							*	.size	__transfer_from_trampoline, .-__transfer_from_trampoline
							*	.ident	"GCC: (GNU) 13.4.0"
