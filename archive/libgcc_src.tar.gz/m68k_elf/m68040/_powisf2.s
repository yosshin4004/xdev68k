* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___powisf2				*	.globl	__powisf2
							*	.hidden	__powisf2
							*	.type	__powisf2, @function
___powisf2:						*__powisf2:
	fsmove.s 4(sp),fp1				*	fsmove.s 4(%sp),%fp1
	move.l 8(sp),d1					*	move.l 8(%sp),%d1
	move.l d1,d0					*	move.l %d1,%d0
	jbmi _?L18					*	jmi .L18
_?L2:							*.L2:
	btst #0,d0					*	btst #0,%d0
	jbeq _?L8					*	jeq .L8
	fsmove.x fp1,fp0				*	fsmove.x %fp1,%fp0
_?L3:							*.L3:
	lsr.l #1,d0					*	lsr.l #1,%d0
	jbeq _?L4					*	jeq .L4
_?L19:							*.L19:
	fsmul.x fp1,fp1					*	fsmul.x %fp1,%fp1
	btst #0,d0					*	btst #0,%d0
	jbeq _?L3					*	jeq .L3
	fsmul.x fp1,fp0					*	fsmul.x %fp1,%fp0
	lsr.l #1,d0					*	lsr.l #1,%d0
	jbne _?L19					*	jne .L19
_?L4:							*.L4:
	tst.l d1					*	tst.l %d1
	jblt _?L20					*	jlt .L20
	rts						*	rts
_?L8:							*.L8:
	fmove.s #0x3f800000,fp0				*	fmove.s #0x3f800000,%fp0
	jbra _?L3					*	jra .L3
_?L20:							*.L20:
	fmove.s #0x3f800000,fp1				*	fmove.s #0x3f800000,%fp1
	fsdiv.x fp0,fp1					*	fsdiv.x %fp0,%fp1
	fsmove.x fp1,fp0				*	fsmove.x %fp1,%fp0
	rts						*	rts
_?L18:							*.L18:
	neg.l d0					*	neg.l %d0
	jbra _?L2					*	jra .L2
							*	.size	__powisf2, .-__powisf2
							*	.ident	"GCC: (GNU) 13.4.0"
