* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___muldi3				*	.globl	__muldi3
							*	.hidden	__muldi3
							*	.type	__muldi3, @function
___muldi3:						*__muldi3:
	movem.l d3/d4/d5/d6,-(sp)			*	movem.l #7680,-(%sp)
	move.l 24(sp),d5				*	move.l 24(%sp),%d5
	move.l 32(sp),d6				*	move.l 32(%sp),%d6
* APP ON (APP) asm_mode=gas				*#APP
							*| 532 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	d5,d0					*	move.l	%d5,%d0
	move.l	d6,d1					*	move.l	%d6,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a0					*	move.l	%d2,%a0
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a1					*	move.l	%d0,%a1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	muls.l 28(sp),d5				*	muls.l 28(%sp),%d5
	add.l a1,d5					*	add.l %a1,%d5
	move.l 20(sp),d0				*	move.l 20(%sp),%d0
	muls.l d6,d0					*	muls.l %d6,%d0
	add.l d5,d0					*	add.l %d5,%d0
	move.l a0,d1					*	move.l %a0,%d1
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
							*	.size	__muldi3, .-__muldi3
							*	.ident	"GCC: (GNU) 13.4.0"
