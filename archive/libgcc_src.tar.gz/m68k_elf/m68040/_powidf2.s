* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___powidf2				*	.globl	__powidf2
							*	.hidden	__powidf2
							*	.type	__powidf2, @function
___powidf2:						*__powidf2:
	fdmove.d 4(sp),fp1				*	fdmove.d 4(%sp),%fp1
	move.l 12(sp),d1				*	move.l 12(%sp),%d1
	move.l d1,d0					*	move.l %d1,%d0
	jbmi _?L18					*	jmi .L18
_?L2:							*.L2:
	btst #0,d0					*	btst #0,%d0
	jbeq _?L8					*	jeq .L8
	fdmove.x fp1,fp0				*	fdmove.x %fp1,%fp0
_?L3:							*.L3:
	lsr.l #1,d0					*	lsr.l #1,%d0
	jbeq _?L4					*	jeq .L4
_?L19:							*.L19:
	fdmul.x fp1,fp1					*	fdmul.x %fp1,%fp1
	btst #0,d0					*	btst #0,%d0
	jbeq _?L3					*	jeq .L3
	fdmul.x fp1,fp0					*	fdmul.x %fp1,%fp0
	lsr.l #1,d0					*	lsr.l #1,%d0
	jbne _?L19					*	jne .L19
_?L4:							*.L4:
	tst.l d1					*	tst.l %d1
	jblt _?L20					*	jlt .L20
	rts						*	rts
_?L8:							*.L8:
	fmove.d #0x3ff00000,#0x00000000,fp0		*	fmove.d #0x3ff0000000000000,%fp0
	jbra _?L3					*	jra .L3
_?L20:							*.L20:
	fmove.d #0x3ff00000,#0x00000000,fp1		*	fmove.d #0x3ff0000000000000,%fp1
	fddiv.x fp0,fp1					*	fddiv.x %fp0,%fp1
	fdmove.x fp1,fp0				*	fdmove.x %fp1,%fp0
	rts						*	rts
_?L18:							*.L18:
	neg.l d0					*	neg.l %d0
	jbra _?L2					*	jra .L2
							*	.size	__powidf2, .-__powidf2
							*	.ident	"GCC: (GNU) 13.4.0"
