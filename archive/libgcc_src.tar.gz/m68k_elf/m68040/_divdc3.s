* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divdc3				*	.globl	__divdc3
							*	.hidden	__divdc3
							*	.type	__divdc3, @function
___divdc3:						*__divdc3:
	fmovem fp2/fp3/fp4/fp6,-(sp)			*	fmovem #92,-(%sp)
	fdabs.d 68(sp),fp0				*	fdabs.d 68(%sp),%fp0
	fdabs.d 76(sp),fp2				*	fdabs.d 76(%sp),%fp2
	fcmp.x fp2,fp0					*	fcmp.x %fp2,%fp0
	fbnlt _?L77					*	fjnlt .L77
	fcmp.d #0x7fdfffff,#0xffffffff,fp2		*	fcmp.d #0x7fdfffffffffffff,%fp2
	fbnge _?L4					*	fjnge .L4
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.d #0x3fe00000,#0x00000000,fp0		*	fdmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fdmul.d #0x3fe00000,#0x00000000,fp1		*	fdmul.d #0x3fe0000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.d #0x3fe00000,#0x00000000,fp0		*	fdmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.d #0x3fe00000,#0x00000000,fp1		*	fdmul.d #0x3fe0000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
	fdabs.x fp1,fp2					*	fdabs.x %fp1,%fp2
_?L4:							*.L4:
	fcmp.d #0x3cb00000,#0x00000000,fp2		*	fcmp.d #0x3cb0000000000000,%fp2
	fbnlt _?L78					*	fjnlt .L78
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
_?L8:							*.L8:
	fdmove.d 68(sp),fp2				*	fdmove.d 68(%sp),%fp2
	fddiv.d 76(sp),fp2				*	fddiv.d 76(%sp),%fp2
	fdmove.d 68(sp),fp1				*	fdmove.d 68(%sp),%fp1
	fdmul.x fp2,fp1					*	fdmul.x %fp2,%fp1
	fdadd.d 76(sp),fp1				*	fdadd.d 76(%sp),%fp1
	fdabs.x fp2,fp0					*	fdabs.x %fp2,%fp0
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fbngt _?L80					*	fjngt .L80
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.x fp2,fp0					*	fdmul.x %fp2,%fp0
	fdadd.d 60(sp),fp0				*	fdadd.d 60(%sp),%fp0
	fdmove.x fp0,fp3				*	fdmove.x %fp0,%fp3
	fddiv.x fp1,fp3					*	fddiv.x %fp1,%fp3
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fdmul.x fp2,fp0					*	fdmul.x %fp2,%fp0
	fdsub.d 52(sp),fp0				*	fdsub.d 52(%sp),%fp0
	fddiv.x fp1,fp0					*	fddiv.x %fp1,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbun _?L96					*	fjun .L96
_?L31:							*.L31:
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L77:							*.L77:
	fcmp.d #0x7fdfffff,#0xffffffff,fp0		*	fcmp.d #0x7fdfffffffffffff,%fp0
	fbnge _?L18					*	fjnge .L18
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.d #0x3fe00000,#0x00000000,fp0		*	fdmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fdmul.d #0x3fe00000,#0x00000000,fp1		*	fdmul.d #0x3fe0000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.d #0x3fe00000,#0x00000000,fp0		*	fdmul.d #0x3fe0000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.d #0x3fe00000,#0x00000000,fp1		*	fdmul.d #0x3fe0000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
	fdabs.x fp0,fp0					*	fdabs.x %fp0,%fp0
_?L18:							*.L18:
	fcmp.d #0x3cb00000,#0x00000000,fp0		*	fcmp.d #0x3cb0000000000000,%fp0
	fbnlt _?L81					*	fjnlt .L81
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
_?L22:							*.L22:
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fddiv.d 68(sp),fp1				*	fddiv.d 68(%sp),%fp1
	fdmove.d 76(sp),fp2				*	fdmove.d 76(%sp),%fp2
	fdmul.x fp1,fp2					*	fdmul.x %fp1,%fp2
	fdadd.d 68(sp),fp2				*	fdadd.d 68(%sp),%fp2
	fdabs.x fp1,fp0					*	fdabs.x %fp1,%fp0
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fbngt _?L83					*	fjngt .L83
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fdmul.x fp1,fp0					*	fdmul.x %fp1,%fp0
	fdadd.d 52(sp),fp0				*	fdadd.d 52(%sp),%fp0
	fdmove.x fp0,fp3				*	fdmove.x %fp0,%fp3
	fddiv.x fp2,fp3					*	fddiv.x %fp2,%fp3
	fdmul.d 52(sp),fp1				*	fdmul.d 52(%sp),%fp1
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fdsub.x fp1,fp0					*	fdsub.x %fp1,%fp0
	fddiv.x fp2,fp0					*	fddiv.x %fp2,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L31					*	fjor .L31
	jbra _?L96					*	jra .L96
_?L78:							*.L78:
	fdabs.d 52(sp),fp0				*	fdabs.d 52(%sp),%fp0
	fdabs.d 60(sp),fp4				*	fdabs.d 60(%sp),%fp4
	fcmp.d #0x10000000,#0x000000,fp0		*	fcmp.d #0x10000000000000,%fp0
	fblt _?L97					*	fjlt .L97
	fcmp.d #0x10000000,#0x000000,fp4		*	fcmp.d #0x10000000000000,%fp4
	fbnlt _?L8					*	fjnlt .L8
	fcmp.d #0x7c9fffff,#0xffffffff,fp0		*	fcmp.d #0x7c9fffffffffffff,%fp0
	fbnlt _?L8					*	fjnlt .L8
	fcmp.d #0x7c9fffff,#0xffffffff,fp2		*	fcmp.d #0x7c9fffffffffffff,%fp2
	fbnlt _?L8					*	fjnlt .L8
_?L100:							*.L100:
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
	jbra _?L8					*	jra .L8
_?L81:							*.L81:
	fdabs.d 52(sp),fp2				*	fdabs.d 52(%sp),%fp2
	fdabs.d 60(sp),fp4				*	fdabs.d 60(%sp),%fp4
	fcmp.d #0x10000000,#0x000000,fp2		*	fcmp.d #0x10000000000000,%fp2
	fblt _?L98					*	fjlt .L98
	fcmp.d #0x10000000,#0x000000,fp4		*	fcmp.d #0x10000000000000,%fp4
	fbnlt _?L22					*	fjnlt .L22
	fcmp.d #0x7c9fffff,#0xffffffff,fp2		*	fcmp.d #0x7c9fffffffffffff,%fp2
	fbnlt _?L22					*	fjnlt .L22
	fcmp.d #0x7c9fffff,#0xffffffff,fp0		*	fcmp.d #0x7c9fffffffffffff,%fp0
	fbnlt _?L22					*	fjnlt .L22
_?L99:							*.L99:
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,52(sp)				*	fmove.d %fp0,52(%sp)
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,60(sp)				*	fmove.d %fp1,60(%sp)
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.d #0x43300000,#0x00000000,fp0		*	fdmul.d #0x4330000000000000,%fp0
	fmove.d fp0,68(sp)				*	fmove.d %fp0,68(%sp)
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.d #0x43300000,#0x00000000,fp1		*	fdmul.d #0x4330000000000000,%fp1
	fmove.d fp1,76(sp)				*	fmove.d %fp1,76(%sp)
	jbra _?L22					*	jra .L22
_?L80:							*.L80:
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fddiv.d 76(sp),fp0				*	fddiv.d 76(%sp),%fp0
	fdmul.d 68(sp),fp0				*	fdmul.d 68(%sp),%fp0
	fdadd.d 60(sp),fp0				*	fdadd.d 60(%sp),%fp0
	fdmove.x fp0,fp3				*	fdmove.x %fp0,%fp3
	fddiv.x fp1,fp3					*	fddiv.x %fp1,%fp3
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fddiv.d 76(sp),fp0				*	fddiv.d 76(%sp),%fp0
	fdmul.d 68(sp),fp0				*	fdmul.d 68(%sp),%fp0
	fdsub.d 52(sp),fp0				*	fdsub.d 52(%sp),%fp0
	fddiv.x fp1,fp0					*	fddiv.x %fp1,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L31					*	fjor .L31
	jbra _?L96					*	jra .L96
_?L83:							*.L83:
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fddiv.d 68(sp),fp0				*	fddiv.d 68(%sp),%fp0
	fdmul.d 76(sp),fp0				*	fdmul.d 76(%sp),%fp0
	fdadd.d 52(sp),fp0				*	fdadd.d 52(%sp),%fp0
	fdmove.x fp0,fp3				*	fdmove.x %fp0,%fp3
	fddiv.x fp2,fp3					*	fddiv.x %fp2,%fp3
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fddiv.d 68(sp),fp0				*	fddiv.d 68(%sp),%fp0
	fdmove.d 76(sp),fp1				*	fdmove.d 76(%sp),%fp1
	fdmul.x fp0,fp1					*	fdmul.x %fp0,%fp1
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fdsub.x fp1,fp0					*	fdsub.x %fp1,%fp0
	fddiv.x fp2,fp0					*	fddiv.x %fp2,%fp0
	fcmp.x fp3,fp3					*	fcmp.x %fp3,%fp3
	fbor _?L31					*	fjor .L31
	jbra _?L96					*	jra .L96
_?L98:							*.L98:
	fcmp.d #0x7c9fffff,#0xffffffff,fp4		*	fcmp.d #0x7c9fffffffffffff,%fp4
	fbnlt _?L22					*	fjnlt .L22
	fcmp.d #0x7c9fffff,#0xffffffff,fp0		*	fcmp.d #0x7c9fffffffffffff,%fp0
	fbnlt _?L22					*	fjnlt .L22
	jbra _?L99					*	jra .L99
_?L97:							*.L97:
	fcmp.d #0x7c9fffff,#0xffffffff,fp4		*	fcmp.d #0x7c9fffffffffffff,%fp4
	fbnlt _?L8					*	fjnlt .L8
	fcmp.d #0x7c9fffff,#0xffffffff,fp2		*	fcmp.d #0x7c9fffffffffffff,%fp2
	fbnlt _?L8					*	fjnlt .L8
	jbra _?L100					*	jra .L100
_?L96:							*.L96:
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L31					*	fjor .L31
	ftst.d 68(sp)					*	ftst.d 68(%sp)
	fbne _?L32					*	fjne .L32
	ftst.d 76(sp)					*	ftst.d 76(%sp)
	fbeq _?L33					*	fjeq .L33
	fdabs.d 52(sp),fp2				*	fdabs.d 52(%sp),%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbule _?L34					*	fjule .L34
_?L88:							*.L88:
	clr.b d0					*	clr.b %d0
	fmove.d #0x7ff00000,#0x00000000,fp2		*	fmove.d #0x7ff0000000000000,%fp2
_?L35:							*.L35:
	fdabs.d 76(sp),fp4				*	fdabs.d 76(%sp),%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbugt _?L40					*	fjugt .L40
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp2					*	fdmove.l %d0,%fp2
	fdabs.x fp2,fp2					*	fdabs.x %fp2,%fp2
	tst.l 52(sp)					*	tst.l 52(%sp)
	jbge _?L41					*	jge .L41
	fdneg.x fp2,fp2					*	fdneg.x %fp2,%fp2
_?L41:							*.L41:
	fdabs.d 60(sp),fp0				*	fdabs.d 60(%sp),%fp0
	fcmp.d #0x7fefffff,#0xffffffff,fp0		*	fcmp.d #0x7fefffffffffffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp0					*	fdmove.l %d0,%fp0
	fdabs.x fp0,fp1					*	fdabs.x %fp0,%fp1
	tst.l 60(sp)					*	tst.l 60(%sp)
	jbge _?L42					*	jge .L42
	fdneg.x fp1,fp1					*	fdneg.x %fp1,%fp1
_?L42:							*.L42:
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.x fp2,fp0					*	fdmul.x %fp2,%fp0
	fdmove.d 76(sp),fp3				*	fdmove.d 76(%sp),%fp3
	fdmul.x fp1,fp3					*	fdmul.x %fp1,%fp3
	fdadd.x fp3,fp0					*	fdadd.x %fp3,%fp0
	fdmove.x fp0,fp3				*	fdmove.x %fp0,%fp3
	fdmul.d #0x7ff00000,#0x00000000,fp3		*	fdmul.d #0x7ff0000000000000,%fp3
	fdmove.d 68(sp),fp0				*	fdmove.d 68(%sp),%fp0
	fdmul.x fp1,fp0					*	fdmul.x %fp1,%fp0
	fdmul.d 76(sp),fp2				*	fdmul.d 76(%sp),%fp2
	fdsub.x fp2,fp0					*	fdsub.x %fp2,%fp0
	fdmul.d #0x7ff00000,#0x00000000,fp0		*	fdmul.d #0x7ff0000000000000,%fp0
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L34:							*.L34:
	fdabs.d 60(sp),fp4				*	fdabs.d 60(%sp),%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbule _?L47					*	fjule .L47
_?L89:							*.L89:
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L35					*	jra .L35
_?L47:							*.L47:
	fdabs.d 76(sp),fp4				*	fdabs.d 76(%sp),%fp4
_?L40:							*.L40:
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbule _?L31					*	fjule .L31
	moveq #1,d0					*	moveq #1,%d0
_?L43:							*.L43:
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbugt _?L31					*	fjugt .L31
	fdabs.d 60(sp),fp2				*	fdabs.d 60(%sp),%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbugt _?L31					*	fjugt .L31
	eor.b #1,d0					*	eor.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp0					*	fdmove.l %d0,%fp0
	fdabs.x fp0,fp1					*	fdabs.x %fp0,%fp1
	tst.l 68(sp)					*	tst.l 68(%sp)
	jbge _?L45					*	jge .L45
	fdneg.x fp1,fp1					*	fdneg.x %fp1,%fp1
_?L45:							*.L45:
	fdabs.d 76(sp),fp0				*	fdabs.d 76(%sp),%fp0
	fcmp.d #0x7fefffff,#0xffffffff,fp0		*	fcmp.d #0x7fefffffffffffff,%fp0
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp2					*	fdmove.l %d0,%fp2
	fdabs.x fp2,fp2					*	fdabs.x %fp2,%fp2
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L46					*	jge .L46
	fdneg.x fp2,fp2					*	fdneg.x %fp2,%fp2
_?L46:							*.L46:
	fdmove.d 52(sp),fp0				*	fdmove.d 52(%sp),%fp0
	fdmul.x fp1,fp0					*	fdmul.x %fp1,%fp0
	fdmove.d 60(sp),fp3				*	fdmove.d 60(%sp),%fp3
	fdmul.x fp2,fp3					*	fdmul.x %fp2,%fp3
	fdadd.x fp3,fp0					*	fdadd.x %fp3,%fp0
	fdmove.x fp0,fp3				*	fdmove.x %fp0,%fp3
	fdmul.d #0x00000000,#0x0,fp3			*	fdmul.d #0x000000000,%fp3
	fdmove.d 60(sp),fp0				*	fdmove.d 60(%sp),%fp0
	fdmul.x fp1,fp0					*	fdmul.x %fp1,%fp0
	fdmul.d 52(sp),fp2				*	fdmul.d 52(%sp),%fp2
	fdsub.x fp2,fp0					*	fdsub.x %fp2,%fp0
	fdmul.d #0x00000000,#0x0,fp0			*	fdmul.d #0x000000000,%fp0
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L32:							*.L32:
	fdabs.d 52(sp),fp2				*	fdabs.d 52(%sp),%fp2
	fdabs.d 68(sp),fp4				*	fdabs.d 68(%sp),%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbule _?L38					*	fjule .L38
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbole _?L88					*	fjole .L88
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L33:							*.L33:
	fdmove.d 52(sp),fp1				*	fdmove.d 52(%sp),%fp1
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbun _?L101					*	fjun .L101
_?L36:							*.L36:
	fmove.d #0x7ff00000,#0x00000000,fp0		*	fmove.d #0x7ff0000000000000,%fp0
	tst.l 68(sp)					*	tst.l 68(%sp)
	jbge _?L37					*	jge .L37
	fmove.d #0xfff00000,#0x00000000,fp0		*	fmove.d #0xfff0000000000000,%fp0
_?L37:							*.L37:
	fdmove.d 52(sp),fp3				*	fdmove.d 52(%sp),%fp3
	fdmul.x fp0,fp3					*	fdmul.x %fp0,%fp3
	fdmul.d 60(sp),fp0				*	fdmul.d 60(%sp),%fp0
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L101:							*.L101:
	fdmove.d 60(sp),fp1				*	fdmove.d 60(%sp),%fp1
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L36					*	fjor .L36
	fmove.d fp3,(a0)				*	fmove.d %fp3,(%a0)
	fmove.d fp0,8(a0)				*	fmove.d %fp0,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp6			*	fmovem (%sp)+,#58
	rts						*	rts
_?L38:							*.L38:
	fdabs.d 60(sp),fp6				*	fdabs.d 60(%sp),%fp6
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fbule _?L39					*	fjule .L39
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbole _?L89					*	fjole .L89
_?L39:							*.L39:
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbule _?L47					*	fjule .L47
	clr.b d0					*	clr.b %d0
	jbra _?L43					*	jra .L43
							*	.size	__divdc3, .-__divdc3
							*	.ident	"GCC: (GNU) 13.4.0"
