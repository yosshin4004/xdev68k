* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___divdi3				*	.globl	__divdi3
							*	.hidden	__divdi3
							*	.type	__divdi3, @function
___divdi3:						*__divdi3:
	movem.l d3/d4/d5/d6/d7/a3,-(sp)			*	movem.l #7952,-(%sp)
	move.l 28(sp),d0				*	move.l 28(%sp),%d0
	move.l 32(sp),d1				*	move.l 32(%sp),%d1
	move.l 36(sp),d4				*	move.l 36(%sp),%d4
	move.l 40(sp),d5				*	move.l 40(%sp),%d5
	move.l d0,a1					*	move.l %d0,%a1
	tst.l a1					*	tst.l %a1
	jblt _?L61					*	jlt .L61
	clr.l d6					*	clr.l %d6
	move.l d4,d2					*	move.l %d4,%d2
	jbmi _?L62					*	jmi .L62
_?L3:							*.L3:
	move.l d5,d0					*	move.l %d5,%d0
	move.l d1,d7					*	move.l %d1,%d7
	move.l a1,d1					*	move.l %a1,%d1
	tst.l d2					*	tst.l %d2
	jbne _?L4					*	jne .L4
	cmp.l d5,a1					*	cmp.l %d5,%a1
	jbcc _?L5					*	jcc .L5
	cmp.l #65535,d5					*	cmp.l #65535,%d5
	jbls _?L63					*	jls .L63
	cmp.l #16777215,d5				*	cmp.l #16777215,%d5
	jbhi _?L31					*	jhi .L31
	moveq #16,d2					*	moveq #16,%d2
_?L7:							*.L7:
	move.l d0,d3					*	move.l %d0,%d3
	lsr.l d2,d3					*	lsr.l %d2,%d3
	move.b ___clz_tab(d3.l),d3			*	move.b __clz_tab(%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	add.l d2,d3					*	add.l %d2,%d3
	moveq #32,d4					*	moveq #32,%d4
	sub.l d3,d4					*	sub.l %d3,%d4
	moveq #32,d2					*	moveq #32,%d2
	cmp.l d3,d2					*	cmp.l %d3,%d2
	jbeq _?L8					*	jeq .L8
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l a1,d2					*	move.l %a1,%d2
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d7,d1					*	move.l %d7,%d1
	lsr.l d3,d1					*	lsr.l %d3,%d1
	or.l d2,d1					*	or.l %d2,%d1
	lsl.l d4,d7					*	lsl.l %d4,%d7
_?L8:							*.L8:
	move.l d0,d4					*	move.l %d0,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	move.l d0,d3					*	move.l %d0,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	divul.l d4,d5:d1				*	divul.l %d4,%d5:%d1
	move.l d3,d2					*	move.l %d3,%d2
	muls.l d1,d2					*	muls.l %d1,%d2
	move.l d2,a0					*	move.l %d2,%a0
	swap d5						*	swap %d5
	clr.w d5					*	clr.w %d5
	move.l d7,d2					*	move.l %d7,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d5,d2					*	or.l %d5,%d2
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbcc _?L9					*	jcc .L9
	move.l d1,a1					*	move.l %d1,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d0,d2					*	add.l %d0,%d2
	cmp.l d0,d2					*	cmp.l %d0,%d2
	jbcs _?L33					*	jcs .L33
	cmp.l a0,d2					*	cmp.l %a0,%d2
	jbcc _?L33					*	jcc .L33
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d0,d2					*	add.l %d0,%d2
_?L9:							*.L9:
	sub.l a0,d2					*	sub.l %a0,%d2
	divul.l d4,d4:d2				*	divul.l %d4,%d4:%d2
	muls.l d2,d3					*	muls.l %d2,%d3
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.w d7,d4					*	or.w %d7,%d4
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbcc _?L10					*	jcc .L10
	move.l d2,a0					*	move.l %d2,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d0,d4					*	add.l %d0,%d4
	cmp.l d0,d4					*	cmp.l %d0,%d4
	jbcs _?L35					*	jcs .L35
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbcc _?L35					*	jcc .L35
	subq.l #2,d2					*	subq.l #2,%d2
_?L10:							*.L10:
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d2,d1					*	or.l %d2,%d1
	clr.l d2					*	clr.l %d2
_?L11:							*.L11:
	move.l d2,d4					*	move.l %d2,%d4
	move.l d1,d5					*	move.l %d1,%d5
	tst.l d6					*	tst.l %d6
	jbeq _?L1					*	jeq .L1
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
_?L1:							*.L1:
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3			*	movem.l (%sp)+,#2296
	rts						*	rts
_?L4:							*.L4:
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbcc _?L64					*	jcc .L64
_?L47:							*.L47:
	clr.l d1					*	clr.l %d1
	clr.l d2					*	clr.l %d2
	jbra _?L11					*	jra .L11
_?L62:							*.L62:
	not.l d6					*	not.l %d6
	neg.l d5					*	neg.l %d5
	negx.l d4					*	negx.l %d4
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L3					*	jra .L3
_?L64:							*.L64:
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbls _?L65					*	jls .L65
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L46					*	jhi .L46
	moveq #16,d1					*	moveq #16,%d1
_?L22:							*.L22:
	move.l d2,d3					*	move.l %d2,%d3
	lsr.l d1,d3					*	lsr.l %d1,%d3
	move.b ___clz_tab(d3.l),d3			*	move.b __clz_tab(%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	add.l d1,d3					*	add.l %d1,%d3
	move.w #32,a0					*	move.w #32,%a0
	sub.l d3,a0					*	sub.l %d3,%a0
	moveq #32,d5					*	moveq #32,%d5
	cmp.l d3,d5					*	cmp.l %d3,%d5
	jbne _?L23					*	jne .L23
_?L67:							*.L67:
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbhi _?L24					*	jhi .L24
	cmp.l d0,d7					*	cmp.l %d0,%d7
	jbcs _?L47					*	jcs .L47
_?L24:							*.L24:
	moveq #1,d1					*	moveq #1,%d1
	clr.l d2					*	clr.l %d2
	jbra _?L11					*	jra .L11
_?L5:							*.L5:
	tst.l d5					*	tst.l %d5
	jbeq _?L36					*	jeq .L36
	cmp.l #65535,d5					*	cmp.l #65535,%d5
	jbhi _?L13					*	jhi .L13
	cmp.l #255,d5					*	cmp.l #255,%d5
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d5,d2					*	move.l %d5,%d2
	lsr.l d1,d2					*	lsr.l %d1,%d2
_?L12:							*.L12:
	clr.l d5					*	clr.l %d5
	move.b ___clz_tab(d2.l),d5			*	move.b __clz_tab(%d2.l),%d5
	add.l d1,d5					*	add.l %d1,%d5
	moveq #32,d1					*	moveq #32,%d1
	sub.l d5,d1					*	sub.l %d5,%d1
	moveq #32,d2					*	moveq #32,%d2
	cmp.l d5,d2					*	cmp.l %d5,%d2
	jbne _?L15					*	jne .L15
_?L66:							*.L66:
	move.l a1,d1					*	move.l %a1,%d1
	sub.l d0,d1					*	sub.l %d0,%d1
	move.l d0,d4					*	move.l %d0,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	move.l d4,a3					*	move.l %d4,%a3
	move.l d0,d3					*	move.l %d0,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	moveq #1,d2					*	moveq #1,%d2
_?L16:							*.L16:
	move.l a3,d5					*	move.l %a3,%d5
	divul.l d5,d5:d1				*	divul.l %d5,%d5:%d1
	move.l d1,d4					*	move.l %d1,%d4
	muls.l d3,d4					*	muls.l %d3,%d4
	move.l d4,a1					*	move.l %d4,%a1
	swap d5						*	swap %d5
	clr.w d5					*	clr.w %d5
	move.l d7,d4					*	move.l %d7,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	or.l d5,d4					*	or.l %d5,%d4
	move.l d4,a2					*	move.l %d4,%a2
	cmp.l a1,d4					*	cmp.l %a1,%d4
	jbcc _?L19					*	jcc .L19
	move.l d1,a0					*	move.l %d1,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d0,a2					*	add.l %d0,%a2
	cmp.l d0,a2					*	cmp.l %d0,%a2
	jbcs _?L42					*	jcs .L42
	cmp.l a1,a2					*	cmp.l %a1,%a2
	jbcc _?L42					*	jcc .L42
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d0,a2					*	add.l %d0,%a2
_?L19:							*.L19:
	move.l a2,d5					*	move.l %a2,%d5
	sub.l a1,d5					*	sub.l %a1,%d5
	move.l a3,d4					*	move.l %a3,%d4
	divul.l d4,d4:d5				*	divul.l %d4,%d4:%d5
	muls.l d5,d3					*	muls.l %d5,%d3
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	or.w d7,d4					*	or.w %d7,%d4
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbcc _?L20					*	jcc .L20
	move.l d5,a0					*	move.l %d5,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d0,d4					*	add.l %d0,%d4
	cmp.l d0,d4					*	cmp.l %d0,%d4
	jbcs _?L44					*	jcs .L44
	cmp.l d3,d4					*	cmp.l %d3,%d4
	jbcc _?L44					*	jcc .L44
	subq.l #2,d5					*	subq.l #2,%d5
_?L20:							*.L20:
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d5,d1					*	or.l %d5,%d1
	jbra _?L11					*	jra .L11
_?L61:							*.L61:
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	move.l d0,a1					*	move.l %d0,%a1
	moveq #-1,d6					*	moveq #-1,%d6
	move.l d4,d2					*	move.l %d4,%d2
	jbpl _?L3					*	jpl .L3
	jbra _?L62					*	jra .L62
_?L63:							*.L63:
	cmp.l #255,d5					*	cmp.l #255,%d5
	shi d2						*	shi %d2
	extb.l d2					*	extb.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	jbra _?L7					*	jra .L7
_?L36:							*.L36:
	clr.l d2					*	clr.l %d2
	clr.l d1					*	clr.l %d1
	clr.l d5					*	clr.l %d5
	move.b ___clz_tab(d2.l),d5			*	move.b __clz_tab(%d2.l),%d5
	add.l d1,d5					*	add.l %d1,%d5
	moveq #32,d1					*	moveq #32,%d1
	sub.l d5,d1					*	sub.l %d5,%d1
	moveq #32,d2					*	moveq #32,%d2
	cmp.l d5,d2					*	cmp.l %d5,%d2
	jbeq _?L66					*	jeq .L66
_?L15:							*.L15:
	lsl.l d1,d0					*	lsl.l %d1,%d0
	move.l a1,d3					*	move.l %a1,%d3
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d7,d2					*	move.l %d7,%d2
	lsr.l d5,d2					*	lsr.l %d5,%d2
	or.l d3,d2					*	or.l %d3,%d2
	lsl.l d1,d7					*	lsl.l %d1,%d7
	move.l d0,d1					*	move.l %d0,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	move.l d1,a3					*	move.l %d1,%a3
	move.l d0,d3					*	move.l %d0,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	move.l a1,d1					*	move.l %a1,%d1
	lsr.l d5,d1					*	lsr.l %d5,%d1
	move.l d1,d4					*	move.l %d1,%d4
	move.l a3,d5					*	move.l %a3,%d5
	divul.l d5,d1:d4				*	divul.l %d5,%d1:%d4
	move.l d4,a1					*	move.l %d4,%a1
	muls.l d3,d4					*	muls.l %d3,%d4
	move.l d4,a0					*	move.l %d4,%a0
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l d2,d5					*	move.l %d2,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	or.l d1,d5					*	or.l %d1,%d5
	cmp.l d4,d5					*	cmp.l %d4,%d5
	jbcc _?L17					*	jcc .L17
	move.l a1,d1					*	move.l %a1,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	add.l d0,d5					*	add.l %d0,%d5
	cmp.l d0,d5					*	cmp.l %d0,%d5
	jbcs _?L38					*	jcs .L38
	cmp.l d4,d5					*	cmp.l %d4,%d5
	jbcc _?L38					*	jcc .L38
	subq.l #2,a1					*	subq.l #2,%a1
	add.l d0,d5					*	add.l %d0,%d5
_?L17:							*.L17:
	sub.l a0,d5					*	sub.l %a0,%d5
	move.l a3,d1					*	move.l %a3,%d1
	divul.l d1,d1:d5				*	divul.l %d1,%d1:%d5
	move.l d3,d4					*	move.l %d3,%d4
	muls.l d5,d4					*	muls.l %d5,%d4
	move.l d4,a0					*	move.l %d4,%a0
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d2,d1					*	or.w %d2,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L18					*	jcc .L18
	move.l d5,d2					*	move.l %d5,%d2
	subq.l #1,d2					*	subq.l #1,%d2
	add.l d0,d1					*	add.l %d0,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L40					*	jcs .L40
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L40					*	jcc .L40
	subq.l #2,d5					*	subq.l #2,%d5
	add.l d0,d1					*	add.l %d0,%d1
_?L18:							*.L18:
	sub.l a0,d1					*	sub.l %a0,%d1
	move.l a1,d2					*	move.l %a1,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d5,d2					*	or.l %d5,%d2
	jbra _?L16					*	jra .L16
_?L65:							*.L65:
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d2,d3					*	move.l %d2,%d3
	lsr.l d1,d3					*	lsr.l %d1,%d3
	move.b ___clz_tab(d3.l),d3			*	move.b __clz_tab(%d3.l),%d3
	and.l #255,d3					*	and.l #255,%d3
	add.l d1,d3					*	add.l %d1,%d3
	move.w #32,a0					*	move.w #32,%a0
	sub.l d3,a0					*	sub.l %d3,%a0
	moveq #32,d5					*	moveq #32,%d5
	cmp.l d3,d5					*	cmp.l %d3,%d5
	jbeq _?L67					*	jeq .L67
_?L23:							*.L23:
	move.l a0,d1					*	move.l %a0,%d1
	lsl.l d1,d2					*	lsl.l %d1,%d2
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d3,d4					*	lsr.l %d3,%d4
	or.l d2,d4					*	or.l %d2,%d4
	lsl.l d1,d0					*	lsl.l %d1,%d0
	move.l d0,a2					*	move.l %d0,%a2
	move.l a1,d0					*	move.l %a1,%d0
	lsl.l d1,d0					*	lsl.l %d1,%d0
	move.l d7,d5					*	move.l %d7,%d5
	lsr.l d3,d5					*	lsr.l %d3,%d5
	or.l d0,d5					*	or.l %d0,%d5
	move.l d4,d0					*	move.l %d4,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d4,d2					*	move.l %d4,%d2
	and.l #65535,d2					*	and.l #65535,%d2
	move.l d2,a3					*	move.l %d2,%a3
	move.l a1,d1					*	move.l %a1,%d1
	lsr.l d3,d1					*	lsr.l %d3,%d1
	divul.l d0,d3:d1				*	divul.l %d0,%d3:%d1
	muls.l d1,d2					*	muls.l %d1,%d2
	move.l d2,a1					*	move.l %d2,%a1
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	move.l d5,d2					*	move.l %d5,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d3,d2					*	or.l %d3,%d2
	cmp.l a1,d2					*	cmp.l %a1,%d2
	jbcc _?L25					*	jcc .L25
	move.l d1,d3					*	move.l %d1,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	add.l d4,d2					*	add.l %d4,%d2
	cmp.l d4,d2					*	cmp.l %d4,%d2
	jbcs _?L49					*	jcs .L49
	cmp.l a1,d2					*	cmp.l %a1,%d2
	jbcc _?L49					*	jcc .L49
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d4,d2					*	add.l %d4,%d2
_?L25:							*.L25:
	sub.l a1,d2					*	sub.l %a1,%d2
	divul.l d0,d0:d2				*	divul.l %d0,%d0:%d2
	move.l a3,d3					*	move.l %a3,%d3
	muls.l d2,d3					*	muls.l %d2,%d3
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d5,d0					*	or.w %d5,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L26					*	jcc .L26
	move.l d2,a1					*	move.l %d2,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d4,d0					*	add.l %d4,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L51					*	jcs .L51
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L51					*	jcc .L51
	subq.l #2,d2					*	subq.l #2,%d2
	add.l d4,d0					*	add.l %d4,%d0
_?L26:							*.L26:
	move.l d0,a1					*	move.l %d0,%a1
	sub.l d3,a1					*	sub.l %d3,%a1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l d1,d5					*	move.l %d1,%d5
	or.l d2,d5					*	or.l %d2,%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	d5,d0					*	move.l	%d5,%d0
	move.l	a2,d1					*	move.l	%a2,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a3					*	move.l	%d2,%a3
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a2					*	move.l	%d0,%a2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	cmp.l a1,a2					*	cmp.l %a1,%a2
	jbhi _?L27					*	jhi .L27
	jbeq _?L28					*	jeq .L28
_?L58:							*.L58:
	move.l d5,d1					*	move.l %d5,%d1
	clr.l d2					*	clr.l %d2
	jbra _?L11					*	jra .L11
_?L33:							*.L33:
	move.l a1,d1					*	move.l %a1,%d1
	jbra _?L9					*	jra .L9
_?L35:							*.L35:
	move.l a0,d2					*	move.l %a0,%d2
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d2,d1					*	or.l %d2,%d1
	clr.l d2					*	clr.l %d2
	jbra _?L11					*	jra .L11
_?L42:							*.L42:
	move.l a0,d1					*	move.l %a0,%d1
	jbra _?L19					*	jra .L19
_?L44:							*.L44:
	move.l a0,d5					*	move.l %a0,%d5
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d5,d1					*	or.l %d5,%d1
	jbra _?L11					*	jra .L11
_?L28:							*.L28:
	move.l a0,d4					*	move.l %a0,%d4
	lsl.l d4,d7					*	lsl.l %d4,%d7
	cmp.l d7,a3					*	cmp.l %d7,%a3
	jbls _?L58					*	jls .L58
_?L27:							*.L27:
	move.l d5,d1					*	move.l %d5,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	clr.l d2					*	clr.l %d2
	jbra _?L11					*	jra .L11
_?L46:							*.L46:
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L22					*	jra .L22
_?L31:							*.L31:
	moveq #24,d2					*	moveq #24,%d2
	jbra _?L7					*	jra .L7
_?L13:							*.L13:
	move.l d5,d2					*	move.l %d5,%d2
	cmp.l #16777215,d5				*	cmp.l #16777215,%d5
	jbhi _?L14					*	jhi .L14
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	moveq #16,d1					*	moveq #16,%d1
	jbra _?L12					*	jra .L12
_?L40:							*.L40:
	move.l d2,d5					*	move.l %d2,%d5
	sub.l a0,d1					*	sub.l %a0,%d1
	move.l a1,d2					*	move.l %a1,%d2
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	or.l d5,d2					*	or.l %d5,%d2
	jbra _?L16					*	jra .L16
_?L51:							*.L51:
	move.l a1,d2					*	move.l %a1,%d2
	jbra _?L26					*	jra .L26
_?L38:							*.L38:
	move.l d1,a1					*	move.l %d1,%a1
	jbra _?L17					*	jra .L17
_?L49:							*.L49:
	move.l d3,d1					*	move.l %d3,%d1
	jbra _?L25					*	jra .L25
_?L14:							*.L14:
	moveq #24,d4					*	moveq #24,%d4
	lsr.l d4,d2					*	lsr.l %d4,%d2
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L12					*	jra .L12
							*	.size	__divdi3, .-__divdi3
							*	.ident	"GCC: (GNU) 13.4.0"
