* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___udiv_w_sdiv				*	.globl	__udiv_w_sdiv
							*	.hidden	__udiv_w_sdiv
							*	.type	__udiv_w_sdiv, @function
___udiv_w_sdiv:						*__udiv_w_sdiv:
	clr.l d0					*	clr.l %d0
	rts						*	rts
							*	.size	__udiv_w_sdiv, .-__udiv_w_sdiv
							*	.ident	"GCC: (GNU) 13.4.0"
