* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___fixxfsi				*	.globl	__fixxfsi
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	1075707904				*	.long	1075707904
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsxfsi				*	.globl	__fixunsxfsi
							*	.hidden	__fixunsxfsi
							*	.type	__fixunsxfsi, @function
___fixunsxfsi:						*__fixunsxfsi:
	fmove.x 4(sp),fp0				*	fmove.x 4(%sp),%fp0
	fmove.x _?LC0,fp1				*	fmove.x .LC0,%fp1
	fcmp.x fp1,fp0					*	fcmp.x %fp1,%fp0
	fbge _?L9					*	fjge .L9
	fmove.x fp0,-(sp)				*	fmove.x %fp0,-(%sp)
	jbsr ___fixxfsi					*	jsr __fixxfsi
	add.w #12,sp					*	add.w #12,%sp
	rts						*	rts
_?L9:							*.L9:
	fsub.x fp1,fp0					*	fsub.x %fp1,%fp0
	fmove.x fp0,-(sp)				*	fmove.x %fp0,-(%sp)
	jbsr ___fixxfsi					*	jsr __fixxfsi
	add.w #12,sp					*	add.w #12,%sp
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	rts						*	rts
							*	.size	__fixunsxfsi, .-__fixunsxfsi
							*	.ident	"GCC: (GNU) 13.4.0"
