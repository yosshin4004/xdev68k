* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___muldc3				*	.globl	__muldc3
							*	.hidden	__muldc3
							*	.type	__muldc3, @function
___muldc3:						*__muldc3:
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	fdmove.d 76(sp),fp2				*	fdmove.d 76(%sp),%fp2
	fdmul.d 92(sp),fp2				*	fdmul.d 92(%sp),%fp2
	fdmove.d 84(sp),fp5				*	fdmove.d 84(%sp),%fp5
	fdmul.d 100(sp),fp5				*	fdmul.d 100(%sp),%fp5
	fdmove.d 76(sp),fp4				*	fdmove.d 76(%sp),%fp4
	fdmul.d 100(sp),fp4				*	fdmul.d 100(%sp),%fp4
	fdmove.d 92(sp),fp3				*	fdmove.d 92(%sp),%fp3
	fdmul.d 84(sp),fp3				*	fdmul.d 84(%sp),%fp3
	fdmove.x fp2,fp0				*	fdmove.x %fp2,%fp0
	fdsub.x fp5,fp0					*	fdsub.x %fp5,%fp0
	fdmove.x fp4,fp1				*	fdmove.x %fp4,%fp1
	fdadd.x fp3,fp1					*	fdadd.x %fp3,%fp1
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L76					*	fjun .L76
_?L2:							*.L2:
	fmove.d fp0,(a0)				*	fmove.d %fp0,(%a0)
	fmove.d fp1,8(a0)				*	fmove.d %fp1,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	rts						*	rts
_?L76:							*.L76:
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L2					*	fjor .L2
	fdabs.d 76(sp),fp6				*	fdabs.d 76(%sp),%fp6
	fdabs.d 84(sp),fp7				*	fdabs.d 84(%sp),%fp7
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fbogt _?L3					*	fjogt .L3
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fbogt _?L3					*	fjogt .L3
	clr.b d0					*	clr.b %d0
_?L5:							*.L5:
	fdabs.d 92(sp),fp7				*	fdabs.d 92(%sp),%fp7
	fdabs.d 100(sp),fp6				*	fdabs.d 100(%sp),%fp6
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fbogt _?L11					*	fjogt .L11
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fbogt _?L11					*	fjogt .L11
	tst.b d0					*	tst.b %d0
	jbne _?L18					*	jne .L18
	fdabs.x fp2,fp2					*	fdabs.x %fp2,%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fdabs.x fp5,fp2					*	fdabs.x %fp5,%fp2
	fcmp.d #0x7fefffff,#0xffffffff,fp2		*	fcmp.d #0x7fefffffffffffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fdabs.x fp4,fp4					*	fdabs.x %fp4,%fp4
	fcmp.d #0x7fefffff,#0xffffffff,fp4		*	fcmp.d #0x7fefffffffffffff,%fp4
	fbogt _?L20					*	fjogt .L20
	fdabs.x fp3,fp3					*	fdabs.x %fp3,%fp3
	fcmp.d #0x7fefffff,#0xffffffff,fp3		*	fcmp.d #0x7fefffffffffffff,%fp3
	fbule _?L2					*	fjule .L2
_?L20:							*.L20:
	fdmove.d 76(sp),fp0				*	fdmove.d 76(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L77					*	fjun .L77
	fdmove.d 84(sp),fp6				*	fdmove.d 84(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbun _?L78					*	fjun .L78
_?L26:							*.L26:
	fdmove.d 92(sp),fp0				*	fdmove.d 92(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L79					*	fjun .L79
_?L28:							*.L28:
	fdmove.d 100(sp),fp6				*	fdmove.d 100(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbun _?L80					*	fjun .L80
_?L18:							*.L18:
	fdmove.d 76(sp),fp0				*	fdmove.d 76(%sp),%fp0
	fdmul.d 92(sp),fp0				*	fdmul.d 92(%sp),%fp0
	fdmove.d 84(sp),fp1				*	fdmove.d 84(%sp),%fp1
	fdmul.d 100(sp),fp1				*	fdmul.d 100(%sp),%fp1
	fdsub.x fp1,fp0					*	fdsub.x %fp1,%fp0
	fdmul.d #0x7ff00000,#0x00000000,fp0		*	fdmul.d #0x7ff0000000000000,%fp0
	fdmove.d 76(sp),fp2				*	fdmove.d 76(%sp),%fp2
	fdmul.d 100(sp),fp2				*	fdmul.d 100(%sp),%fp2
	fdmove.d 84(sp),fp1				*	fdmove.d 84(%sp),%fp1
	fdmul.d 92(sp),fp1				*	fdmul.d 92(%sp),%fp1
	fdadd.x fp1,fp2					*	fdadd.x %fp1,%fp2
	fdmove.x fp2,fp1				*	fdmove.x %fp2,%fp1
	fdmul.d #0x7ff00000,#0x00000000,fp1		*	fdmul.d #0x7ff0000000000000,%fp1
_?L81:							*.L81:
	fmove.d fp0,(a0)				*	fmove.d %fp0,(%a0)
	fmove.d fp1,8(a0)				*	fmove.d %fp1,8(%a0)
	move.l a0,d0					*	move.l %a0,%d0
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	rts						*	rts
_?L80:							*.L80:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L30					*	jge .L30
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L30:							*.L30:
	move.l d0,100(sp)				*	move.l %d0,100(%sp)
	move.l d1,104(sp)				*	move.l %d1,104(%sp)
	fdmove.d 76(sp),fp0				*	fdmove.d 76(%sp),%fp0
	fdmul.d 92(sp),fp0				*	fdmul.d 92(%sp),%fp0
	fdmove.d 84(sp),fp1				*	fdmove.d 84(%sp),%fp1
	fdmul.d 100(sp),fp1				*	fdmul.d 100(%sp),%fp1
	fdsub.x fp1,fp0					*	fdsub.x %fp1,%fp0
	fdmul.d #0x7ff00000,#0x00000000,fp0		*	fdmul.d #0x7ff0000000000000,%fp0
	fdmove.d 76(sp),fp2				*	fdmove.d 76(%sp),%fp2
	fdmul.d 100(sp),fp2				*	fdmul.d 100(%sp),%fp2
	fdmove.d 84(sp),fp1				*	fdmove.d 84(%sp),%fp1
	fdmul.d 92(sp),fp1				*	fdmul.d 92(%sp),%fp1
	fdadd.x fp1,fp2					*	fdadd.x %fp1,%fp2
	fdmove.x fp2,fp1				*	fdmove.x %fp2,%fp1
	fdmul.d #0x7ff00000,#0x00000000,fp1		*	fdmul.d #0x7ff0000000000000,%fp1
	jbra _?L81					*	jra .L81
_?L77:							*.L77:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L25					*	jge .L25
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L25:							*.L25:
	move.l d0,76(sp)				*	move.l %d0,76(%sp)
	move.l d1,80(sp)				*	move.l %d1,80(%sp)
	fdmove.d 84(sp),fp6				*	fdmove.d 84(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbor _?L26					*	fjor .L26
	jbra _?L78					*	jra .L78
_?L79:							*.L79:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 92(sp)					*	tst.l 92(%sp)
	jbge _?L29					*	jge .L29
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L29:							*.L29:
	move.l d0,92(sp)				*	move.l %d0,92(%sp)
	move.l d1,96(sp)				*	move.l %d1,96(%sp)
	fdmove.d 100(sp),fp6				*	fdmove.d 100(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbor _?L18					*	fjor .L18
	jbra _?L80					*	jra .L80
_?L78:							*.L78:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 84(sp)					*	tst.l 84(%sp)
	jbge _?L27					*	jge .L27
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L27:							*.L27:
	move.l d0,84(sp)				*	move.l %d0,84(%sp)
	move.l d1,88(sp)				*	move.l %d1,88(%sp)
	fdmove.d 92(sp),fp0				*	fdmove.d 92(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbor _?L28					*	fjor .L28
	jbra _?L79					*	jra .L79
_?L11:							*.L11:
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp0					*	fdmove.l %d0,%fp0
	fdabs.x fp0,fp0					*	fdabs.x %fp0,%fp0
	tst.l 92(sp)					*	tst.l 92(%sp)
	jbge _?L14					*	jge .L14
	fdneg.x fp0,fp0					*	fdneg.x %fp0,%fp0
_?L14:							*.L14:
	fmove.d fp0,92(sp)				*	fmove.d %fp0,92(%sp)
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp0					*	fdmove.l %d0,%fp0
	fdabs.x fp0,fp0					*	fdabs.x %fp0,%fp0
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L15					*	jge .L15
	fdneg.x fp0,fp0					*	fdneg.x %fp0,%fp0
_?L15:							*.L15:
	fmove.d fp0,100(sp)				*	fmove.d %fp0,100(%sp)
	fdmove.d 76(sp),fp0				*	fdmove.d 76(%sp),%fp0
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L82					*	fjun .L82
_?L16:							*.L16:
	fdmove.d 84(sp),fp6				*	fdmove.d 84(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbor _?L18					*	fjor .L18
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 84(sp)					*	tst.l 84(%sp)
	jbge _?L19					*	jge .L19
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L19:							*.L19:
	move.l d0,84(sp)				*	move.l %d0,84(%sp)
	move.l d1,88(sp)				*	move.l %d1,88(%sp)
	fdmove.d 76(sp),fp0				*	fdmove.d 76(%sp),%fp0
	fdmul.d 92(sp),fp0				*	fdmul.d 92(%sp),%fp0
	fdmove.d 84(sp),fp1				*	fdmove.d 84(%sp),%fp1
	fdmul.d 100(sp),fp1				*	fdmul.d 100(%sp),%fp1
	fdsub.x fp1,fp0					*	fdsub.x %fp1,%fp0
	fdmul.d #0x7ff00000,#0x00000000,fp0		*	fdmul.d #0x7ff0000000000000,%fp0
	fdmove.d 76(sp),fp2				*	fdmove.d 76(%sp),%fp2
	fdmul.d 100(sp),fp2				*	fdmul.d 100(%sp),%fp2
	fdmove.d 84(sp),fp1				*	fdmove.d 84(%sp),%fp1
	fdmul.d 92(sp),fp1				*	fdmul.d 92(%sp),%fp1
	fdadd.x fp1,fp2					*	fdadd.x %fp1,%fp2
	fdmove.x fp2,fp1				*	fdmove.x %fp2,%fp1
	fdmul.d #0x7ff00000,#0x00000000,fp1		*	fdmul.d #0x7ff0000000000000,%fp1
	jbra _?L81					*	jra .L81
_?L82:							*.L82:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L17					*	jge .L17
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L17:							*.L17:
	move.l d0,76(sp)				*	move.l %d0,76(%sp)
	move.l d1,80(sp)				*	move.l %d1,80(%sp)
	jbra _?L16					*	jra .L16
_?L3:							*.L3:
	fcmp.d #0x7fefffff,#0xffffffff,fp6		*	fcmp.d #0x7fefffffffffffff,%fp6
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp6					*	fdmove.l %d0,%fp6
	fdabs.x fp6,fp6					*	fdabs.x %fp6,%fp6
	tst.l 76(sp)					*	tst.l 76(%sp)
	jbge _?L6					*	jge .L6
	fdneg.x fp6,fp6					*	fdneg.x %fp6,%fp6
_?L6:							*.L6:
	fmove.d fp6,76(sp)				*	fmove.d %fp6,76(%sp)
	fcmp.d #0x7fefffff,#0xffffffff,fp7		*	fcmp.d #0x7fefffffffffffff,%fp7
	fsule d0					*	fsule %d0
	addq.b #1,d0					*	addq.b #1,%d0
	and.l #255,d0					*	and.l #255,%d0
	fdmove.l d0,fp6					*	fdmove.l %d0,%fp6
	fdabs.x fp6,fp6					*	fdabs.x %fp6,%fp6
	tst.l 84(sp)					*	tst.l 84(%sp)
	jbge _?L7					*	jge .L7
	fdneg.x fp6,fp6					*	fdneg.x %fp6,%fp6
_?L7:							*.L7:
	fmove.d fp6,84(sp)				*	fmove.d %fp6,84(%sp)
	fdmove.d 92(sp),fp6				*	fdmove.d 92(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbun _?L83					*	fjun .L83
_?L8:							*.L8:
	moveq #1,d0					*	moveq #1,%d0
	fdmove.d 100(sp),fp6				*	fdmove.d 100(%sp),%fp6
	fcmp.x fp6,fp6					*	fcmp.x %fp6,%fp6
	fbor _?L5					*	fjor .L5
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 100(sp)					*	tst.l 100(%sp)
	jbge _?L10					*	jge .L10
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L10:							*.L10:
	move.l d0,100(sp)				*	move.l %d0,100(%sp)
	move.l d1,104(sp)				*	move.l %d1,104(%sp)
	moveq #1,d0					*	moveq #1,%d0
	jbra _?L5					*	jra .L5
_?L83:							*.L83:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	tst.l 92(sp)					*	tst.l 92(%sp)
	jbge _?L9					*	jge .L9
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	clr.l d1					*	clr.l %d1
_?L9:							*.L9:
	move.l d0,92(sp)				*	move.l %d0,92(%sp)
	move.l d1,96(sp)				*	move.l %d1,96(%sp)
	jbra _?L8					*	jra .L8
							*	.size	__muldc3, .-__muldc3
							*	.ident	"GCC: (GNU) 13.4.0"
