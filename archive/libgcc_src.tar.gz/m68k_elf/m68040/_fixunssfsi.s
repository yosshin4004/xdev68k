* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunssfsi				*	.globl	__fixunssfsi
							*	.hidden	__fixunssfsi
							*	.type	__fixunssfsi, @function
___fixunssfsi:						*__fixunssfsi:
	fsmove.s 4(sp),fp0				*	fsmove.s 4(%sp),%fp0
	fcmp.s #0x4f000000,fp0				*	fcmp.s #0x4f000000,%fp0
	fbge _?L9					*	fjge .L9
	fmovem.l fpcr,d1				*	fmovem.l %fpcr,%d1
	moveq #16,d2					*	moveq #16,%d2
	or.l d1,d2					*	or.l %d1,%d2
	and.w #-33,d2					*	and.w #-33,%d2
	fmovem.l d2,fpcr				*	fmovem.l %d2,%fpcr
	fmove.l fp0,d0					*	fmove.l %fp0,%d0
	fmovem.l d1,fpcr				*	fmovem.l %d1,%fpcr
	rts						*	rts
_?L9:							*.L9:
	fssub.s #0x4f000000,fp0				*	fssub.s #0x4f000000,%fp0
	fmovem.l fpcr,d1				*	fmovem.l %fpcr,%d1
	moveq #16,d2					*	moveq #16,%d2
	or.l d1,d2					*	or.l %d1,%d2
	and.w #-33,d2					*	and.w #-33,%d2
	fmovem.l d2,fpcr				*	fmovem.l %d2,%fpcr
	fmove.l fp0,d0					*	fmove.l %fp0,%d0
	fmovem.l d1,fpcr				*	fmovem.l %d1,%fpcr
	add.l #-2147483648,d0				*	add.l #-2147483648,%d0
	rts						*	rts
							*	.size	__fixunssfsi, .-__fixunssfsi
							*	.ident	"GCC: (GNU) 13.4.0"
