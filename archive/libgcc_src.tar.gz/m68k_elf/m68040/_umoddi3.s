* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___umoddi3				*	.globl	__umoddi3
							*	.hidden	__umoddi3
							*	.type	__umoddi3, @function
___umoddi3:						*__umoddi3:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 36(sp),d0				*	move.l 36(%sp),%d0
	move.l 40(sp),d1				*	move.l 40(%sp),%d1
	move.l 44(sp),d3				*	move.l 44(%sp),%d3
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l d1,d5					*	move.l %d1,%d5
	move.l d0,a0					*	move.l %d0,%a0
	move.l d0,d4					*	move.l %d0,%d4
	tst.l d3					*	tst.l %d3
	jbne _?L2					*	jne .L2
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcc _?L3					*	jcc .L3
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbls _?L48					*	jls .L48
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L30					*	jhi .L30
	moveq #16,d3					*	moveq #16,%d3
_?L5:							*.L5:
	move.l d2,d6					*	move.l %d2,%d6
	lsr.l d3,d6					*	lsr.l %d3,%d6
	move.b ___clz_tab(d6.l),d6			*	move.b __clz_tab(%d6.l),%d6
	and.l #255,d6					*	and.l #255,%d6
	add.l d3,d6					*	add.l %d3,%d6
	moveq #32,d3					*	moveq #32,%d3
	sub.l d6,d3					*	sub.l %d6,%d3
	moveq #32,d7					*	moveq #32,%d7
	cmp.l d6,d7					*	cmp.l %d6,%d7
	jbeq _?L6					*	jeq .L6
	lsl.l d3,d2					*	lsl.l %d3,%d2
	lsl.l d3,d0					*	lsl.l %d3,%d0
	move.l d1,d4					*	move.l %d1,%d4
	lsr.l d6,d4					*	lsr.l %d6,%d4
	or.l d0,d4					*	or.l %d0,%d4
	move.l d1,d5					*	move.l %d1,%d5
	lsl.l d3,d5					*	lsl.l %d3,%d5
_?L6:							*.L6:
	move.l d2,d0					*	move.l %d2,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d2,d7					*	move.l %d2,%d7
	and.l #65535,d7					*	and.l #65535,%d7
	divul.l d0,d6:d4				*	divul.l %d0,%d6:%d4
	muls.l d7,d4					*	muls.l %d7,%d4
	swap d6						*	swap %d6
	clr.w d6					*	clr.w %d6
	move.l d5,d1					*	move.l %d5,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d6,d1					*	or.l %d6,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L7					*	jcc .L7
	add.l d2,d1					*	add.l %d2,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L7					*	jcs .L7
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L7					*	jcc .L7
	add.l d2,d1					*	add.l %d2,%d1
_?L7:							*.L7:
	sub.l d4,d1					*	sub.l %d4,%d1
	move.l d1,d4					*	move.l %d1,%d4
	divul.l d0,d1:d4				*	divul.l %d0,%d1:%d4
	muls.l d7,d4					*	muls.l %d7,%d4
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d5,d1					*	or.w %d5,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L18					*	jcc .L18
_?L44:							*.L44:
	add.l d2,d1					*	add.l %d2,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L18					*	jcs .L18
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L18					*	jcc .L18
	add.l d2,d1					*	add.l %d2,%d1
_?L18:							*.L18:
	sub.l d4,d1					*	sub.l %d4,%d1
	clr.l d0					*	clr.l %d0
	lsr.l d3,d1					*	lsr.l %d3,%d1
_?L19:							*.L19:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L2:							*.L2:
	move.l d1,a1					*	move.l %d1,%a1
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcs _?L19					*	jcs .L19
	cmp.l #65535,d3					*	cmp.l #65535,%d3
	jbls _?L49					*	jls .L49
	cmp.l #16777215,d3				*	cmp.l #16777215,%d3
	jbhi _?L32					*	jhi .L32
	moveq #16,d4					*	moveq #16,%d4
_?L22:							*.L22:
	move.l d3,d5					*	move.l %d3,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	clr.l d6					*	clr.l %d6
	move.b ___clz_tab(d5.l),d6			*	move.b __clz_tab(%d5.l),%d6
	add.l d4,d6					*	add.l %d4,%d6
	moveq #32,d5					*	moveq #32,%d5
	sub.l d6,d5					*	sub.l %d6,%d5
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d6,d4					*	cmp.l %d6,%d4
	jbne _?L23					*	jne .L23
_?L50:							*.L50:
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L24					*	jhi .L24
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L25					*	jcs .L25
_?L24:							*.L24:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d2,d1					*	sub.l %d2,%d1
	subx.l d3,d0					*	subx.l %d3,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d1,a1					*	move.l %d1,%a1
	move.l d0,a0					*	move.l %d0,%a0
_?L25:							*.L25:
	move.l a0,d0					*	move.l %a0,%d0
	move.l a1,d1					*	move.l %a1,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L3:							*.L3:
	tst.l d2					*	tst.l %d2
	jbeq _?L31					*	jeq .L31
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbhi _?L11					*	jhi .L11
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d3						*	shi %d3
	extb.l d3					*	extb.l %d3
	neg.l d3					*	neg.l %d3
	lsl.l #3,d3					*	lsl.l #3,%d3
	move.l d2,d4					*	move.l %d2,%d4
	lsr.l d3,d4					*	lsr.l %d3,%d4
_?L10:							*.L10:
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d3,d4					*	add.l %d3,%d4
	moveq #32,d3					*	moveq #32,%d3
	sub.l d4,d3					*	sub.l %d4,%d3
	moveq #32,d6					*	moveq #32,%d6
	cmp.l d4,d6					*	cmp.l %d4,%d6
	jbne _?L13					*	jne .L13
_?L52:							*.L52:
	sub.l d2,d0					*	sub.l %d2,%d0
	move.l d2,d1					*	move.l %d2,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	move.l d2,d6					*	move.l %d2,%d6
	and.l #65535,d6					*	and.l #65535,%d6
_?L14:							*.L14:
	divul.l d1,d7:d0				*	divul.l %d1,%d7:%d0
	muls.l d6,d0					*	muls.l %d6,%d0
	swap d7						*	swap %d7
	clr.w d7					*	clr.w %d7
	move.l d5,d4					*	move.l %d5,%d4
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	or.l d7,d4					*	or.l %d7,%d4
	cmp.l d0,d4					*	cmp.l %d0,%d4
	jbcc _?L17					*	jcc .L17
	add.l d2,d4					*	add.l %d2,%d4
	cmp.l d2,d4					*	cmp.l %d2,%d4
	jbcs _?L17					*	jcs .L17
	cmp.l d0,d4					*	cmp.l %d0,%d4
	jbcc _?L17					*	jcc .L17
	add.l d2,d4					*	add.l %d2,%d4
_?L17:							*.L17:
	sub.l d0,d4					*	sub.l %d0,%d4
	divul.l d1,d1:d4				*	divul.l %d1,%d1:%d4
	muls.l d6,d4					*	muls.l %d6,%d4
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d5,d1					*	or.w %d5,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcs _?L44					*	jcs .L44
	sub.l d4,d1					*	sub.l %d4,%d1
	clr.l d0					*	clr.l %d0
	lsr.l d3,d1					*	lsr.l %d3,%d1
	jbra _?L19					*	jra .L19
_?L48:							*.L48:
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d3						*	shi %d3
	extb.l d3					*	extb.l %d3
	neg.l d3					*	neg.l %d3
	lsl.l #3,d3					*	lsl.l #3,%d3
	jbra _?L5					*	jra .L5
_?L49:							*.L49:
	cmp.l #255,d3					*	cmp.l #255,%d3
	shi d4						*	shi %d4
	extb.l d4					*	extb.l %d4
	neg.l d4					*	neg.l %d4
	lsl.l #3,d4					*	lsl.l #3,%d4
	move.l d3,d5					*	move.l %d3,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	clr.l d6					*	clr.l %d6
	move.b ___clz_tab(d5.l),d6			*	move.b __clz_tab(%d5.l),%d6
	add.l d4,d6					*	add.l %d4,%d6
	moveq #32,d5					*	moveq #32,%d5
	sub.l d6,d5					*	sub.l %d6,%d5
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d6,d4					*	cmp.l %d6,%d4
	jbeq _?L50					*	jeq .L50
_?L23:							*.L23:
	lsl.l d5,d3					*	lsl.l %d5,%d3
	move.l d2,d4					*	move.l %d2,%d4
	lsr.l d6,d4					*	lsr.l %d6,%d4
	or.l d3,d4					*	or.l %d3,%d4
	move.l d4,a1					*	move.l %d4,%a1
	lsl.l d5,d2					*	lsl.l %d5,%d2
	move.l d2,a2					*	move.l %d2,%a2
	move.l d0,d2					*	move.l %d0,%d2
	lsl.l d5,d2					*	lsl.l %d5,%d2
	move.l d1,d3					*	move.l %d1,%d3
	lsr.l d6,d3					*	lsr.l %d6,%d3
	or.l d2,d3					*	or.l %d2,%d3
	lsl.l d5,d1					*	lsl.l %d5,%d1
	move.l d1,a5					*	move.l %d1,%a5
	move.l d4,d1					*	move.l %d4,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	and.l #65535,d4					*	and.l #65535,%d4
	lsr.l d6,d0					*	lsr.l %d6,%d0
	divul.l d1,d2:d0				*	divul.l %d1,%d2:%d0
	move.l d4,d7					*	move.l %d4,%d7
	muls.l d0,d7					*	muls.l %d0,%d7
	move.l d7,a3					*	move.l %d7,%a3
	swap d2						*	swap %d2
	clr.w d2					*	clr.w %d2
	move.l d2,a0					*	move.l %d2,%a0
	move.l d3,d2					*	move.l %d3,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	move.l a0,d7					*	move.l %a0,%d7
	or.l d7,d2					*	or.l %d7,%d2
	cmp.l a3,d2					*	cmp.l %a3,%d2
	jbcc _?L26					*	jcc .L26
	move.l d0,a0					*	move.l %d0,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l a1,d2					*	add.l %a1,%d2
	cmp.l a1,d2					*	cmp.l %a1,%d2
	jbcs _?L34					*	jcs .L34
	cmp.l a3,d2					*	cmp.l %a3,%d2
	jbcc _?L34					*	jcc .L34
	subq.l #2,d0					*	subq.l #2,%d0
	add.l a1,d2					*	add.l %a1,%d2
_?L26:							*.L26:
	sub.l a3,d2					*	sub.l %a3,%d2
	divul.l d1,d1:d2				*	divul.l %d1,%d1:%d2
	muls.l d2,d4					*	muls.l %d2,%d4
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d3,d1					*	or.w %d3,%d1
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L27					*	jcc .L27
	move.l d2,a0					*	move.l %d2,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l a1,d1					*	add.l %a1,%d1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbcs _?L36					*	jcs .L36
	cmp.l d4,d1					*	cmp.l %d4,%d1
	jbcc _?L36					*	jcc .L36
	subq.l #2,d2					*	subq.l #2,%d2
	add.l a1,d1					*	add.l %a1,%d1
_?L27:							*.L27:
	move.l d1,a0					*	move.l %d1,%a0
	sub.l d4,a0					*	sub.l %d4,%a0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d2,d0					*	or.l %d2,%d0
	move.l d0,a3					*	move.l %d0,%a3
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	a3,d0					*	move.l	%a3,%d0
	move.l	a2,d1					*	move.l	%a2,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a4					*	move.l	%d2,%a4
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a3					*	move.l	%d0,%a3
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a3,d2					*	move.l %a3,%d2
	move.l a4,d1					*	move.l %a4,%d1
	cmp.l a0,a3					*	cmp.l %a0,%a3
	jbhi _?L28					*	jhi .L28
	jbeq _?L51					*	jeq .L51
_?L29:							*.L29:
	move.l a0,d0					*	move.l %a0,%d0
	move.l a5,d7					*	move.l %a5,%d7
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d1,d7					*	sub.l %d1,%d7
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	lsl.l d6,d1					*	lsl.l %d6,%d1
	lsr.l d5,d7					*	lsr.l %d5,%d7
	lsr.l d5,d0					*	lsr.l %d5,%d0
	or.l d7,d1					*	or.l %d7,%d1
_?L53:							*.L53:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14584
	rts						*	rts
_?L31:							*.L31:
	clr.l d4					*	clr.l %d4
	clr.l d3					*	clr.l %d3
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d3,d4					*	add.l %d3,%d4
	moveq #32,d3					*	moveq #32,%d3
	sub.l d4,d3					*	sub.l %d4,%d3
	moveq #32,d6					*	moveq #32,%d6
	cmp.l d4,d6					*	cmp.l %d4,%d6
	jbeq _?L52					*	jeq .L52
_?L13:							*.L13:
	lsl.l d3,d2					*	lsl.l %d3,%d2
	move.l d0,d5					*	move.l %d0,%d5
	lsl.l d3,d5					*	lsl.l %d3,%d5
	move.l d1,d7					*	move.l %d1,%d7
	lsr.l d4,d7					*	lsr.l %d4,%d7
	or.l d5,d7					*	or.l %d5,%d7
	move.l d1,d5					*	move.l %d1,%d5
	lsl.l d3,d5					*	lsl.l %d3,%d5
	move.l d2,d1					*	move.l %d2,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	move.l d2,d6					*	move.l %d2,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	lsr.l d4,d0					*	lsr.l %d4,%d0
	divul.l d1,d4:d0				*	divul.l %d1,%d4:%d0
	muls.l d6,d0					*	muls.l %d6,%d0
	move.l d0,a2					*	move.l %d0,%a2
	swap d4						*	swap %d4
	clr.w d4					*	clr.w %d4
	move.l d7,d0					*	move.l %d7,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	or.l d4,d0					*	or.l %d4,%d0
	move.l d0,a0					*	move.l %d0,%a0
	cmp.l a2,d0					*	cmp.l %a2,%d0
	jbcc _?L15					*	jcc .L15
	add.l d2,a0					*	add.l %d2,%a0
	cmp.l d2,a0					*	cmp.l %d2,%a0
	jbcs _?L15					*	jcs .L15
	cmp.l a2,a0					*	cmp.l %a2,%a0
	jbcc _?L15					*	jcc .L15
	add.l d2,a0					*	add.l %d2,%a0
_?L15:							*.L15:
	move.l a0,d4					*	move.l %a0,%d4
	sub.l a2,d4					*	sub.l %a2,%d4
	divul.l d1,d0:d4				*	divul.l %d1,%d0:%d4
	muls.l d6,d4					*	muls.l %d6,%d4
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d7,d0					*	or.w %d7,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcc _?L16					*	jcc .L16
	add.l d2,d0					*	add.l %d2,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L16					*	jcs .L16
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcc _?L16					*	jcc .L16
	add.l d2,d0					*	add.l %d2,%d0
_?L16:							*.L16:
	sub.l d4,d0					*	sub.l %d4,%d0
	jbra _?L14					*	jra .L14
_?L51:							*.L51:
	cmp.l a5,a4					*	cmp.l %a5,%a4
	jbls _?L29					*	jls .L29
_?L28:							*.L28:
	move.l a3,d2					*	move.l %a3,%d2
	move.l a4,d1					*	move.l %a4,%d1
	move.l a1,d0					*	move.l %a1,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a2,d1					*	sub.l %a2,%d1
	subx.l d0,d2					*	subx.l %d0,%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a0,d0					*	move.l %a0,%d0
	move.l a5,d7					*	move.l %a5,%d7
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d1,d7					*	sub.l %d1,%d7
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d1					*	move.l %d0,%d1
	lsl.l d6,d1					*	lsl.l %d6,%d1
	lsr.l d5,d7					*	lsr.l %d5,%d7
	lsr.l d5,d0					*	lsr.l %d5,%d0
	or.l d7,d1					*	or.l %d7,%d1
	jbra _?L53					*	jra .L53
_?L11:							*.L11:
	move.l d2,d4					*	move.l %d2,%d4
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L12					*	jhi .L12
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	moveq #16,d3					*	moveq #16,%d3
	jbra _?L10					*	jra .L10
_?L30:							*.L30:
	moveq #24,d3					*	moveq #24,%d3
	jbra _?L5					*	jra .L5
_?L32:							*.L32:
	moveq #24,d4					*	moveq #24,%d4
	jbra _?L22					*	jra .L22
_?L36:							*.L36:
	move.l a0,d2					*	move.l %a0,%d2
	jbra _?L27					*	jra .L27
_?L34:							*.L34:
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L26					*	jra .L26
_?L12:							*.L12:
	moveq #24,d3					*	moveq #24,%d3
	lsr.l d3,d4					*	lsr.l %d3,%d4
	jbra _?L10					*	jra .L10
							*	.size	__umoddi3, .-__umoddi3
							*	.ident	"GCC: (GNU) 13.4.0"
