* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___mulsc3				*	.globl	__mulsc3
							*	.hidden	__mulsc3
							*	.type	__mulsc3, @function
___mulsc3:						*__mulsc3:
	fmovem fp2/fp3/fp4/fp5/fp6/fp7,-(sp)		*	fmovem #252,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 84(sp),d0				*	move.l 84(%sp),%d0
	move.l 88(sp),d1				*	move.l 88(%sp),%d1
	move.l 92(sp),d2				*	move.l 92(%sp),%d2
	move.l 96(sp),d3				*	move.l 96(%sp),%d3
	fsmove.s d0,fp2					*	fsmove.s %d0,%fp2
	fsmul.s d2,fp2					*	fsmul.s %d2,%fp2
	fsmove.s d1,fp3					*	fsmove.s %d1,%fp3
	fsmul.s d3,fp3					*	fsmul.s %d3,%fp3
	fsmove.s d0,fp5					*	fsmove.s %d0,%fp5
	fsmul.s d3,fp5					*	fsmul.s %d3,%fp5
	fsmove.s d2,fp4					*	fsmove.s %d2,%fp4
	fsmul.s d1,fp4					*	fsmul.s %d1,%fp4
	fsmove.x fp2,fp0				*	fsmove.x %fp2,%fp0
	fssub.x fp3,fp0					*	fssub.x %fp3,%fp0
	fsmove.x fp5,fp1				*	fsmove.x %fp5,%fp1
	fsadd.x fp4,fp1					*	fsadd.x %fp4,%fp1
	fcmp.x fp0,fp0					*	fcmp.x %fp0,%fp0
	fbun _?L76					*	fjun .L76
_?L2:							*.L2:
	fmove.s fp0,d0					*	fmove.s %fp0,%d0
	fmove.s fp1,d1					*	fmove.s %fp1,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	rts						*	rts
_?L76:							*.L76:
	fcmp.x fp1,fp1					*	fcmp.x %fp1,%fp1
	fbor _?L2					*	fjor .L2
	fsabs.s d0,fp6					*	fsabs.s %d0,%fp6
	fsabs.s d1,fp7					*	fsabs.s %d1,%fp7
	fcmp.s #0x7f7fffff,fp6				*	fcmp.s #0x7f7fffff,%fp6
	fbogt _?L3					*	fjogt .L3
	fcmp.s #0x7f7fffff,fp7				*	fcmp.s #0x7f7fffff,%fp7
	fbogt _?L3					*	fjogt .L3
	clr.b d4					*	clr.b %d4
_?L5:							*.L5:
	fsabs.s d2,fp6					*	fsabs.s %d2,%fp6
	fsabs.s d3,fp7					*	fsabs.s %d3,%fp7
	fcmp.s #0x7f7fffff,fp6				*	fcmp.s #0x7f7fffff,%fp6
	fbogt _?L11					*	fjogt .L11
	fcmp.s #0x7f7fffff,fp7				*	fcmp.s #0x7f7fffff,%fp7
	fbogt _?L11					*	fjogt .L11
	tst.b d4					*	tst.b %d4
	jbne _?L18					*	jne .L18
	fsabs.x fp2,fp2					*	fsabs.x %fp2,%fp2
	fcmp.s #0x7f7fffff,fp2				*	fcmp.s #0x7f7fffff,%fp2
	fbogt _?L20					*	fjogt .L20
	fsabs.x fp3,fp3					*	fsabs.x %fp3,%fp3
	fcmp.s #0x7f7fffff,fp3				*	fcmp.s #0x7f7fffff,%fp3
	fbogt _?L20					*	fjogt .L20
	fsabs.x fp5,fp5					*	fsabs.x %fp5,%fp5
	fcmp.s #0x7f7fffff,fp5				*	fcmp.s #0x7f7fffff,%fp5
	fbogt _?L20					*	fjogt .L20
	fsabs.x fp4,fp4					*	fsabs.x %fp4,%fp4
	fcmp.s #0x7f7fffff,fp4				*	fcmp.s #0x7f7fffff,%fp4
	fbule _?L2					*	fjule .L2
_?L20:							*.L20:
	fsmove.s d0,fp0					*	fsmove.s %d0,%fp0
	fcmp.s d0,fp0					*	fcmp.s %d0,%fp0
	fbun _?L77					*	fjun .L77
	fsmove.s d1,fp6					*	fsmove.s %d1,%fp6
	fcmp.s d1,fp6					*	fcmp.s %d1,%fp6
	fbun _?L78					*	fjun .L78
_?L26:							*.L26:
	fsmove.s d2,fp0					*	fsmove.s %d2,%fp0
	fcmp.s d2,fp0					*	fcmp.s %d2,%fp0
	fbun _?L79					*	fjun .L79
_?L28:							*.L28:
	fsmove.s d3,fp6					*	fsmove.s %d3,%fp6
	fcmp.s d3,fp6					*	fcmp.s %d3,%fp6
	fbun _?L80					*	fjun .L80
_?L18:							*.L18:
	fsmove.s d0,fp0					*	fsmove.s %d0,%fp0
	fsmul.s d2,fp0					*	fsmul.s %d2,%fp0
	fsmove.s d1,fp1					*	fsmove.s %d1,%fp1
	fsmul.s d3,fp1					*	fsmul.s %d3,%fp1
	fssub.x fp1,fp0					*	fssub.x %fp1,%fp0
	fsmul.s #0x7f800000,fp0				*	fsmul.s #0x7f800000,%fp0
	fsmove.s d0,fp1					*	fsmove.s %d0,%fp1
	fsmul.s d3,fp1					*	fsmul.s %d3,%fp1
	fsmove.s d1,fp2					*	fsmove.s %d1,%fp2
	fsmul.s d2,fp2					*	fsmul.s %d2,%fp2
	fsadd.x fp2,fp1					*	fsadd.x %fp2,%fp1
	fsmul.s #0x7f800000,fp1				*	fsmul.s #0x7f800000,%fp1
_?L81:							*.L81:
	fmove.s fp0,d0					*	fmove.s %fp0,%d0
	fmove.s fp1,d1					*	fmove.s %fp1,%d1
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	fmovem (sp)+,fp2/fp3/fp4/fp5/fp6/fp7		*	fmovem (%sp)+,#63
	rts						*	rts
_?L80:							*.L80:
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d3					*	tst.l %d3
	jbge _?L30					*	jge .L30
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L30:							*.L30:
	move.l a0,d3					*	move.l %a0,%d3
	fsmove.s d0,fp0					*	fsmove.s %d0,%fp0
	fsmul.s d2,fp0					*	fsmul.s %d2,%fp0
	fsmove.s d1,fp1					*	fsmove.s %d1,%fp1
	fsmul.s d3,fp1					*	fsmul.s %d3,%fp1
	fssub.x fp1,fp0					*	fssub.x %fp1,%fp0
	fsmul.s #0x7f800000,fp0				*	fsmul.s #0x7f800000,%fp0
	fsmove.s d0,fp1					*	fsmove.s %d0,%fp1
	fsmul.s d3,fp1					*	fsmul.s %d3,%fp1
	fsmove.s d1,fp2					*	fsmove.s %d1,%fp2
	fsmul.s d2,fp2					*	fsmul.s %d2,%fp2
	fsadd.x fp2,fp1					*	fsadd.x %fp2,%fp1
	fsmul.s #0x7f800000,fp1				*	fsmul.s #0x7f800000,%fp1
	jbra _?L81					*	jra .L81
_?L77:							*.L77:
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d0					*	tst.l %d0
	jbge _?L25					*	jge .L25
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L25:							*.L25:
	move.l a0,d0					*	move.l %a0,%d0
	fsmove.s d1,fp6					*	fsmove.s %d1,%fp6
	fcmp.s d1,fp6					*	fcmp.s %d1,%fp6
	fbor _?L26					*	fjor .L26
	jbra _?L78					*	jra .L78
_?L79:							*.L79:
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d2					*	tst.l %d2
	jbge _?L29					*	jge .L29
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L29:							*.L29:
	move.l a0,d2					*	move.l %a0,%d2
	fsmove.s d3,fp6					*	fsmove.s %d3,%fp6
	fcmp.s d3,fp6					*	fcmp.s %d3,%fp6
	fbor _?L18					*	fjor .L18
	jbra _?L80					*	jra .L80
_?L78:							*.L78:
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d1					*	tst.l %d1
	jbge _?L27					*	jge .L27
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L27:							*.L27:
	move.l a0,d1					*	move.l %a0,%d1
	fsmove.s d2,fp0					*	fsmove.s %d2,%fp0
	fcmp.s d2,fp0					*	fcmp.s %d2,%fp0
	fbor _?L28					*	fjor .L28
	jbra _?L79					*	jra .L79
_?L11:							*.L11:
	fcmp.s #0x7f7fffff,fp6				*	fcmp.s #0x7f7fffff,%fp6
	fsule d4					*	fsule %d4
	addq.b #1,d4					*	addq.b #1,%d4
	and.l #255,d4					*	and.l #255,%d4
	fsmove.l d4,fp0					*	fsmove.l %d4,%fp0
	fsabs.x fp0,fp0					*	fsabs.x %fp0,%fp0
	tst.l d2					*	tst.l %d2
	jbge _?L14					*	jge .L14
	fsneg.x fp0,fp0					*	fsneg.x %fp0,%fp0
_?L14:							*.L14:
	fmove.s fp0,d2					*	fmove.s %fp0,%d2
	fcmp.s #0x7f7fffff,fp7				*	fcmp.s #0x7f7fffff,%fp7
	fsule d4					*	fsule %d4
	addq.b #1,d4					*	addq.b #1,%d4
	and.l #255,d4					*	and.l #255,%d4
	fsmove.l d4,fp0					*	fsmove.l %d4,%fp0
	fsabs.x fp0,fp0					*	fsabs.x %fp0,%fp0
	tst.l d3					*	tst.l %d3
	jbge _?L15					*	jge .L15
	fsneg.x fp0,fp0					*	fsneg.x %fp0,%fp0
_?L15:							*.L15:
	fmove.s fp0,d3					*	fmove.s %fp0,%d3
	fsmove.s d0,fp0					*	fsmove.s %d0,%fp0
	fcmp.s d0,fp0					*	fcmp.s %d0,%fp0
	fbun _?L82					*	fjun .L82
_?L16:							*.L16:
	fsmove.s d1,fp6					*	fsmove.s %d1,%fp6
	fcmp.s d1,fp6					*	fcmp.s %d1,%fp6
	fbor _?L18					*	fjor .L18
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d1					*	tst.l %d1
	jbge _?L19					*	jge .L19
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L19:							*.L19:
	move.l a0,d1					*	move.l %a0,%d1
	fsmove.s d0,fp0					*	fsmove.s %d0,%fp0
	fsmul.s d2,fp0					*	fsmul.s %d2,%fp0
	fsmove.s d1,fp1					*	fsmove.s %d1,%fp1
	fsmul.s d3,fp1					*	fsmul.s %d3,%fp1
	fssub.x fp1,fp0					*	fssub.x %fp1,%fp0
	fsmul.s #0x7f800000,fp0				*	fsmul.s #0x7f800000,%fp0
	fsmove.s d0,fp1					*	fsmove.s %d0,%fp1
	fsmul.s d3,fp1					*	fsmul.s %d3,%fp1
	fsmove.s d1,fp2					*	fsmove.s %d1,%fp2
	fsmul.s d2,fp2					*	fsmul.s %d2,%fp2
	fsadd.x fp2,fp1					*	fsadd.x %fp2,%fp1
	fsmul.s #0x7f800000,fp1				*	fsmul.s #0x7f800000,%fp1
	jbra _?L81					*	jra .L81
_?L82:							*.L82:
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d0					*	tst.l %d0
	jbge _?L17					*	jge .L17
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L17:							*.L17:
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L16					*	jra .L16
_?L3:							*.L3:
	fcmp.s #0x7f7fffff,fp6				*	fcmp.s #0x7f7fffff,%fp6
	fsule d4					*	fsule %d4
	addq.b #1,d4					*	addq.b #1,%d4
	and.l #255,d4					*	and.l #255,%d4
	fsmove.l d4,fp6					*	fsmove.l %d4,%fp6
	fsabs.x fp6,fp6					*	fsabs.x %fp6,%fp6
	tst.l d0					*	tst.l %d0
	jbge _?L6					*	jge .L6
	fsneg.x fp6,fp6					*	fsneg.x %fp6,%fp6
_?L6:							*.L6:
	fmove.s fp6,d0					*	fmove.s %fp6,%d0
	fcmp.s #0x7f7fffff,fp7				*	fcmp.s #0x7f7fffff,%fp7
	fsule d4					*	fsule %d4
	addq.b #1,d4					*	addq.b #1,%d4
	and.l #255,d4					*	and.l #255,%d4
	fsmove.l d4,fp6					*	fsmove.l %d4,%fp6
	fsabs.x fp6,fp6					*	fsabs.x %fp6,%fp6
	tst.l d1					*	tst.l %d1
	jbge _?L7					*	jge .L7
	fsneg.x fp6,fp6					*	fsneg.x %fp6,%fp6
_?L7:							*.L7:
	fmove.s fp6,d1					*	fmove.s %fp6,%d1
	fsmove.s d2,fp6					*	fsmove.s %d2,%fp6
	fcmp.s d2,fp6					*	fcmp.s %d2,%fp6
	fbun _?L83					*	fjun .L83
_?L8:							*.L8:
	moveq #1,d4					*	moveq #1,%d4
	fsmove.s d3,fp6					*	fsmove.s %d3,%fp6
	fcmp.s d3,fp6					*	fcmp.s %d3,%fp6
	fbor _?L5					*	fjor .L5
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d3					*	tst.l %d3
	jbge _?L10					*	jge .L10
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L10:							*.L10:
	move.l a0,d3					*	move.l %a0,%d3
	moveq #1,d4					*	moveq #1,%d4
	jbra _?L5					*	jra .L5
_?L83:							*.L83:
	lea 0.w,a0					*	lea 0.w,%a0
	tst.l d2					*	tst.l %d2
	jbge _?L9					*	jge .L9
	move.l #0x80000000,a0				*	move.l #0x80000000,%a0
_?L9:							*.L9:
	move.l a0,d2					*	move.l %a0,%d2
	jbra _?L8					*	jra .L8
							*	.size	__mulsc3, .-__mulsc3
							*	.ident	"GCC: (GNU) 13.4.0"
