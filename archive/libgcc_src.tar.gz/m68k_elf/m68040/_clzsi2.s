* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clzsi2				*	.globl	__clzsi2
							*	.hidden	__clzsi2
							*	.type	__clzsi2, @function
___clzsi2:						*__clzsi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbhi _?L2					*	jhi .L2
	cmp.l #255,d1					*	cmp.l #255,%d1
	shi d2						*	shi %d2
	extb.l d2					*	extb.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	moveq #32,d0					*	moveq #32,%d0
	sub.l d2,d0					*	sub.l %d2,%d0
	lsr.l d2,d1					*	lsr.l %d2,%d1
	move.b ___clz_tab(d1.l),d1			*	move.b __clz_tab(%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
_?L2:							*.L2:
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbhi _?L4					*	jhi .L4
	moveq #16,d0					*	moveq #16,%d0
	moveq #16,d2					*	moveq #16,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	move.b ___clz_tab(d1.l),d1			*	move.b __clz_tab(%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
_?L4:							*.L4:
	moveq #8,d0					*	moveq #8,%d0
	moveq #24,d2					*	moveq #24,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	move.b ___clz_tab(d1.l),d1			*	move.b __clz_tab(%d1.l),%d1
	and.l #255,d1					*	and.l #255,%d1
	sub.l d1,d0					*	sub.l %d1,%d0
	rts						*	rts
							*	.size	__clzsi2, .-__clzsi2
							*	.ident	"GCC: (GNU) 13.4.0"
