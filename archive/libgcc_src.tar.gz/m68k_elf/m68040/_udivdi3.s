* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___udivdi3				*	.globl	__udivdi3
							*	.hidden	__udivdi3
							*	.type	__udivdi3, @function
___udivdi3:						*__udivdi3:
	movem.l d3/d4/d5/d6/d7,-(sp)			*	movem.l #7936,-(%sp)
	move.l 24(sp),d3				*	move.l 24(%sp),%d3
	move.l 28(sp),d6				*	move.l 28(%sp),%d6
	move.l 32(sp),d0				*	move.l 32(%sp),%d0
	move.l 36(sp),d2				*	move.l 36(%sp),%d2
	move.l d6,d4					*	move.l %d6,%d4
	move.l d3,d1					*	move.l %d3,%d1
	tst.l d0					*	tst.l %d0
	jbne _?L2					*	jne .L2
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbcc _?L3					*	jcc .L3
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbls _?L54					*	jls .L54
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L27					*	jhi .L27
	moveq #16,d0					*	moveq #16,%d0
_?L5:							*.L5:
	move.l d2,d5					*	move.l %d2,%d5
	lsr.l d0,d5					*	lsr.l %d0,%d5
	move.b ___clz_tab(d5.l),d5			*	move.b __clz_tab(%d5.l),%d5
	and.l #255,d5					*	and.l #255,%d5
	add.l d0,d5					*	add.l %d0,%d5
	moveq #32,d7					*	moveq #32,%d7
	sub.l d5,d7					*	sub.l %d5,%d7
	moveq #32,d0					*	moveq #32,%d0
	cmp.l d5,d0					*	cmp.l %d5,%d0
	jbeq _?L6					*	jeq .L6
	lsl.l d7,d2					*	lsl.l %d7,%d2
	lsl.l d7,d3					*	lsl.l %d7,%d3
	move.l d6,d1					*	move.l %d6,%d1
	lsr.l d5,d1					*	lsr.l %d5,%d1
	or.l d3,d1					*	or.l %d3,%d1
	move.l d6,d4					*	move.l %d6,%d4
	lsl.l d7,d4					*	lsl.l %d7,%d4
_?L6:							*.L6:
	move.l d2,d3					*	move.l %d2,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	move.l d2,d5					*	move.l %d2,%d5
	and.l #65535,d5					*	and.l #65535,%d5
	divul.l d3,d6:d1				*	divul.l %d3,%d6:%d1
	move.l d5,d7					*	move.l %d5,%d7
	muls.l d1,d7					*	muls.l %d1,%d7
	swap d6						*	swap %d6
	clr.w d6					*	clr.w %d6
	move.l d4,d0					*	move.l %d4,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	or.l d6,d0					*	or.l %d6,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcc _?L7					*	jcc .L7
	move.l d1,a0					*	move.l %d1,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d2,d0					*	add.l %d2,%d0
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbcs _?L29					*	jcs .L29
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbcc _?L29					*	jcc .L29
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d2,d0					*	add.l %d2,%d0
_?L7:							*.L7:
	sub.l d7,d0					*	sub.l %d7,%d0
	divul.l d3,d3:d0				*	divul.l %d3,%d3:%d0
	muls.l d0,d5					*	muls.l %d0,%d5
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	or.w d4,d3					*	or.w %d4,%d3
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbcc _?L8					*	jcc .L8
	move.l d0,a0					*	move.l %d0,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d2,d3					*	add.l %d2,%d3
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbcs _?L31					*	jcs .L31
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbcc _?L31					*	jcc .L31
	subq.l #2,d0					*	subq.l #2,%d0
_?L8:							*.L8:
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
_?L9:							*.L9:
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L2:							*.L2:
	cmp.l d0,d3					*	cmp.l %d0,%d3
	jbcc _?L55					*	jcc .L55
_?L43:							*.L43:
	clr.l d1					*	clr.l %d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L3:							*.L3:
	tst.l d2					*	tst.l %d2
	jbeq _?L32					*	jeq .L32
	cmp.l #65535,d2					*	cmp.l #65535,%d2
	jbhi _?L11					*	jhi .L11
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	lsl.l #3,d0					*	lsl.l #3,%d0
	move.l d2,d1					*	move.l %d2,%d1
	lsr.l d0,d1					*	lsr.l %d0,%d1
_?L10:							*.L10:
	clr.l d7					*	clr.l %d7
	move.b ___clz_tab(d1.l),d7			*	move.b __clz_tab(%d1.l),%d7
	add.l d0,d7					*	add.l %d0,%d7
	moveq #32,d1					*	moveq #32,%d1
	sub.l d7,d1					*	sub.l %d7,%d1
	moveq #32,d0					*	moveq #32,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbne _?L13					*	jne .L13
_?L58:							*.L58:
	move.l d3,d1					*	move.l %d3,%d1
	sub.l d2,d1					*	sub.l %d2,%d1
	move.l d2,d5					*	move.l %d2,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	move.l d2,d6					*	move.l %d2,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	moveq #1,d0					*	moveq #1,%d0
_?L14:							*.L14:
	divul.l d5,d7:d1				*	divul.l %d5,%d7:%d1
	move.l d1,d3					*	move.l %d1,%d3
	muls.l d6,d3					*	muls.l %d6,%d3
	move.l d3,a0					*	move.l %d3,%a0
	swap d7						*	swap %d7
	clr.w d7					*	clr.w %d7
	move.l d4,d3					*	move.l %d4,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	or.l d7,d3					*	or.l %d7,%d3
	cmp.l a0,d3					*	cmp.l %a0,%d3
	jbcc _?L17					*	jcc .L17
	move.l d1,a1					*	move.l %d1,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d2,d3					*	add.l %d2,%d3
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbcs _?L38					*	jcs .L38
	cmp.l a0,d3					*	cmp.l %a0,%d3
	jbcc _?L38					*	jcc .L38
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d2,d3					*	add.l %d2,%d3
_?L17:							*.L17:
	sub.l a0,d3					*	sub.l %a0,%d3
	divul.l d5,d5:d3				*	divul.l %d5,%d5:%d3
	muls.l d3,d6					*	muls.l %d3,%d6
	swap d5						*	swap %d5
	clr.w d5					*	clr.w %d5
	or.w d4,d5					*	or.w %d4,%d5
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbcc _?L18					*	jcc .L18
	move.l d3,a0					*	move.l %d3,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d2,d5					*	add.l %d2,%d5
	cmp.l d2,d5					*	cmp.l %d2,%d5
	jbcs _?L40					*	jcs .L40
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbcc _?L40					*	jcc .L40
	subq.l #2,d3					*	subq.l #2,%d3
_?L18:							*.L18:
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d3,d1					*	or.l %d3,%d1
_?L59:							*.L59:
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L55:							*.L55:
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbls _?L56					*	jls .L56
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbhi _?L42					*	jhi .L42
	moveq #16,d1					*	moveq #16,%d1
_?L20:							*.L20:
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d4,d1					*	add.l %d4,%d1
	moveq #32,d7					*	moveq #32,%d7
	sub.l d1,d7					*	sub.l %d1,%d7
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d1,d4					*	cmp.l %d1,%d4
	jbne _?L21					*	jne .L21
_?L57:							*.L57:
	cmp.l d0,d3					*	cmp.l %d0,%d3
	jbhi _?L22					*	jhi .L22
	cmp.l d2,d6					*	cmp.l %d2,%d6
	jbcs _?L43					*	jcs .L43
_?L22:							*.L22:
	moveq #1,d1					*	moveq #1,%d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L56:							*.L56:
	cmp.l #255,d0					*	cmp.l #255,%d0
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d0,d4					*	move.l %d0,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d4,d1					*	add.l %d4,%d1
	moveq #32,d7					*	moveq #32,%d7
	sub.l d1,d7					*	sub.l %d1,%d7
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d1,d4					*	cmp.l %d1,%d4
	jbeq _?L57					*	jeq .L57
_?L21:							*.L21:
	lsl.l d7,d0					*	lsl.l %d7,%d0
	move.l d2,d4					*	move.l %d2,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
	or.l d0,d4					*	or.l %d0,%d4
	lsl.l d7,d2					*	lsl.l %d7,%d2
	move.l d2,a1					*	move.l %d2,%a1
	move.l d3,d0					*	move.l %d3,%d0
	lsl.l d7,d0					*	lsl.l %d7,%d0
	move.l d6,d5					*	move.l %d6,%d5
	lsr.l d1,d5					*	lsr.l %d1,%d5
	or.l d0,d5					*	or.l %d0,%d5
	move.l d4,d0					*	move.l %d4,%d0
	clr.w d0					*	clr.w %d0
	swap d0						*	swap %d0
	move.l d4,d2					*	move.l %d4,%d2
	and.l #65535,d2					*	and.l #65535,%d2
	move.l d2,a0					*	move.l %d2,%a0
	move.l d3,d2					*	move.l %d3,%d2
	lsr.l d1,d2					*	lsr.l %d1,%d2
	move.l d2,d1					*	move.l %d2,%d1
	divul.l d0,d3:d1				*	divul.l %d0,%d3:%d1
	move.l a0,d2					*	move.l %a0,%d2
	muls.l d1,d2					*	muls.l %d1,%d2
	move.l d2,a2					*	move.l %d2,%a2
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	move.l d5,d2					*	move.l %d5,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d3,d2					*	or.l %d3,%d2
	cmp.l a2,d2					*	cmp.l %a2,%d2
	jbcc _?L23					*	jcc .L23
	move.l d1,d3					*	move.l %d1,%d3
	subq.l #1,d3					*	subq.l #1,%d3
	add.l d4,d2					*	add.l %d4,%d2
	cmp.l d4,d2					*	cmp.l %d4,%d2
	jbcs _?L45					*	jcs .L45
	cmp.l a2,d2					*	cmp.l %a2,%d2
	jbcc _?L45					*	jcc .L45
	subq.l #2,d1					*	subq.l #2,%d1
	add.l d4,d2					*	add.l %d4,%d2
_?L23:							*.L23:
	sub.l a2,d2					*	sub.l %a2,%d2
	divul.l d0,d0:d2				*	divul.l %d0,%d0:%d2
	move.l a0,d3					*	move.l %a0,%d3
	muls.l d2,d3					*	muls.l %d2,%d3
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.w d5,d0					*	or.w %d5,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L24					*	jcc .L24
	move.l d2,a0					*	move.l %d2,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	add.l d4,d0					*	add.l %d4,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L47					*	jcs .L47
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbcc _?L47					*	jcc .L47
	subq.l #2,d2					*	subq.l #2,%d2
	add.l d4,d0					*	add.l %d4,%d0
_?L24:							*.L24:
	move.l d0,a0					*	move.l %d0,%a0
	sub.l d3,a0					*	sub.l %d3,%a0
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l d1,d5					*	move.l %d1,%d5
	or.l d2,d5					*	or.l %d2,%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	d5,d0					*	move.l	%d5,%d0
	move.l	a1,d1					*	move.l	%a1,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a2					*	move.l	%d2,%a2
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a1					*	move.l	%d0,%a1
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	cmp.l a0,a1					*	cmp.l %a0,%a1
	jbhi _?L25					*	jhi .L25
	jbeq _?L26					*	jeq .L26
_?L51:							*.L51:
	move.l d5,d1					*	move.l %d5,%d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L54:							*.L54:
	cmp.l #255,d2					*	cmp.l #255,%d2
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	lsl.l #3,d0					*	lsl.l #3,%d0
	jbra _?L5					*	jra .L5
_?L32:							*.L32:
	clr.l d1					*	clr.l %d1
	clr.l d0					*	clr.l %d0
	clr.l d7					*	clr.l %d7
	move.b ___clz_tab(d1.l),d7			*	move.b __clz_tab(%d1.l),%d7
	add.l d0,d7					*	add.l %d0,%d7
	moveq #32,d1					*	moveq #32,%d1
	sub.l d7,d1					*	sub.l %d7,%d1
	moveq #32,d0					*	moveq #32,%d0
	cmp.l d7,d0					*	cmp.l %d7,%d0
	jbeq _?L58					*	jeq .L58
_?L13:							*.L13:
	lsl.l d1,d2					*	lsl.l %d1,%d2
	move.l d3,d4					*	move.l %d3,%d4
	lsl.l d1,d4					*	lsl.l %d1,%d4
	move.l d6,d0					*	move.l %d6,%d0
	lsr.l d7,d0					*	lsr.l %d7,%d0
	or.l d4,d0					*	or.l %d4,%d0
	move.l d6,d4					*	move.l %d6,%d4
	lsl.l d1,d4					*	lsl.l %d1,%d4
	move.l d2,d5					*	move.l %d2,%d5
	clr.w d5					*	clr.w %d5
	swap d5						*	swap %d5
	move.l d2,d6					*	move.l %d2,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	lsr.l d7,d3					*	lsr.l %d7,%d3
	move.l d3,d7					*	move.l %d3,%d7
	divul.l d5,d1:d7				*	divul.l %d5,%d1:%d7
	move.l d6,d3					*	move.l %d6,%d3
	muls.l d7,d3					*	muls.l %d7,%d3
	move.l d3,a0					*	move.l %d3,%a0
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	move.l d0,d3					*	move.l %d0,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	or.l d1,d3					*	or.l %d1,%d3
	cmp.l a0,d3					*	cmp.l %a0,%d3
	jbcc _?L15					*	jcc .L15
	move.l d7,d1					*	move.l %d7,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	add.l d2,d3					*	add.l %d2,%d3
	cmp.l d2,d3					*	cmp.l %d2,%d3
	jbcs _?L34					*	jcs .L34
	cmp.l a0,d3					*	cmp.l %a0,%d3
	jbcc _?L34					*	jcc .L34
	subq.l #2,d7					*	subq.l #2,%d7
	add.l d2,d3					*	add.l %d2,%d3
_?L15:							*.L15:
	sub.l a0,d3					*	sub.l %a0,%d3
	divul.l d5,d1:d3				*	divul.l %d5,%d1:%d3
	move.l d1,a1					*	move.l %d1,%a1
	move.l d6,d1					*	move.l %d6,%d1
	muls.l d3,d1					*	muls.l %d3,%d1
	move.l d1,a0					*	move.l %d1,%a0
	move.l a1,d1					*	move.l %a1,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d0,d1					*	or.w %d0,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbcc _?L16					*	jcc .L16
	move.l d3,d0					*	move.l %d3,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	add.l d2,d1					*	add.l %d2,%d1
	cmp.l d2,d1					*	cmp.l %d2,%d1
	jbcs _?L36					*	jcs .L36
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbcc _?L36					*	jcc .L36
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d2,d1					*	add.l %d2,%d1
_?L16:							*.L16:
	sub.l a0,d1					*	sub.l %a0,%d1
	move.l d7,d0					*	move.l %d7,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d3,d0					*	or.l %d3,%d0
	jbra _?L14					*	jra .L14
_?L38:							*.L38:
	move.l a1,d1					*	move.l %a1,%d1
	jbra _?L17					*	jra .L17
_?L40:							*.L40:
	move.l a0,d3					*	move.l %a0,%d3
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d3,d1					*	or.l %d3,%d1
	jbra _?L59					*	jra .L59
_?L29:							*.L29:
	move.l a0,d1					*	move.l %a0,%d1
	jbra _?L7					*	jra .L7
_?L31:							*.L31:
	move.l a0,d0					*	move.l %a0,%d0
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d0,d1					*	or.l %d0,%d1
	clr.l d0					*	clr.l %d0
	jbra _?L9					*	jra .L9
_?L26:							*.L26:
	lsl.l d7,d6					*	lsl.l %d7,%d6
	cmp.l d6,a2					*	cmp.l %d6,%a2
	jbls _?L51					*	jls .L51
_?L25:							*.L25:
	move.l d5,d1					*	move.l %d5,%d1
	subq.l #1,d1					*	subq.l #1,%d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7			*	movem.l (%sp)+,#248
	rts						*	rts
_?L11:							*.L11:
	move.l d2,d1					*	move.l %d2,%d1
	cmp.l #16777215,d2				*	cmp.l #16777215,%d2
	jbhi _?L12					*	jhi .L12
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	moveq #16,d0					*	moveq #16,%d0
	jbra _?L10					*	jra .L10
_?L42:							*.L42:
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L20					*	jra .L20
_?L27:							*.L27:
	moveq #24,d0					*	moveq #24,%d0
	jbra _?L5					*	jra .L5
_?L36:							*.L36:
	move.l d0,d3					*	move.l %d0,%d3
	sub.l a0,d1					*	sub.l %a0,%d1
	move.l d7,d0					*	move.l %d7,%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d3,d0					*	or.l %d3,%d0
	jbra _?L14					*	jra .L14
_?L47:							*.L47:
	move.l a0,d2					*	move.l %a0,%d2
	jbra _?L24					*	jra .L24
_?L34:							*.L34:
	move.l d1,d7					*	move.l %d1,%d7
	jbra _?L15					*	jra .L15
_?L45:							*.L45:
	move.l d3,d1					*	move.l %d3,%d1
	jbra _?L23					*	jra .L23
_?L12:							*.L12:
	moveq #24,d0					*	moveq #24,%d0
	lsr.l d0,d1					*	lsr.l %d0,%d1
	jbra _?L10					*	jra .L10
							*	.size	__udivdi3, .-__udivdi3
							*	.ident	"GCC: (GNU) 13.4.0"
