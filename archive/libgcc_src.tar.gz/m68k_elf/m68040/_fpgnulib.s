* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"fpgnulib.c"				*	.file	"fpgnulib.c"
	.text						*	.text
	.align	2					*	.align	2
							*	.type	__floatsidf.part.0, @function
___floatsidf?part?0:					*__floatsidf.part.0:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	jbmi _?L17					*	jmi .L17
	clr.l d2					*	clr.l %d2
	move.l #1053,d1					*	move.l #1053,%d1
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbgt _?L14					*	jgt .L14
_?L4:							*.L4:
	lsl.l #4,d0					*	lsl.l #4,%d0
	subq.l #4,d1					*	subq.l #4,%d1
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jble _?L4					*	jle .L4
_?L14:							*.L14:
	cmp.l #1073741823,d0				*	cmp.l #1073741823,%d0
	jbgt _?L18					*	jgt .L18
_?L7:							*.L7:
	add.l d0,d0					*	add.l %d0,%d0
	subq.l #1,d1					*	subq.l #1,%d1
	cmp.l #1073741823,d0				*	cmp.l #1073741823,%d0
	jble _?L7					*	jle .L7
_?L18:							*.L18:
	moveq #20,d3					*	moveq #20,%d3
	lsl.l d3,d1					*	lsl.l %d3,%d1
	or.l d2,d1					*	or.l %d2,%d1
	move.l d0,d4					*	move.l %d0,%d4
	moveq #10,d2					*	moveq #10,%d2
	asr.l d2,d4					*	asr.l %d2,%d4
	bclr #20,d4					*	bclr #20,%d4
	move.l d1,d2					*	move.l %d1,%d2
	or.l d4,d2					*	or.l %d4,%d2
	move.l d0,d3					*	move.l %d0,%d3
	moveq #22,d1					*	moveq #22,%d1
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L17:							*.L17:
	neg.l d0					*	neg.l %d0
	jbmi _?L9					*	jmi .L9
	move.l #-2147483648,d2				*	move.l #-2147483648,%d2
	move.l #1053,d1					*	move.l #1053,%d1
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jble _?L4					*	jle .L4
	jbra _?L14					*	jra .L14
_?L9:							*.L9:
	fmove.d #0xc1e00000,#0x00000000,fp0		*	fmove.d #0xc1e0000000000000,%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
							*	.size	__floatsidf.part.0, .-__floatsidf.part.0
	.align	2					*	.align	2
	.globl	___unordsf2				*	.globl	__unordsf2
							*	.hidden	__unordsf2
							*	.type	__unordsf2, @function
___unordsf2:						*__unordsf2:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	move.l d0,d1					*	move.l %d0,%d1
	and.l #2139095040,d1				*	and.l #2139095040,%d1
	cmp.l #2139095040,d1				*	cmp.l #2139095040,%d1
	jbeq _?L26					*	jeq .L26
_?L20:							*.L20:
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	move.l d0,d1					*	move.l %d0,%d1
	and.l #2139095040,d1				*	and.l #2139095040,%d1
	cmp.l #2139095040,d1				*	cmp.l #2139095040,%d1
	jbeq _?L27					*	jeq .L27
	clr.l d0					*	clr.l %d0
	rts						*	rts
_?L26:							*.L26:
	bftst d0{#9:#23}				*	bftst %d0{#9:#23}
	jbeq _?L20					*	jeq .L20
	moveq #1,d0					*	moveq #1,%d0
	rts						*	rts
_?L27:							*.L27:
	bftst d0{#9:#23}				*	bftst %d0{#9:#23}
	sne d0						*	sne %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	rts						*	rts
							*	.size	__unordsf2, .-__unordsf2
	.align	2					*	.align	2
	.globl	___unorddf2				*	.globl	__unorddf2
							*	.hidden	__unorddf2
							*	.type	__unorddf2, @function
___unorddf2:						*__unorddf2:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	move.l 8(sp),a1					*	move.l 8(%sp),%a1
	move.l a0,d0					*	move.l %a0,%d0
	move.l d0,d1					*	move.l %d0,%d1
	and.l #2146435072,d1				*	and.l #2146435072,%d1
	cmp.l #2146435072,d1				*	cmp.l #2146435072,%d1
	jbeq _?L35					*	jeq .L35
_?L29:							*.L29:
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	move.l d0,d1					*	move.l %d0,%d1
	and.l #2146435072,d1				*	and.l #2146435072,%d1
	cmp.l #2146435072,d1				*	cmp.l #2146435072,%d1
	jbeq _?L36					*	jeq .L36
	clr.l d0					*	clr.l %d0
	rts						*	rts
_?L35:							*.L35:
	and.l #1048575,d0				*	and.l #1048575,%d0
	move.l a1,d1					*	move.l %a1,%d1
	or.l d1,d0					*	or.l %d1,%d0
	jbeq _?L29					*	jeq .L29
	moveq #1,d0					*	moveq #1,%d0
	rts						*	rts
_?L36:							*.L36:
	and.l #1048575,d0				*	and.l #1048575,%d0
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	or.l d1,d0					*	or.l %d1,%d0
	sne d0						*	sne %d0
	extb.l d0					*	extb.l %d0
	neg.l d0					*	neg.l %d0
	rts						*	rts
							*	.size	__unorddf2, .-__unorddf2
	.align	2					*	.align	2
	.globl	___floatunsidf				*	.globl	__floatunsidf
							*	.hidden	__floatunsidf
							*	.type	__floatunsidf, @function
___floatunsidf:						*__floatunsidf:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	jbeq _?L44					*	jeq .L44
	move.l #1054,d1					*	move.l #1054,%d1
	cmp.l #33554431,d0				*	cmp.l #33554431,%d0
	jbhi _?L39					*	jhi .L39
_?L40:							*.L40:
	lsl.l #4,d0					*	lsl.l #4,%d0
	subq.l #4,d1					*	subq.l #4,%d1
	cmp.l #33554431,d0				*	cmp.l #33554431,%d0
	jbls _?L40					*	jls .L40
_?L43:							*.L43:
	add.l d0,d0					*	add.l %d0,%d0
	subq.l #1,d1					*	subq.l #1,%d1
	tst.l d0					*	tst.l %d0
	jbge _?L43					*	jge .L43
	bfextu d0{#1:#20},d4				*	bfextu %d0{#1:#20},%d4
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d4,d2					*	move.l %d4,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d0,d3					*	move.l %d0,%d3
	moveq #21,d1					*	moveq #21,%d1
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
_?L37:							*.L37:
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L44:							*.L44:
	fmove.d #0x00000000,#0x0,fp0			*	fmove.d #0x000000000,%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L39:							*.L39:
	tst.l d0					*	tst.l %d0
	jbge _?L43					*	jge .L43
	bfextu d0{#1:#20},d4				*	bfextu %d0{#1:#20},%d4
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d4,d2					*	move.l %d4,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d0,d3					*	move.l %d0,%d3
	moveq #21,d1					*	moveq #21,%d1
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	jbra _?L37					*	jra .L37
							*	.size	__floatunsidf, .-__floatunsidf
	.align	2					*	.align	2
	.globl	___floatsidf				*	.globl	__floatsidf
							*	.hidden	__floatsidf
							*	.type	__floatsidf, @function
___floatsidf:						*__floatsidf:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	jbeq _?L52					*	jeq .L52
	move.l d0,4(sp)					*	move.l %d0,4(%sp)
	jbra (___floatsidf?part?0)			*	jra (__floatsidf.part.0)
_?L52:							*.L52:
	fmove.d #0x00000000,#0x0,fp0			*	fmove.d #0x000000000,%fp0
	rts						*	rts
							*	.size	__floatsidf, .-__floatsidf
	.align	2					*	.align	2
	.globl	___floatunsisf				*	.globl	__floatunsisf
							*	.hidden	__floatunsisf
							*	.type	__floatunsisf, @function
___floatunsisf:						*__floatunsisf:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 12(sp),d0				*	move.l 12(%sp),%d0
	jbeq _?L62					*	jeq .L62
	move.l #1054,d1					*	move.l #1054,%d1
	cmp.l #33554431,d0				*	cmp.l #33554431,%d0
	jbhi _?L57					*	jhi .L57
_?L58:							*.L58:
	lsl.l #4,d0					*	lsl.l #4,%d0
	subq.l #4,d1					*	subq.l #4,%d1
	cmp.l #33554431,d0				*	cmp.l #33554431,%d0
	jbls _?L58					*	jls .L58
_?L61:							*.L61:
	add.l d0,d0					*	add.l %d0,%d0
	subq.l #1,d1					*	subq.l #1,%d1
	tst.l d0					*	tst.l %d0
	jbge _?L61					*	jge .L61
	bfextu d0{#1:#20},d4				*	bfextu %d0{#1:#20},%d4
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d4,d2					*	move.l %d4,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d0,d3					*	move.l %d0,%d3
	moveq #21,d1					*	moveq #21,%d1
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fsmove.x fp0,fp0				*	fsmove.x %fp0,%fp0
_?L55:							*.L55:
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L62:							*.L62:
	fmove.s #0x0,fp0				*	fmove.s #0x0,%fp0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l (sp)+,d4					*	move.l (%sp)+,%d4
	rts						*	rts
_?L57:							*.L57:
	tst.l d0					*	tst.l %d0
	jbge _?L61					*	jge .L61
	bfextu d0{#1:#20},d4				*	bfextu %d0{#1:#20},%d4
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d4,d2					*	move.l %d4,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d0,d3					*	move.l %d0,%d3
	moveq #21,d1					*	moveq #21,%d1
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	fsmove.x fp0,fp0				*	fsmove.x %fp0,%fp0
	jbra _?L55					*	jra .L55
							*	.size	__floatunsisf, .-__floatunsisf
	.align	2					*	.align	2
	.globl	___floatsisf				*	.globl	__floatsisf
							*	.hidden	__floatsisf
							*	.type	__floatsisf, @function
___floatsisf:						*__floatsisf:
	move.l 4(sp),d0					*	move.l 4(%sp),%d0
	jbeq _?L71					*	jeq .L71
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (___floatsidf?part?0)			*	jsr (__floatsidf.part.0)
	addq.l #4,sp					*	addq.l #4,%sp
	fsmove.x fp0,fp0				*	fsmove.x %fp0,%fp0
	rts						*	rts
_?L71:							*.L71:
	fmove.s #0x0,fp0				*	fmove.s #0x0,%fp0
	rts						*	rts
							*	.size	__floatsisf, .-__floatsisf
	.align	2					*	.align	2
	.globl	___extendsfdf2				*	.globl	__extendsfdf2
							*	.hidden	__extendsfdf2
							*	.type	__extendsfdf2, @function
___extendsfdf2:						*__extendsfdf2:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d4				*	move.l 16(%sp),%d4
	move.l d4,d5					*	move.l %d4,%d5
	and.l #-2147483648,d5				*	and.l #-2147483648,%d5
	move.l d5,d2					*	move.l %d5,%d2
	bftst d4{#1:#31}				*	bftst %d4{#1:#31}
	jbeq _?L83					*	jeq .L83
	bfextu d4{#1:#8},d1				*	bfextu %d4{#1:#8},%d1
	move.l d4,d0					*	move.l %d4,%d0
	and.l #8388607,d0				*	and.l #8388607,%d0
	bftst d4{#1:#8}					*	bftst %d4{#1:#8}
	jbne _?L77					*	jne .L77
	moveq #1,d1					*	moveq #1,%d1
_?L78:							*.L78:
	add.l d0,d0					*	add.l %d0,%d0
	subq.l #1,d1					*	subq.l #1,%d1
	btst #23,d0					*	btst #23,%d0
	jbeq _?L78					*	jeq .L78
	bclr #23,d0					*	bclr #23,%d0
_?L77:							*.L77:
	add.l #896,d1					*	add.l #896,%d1
	moveq #20,d2					*	moveq #20,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d0,d4					*	move.l %d0,%d4
	asr.l #3,d4					*	asr.l #3,%d4
	or.l d5,d4					*	or.l %d5,%d4
	move.l d1,d2					*	move.l %d1,%d2
	or.l d4,d2					*	or.l %d4,%d2
	move.l d0,d3					*	move.l %d0,%d3
	moveq #29,d1					*	moveq #29,%d1
	lsl.l d1,d3					*	lsl.l %d1,%d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L83:							*.L83:
	clr.l d3					*	clr.l %d3
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	fdmove.d (sp)+,fp0				*	fdmove.d (%sp)+,%fp0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
							*	.size	__extendsfdf2, .-__extendsfdf2
	.align	2					*	.align	2
	.globl	___truncdfsf2				*	.globl	__truncdfsf2
							*	.hidden	__truncdfsf2
							*	.type	__truncdfsf2, @function
___truncdfsf2:						*__truncdfsf2:
	movem.l d3/d4/d5/d6,-(sp)			*	movem.l #7680,-(%sp)
	move.l 20(sp),d4				*	move.l 20(%sp),%d4
	move.l 24(sp),d5				*	move.l 24(%sp),%d5
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	move.l d0,d2					*	move.l %d0,%d2
	and.l #-2147483648,d2				*	and.l #-2147483648,%d2
	bclr #31,d0					*	bclr #31,%d0
	or.l d5,d0					*	or.l %d5,%d0
	jbeq _?L84					*	jeq .L84
	bfextu d4{#1:#11},d3				*	bfextu %d4{#1:#11},%d3
	add.l #-896,d3					*	add.l #-896,%d3
	move.l d4,d0					*	move.l %d4,%d0
	moveq #10,d6					*	moveq #10,%d6
	lsl.l d6,d0					*	lsl.l %d6,%d0
	and.l #1073740800,d0				*	and.l #1073740800,%d0
	move.l d5,d4					*	move.l %d5,%d4
	moveq #22,d6					*	moveq #22,%d6
	lsr.l d6,d4					*	lsr.l %d6,%d4
	or.l d4,d0					*	or.l %d4,%d0
	and.l #4194303,d1				*	and.l #4194303,%d1
	moveq #63,d5					*	moveq #63,%d5
	and.l d5,d4					*	and.l %d5,%d4
	or.l d1,d4					*	or.l %d1,%d4
	asr.l #6,d0					*	asr.l #6,%d0
	move.l d0,d1					*	move.l %d0,%d1
	bset #24,d1					*	bset #24,%d1
	tst.l d3					*	tst.l %d3
	jble _?L87					*	jle .L87
	btst #0,d0					*	btst #0,%d0
	jbeq _?L101					*	jeq .L101
	moveq #2,d5					*	moveq #2,%d5
	and.l d5,d0					*	and.l %d5,%d0
	or.l d4,d0					*	or.l %d4,%d0
	jbeq _?L102					*	jeq .L102
	clr.b d4					*	clr.b %d4
	moveq #2,d5					*	moveq #2,%d5
_?L91:							*.L91:
	addq.l #1,d1					*	addq.l #1,%d1
	move.l #33554432,d0				*	move.l #33554432,%d0
	tst.b d4					*	tst.b %d4
	jbeq _?L94					*	jeq .L94
	move.l #16777216,d0				*	move.l #16777216,%d0
_?L94:							*.L94:
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbge _?L92					*	jge .L92
	asr.l #1,d1					*	asr.l #1,%d1
	move.l d1,d0					*	move.l %d1,%d0
	bclr #23,d0					*	bclr #23,%d0
	move.l d3,d5					*	move.l %d3,%d5
	moveq #23,d1					*	moveq #23,%d1
	lsl.l d1,d5					*	lsl.l %d1,%d5
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
_?L84:							*.L84:
	fsmove.s d2,fp0					*	fsmove.s %d2,%fp0
	movem.l (sp)+,d3/d4/d5/d6			*	movem.l (%sp)+,#120
	rts						*	rts
_?L87:							*.L87:
	moveq #-24,d0					*	moveq #-24,%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbgt _?L95					*	jgt .L95
	moveq #1,d6					*	moveq #1,%d6
	sub.l d3,d6					*	sub.l %d3,%d6
	move.l d1,d3					*	move.l %d1,%d3
	asr.l d6,d3					*	asr.l %d6,%d3
	moveq #1,d5					*	moveq #1,%d5
	and.l d3,d5					*	and.l %d3,%d5
	btst #0,d3					*	btst #0,%d3
	jbeq _?L103					*	jeq .L103
	moveq #1,d0					*	moveq #1,%d0
	lsl.l d6,d0					*	lsl.l %d6,%d0
	subq.l #1,d0					*	subq.l #1,%d0
	and.l d1,d0					*	and.l %d1,%d0
	or.l d4,d0					*	or.l %d4,%d0
	moveq #2,d1					*	moveq #2,%d1
	and.l d3,d1					*	and.l %d3,%d1
	or.l d1,d0					*	or.l %d1,%d0
	jbeq _?L104					*	jeq .L104
	move.l d3,d1					*	move.l %d3,%d1
	moveq #1,d4					*	moveq #1,%d4
	clr.l d3					*	clr.l %d3
	jbra _?L91					*	jra .L91
_?L95:							*.L95:
	clr.l d5					*	clr.l %d5
	clr.l d0					*	clr.l %d0
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
	jbra _?L84					*	jra .L84
_?L102:							*.L102:
	move.l d1,d0					*	move.l %d1,%d0
	asr.l #1,d0					*	asr.l #1,%d0
	bclr #23,d0					*	bclr #23,%d0
	move.l d3,d5					*	move.l %d3,%d5
	moveq #23,d6					*	moveq #23,%d6
	lsl.l d6,d5					*	lsl.l %d6,%d5
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
	jbra _?L84					*	jra .L84
_?L101:							*.L101:
	bfextu d1{#8:#23},d0				*	bfextu %d1{#8:#23},%d0
	move.l d3,d5					*	move.l %d3,%d5
	moveq #23,d6					*	moveq #23,%d6
	lsl.l d6,d5					*	lsl.l %d6,%d5
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
	jbra _?L84					*	jra .L84
_?L92:							*.L92:
	asr.l d5,d1					*	asr.l %d5,%d1
	move.l d1,d0					*	move.l %d1,%d0
	bclr #23,d0					*	bclr #23,%d0
	addq.l #1,d3					*	addq.l #1,%d3
	move.l d3,d5					*	move.l %d3,%d5
	moveq #23,d6					*	moveq #23,%d6
	lsl.l d6,d5					*	lsl.l %d6,%d5
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
	jbra _?L84					*	jra .L84
_?L103:							*.L103:
	move.l d3,d0					*	move.l %d3,%d0
	asr.l #1,d0					*	asr.l #1,%d0
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
	jbra _?L84					*	jra .L84
_?L104:							*.L104:
	move.l d3,d0					*	move.l %d3,%d0
	asr.l #1,d0					*	asr.l #1,%d0
	clr.l d5					*	clr.l %d5
	or.l d5,d0					*	or.l %d5,%d0
	or.l d0,d2					*	or.l %d0,%d2
	jbra _?L84					*	jra .L84
							*	.size	__truncdfsf2, .-__truncdfsf2
	.align	2					*	.align	2
	.globl	___fixdfsi				*	.globl	__fixdfsi
							*	.hidden	__fixdfsi
							*	.type	__fixdfsi, @function
___fixdfsi:						*__fixdfsi:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d2				*	move.l 16(%sp),%d2
	move.l 20(sp),d3				*	move.l 20(%sp),%d3
	move.l d2,d0					*	move.l %d2,%d0
	jbeq _?L105					*	jeq .L105
	bfextu d2{#1:#11},d4				*	bfextu %d2{#1:#11},%d4
	move.l d4,a0					*	move.l %d4,%a0
	add.w #-1053,a0					*	add.w #-1053,%a0
	tst.l a0					*	tst.l %a0
	jble _?L107					*	jle .L107
	tst.l d0					*	tst.l %d0
	jblt _?L120					*	jlt .L120
	move.l #2147483647,d0				*	move.l #2147483647,%d0
_?L105:							*.L105:
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L107:							*.L107:
	moveq #-31,d1					*	moveq #-31,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbgt _?L110					*	jgt .L110
	move.l d2,d1					*	move.l %d2,%d1
	moveq #10,d5					*	moveq #10,%d5
	lsl.l d5,d1					*	lsl.l %d5,%d1
	and.l #1073740800,d1				*	and.l #1073740800,%d1
	move.l d3,d2					*	move.l %d3,%d2
	moveq #22,d5					*	moveq #22,%d5
	lsr.l d5,d2					*	lsr.l %d5,%d2
	or.l d2,d1					*	or.l %d2,%d1
	bset #30,d1					*	bset #30,%d1
	tst.l a0					*	tst.l %a0
	jbeq _?L108					*	jeq .L108
	move.l #1053,d2					*	move.l #1053,%d2
	sub.l d4,d2					*	sub.l %d4,%d2
	asr.l d2,d1					*	asr.l %d2,%d1
_?L108:							*.L108:
	tst.l d0					*	tst.l %d0
	jblt _?L121					*	jlt .L121
	move.l d1,d0					*	move.l %d1,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L121:							*.L121:
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L120:							*.L120:
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L110:							*.L110:
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
							*	.size	__fixdfsi, .-__fixdfsi
	.align	2					*	.align	2
	.globl	___fixsfsi				*	.globl	__fixsfsi
							*	.hidden	__fixsfsi
							*	.type	__fixsfsi, @function
___fixsfsi:						*__fixsfsi:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	fsmove.s 16(sp),fp0				*	fsmove.s 16(%sp),%fp0
	fmove.d fp0,-(sp)				*	fmove.d %fp0,-(%sp)
	move.l (sp)+,d2					*	move.l (%sp)+,%d2
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	move.l d2,d0					*	move.l %d2,%d0
	jbeq _?L122					*	jeq .L122
	bfextu d2{#1:#11},d4				*	bfextu %d2{#1:#11},%d4
	move.l d4,a0					*	move.l %d4,%a0
	add.w #-1053,a0					*	add.w #-1053,%a0
	tst.l a0					*	tst.l %a0
	jble _?L124					*	jle .L124
	tst.l d0					*	tst.l %d0
	jblt _?L137					*	jlt .L137
	move.l #2147483647,d0				*	move.l #2147483647,%d0
_?L122:							*.L122:
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L124:							*.L124:
	moveq #-31,d1					*	moveq #-31,%d1
	cmp.l a0,d1					*	cmp.l %a0,%d1
	jbgt _?L127					*	jgt .L127
	move.l d2,d1					*	move.l %d2,%d1
	moveq #10,d5					*	moveq #10,%d5
	lsl.l d5,d1					*	lsl.l %d5,%d1
	and.l #1073740800,d1				*	and.l #1073740800,%d1
	move.l d3,d2					*	move.l %d3,%d2
	moveq #22,d5					*	moveq #22,%d5
	lsr.l d5,d2					*	lsr.l %d5,%d2
	or.l d2,d1					*	or.l %d2,%d1
	bset #30,d1					*	bset #30,%d1
	tst.l a0					*	tst.l %a0
	jbeq _?L125					*	jeq .L125
	move.l #1053,d2					*	move.l #1053,%d2
	sub.l d4,d2					*	sub.l %d4,%d2
	asr.l d2,d1					*	asr.l %d2,%d1
_?L125:							*.L125:
	tst.l d0					*	tst.l %d0
	jblt _?L138					*	jlt .L138
	move.l d1,d0					*	move.l %d1,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L138:							*.L138:
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L137:							*.L137:
	move.l #-2147483648,d0				*	move.l #-2147483648,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L127:							*.L127:
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
							*	.size	__fixsfsi, .-__fixsfsi
							*	.ident	"GCC: (GNU) 13.4.0"
