* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___clrsbdi2				*	.globl	__clrsbdi2
							*	.hidden	__clrsbdi2
							*	.type	__clrsbdi2, @function
___clrsbdi2:						*__clrsbdi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	tst.l d1					*	tst.l %d1
	jbeq _?L3					*	jeq .L3
	moveq #-1,d2					*	moveq #-1,%d2
	cmp.l d1,d2					*	cmp.l %d1,%d2
	jbeq _?L13					*	jeq .L13
	move.l d1,d0					*	move.l %d1,%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	eor.l d1,d0					*	eor.l %d1,%d0
	lea 0.w,a1					*	lea 0.w,%a1
_?L5:							*.L5:
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbhi _?L7					*	jhi .L7
	cmp.l #255,d0					*	cmp.l #255,%d0
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.w #32,a0					*	move.w #32,%a0
	sub.l d1,a0					*	sub.l %d1,%a0
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	sub.l d0,a0					*	sub.l %d0,%a0
	lea -1(a1,a0.l),a0				*	lea -1(%a1,%a0.l),%a0
	move.l a0,d0					*	move.l %a0,%d0
_?L1:							*.L1:
	rts						*	rts
_?L13:							*.L13:
	not.l d0					*	not.l %d0
_?L3:							*.L3:
	tst.l d0					*	tst.l %d0
	jbne _?L14					*	jne .L14
	moveq #63,d0					*	moveq #63,%d0
	rts						*	rts
_?L7:							*.L7:
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbhi _?L10					*	jhi .L10
	move.w #16,a0					*	move.w #16,%a0
	moveq #16,d1					*	moveq #16,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	sub.l d0,a0					*	sub.l %d0,%a0
	lea -1(a1,a0.l),a0				*	lea -1(%a1,%a0.l),%a0
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L1					*	jra .L1
_?L10:							*.L10:
	move.w #8,a0					*	move.w #8,%a0
	moveq #24,d1					*	moveq #24,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	sub.l d0,a0					*	sub.l %d0,%a0
	lea -1(a1,a0.l),a0				*	lea -1(%a1,%a0.l),%a0
	move.l a0,d0					*	move.l %a0,%d0
	jbra _?L1					*	jra .L1
_?L14:							*.L14:
	move.w #32,a1					*	move.w #32,%a1
	jbra _?L5					*	jra .L5
							*	.size	__clrsbdi2, .-__clrsbdi2
							*	.ident	"GCC: (GNU) 13.4.0"
