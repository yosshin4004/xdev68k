* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ctzsi2				*	.globl	__ctzsi2
							*	.hidden	__ctzsi2
							*	.type	__ctzsi2, @function
___ctzsi2:						*__ctzsi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l d1,d0					*	move.l %d1,%d0
	neg.l d0					*	neg.l %d0
	and.l d1,d0					*	and.l %d1,%d0
	cmp.l #65535,d0					*	cmp.l #65535,%d0
	jbhi _?L2					*	jhi .L2
	cmp.l #255,d0					*	cmp.l #255,%d0
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d1,a0					*	move.l %d1,%a0
	subq.l #1,a0					*	subq.l #1,%a0
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L2:							*.L2:
	cmp.l #16777215,d0				*	cmp.l #16777215,%d0
	jbhi _?L4					*	jhi .L4
	move.w #15,a0					*	move.w #15,%a0
	moveq #16,d1					*	moveq #16,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L4:							*.L4:
	move.w #23,a0					*	move.w #23,%a0
	moveq #24,d1					*	moveq #24,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.b ___clz_tab(d0.l),d0			*	move.b __clz_tab(%d0.l),%d0
	and.l #255,d0					*	and.l #255,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
							*	.size	__ctzsi2, .-__ctzsi2
							*	.ident	"GCC: (GNU) 13.4.0"
