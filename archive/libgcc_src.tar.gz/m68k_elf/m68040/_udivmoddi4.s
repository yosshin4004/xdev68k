* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___udivmoddi4				*	.globl	__udivmoddi4
							*	.hidden	__udivmoddi4
							*	.type	__udivmoddi4, @function
___udivmoddi4:						*__udivmoddi4:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d0				*	move.l 40(%sp),%d0
	move.l 44(sp),d3				*	move.l 44(%sp),%d3
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	move.l 52(sp),d6				*	move.l 52(%sp),%d6
	move.l 56(sp),a0				*	move.l 56(%sp),%a0
	move.l d6,d5					*	move.l %d6,%d5
	move.l d3,d2					*	move.l %d3,%d2
	move.l d0,a2					*	move.l %d0,%a2
	tst.l d1					*	tst.l %d1
	jbne _?L2					*	jne .L2
	cmp.l d6,d0					*	cmp.l %d6,%d0
	jbcc _?L3					*	jcc .L3
	cmp.l #65535,d6					*	cmp.l #65535,%d6
	jbls _?L63					*	jls .L63
	cmp.l #16777215,d6				*	cmp.l #16777215,%d6
	jbhi _?L33					*	jhi .L33
	moveq #16,d1					*	moveq #16,%d1
_?L5:							*.L5:
	move.l d6,d4					*	move.l %d6,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
	move.b ___clz_tab(d4.l),d4			*	move.b __clz_tab(%d4.l),%d4
	and.l #255,d4					*	and.l #255,%d4
	add.l d4,d1					*	add.l %d4,%d1
	moveq #32,d4					*	moveq #32,%d4
	sub.l d1,d4					*	sub.l %d1,%d4
	moveq #32,d7					*	moveq #32,%d7
	cmp.l d1,d7					*	cmp.l %d1,%d7
	jbeq _?L6					*	jeq .L6
	move.l d6,d5					*	move.l %d6,%d5
	lsl.l d4,d5					*	lsl.l %d4,%d5
	lsl.l d4,d0					*	lsl.l %d4,%d0
	move.l d3,d2					*	move.l %d3,%d2
	lsr.l d1,d2					*	lsr.l %d1,%d2
	or.l d0,d2					*	or.l %d0,%d2
	move.l d2,a2					*	move.l %d2,%a2
	move.l d3,d2					*	move.l %d3,%d2
	lsl.l d4,d2					*	lsl.l %d4,%d2
_?L6:							*.L6:
	move.l d5,d1					*	move.l %d5,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	move.l d5,d6					*	move.l %d5,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	move.l a2,d0					*	move.l %a2,%d0
	divul.l d1,d7:d0				*	divul.l %d1,%d7:%d0
	move.l d6,d3					*	move.l %d6,%d3
	muls.l d0,d3					*	muls.l %d0,%d3
	move.l d3,a1					*	move.l %d3,%a1
	swap d7						*	swap %d7
	clr.w d7					*	clr.w %d7
	move.l d2,d3					*	move.l %d2,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	or.l d7,d3					*	or.l %d7,%d3
	cmp.l a1,d3					*	cmp.l %a1,%d3
	jbcc _?L7					*	jcc .L7
	move.l d0,d7					*	move.l %d0,%d7
	subq.l #1,d7					*	subq.l #1,%d7
	add.l d5,d3					*	add.l %d5,%d3
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbcs _?L35					*	jcs .L35
	cmp.l a1,d3					*	cmp.l %a1,%d3
	jbcc _?L35					*	jcc .L35
	subq.l #2,d0					*	subq.l #2,%d0
	add.l d5,d3					*	add.l %d5,%d3
_?L7:							*.L7:
	sub.l a1,d3					*	sub.l %a1,%d3
	divul.l d1,d1:d3				*	divul.l %d1,%d1:%d3
	muls.l d3,d6					*	muls.l %d3,%d6
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d2,d1					*	or.w %d2,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcc _?L8					*	jcc .L8
	move.l d3,a1					*	move.l %d3,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L37					*	jcs .L37
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcc _?L37					*	jcc .L37
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d5,d1					*	add.l %d5,%d1
_?L8:							*.L8:
	move.l d1,d2					*	move.l %d1,%d2
	sub.l d6,d2					*	sub.l %d6,%d2
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d3,d1					*	or.l %d3,%d1
	clr.l d0					*	clr.l %d0
_?L9:							*.L9:
	tst.l a0					*	tst.l %a0
	jbeq _?L20					*	jeq .L20
	lsr.l d4,d2					*	lsr.l %d4,%d2
	clr.l (a0)					*	clr.l (%a0)
	move.l d2,4(a0)					*	move.l %d2,4(%a0)
_?L20:							*.L20:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L2:							*.L2:
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbcc _?L22					*	jcc .L22
	tst.l a0					*	tst.l %a0
	jbeq _?L47					*	jeq .L47
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l d3,4(a0)					*	move.l %d3,4(%a0)
	clr.l d1					*	clr.l %d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L22:							*.L22:
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbls _?L64					*	jls .L64
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbhi _?L48					*	jhi .L48
	moveq #16,d4					*	moveq #16,%d4
_?L24:							*.L24:
	move.l d1,d5					*	move.l %d1,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	clr.l d7					*	clr.l %d7
	move.b ___clz_tab(d5.l),d7			*	move.b __clz_tab(%d5.l),%d7
	add.l d4,d7					*	add.l %d4,%d7
	move.w #32,a1					*	move.w #32,%a1
	sub.l d7,a1					*	sub.l %d7,%a1
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d7,d4					*	cmp.l %d7,%d4
	jbne _?L25					*	jne .L25
_?L65:							*.L65:
	cmp.l d1,d0					*	cmp.l %d1,%d0
	jbhi _?L26					*	jhi .L26
	cmp.l d6,d3					*	cmp.l %d6,%d3
	jbcs _?L49					*	jcs .L49
_?L26:							*.L26:
* APP ON (APP) asm_mode=gas				*#APP
							*| 1153 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d6,d3					*	sub.l %d6,%d3
	subx.l d1,d0					*	subx.l %d1,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,a2					*	move.l %d0,%a2
	move.l d3,d2					*	move.l %d3,%d2
	moveq #1,d1					*	moveq #1,%d1
_?L27:							*.L27:
	tst.l a0					*	tst.l %a0
	jbeq _?L50					*	jeq .L50
	move.l a2,(a0)					*	move.l %a2,(%a0)
	move.l d2,4(a0)					*	move.l %d2,4(%a0)
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L3:							*.L3:
	tst.l d6					*	tst.l %d6
	jbeq _?L38					*	jeq .L38
	cmp.l #65535,d6					*	cmp.l #65535,%d6
	jbhi _?L11					*	jhi .L11
	cmp.l #255,d6					*	cmp.l #255,%d6
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	move.l d6,d4					*	move.l %d6,%d4
	lsr.l d1,d4					*	lsr.l %d1,%d4
_?L10:							*.L10:
	clr.l d7					*	clr.l %d7
	move.b ___clz_tab(d4.l),d7			*	move.b __clz_tab(%d4.l),%d7
	add.l d1,d7					*	add.l %d1,%d7
	moveq #32,d4					*	moveq #32,%d4
	sub.l d7,d4					*	sub.l %d7,%d4
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbne _?L13					*	jne .L13
_?L67:							*.L67:
	move.l d0,d3					*	move.l %d0,%d3
	sub.l d6,d3					*	sub.l %d6,%d3
	move.l d6,d7					*	move.l %d6,%d7
	clr.w d7					*	clr.w %d7
	swap d7						*	swap %d7
	move.l d7,a4					*	move.l %d7,%a4
	and.l #65535,d6					*	and.l #65535,%d6
	moveq #1,d0					*	moveq #1,%d0
_?L14:							*.L14:
	move.l a4,d7					*	move.l %a4,%d7
	divul.l d7,d7:d3				*	divul.l %d7,%d7:%d3
	move.l d3,d1					*	move.l %d3,%d1
	muls.l d6,d1					*	muls.l %d6,%d1
	move.l d1,a2					*	move.l %d1,%a2
	swap d7						*	swap %d7
	clr.w d7					*	clr.w %d7
	move.l d2,d1					*	move.l %d2,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	or.l d7,d1					*	or.l %d7,%d1
	move.l d1,a3					*	move.l %d1,%a3
	cmp.l a2,d1					*	cmp.l %a2,%d1
	jbcc _?L17					*	jcc .L17
	move.l d3,a1					*	move.l %d3,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d5,a3					*	add.l %d5,%a3
	cmp.l d5,a3					*	cmp.l %d5,%a3
	jbcs _?L44					*	jcs .L44
	cmp.l a2,a3					*	cmp.l %a2,%a3
	jbcc _?L44					*	jcc .L44
	subq.l #2,d3					*	subq.l #2,%d3
	add.l d5,a3					*	add.l %d5,%a3
_?L17:							*.L17:
	move.l a3,d7					*	move.l %a3,%d7
	sub.l a2,d7					*	sub.l %a2,%d7
	move.l a4,d1					*	move.l %a4,%d1
	divul.l d1,d1:d7				*	divul.l %d1,%d1:%d7
	muls.l d7,d6					*	muls.l %d7,%d6
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d2,d1					*	or.w %d2,%d1
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcc _?L18					*	jcc .L18
	move.l d7,a1					*	move.l %d7,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	add.l d5,d1					*	add.l %d5,%d1
	cmp.l d5,d1					*	cmp.l %d5,%d1
	jbcs _?L46					*	jcs .L46
	cmp.l d6,d1					*	cmp.l %d6,%d1
	jbcc _?L46					*	jcc .L46
	subq.l #2,d7					*	subq.l #2,%d7
	add.l d5,d1					*	add.l %d5,%d1
_?L18:							*.L18:
	move.l d1,d2					*	move.l %d1,%d2
	sub.l d6,d2					*	sub.l %d6,%d2
	move.l d3,d1					*	move.l %d3,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d7,d1					*	or.l %d7,%d1
	jbra _?L9					*	jra .L9
_?L64:							*.L64:
	cmp.l #255,d1					*	cmp.l #255,%d1
	shi d4						*	shi %d4
	extb.l d4					*	extb.l %d4
	neg.l d4					*	neg.l %d4
	lsl.l #3,d4					*	lsl.l #3,%d4
	move.l d1,d5					*	move.l %d1,%d5
	lsr.l d4,d5					*	lsr.l %d4,%d5
	clr.l d7					*	clr.l %d7
	move.b ___clz_tab(d5.l),d7			*	move.b __clz_tab(%d5.l),%d7
	add.l d4,d7					*	add.l %d4,%d7
	move.w #32,a1					*	move.w #32,%a1
	sub.l d7,a1					*	sub.l %d7,%a1
	moveq #32,d4					*	moveq #32,%d4
	cmp.l d7,d4					*	cmp.l %d7,%d4
	jbeq _?L65					*	jeq .L65
_?L25:							*.L25:
	move.l a1,d2					*	move.l %a1,%d2
	lsl.l d2,d1					*	lsl.l %d2,%d1
	move.l d6,d2					*	move.l %d6,%d2
	lsr.l d7,d2					*	lsr.l %d7,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d2,a2					*	move.l %d2,%a2
	move.l a1,d4					*	move.l %a1,%d4
	lsl.l d4,d6					*	lsl.l %d4,%d6
	move.l d6,a3					*	move.l %d6,%a3
	move.l d0,d1					*	move.l %d0,%d1
	lsl.l d4,d1					*	lsl.l %d4,%d1
	move.l d3,d4					*	move.l %d3,%d4
	lsr.l d7,d4					*	lsr.l %d7,%d4
	or.l d1,d4					*	or.l %d1,%d4
	move.l d3,d6					*	move.l %d3,%d6
	move.l a1,d1					*	move.l %a1,%d1
	lsl.l d1,d6					*	lsl.l %d1,%d6
	move.l d2,d1					*	move.l %d2,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	move.l d2,d3					*	move.l %d2,%d3
	and.l #65535,d3					*	and.l #65535,%d3
	lsr.l d7,d0					*	lsr.l %d7,%d0
	divul.l d1,d5:d0				*	divul.l %d1,%d5:%d0
	move.l d3,d2					*	move.l %d3,%d2
	muls.l d0,d2					*	muls.l %d0,%d2
	move.l d2,a4					*	move.l %d2,%a4
	swap d5						*	swap %d5
	clr.w d5					*	clr.w %d5
	move.l d4,d2					*	move.l %d4,%d2
	clr.w d2					*	clr.w %d2
	swap d2						*	swap %d2
	or.l d5,d2					*	or.l %d5,%d2
	cmp.l a4,d2					*	cmp.l %a4,%d2
	jbcc _?L28					*	jcc .L28
	move.l d0,d5					*	move.l %d0,%d5
	subq.l #1,d5					*	subq.l #1,%d5
	add.l a2,d2					*	add.l %a2,%d2
	cmp.l a2,d2					*	cmp.l %a2,%d2
	jbcs _?L52					*	jcs .L52
	cmp.l a4,d2					*	cmp.l %a4,%d2
	jbcc _?L52					*	jcc .L52
	subq.l #2,d0					*	subq.l #2,%d0
	add.l a2,d2					*	add.l %a2,%d2
_?L28:							*.L28:
	sub.l a4,d2					*	sub.l %a4,%d2
	divul.l d1,d1:d2				*	divul.l %d1,%d1:%d2
	muls.l d2,d3					*	muls.l %d2,%d3
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.w d4,d1					*	or.w %d4,%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcc _?L29					*	jcc .L29
	move.l d2,d4					*	move.l %d2,%d4
	subq.l #1,d4					*	subq.l #1,%d4
	add.l a2,d1					*	add.l %a2,%d1
	cmp.l a2,d1					*	cmp.l %a2,%d1
	jbcs _?L54					*	jcs .L54
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbcc _?L54					*	jcc .L54
	subq.l #2,d2					*	subq.l #2,%d2
	add.l a2,d1					*	add.l %a2,%d1
_?L29:							*.L29:
	move.l d1,a4					*	move.l %d1,%a4
	sub.l d3,a4					*	sub.l %d3,%a4
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l d0,d5					*	move.l %d0,%d5
	or.l d2,d5					*	or.l %d2,%d5
* APP ON (APP) asm_mode=gas				*#APP
							*| 1181 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
							*	| Inlined umul_ppmm
	move.l	d5,d0					*	move.l	%d5,%d0
	move.l	a3,d1					*	move.l	%a3,%d1
	move.l	d0,d2					*	move.l	%d0,%d2
	swap	d0					*	swap	%d0
	move.l	d1,d3					*	move.l	%d1,%d3
	swap	d1					*	swap	%d1
	move.w	d2,d4					*	move.w	%d2,%d4
	mulu	d3,d4					*	mulu	%d3,%d4
	mulu	d1,d2					*	mulu	%d1,%d2
	mulu	d0,d3					*	mulu	%d0,%d3
	mulu	d0,d1					*	mulu	%d0,%d1
	move.l	d4,d0					*	move.l	%d4,%d0
	eor.w	d0,d0					*	eor.w	%d0,%d0
	swap	d0					*	swap	%d0
	add.l	d0,d2					*	add.l	%d0,%d2
	add.l	d3,d2					*	add.l	%d3,%d2
	jbcc	1f					*	jcc	1f
	add.l	#65536,d1				*	add.l	#65536,%d1
1:	swap	d2					*1:	swap	%d2
	moveq	#0,d0					*	moveq	#0,%d0
	move.w	d2,d0					*	move.w	%d2,%d0
	move.w	d4,d2					*	move.w	%d4,%d2
	move.l	d2,a6					*	move.l	%d2,%a6
	add.l	d1,d0					*	add.l	%d1,%d0
	move.l	d0,a5					*	move.l	%d0,%a5
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l a5,d2					*	move.l %a5,%d2
	move.l a6,d3					*	move.l %a6,%d3
	cmp.l a4,a5					*	cmp.l %a4,%a5
	jbhi _?L30					*	jhi .L30
	jbeq _?L66					*	jeq .L66
_?L31:							*.L31:
	move.l d5,d1					*	move.l %d5,%d1
	tst.l a0					*	tst.l %a0
	jbeq _?L50					*	jeq .L50
	move.l a4,d0					*	move.l %a4,%d0
* APP ON (APP) asm_mode=gas				*#APP
							*| 1194 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l d3,d6					*	sub.l %d3,%d6
	subx.l d2,d0					*	subx.l %d2,%d0
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	move.l d0,d2					*	move.l %d0,%d2
	lsl.l d7,d2					*	lsl.l %d7,%d2
	move.l a1,d7					*	move.l %a1,%d7
	lsr.l d7,d6					*	lsr.l %d7,%d6
	lsr.l d7,d0					*	lsr.l %d7,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	or.l d6,d2					*	or.l %d6,%d2
	move.l d2,4(a0)					*	move.l %d2,4(%a0)
_?L50:							*.L50:
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L63:							*.L63:
	cmp.l #255,d6					*	cmp.l #255,%d6
	shi d1						*	shi %d1
	extb.l d1					*	extb.l %d1
	neg.l d1					*	neg.l %d1
	lsl.l #3,d1					*	lsl.l #3,%d1
	jbra _?L5					*	jra .L5
_?L38:							*.L38:
	clr.l d4					*	clr.l %d4
	clr.l d1					*	clr.l %d1
	clr.l d7					*	clr.l %d7
	move.b ___clz_tab(d4.l),d7			*	move.b __clz_tab(%d4.l),%d7
	add.l d1,d7					*	add.l %d1,%d7
	moveq #32,d4					*	moveq #32,%d4
	sub.l d7,d4					*	sub.l %d7,%d4
	moveq #32,d1					*	moveq #32,%d1
	cmp.l d7,d1					*	cmp.l %d7,%d1
	jbeq _?L67					*	jeq .L67
_?L13:							*.L13:
	move.l d6,d5					*	move.l %d6,%d5
	lsl.l d4,d5					*	lsl.l %d4,%d5
	move.l d0,d1					*	move.l %d0,%d1
	lsl.l d4,d1					*	lsl.l %d4,%d1
	move.l d3,d2					*	move.l %d3,%d2
	lsr.l d7,d2					*	lsr.l %d7,%d2
	or.l d1,d2					*	or.l %d1,%d2
	move.l d2,a1					*	move.l %d2,%a1
	move.l d3,d2					*	move.l %d3,%d2
	lsl.l d4,d2					*	lsl.l %d4,%d2
	move.l d5,d1					*	move.l %d5,%d1
	clr.w d1					*	clr.w %d1
	swap d1						*	swap %d1
	move.l d1,a4					*	move.l %d1,%a4
	move.l d5,d6					*	move.l %d5,%d6
	and.l #65535,d6					*	and.l #65535,%d6
	lsr.l d7,d0					*	lsr.l %d7,%d0
	divul.l d1,d7:d0				*	divul.l %d1,%d7:%d0
	move.l d6,d3					*	move.l %d6,%d3
	muls.l d0,d3					*	muls.l %d0,%d3
	move.l d3,a2					*	move.l %d3,%a2
	swap d7						*	swap %d7
	clr.w d7					*	clr.w %d7
	move.l a1,d3					*	move.l %a1,%d3
	clr.w d3					*	clr.w %d3
	swap d3						*	swap %d3
	or.l d7,d3					*	or.l %d7,%d3
	cmp.l a2,d3					*	cmp.l %a2,%d3
	jbcc _?L15					*	jcc .L15
	move.l d0,d7					*	move.l %d0,%d7
	subq.l #1,d7					*	subq.l #1,%d7
	add.l d5,d3					*	add.l %d5,%d3
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbcs _?L40					*	jcs .L40
	cmp.l a2,d3					*	cmp.l %a2,%d3
	jbcc _?L40					*	jcc .L40
	subq.l #2,d0					*	subq.l #2,%d0
	add.l d5,d3					*	add.l %d5,%d3
_?L15:							*.L15:
	sub.l a2,d3					*	sub.l %a2,%d3
	move.l a4,d1					*	move.l %a4,%d1
	divul.l d1,d7:d3				*	divul.l %d1,%d7:%d3
	move.l d3,a3					*	move.l %d3,%a3
	muls.l d6,d3					*	muls.l %d6,%d3
	move.l d3,a2					*	move.l %d3,%a2
	move.l d7,d3					*	move.l %d7,%d3
	swap d3						*	swap %d3
	clr.w d3					*	clr.w %d3
	move.w a1,d7					*	move.w %a1,%d7
	or.w d7,d3					*	or.w %d7,%d3
	cmp.l a2,d3					*	cmp.l %a2,%d3
	jbcc _?L16					*	jcc .L16
	lea (-1,a3),a1					*	lea (-1,%a3),%a1
	add.l d5,d3					*	add.l %d5,%d3
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbcs _?L42					*	jcs .L42
	cmp.l a2,d3					*	cmp.l %a2,%d3
	jbcc _?L42					*	jcc .L42
	subq.l #2,a3					*	subq.l #2,%a3
	add.l d5,d3					*	add.l %d5,%d3
_?L16:							*.L16:
	sub.l a2,d3					*	sub.l %a2,%d3
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l a3,d1					*	move.l %a3,%d1
	or.l d1,d0					*	or.l %d1,%d0
	jbra _?L14					*	jra .L14
_?L47:							*.L47:
	clr.l d1					*	clr.l %d1
	clr.l d0					*	clr.l %d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L35:							*.L35:
	move.l d7,d0					*	move.l %d7,%d0
	jbra _?L7					*	jra .L7
_?L37:							*.L37:
	move.l a1,d3					*	move.l %a1,%d3
	move.l d1,d2					*	move.l %d1,%d2
	sub.l d6,d2					*	sub.l %d6,%d2
	move.l d0,d1					*	move.l %d0,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d3,d1					*	or.l %d3,%d1
	clr.l d0					*	clr.l %d0
	jbra _?L9					*	jra .L9
_?L44:							*.L44:
	move.l a1,d3					*	move.l %a1,%d3
	jbra _?L17					*	jra .L17
_?L46:							*.L46:
	move.l a1,d7					*	move.l %a1,%d7
	move.l d1,d2					*	move.l %d1,%d2
	sub.l d6,d2					*	sub.l %d6,%d2
	move.l d3,d1					*	move.l %d3,%d1
	swap d1						*	swap %d1
	clr.w d1					*	clr.w %d1
	or.l d7,d1					*	or.l %d7,%d1
	jbra _?L9					*	jra .L9
_?L66:							*.L66:
	cmp.l d6,a6					*	cmp.l %d6,%a6
	jbls _?L31					*	jls .L31
_?L30:							*.L30:
	subq.l #1,d5					*	subq.l #1,%d5
	move.l a5,d2					*	move.l %a5,%d2
	move.l a6,d3					*	move.l %a6,%d3
	move.l a2,d4					*	move.l %a2,%d4
* APP ON (APP) asm_mode=gas				*#APP
							*| 1186 "build_gcc/src/gcc-13.4.0/libgcc/libgcc2.c" 1
	sub.l a3,d3					*	sub.l %a3,%d3
	subx.l d4,d2					*	subx.l %d4,%d2
							*| 0 "" 2
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	jbra _?L31					*	jra .L31
_?L11:							*.L11:
	move.l d6,d4					*	move.l %d6,%d4
	cmp.l #16777215,d6				*	cmp.l #16777215,%d6
	jbhi _?L12					*	jhi .L12
	clr.w d4					*	clr.w %d4
	swap d4						*	swap %d4
	moveq #16,d1					*	moveq #16,%d1
	jbra _?L10					*	jra .L10
_?L33:							*.L33:
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L5					*	jra .L5
_?L48:							*.L48:
	moveq #24,d4					*	moveq #24,%d4
	jbra _?L24					*	jra .L24
_?L42:							*.L42:
	move.l a1,a3					*	move.l %a1,%a3
	sub.l a2,d3					*	sub.l %a2,%d3
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	move.l a3,d1					*	move.l %a3,%d1
	or.l d1,d0					*	or.l %d1,%d0
	jbra _?L14					*	jra .L14
_?L40:							*.L40:
	move.l d7,d0					*	move.l %d7,%d0
	jbra _?L15					*	jra .L15
_?L54:							*.L54:
	move.l d4,d2					*	move.l %d4,%d2
	jbra _?L29					*	jra .L29
_?L52:							*.L52:
	move.l d5,d0					*	move.l %d5,%d0
	jbra _?L28					*	jra .L28
_?L49:							*.L49:
	clr.l d1					*	clr.l %d1
	jbra _?L27					*	jra .L27
_?L12:							*.L12:
	moveq #24,d7					*	moveq #24,%d7
	lsr.l d7,d4					*	lsr.l %d7,%d4
	moveq #24,d1					*	moveq #24,%d1
	jbra _?L10					*	jra .L10
							*	.size	__udivmoddi4, .-__udivmoddi4
							*	.ident	"GCC: (GNU) 13.4.0"
