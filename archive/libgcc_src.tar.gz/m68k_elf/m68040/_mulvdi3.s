* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___mulvdi3				*	.globl	__mulvdi3
							*	.hidden	__mulvdi3
							*	.type	__mulvdi3, @function
___mulvdi3:						*__mulvdi3:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d4				*	move.l 40(%sp),%d4
	move.l 44(sp),d5				*	move.l 44(%sp),%d5
	move.l 48(sp),d2				*	move.l 48(%sp),%d2
	move.l 52(sp),d3				*	move.l 52(%sp),%d3
	move.l d4,a2					*	move.l %d4,%a2
	move.l d5,d1					*	move.l %d5,%d1
	move.l d3,d0					*	move.l %d3,%d0
	move.l d3,d6					*	move.l %d3,%d6
	add.l d6,d6					*	add.l %d6,%d6
	subx.l d6,d6					*	subx.l %d6,%d6
	move.l d2,a3					*	move.l %d2,%a3
	move.l d5,d7					*	move.l %d5,%d7
	add.l d7,d7					*	add.l %d7,%d7
	subx.l d7,d7					*	subx.l %d7,%d7
	cmp.l d7,a2					*	cmp.l %d7,%a2
	jbne _?L2					*	jne .L2
	cmp.l d6,a3					*	cmp.l %d6,%a3
	jbne _?L3					*	jne .L3
	muls.l d3,d0:d1					*	muls.l %d3,%d0:%d1
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L2:							*.L2:
	cmp.l d6,a3					*	cmp.l %d6,%a3
	jbne _?L9					*	jne .L9
	mulu.l d3,d7:d1					*	mulu.l %d3,%d7:%d1
	move.l d7,a3					*	move.l %d7,%a3
	move.l a2,d7					*	move.l %a2,%d7
	mulu.l d3,d6:d7					*	mulu.l %d3,%d6:%d7
	tst.l a2					*	tst.l %a2
	jblt _?L25					*	jlt .L25
	tst.l d0					*	tst.l %d0
	jblt _?L26					*	jlt .L26
_?L11:							*.L11:
	move.l a3,a1					*	move.l %a3,%a1
	lea 0.w,a0					*	lea 0.w,%a0
	move.l a0,d0					*	move.l %a0,%d0
	add.l a1,d7					*	add.l %a1,%d7
	addx.l d0,d6					*	addx.l %d0,%d6
	move.l d7,d0					*	move.l %d7,%d0
	add.l d0,d0					*	add.l %d0,%d0
	subx.l d0,d0					*	subx.l %d0,%d0
	cmp.l d0,d6					*	cmp.l %d0,%d6
	jbne _?L8					*	jne .L8
	move.l d7,d0					*	move.l %d7,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L3:							*.L3:
	move.l d3,d6					*	move.l %d3,%d6
	mulu.l d5,d0:d6					*	mulu.l %d5,%d0:%d6
	move.l d6,a0					*	move.l %d6,%a0
	move.l a3,d7					*	move.l %a3,%d7
	mulu.l d5,d6:d7					*	mulu.l %d5,%d6:%d7
	tst.l a3					*	tst.l %a3
	jblt _?L27					*	jlt .L27
	tst.l d1					*	tst.l %d1
	jblt _?L28					*	jlt .L28
_?L6:							*.L6:
	move.l d0,a6					*	move.l %d0,%a6
	lea 0.w,a5					*	lea 0.w,%a5
	move.l a5,d0					*	move.l %a5,%d0
	move.l a6,d1					*	move.l %a6,%d1
	add.l d7,d1					*	add.l %d7,%d1
	addx.l d6,d0					*	addx.l %d6,%d0
	move.l d1,d2					*	move.l %d1,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	cmp.l d2,d0					*	cmp.l %d2,%d0
	jbne _?L8					*	jne .L8
	move.l d1,d0					*	move.l %d1,%d0
	move.l a0,d1					*	move.l %a0,%d1
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L28:							*.L28:
	sub.l d3,d7					*	sub.l %d3,%d7
	subx.l d2,d6					*	subx.l %d2,%d6
	jbra _?L6					*	jra .L6
_?L27:							*.L27:
	move.l d6,d4					*	move.l %d6,%d4
	sub.l d5,d4					*	sub.l %d5,%d4
	move.l d4,d6					*	move.l %d4,%d6
	tst.l d1					*	tst.l %d1
	jbge _?L6					*	jge .L6
	jbra _?L28					*	jra .L28
_?L26:							*.L26:
	sub.l d5,d7					*	sub.l %d5,%d7
	subx.l d4,d6					*	subx.l %d4,%d6
	jbra _?L11					*	jra .L11
_?L25:							*.L25:
	move.l d6,d2					*	move.l %d6,%d2
	sub.l d3,d2					*	sub.l %d3,%d2
	move.l d2,d6					*	move.l %d2,%d6
	tst.l d0					*	tst.l %d0
	jbge _?L11					*	jge .L11
	jbra _?L26					*	jra .L26
_?L9:							*.L9:
	tst.l a2					*	tst.l %a2
	jblt _?L13					*	jlt .L13
	tst.l a3					*	tst.l %a3
	jblt _?L14					*	jlt .L14
	or.l d2,d4					*	or.l %d2,%d4
	jbne _?L8					*	jne .L8
	mulu.l d3,d0:d1					*	mulu.l %d3,%d0:%d1
	tst.l d0					*	tst.l %d0
	jbge _?L1					*	jge .L1
_?L8:							*.L8:
	trap #7						*	trap #7
_?L13:							*.L13:
	tst.l a3					*	tst.l %a3
	jblt _?L16					*	jlt .L16
	moveq #-1,d4					*	moveq #-1,%d4
	cmp.l a2,d4					*	cmp.l %a2,%d4
	jbne _?L8					*	jne .L8
	tst.l a3					*	tst.l %a3
	jbne _?L8					*	jne .L8
	mulu.l d3,d0:d1					*	mulu.l %d3,%d0:%d1
	sub.l d3,d0					*	sub.l %d3,%d0
	jbpl _?L8					*	jpl .L8
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L14:							*.L14:
	tst.l a2					*	tst.l %a2
	jbne _?L8					*	jne .L8
	moveq #-1,d2					*	moveq #-1,%d2
	cmp.l a3,d2					*	cmp.l %a3,%d2
	jbne _?L8					*	jne .L8
	mulu.l d3,d0:d1					*	mulu.l %d3,%d0:%d1
	sub.l d5,d0					*	sub.l %d5,%d0
	jbpl _?L8					*	jpl .L8
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L16:							*.L16:
	move.l d4,d6					*	move.l %d4,%d6
	and.l d2,d6					*	and.l %d2,%d6
	addq.l #1,d6					*	addq.l #1,%d6
	jbne _?L8					*	jne .L8
	move.l d5,d6					*	move.l %d5,%d6
	or.l d3,d6					*	or.l %d3,%d6
	jbeq _?L8					*	jeq .L8
	mulu.l d3,d0:d1					*	mulu.l %d3,%d0:%d1
	sub.l d5,d0					*	sub.l %d5,%d0
	sub.l d3,d0					*	sub.l %d3,%d0
	jbmi _?L8					*	jmi .L8
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
							*	.size	__mulvdi3, .-__mulvdi3
							*	.ident	"GCC: (GNU) 13.4.0"
