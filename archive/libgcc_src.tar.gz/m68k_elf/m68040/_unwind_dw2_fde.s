* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"unwind-dw2-fde.c"			*	.file	"unwind-dw2-fde.c"
	.text						*	.text
	.align	2					*	.align	2
							*	.type	frame_downheap, @function
_frame_downheap:					*frame_downheap:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d6				*	move.l 40(%sp),%d6
	move.l 44(sp),a5				*	move.l 44(%sp),%a5
	move.l 48(sp),a4				*	move.l 48(%sp),%a4
	move.l 52(sp),d3				*	move.l 52(%sp),%d3
	move.l 56(sp),d5				*	move.l 56(%sp),%d5
	move.l d3,d4					*	move.l %d3,%d4
	add.l d4,d4					*	add.l %d4,%d4
	addq.l #1,d4					*	addq.l #1,%d4
	cmp.l d4,d5					*	cmp.l %d4,%d5
	jble _?L1					*	jle .L1
	move.l d4,d7					*	move.l %d4,%d7
	addq.l #1,d7					*	addq.l #1,%d7
	move.l d4,d0					*	move.l %d4,%d0
	lsl.l #2,d0					*	lsl.l #2,%d0
	lea (a4,d0.l),a3				*	lea (%a4,%d0.l),%a3
	cmp.l d7,d5					*	cmp.l %d7,%d5
	jble _?L3					*	jle .L3
_?L10:							*.L10:
	lea 4(a4,d0.l),a6				*	lea 4(%a4,%d0.l),%a6
	move.l (a6),-(sp)				*	move.l (%a6),-(%sp)
	move.l (a3),-(sp)				*	move.l (%a3),-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	add.w #12,sp					*	add.w #12,%sp
	tst.l d0					*	tst.l %d0
	jblt _?L4					*	jlt .L4
_?L3:							*.L3:
	move.l a3,a6					*	move.l %a3,%a6
	move.l d4,d7					*	move.l %d4,%d7
_?L4:							*.L4:
	lsl.l #2,d3					*	lsl.l #2,%d3
	lea (a4,d3.l),a3				*	lea (%a4,%d3.l),%a3
	move.l (a6),-(sp)				*	move.l (%a6),-(%sp)
	move.l (a3),-(sp)				*	move.l (%a3),-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	add.w #12,sp					*	add.w #12,%sp
	tst.l d0					*	tst.l %d0
	jbge _?L1					*	jge .L1
	move.l (a3),d0					*	move.l (%a3),%d0
	move.l (a6),(a3)				*	move.l (%a6),(%a3)
	move.l d0,(a6)					*	move.l %d0,(%a6)
	move.l d7,d4					*	move.l %d7,%d4
	add.l d4,d4					*	add.l %d4,%d4
	addq.l #1,d4					*	addq.l #1,%d4
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbge _?L1					*	jge .L1
	move.l d7,d3					*	move.l %d7,%d3
	move.l d4,d7					*	move.l %d4,%d7
	addq.l #1,d7					*	addq.l #1,%d7
	move.l d4,d0					*	move.l %d4,%d0
	lsl.l #2,d0					*	lsl.l #2,%d0
	lea (a4,d0.l),a3				*	lea (%a4,%d0.l),%a3
	cmp.l d7,d5					*	cmp.l %d7,%d5
	jble _?L3					*	jle .L3
	jbra _?L10					*	jra .L10
_?L1:							*.L1:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
							*	.size	frame_downheap, .-frame_downheap
	.align	2					*	.align	2
							*	.type	read_encoded_value_with_base, @function
_read_encoded_value_with_base:				*read_encoded_value_with_base:
	movem.l d3/d4/d5,-(sp)				*	movem.l #7168,-(%sp)
	move.l 16(sp),d2				*	move.l 16(%sp),%d2
	move.l 24(sp),a1				*	move.l 24(%sp),%a1
	move.b d2,d3					*	move.b %d2,%d3
	cmp.b #80,d2					*	cmp.b #80,%d2
	jbeq _?L41					*	jeq .L41
	move.b d2,d0					*	move.b %d2,%d0
	and.b #15,d0					*	and.b #15,%d0
	cmp.b #12,d0					*	cmp.b #12,%d0
	jbhi _?L14					*	jhi .L14
	and.l #255,d0					*	and.l #255,%d0
	add.l d0,d0					*	add.l %d0,%d0
	move.w _?L16(pc,d0.l),d0			*	move.w .L16(%pc,%d0.l),%d0
	jmp 2(pc,d0.w)					*	jmp %pc@(2,%d0:w)
	.align 2,0x284c					*	.balignw 2,0x284c
							*	.swbeg	&13
_?L16:							*.L16:
	.dc.w _?L17-_?L16				*	.word .L17-.L16
	.dc.w _?L28-_?L16				*	.word .L28-.L16
	.dc.w _?L22-_?L16				*	.word .L22-.L16
	.dc.w _?L17-_?L16				*	.word .L17-.L16
	.dc.w _?L15-_?L16				*	.word .L15-.L16
	.dc.w _?L14-_?L16				*	.word .L14-.L16
	.dc.w _?L14-_?L16				*	.word .L14-.L16
	.dc.w _?L14-_?L16				*	.word .L14-.L16
	.dc.w _?L14-_?L16				*	.word .L14-.L16
	.dc.w _?L29-_?L16				*	.word .L29-.L16
	.dc.w _?L18-_?L16				*	.word .L18-.L16
	.dc.w _?L17-_?L16				*	.word .L17-.L16
	.dc.w _?L15-_?L16				*	.word .L15-.L16
_?L17:							*.L17:
	clr.l d1					*	clr.l %d1
	move.b (a1),d1					*	move.b (%a1),%d1
	moveq #24,d0					*	moveq #24,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 1(a1),d0					*	move.b 1(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 2(a1),d1					*	move.b 2(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 3(a1),d1					*	or.b 3(%a1),%d1
	lea (4,a1),a0					*	lea (4,%a1),%a0
_?L25:							*.L25:
	tst.l d1					*	tst.l %d1
	jbne _?L26					*	jne .L26
_?L13:							*.L13:
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L29:							*.L29:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d1					*	clr.l %d1
	clr.l d4					*	clr.l %d4
_?L19:							*.L19:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L19					*	jlt .L19
	moveq #31,d0					*	moveq #31,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbcs _?L25					*	jcs .L25
	btst #6,d5					*	btst #6,%d5
	jbeq _?L25					*	jeq .L25
	moveq #-1,d0					*	moveq #-1,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
_?L26:							*.L26:
	and.b #112,d2					*	and.b #112,%d2
	cmp.b #16,d2					*	cmp.b #16,%d2
	jbeq _?L42					*	jeq .L42
	add.l 20(sp),d1					*	add.l 20(%sp),%d1
	tst.b d3					*	tst.b %d3
	jbge _?L13					*	jge .L13
_?L43:							*.L43:
	move.l d1,a1					*	move.l %d1,%a1
	move.l (a1),d1					*	move.l (%a1),%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L41:							*.L41:
	lea (3,a1),a0					*	lea (3,%a1),%a0
	move.l a0,d0					*	move.l %a0,%d0
	moveq #-4,d1					*	moveq #-4,%d1
	and.l d1,d0					*	and.l %d1,%d0
	move.l d0,a0					*	move.l %d0,%a0
	move.l (a0)+,d1					*	move.l (%a0)+,%d1
	move.l 28(sp),a1				*	move.l 28(%sp),%a1
	move.l d1,(a1)					*	move.l %d1,(%a1)
	move.l a0,d0					*	move.l %a0,%d0
	movem.l (sp)+,d3/d4/d5				*	movem.l (%sp)+,#56
	rts						*	rts
_?L42:							*.L42:
	move.l a1,20(sp)				*	move.l %a1,20(%sp)
	add.l 20(sp),d1					*	add.l 20(%sp),%d1
	tst.b d3					*	tst.b %d3
	jbge _?L13					*	jge .L13
	jbra _?L43					*	jra .L43
_?L15:							*.L15:
	clr.l d1					*	clr.l %d1
	move.b 4(a1),d1					*	move.b 4(%a1),%d1
	moveq #24,d0					*	moveq #24,%d0
	lsl.l d0,d1					*	lsl.l %d0,%d1
	clr.l d0					*	clr.l %d0
	move.b 5(a1),d0					*	move.b 5(%a1),%d0
	swap d0						*	swap %d0
	clr.w d0					*	clr.w %d0
	or.l d1,d0					*	or.l %d1,%d0
	clr.l d1					*	clr.l %d1
	move.b 6(a1),d1					*	move.b 6(%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.l d0,d1					*	or.l %d0,%d1
	or.b 7(a1),d1					*	or.b 7(%a1),%d1
	lea (8,a1),a0					*	lea (8,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L13					*	jeq .L13
	jbra _?L26					*	jra .L26
_?L22:							*.L22:
	clr.l d1					*	clr.l %d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L13					*	jeq .L13
	jbra _?L26					*	jra .L26
_?L18:							*.L18:
	clr.l d1					*	clr.l %d1
	move.b (a1),d1					*	move.b (%a1),%d1
	lsl.l #8,d1					*	lsl.l #8,%d1
	or.b 1(a1),d1					*	or.b 1(%a1),%d1
	ext.l d1					*	ext.l %d1
	lea (2,a1),a0					*	lea (2,%a1),%a0
	tst.l d1					*	tst.l %d1
	jbeq _?L13					*	jeq .L13
	jbra _?L26					*	jra .L26
_?L28:							*.L28:
	move.l a1,a0					*	move.l %a1,%a0
	clr.l d1					*	clr.l %d1
	clr.l d4					*	clr.l %d4
_?L23:							*.L23:
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jbge _?L25					*	jge .L25
	move.b (a0)+,d5					*	move.b (%a0)+,%d5
	moveq #127,d0					*	moveq #127,%d0
	and.l d5,d0					*	and.l %d5,%d0
	lsl.l d4,d0					*	lsl.l %d4,%d0
	or.l d0,d1					*	or.l %d0,%d1
	addq.l #7,d4					*	addq.l #7,%d4
	tst.b d5					*	tst.b %d5
	jblt _?L23					*	jlt .L23
	jbra _?L25					*	jra .L25
_?L14:							*.L14:
	trap #7						*	trap #7
							*	.size	read_encoded_value_with_base, .-read_encoded_value_with_base
	.align	2					*	.align	2
							*	.type	fde_unencoded_compare, @function
_fde_unencoded_compare:					*fde_unencoded_compare:
	subq.l #8,sp					*	subq.l #8,%sp
	move.l 16(sp),a1				*	move.l 16(%sp),%a1
	move.l 20(sp),a0				*	move.l 20(%sp),%a0
	move.b 8(a1),(sp)				*	move.b 8(%a1),(%sp)
	move.b 9(a1),1(sp)				*	move.b 9(%a1),1(%sp)
	move.b 10(a1),2(sp)				*	move.b 10(%a1),2(%sp)
	move.b 11(a1),3(sp)				*	move.b 11(%a1),3(%sp)
	move.b 8(a0),4(sp)				*	move.b 8(%a0),4(%sp)
	move.b 9(a0),5(sp)				*	move.b 9(%a0),5(%sp)
	move.b 10(a0),6(sp)				*	move.b 10(%a0),6(%sp)
	move.b 11(a0),7(sp)				*	move.b 11(%a0),7(%sp)
	move.l (sp),d0					*	move.l (%sp),%d0
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L46					*	jcs .L46
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
_?L46:							*.L46:
	moveq #1,d0					*	moveq #1,%d0
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
							*	.size	fde_unencoded_compare, .-fde_unencoded_compare
	.align	2					*	.align	2
							*	.type	fde_unencoded_extract, @function
_fde_unencoded_extract:					*fde_unencoded_extract:
	move.l 16(sp),d1				*	move.l 16(%sp),%d1
	jble _?L49					*	jle .L49
	move.l 12(sp),a2				*	move.l 12(%sp),%a2
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	lsl.l #2,d1					*	lsl.l #2,%d1
	add.l a2,d1					*	add.l %a2,%d1
_?L51:							*.L51:
	move.l (a2)+,a1					*	move.l (%a2)+,%a1
	move.l d0,a0					*	move.l %d0,%a0
	move.b 8(a1),(a0)+				*	move.b 8(%a1),(%a0)+
	move.b 9(a1),(a0)+				*	move.b 9(%a1),(%a0)+
	move.b 10(a1),(a0)+				*	move.b 10(%a1),(%a0)+
	move.b 11(a1),(a0)				*	move.b 11(%a1),(%a0)
	addq.l #4,d0					*	addq.l #4,%d0
	cmp.l a2,d1					*	cmp.l %a2,%d1
	jbne _?L51					*	jne .L51
_?L49:							*.L49:
	rts						*	rts
							*	.size	fde_unencoded_extract, .-fde_unencoded_extract
	.align	2					*	.align	2
							*	.type	fde_radixsort, @function
_fde_radixsort:						*fde_radixsort:
	add.w #-1556,sp					*	add.w #-1556,%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 1596(sp),44(sp)				*	move.l 1596(%sp),44(%sp)
	move.l 1600(sp),a4				*	move.l 1600(%sp),%a4
	move.l 1604(sp),a0				*	move.l 1604(%sp),%a0
	move.l 1608(sp),a6				*	move.l 1608(%sp),%a6
	lea (8,a0),a1					*	lea (8,%a0),%a1
	move.l a1,48(sp)				*	move.l %a1,48(%sp)
	move.l 4(a0),a5					*	move.l 4(%a0),%a5
	pea 1024.w					*	pea 1024.w
	clr.l -(sp)					*	clr.l -(%sp)
	pea 576(sp)					*	pea 576(%sp)
	jbsr _memset					*	jsr memset
	add.w #12,sp					*	add.w #12,%sp
	tst.l a5					*	tst.l %a5
	jbeq _?L71					*	jeq .L71
	addq.l #8,a6					*	addq.l #8,%a6
	move.l 48(sp),a3				*	move.l 48(%sp),%a3
	clr.l d7					*	clr.l %d7
	moveq #56,d1					*	moveq #56,%d1
	add.l sp,d1					*	add.l %sp,%d1
	move.l d1,36(sp)				*	move.l %d1,36(%sp)
	clr.l d6					*	clr.l %d6
	clr.l d3					*	clr.l %d3
	clr.l d4					*	clr.l %d4
_?L60:							*.L60:
	move.l a5,d2					*	move.l %a5,%d2
	sub.l d6,d2					*	sub.l %d6,%d2
	cmp.l #128,d2					*	cmp.l #128,%d2
	jbls _?L57					*	jls .L57
	moveq #127,d2					*	moveq #127,%d2
	not.b d2					*	not.b %d2
_?L57:							*.L57:
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	move.l d6,d0					*	move.l %d6,%d0
	lsl.l #2,d0					*	lsl.l #2,%d0
	pea (a3,d0.l)					*	pea (%a3,%d0.l)
	move.l 44(sp),-(sp)				*	move.l 44(%sp),-(%sp)
	move.l 56(sp),-(sp)				*	move.l 56(%sp),-(%sp)
	move.l d2,56(sp)				*	move.l %d2,56(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d3,68(sp)				*	move.l %d3,68(%sp)
	add.w #16,sp					*	add.w #16,%sp
	move.l 40(sp),d2				*	move.l 40(%sp),%d2
	cmp.l a5,d6					*	cmp.l %a5,%d6
	jbeq _?L58					*	jeq .L58
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l d2,d0					*	move.l %d2,%d0
	lsl.l #2,d0					*	lsl.l #2,%d0
	lea (a0,d0.l),a1				*	lea (%a0,%d0.l),%a1
_?L59:							*.L59:
	move.l d3,d0					*	move.l %d3,%d0
	move.l (a0)+,d3					*	move.l (%a0)+,%d3
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l d7,d1					*	lsr.l %d7,%d1
	moveq #0,d5					*	moveq #0,%d5
	not.b d5					*	not.b %d5
	and.l d5,d1					*	and.l %d5,%d1
	addq.l #1,568(sp,d1.l*4)			*	addq.l #1,568(%sp,%d1.l*4)
	cmp.l d3,d0					*	cmp.l %d3,%d0
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	sub.l d0,d4					*	sub.l %d0,%d4
	cmp.l a0,a1					*	cmp.l %a0,%a1
	jbne _?L59					*	jne .L59
_?L58:							*.L58:
	add.l d2,d6					*	add.l %d2,%d6
	move.l 52(sp,d2.l*4),d3				*	move.l 52(%sp,%d2.l*4),%d3
	cmp.l a5,d6					*	cmp.l %a5,%d6
	jbcs _?L60					*	jcs .L60
	tst.l d4					*	tst.l %d4
	jbeq _?L72					*	jeq .L72
	lea (568,sp),a0					*	lea (568,%sp),%a0
	lea (1592,sp),a1				*	lea (1592,%sp),%a1
	clr.l d0					*	clr.l %d0
_?L61:							*.L61:
	move.l d0,d1					*	move.l %d0,%d1
	add.l (a0),d0					*	add.l (%a0),%d0
	move.l d1,(a0)+					*	move.l %d1,(%a0)+
	cmp.l a1,a0					*	cmp.l %a1,%a0
	jbne _?L61					*	jne .L61
	clr.l d4					*	clr.l %d4
_?L64:							*.L64:
	move.l a5,d6					*	move.l %a5,%d6
	sub.l d4,d6					*	sub.l %d4,%d6
	cmp.l #128,d6					*	cmp.l #128,%d6
	jbls _?L62					*	jls .L62
	moveq #127,d6					*	moveq #127,%d6
	not.b d6					*	not.b %d6
_?L62:							*.L62:
	move.l d4,d3					*	move.l %d4,%d3
	lsl.l #2,d3					*	lsl.l #2,%d3
	add.l a3,d3					*	add.l %a3,%d3
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	pea 60(sp)					*	pea 60(%sp)
	move.l 56(sp),-(sp)				*	move.l 56(%sp),-(%sp)
	jbsr (a4)					*	jsr (%a4)
	add.w #16,sp					*	add.w #16,%sp
	cmp.l a5,d4					*	cmp.l %a5,%d4
	jbeq _?L67					*	jeq .L67
	lea (52,sp),a0					*	lea (52,%sp),%a0
	move.l d3,a1					*	move.l %d3,%a1
	move.l d6,d3					*	move.l %d6,%d3
	lsl.l #2,d3					*	lsl.l #2,%d3
	add.l a0,d3					*	add.l %a0,%d3
_?L66:							*.L66:
	move.l (a0)+,d0					*	move.l (%a0)+,%d0
	lsr.l d7,d0					*	lsr.l %d7,%d0
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d1,d0					*	and.l %d1,%d0
	move.l 568(sp,d0.l*4),d1			*	move.l 568(%sp,%d0.l*4),%d1
	move.l d1,d2					*	move.l %d1,%d2
	addq.l #1,d2					*	addq.l #1,%d2
	move.l d2,568(sp,d0.l*4)			*	move.l %d2,568(%sp,%d0.l*4)
	move.l (a1)+,(a6,d1.l*4)			*	move.l (%a1)+,(%a6,%d1.l*4)
	cmp.l d3,a0					*	cmp.l %d3,%a0
	jbne _?L66					*	jne .L66
_?L67:							*.L67:
	add.l d6,d4					*	add.l %d6,%d4
	cmp.l a5,d4					*	cmp.l %a5,%d4
	jbcs _?L64					*	jcs .L64
	addq.l #8,d7					*	addq.l #8,%d7
	moveq #32,d5					*	moveq #32,%d5
	cmp.l d7,d5					*	cmp.l %d7,%d5
	jbeq _?L68					*	jeq .L68
	pea 1024.w					*	pea 1024.w
	clr.l -(sp)					*	clr.l -(%sp)
	pea 576(sp)					*	pea 576(%sp)
	jbsr _memset					*	jsr memset
	add.w #12,sp					*	add.w #12,%sp
	move.l a3,d0					*	move.l %a3,%d0
	move.l a6,a3					*	move.l %a6,%a3
	move.l d0,a6					*	move.l %d0,%a6
	clr.l d6					*	clr.l %d6
	clr.l d3					*	clr.l %d3
	clr.l d4					*	clr.l %d4
	jbra _?L60					*	jra .L60
_?L71:							*.L71:
	move.l 48(sp),a6				*	move.l 48(%sp),%a6
_?L68:							*.L68:
	cmp.l 48(sp),a6					*	cmp.l 48(%sp),%a6
	jbeq _?L55					*	jeq .L55
	move.l a5,d0					*	move.l %a5,%d0
	lsl.l #2,d0					*	lsl.l #2,%d0
	move.l d0,1604(sp)				*	move.l %d0,1604(%sp)
	move.l a6,1600(sp)				*	move.l %a6,1600(%sp)
	move.l 48(sp),1596(sp)				*	move.l 48(%sp),1596(%sp)
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	add.w #1556,sp					*	add.w #1556,%sp
	jbra _memcpy					*	jra memcpy
_?L55:							*.L55:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	add.w #1556,sp					*	add.w #1556,%sp
	rts						*	rts
_?L72:							*.L72:
	move.l a3,a6					*	move.l %a3,%a6
	jbra _?L68					*	jra .L68
							*	.size	fde_radixsort, .-fde_radixsort
	.align	2					*	.align	2
							*	.type	get_cie_encoding, @function
_get_cie_encoding:					*get_cie_encoding:
	subq.l #4,sp					*	subq.l #4,%sp
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 16(sp),a4				*	move.l 16(%sp),%a4
	lea (9,a4),a3					*	lea (9,%a4),%a3
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _strlen					*	jsr strlen
	addq.l #4,sp					*	addq.l #4,%sp
	lea 1(a3,d0.l),a0				*	lea 1(%a3,%d0.l),%a0
	move.b 8(a4),d1					*	move.b 8(%a4),%d1
	cmp.b #3,d1					*	cmp.b #3,%d1
	jbhi _?L113					*	jhi .L113
	cmp.b #122,9(a4)				*	cmp.b #122,9(%a4)
	jbeq _?L87					*	jeq .L87
_?L96:							*.L96:
	clr.l d0					*	clr.l %d0
_?L84:							*.L84:
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	move.l (sp)+,a4					*	move.l (%sp)+,%a4
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L87:							*.L87:
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L87					*	jlt .L87
_?L88:							*.L88:
	move.l a0,d0					*	move.l %a0,%d0
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L88					*	jlt .L88
	cmp.b #1,d1					*	cmp.b #1,%d1
	jbeq _?L114					*	jeq .L114
_?L89:							*.L89:
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L89					*	jlt .L89
	lea (10,a4),a3					*	lea (10,%a4),%a3
_?L91:							*.L91:
	tst.b (a0)+					*	tst.b (%a0)+
	jblt _?L91					*	jlt .L91
	move.b 10(a4),d0				*	move.b 10(%a4),%d0
	cmp.b #82,d0					*	cmp.b #82,%d0
	jbeq _?L97					*	jeq .L97
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
_?L92:							*.L92:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L115					*	jeq .L115
	cmp.b #76,d0					*	cmp.b #76,%d0
	jbeq _?L110					*	jeq .L110
	cmp.b #66,d0					*	cmp.b #66,%d0
	jbne _?L96					*	jne .L96
_?L110:							*.L110:
	addq.l #1,a0					*	addq.l #1,%a0
	addq.l #1,a3					*	addq.l #1,%a3
	move.b (a3),d0					*	move.b (%a3),%d0
	cmp.b #82,d0					*	cmp.b #82,%d0
	jbne _?L92					*	jne .L92
_?L97:							*.L97:
	clr.l d0					*	clr.l %d0
	move.b (a0),d0					*	move.b (%a0),%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	move.l (sp)+,a4					*	move.l (%sp)+,%a4
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L115:							*.L115:
	move.b (a0)+,d0					*	move.b (%a0)+,%d0
	and.b #127,d0					*	and.b #127,%d0
	pea 8(sp)					*	pea 8(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #127,d1					*	moveq #127,%d1
	and.l d0,d1					*	and.l %d0,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l d0,a0					*	move.l %d0,%a0
	add.w #16,sp					*	add.w #16,%sp
	addq.l #1,a3					*	addq.l #1,%a3
	move.b (a3),d0					*	move.b (%a3),%d0
	cmp.b #82,d0					*	cmp.b #82,%d0
	jbne _?L92					*	jne .L92
	jbra _?L97					*	jra .L97
_?L114:							*.L114:
	move.l d0,a0					*	move.l %d0,%a0
	addq.l #2,a0					*	addq.l #2,%a0
	lea (10,a4),a3					*	lea (10,%a4),%a3
	jbra _?L91					*	jra .L91
_?L113:							*.L113:
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	cmp.b #4,(a0)					*	cmp.b #4,(%a0)
	jbne _?L84					*	jne .L84
	tst.b 1(a0)					*	tst.b 1(%a0)
	jbne _?L84					*	jne .L84
	addq.l #2,a0					*	addq.l #2,%a0
	cmp.b #122,9(a4)				*	cmp.b #122,9(%a4)
	jbeq _?L87					*	jeq .L87
	jbra _?L96					*	jra .L96
							*	.size	get_cie_encoding, .-get_cie_encoding
	.align	2					*	.align	2
							*	.type	fde_mixed_encoding_extract, @function
_fde_mixed_encoding_extract:				*fde_mixed_encoding_extract:
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 40(sp),d7				*	move.l 40(%sp),%d7
	move.l 52(sp),d5				*	move.l 52(%sp),%d5
	jble _?L116					*	jle .L116
	move.l 48(sp),a3				*	move.l 48(%sp),%a3
	move.l 44(sp),d4				*	move.l 44(%sp),%d4
	clr.l d3					*	clr.l %d3
	lea _get_cie_encoding,a5			*	lea get_cie_encoding,%a5
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
_?L122:							*.L122:
	move.l (a3)+,a6					*	move.l (%a3)+,%a6
	move.l a6,d0					*	move.l %a6,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a6),d0					*	sub.l 4(%a6),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a6,d6					*	move.l %a6,%d6
	addq.l #8,d6					*	addq.l #8,%d6
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L125					*	jeq .L125
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L119					*	jeq .L119
	jbls _?L125					*	jls .L125
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L130					*	jne .L130
	move.l d7,a0					*	move.l %d7,%a0
	move.l 8(a0),d0					*	move.l 8(%a0),%d0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	add.w #16,sp					*	add.w #16,%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L122					*	jne .L122
_?L116:							*.L116:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	rts						*	rts
_?L130:							*.L130:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L131					*	jne .L131
_?L125:							*.L125:
	clr.l d0					*	clr.l %d0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	add.w #16,sp					*	add.w #16,%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L122					*	jne .L122
	jbra _?L116					*	jra .L116
_?L119:							*.L119:
	move.l d7,a0					*	move.l %d7,%a0
	move.l 4(a0),d0					*	move.l 4(%a0),%d0
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	add.w #16,sp					*	add.w #16,%sp
	cmp.l d5,d3					*	cmp.l %d5,%d3
	jbne _?L122					*	jne .L122
	jbra _?L116					*	jra .L116
_?L131:							*.L131:
	trap #7						*	trap #7
							*	.size	fde_mixed_encoding_extract, .-fde_mixed_encoding_extract
	.align	2					*	.align	2
							*	.type	classify_object_over_fdes.constprop.0, @function
_classify_object_over_fdes?constprop?0:			*classify_object_over_fdes.constprop.0:
	subq.l #4,sp					*	subq.l #4,%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 44(sp),a4				*	move.l 44(%sp),%a4
	move.l 48(sp),a3				*	move.l 48(%sp),%a3
	move.l (a3),a6					*	move.l (%a3),%a6
	tst.l a6					*	tst.l %a6
	jbeq _?L153					*	jeq .L153
	clr.l d5					*	clr.l %d5
	clr.l d7					*	clr.l %d7
	clr.l d6					*	clr.l %d6
	clr.l d4					*	clr.l %d4
_?L151:							*.L151:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbeq _?L150					*	jeq .L150
	lea (4,a3),a0					*	lea (4,%a3),%a0
	move.l a0,a5					*	move.l %a0,%a5
	sub.l d0,a5					*	sub.l %d0,%a5
	cmp.l a5,d4					*	cmp.l %a5,%d4
	jbeq _?L171					*	jeq .L171
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d7					*	move.l %d0,%d7
	cmp.l #255,d0					*	cmp.l #255,%d0
	jbeq _?L172					*	jeq .L172
	move.b d0,d3					*	move.b %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L138					*	jeq .L138
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L139					*	jeq .L139
	jbls _?L155					*	jls .L155
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L173					*	jne .L173
	move.l 8(a4),d5					*	move.l 8(%a4),%d5
_?L140:							*.L140:
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	cmp.w #8160,d0					*	cmp.w #8160,%d0
	jbeq _?L143					*	jeq .L143
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	bfextu d0{#19:#8},d4				*	bfextu %d0{#19:#8},%d4
	cmp.l d7,d4					*	cmp.l %d7,%d4
	jbeq _?L146					*	jeq .L146
_?L144:							*.L144:
	or.b #32,16(a4)					*	or.b #32,16(%a4)
	move.l a5,d4					*	move.l %a5,%d4
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	add.w #16,sp					*	add.w #16,%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbeq _?L150					*	jeq .L150
_?L152:							*.L152:
	and.b #7,d3					*	and.b #7,%d3
	cmp.b #2,d3					*	cmp.b #2,%d3
	jbeq _?L157					*	jeq .L157
_?L174:							*.L174:
	cmp.b #2,d3					*	cmp.b #2,%d3
	jbhi _?L148					*	jhi .L148
	tst.b d3					*	tst.b %d3
	jbne _?L142					*	jne .L142
_?L158:							*.L158:
	moveq #-1,d0					*	moveq #-1,%d0
_?L147:							*.L147:
	move.l 36(sp),d2				*	move.l 36(%sp),%d2
	and.l d2,d0					*	and.l %d2,%d0
	jbeq _?L150					*	jeq .L150
	addq.l #1,d6					*	addq.l #1,%d6
	cmp.l (a4),d2					*	cmp.l (%a4),%d2
	jbcc _?L150					*	jcc .L150
	move.l d2,(a4)					*	move.l %d2,(%a4)
_?L150:							*.L150:
	lea 4(a3,a6.l),a3				*	lea 4(%a3,%a6.l),%a3
	move.l (a3),a6					*	move.l (%a3),%a6
	tst.l a6					*	tst.l %a6
	jbne _?L151					*	jne .L151
	move.l d6,d0					*	move.l %d6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L146:							*.L146:
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	add.w #16,sp					*	add.w #16,%sp
	move.b d4,d3					*	move.b %d4,%d3
	move.l a5,d4					*	move.l %a5,%d4
	and.b #7,d3					*	and.b #7,%d3
	cmp.b #2,d3					*	cmp.b #2,%d3
	jbne _?L174					*	jne .L174
_?L157:							*.L157:
	moveq #0,d0					*	moveq #0,%d0
	not.w d0					*	not.w %d0
	jbra _?L147					*	jra .L147
_?L171:							*.L171:
	move.b d7,d3					*	move.b %d7,%d3
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	add.w #16,sp					*	add.w #16,%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbne _?L152					*	jne .L152
	jbra _?L150					*	jra .L150
_?L148:							*.L148:
	subq.b #3,d3					*	subq.b #3,%d3
	cmp.b #1,d3					*	cmp.b #1,%d3
	jbls _?L158					*	jls .L158
_?L142:							*.L142:
	trap #7						*	trap #7
_?L138:							*.L138:
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	clr.l d5					*	clr.l %d5
	cmp.w #8160,d0					*	cmp.w #8160,%d0
	jbne _?L144					*	jne .L144
_?L143:							*.L143:
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	bfins d3,d0{#19:#8}				*	bfins %d3,%d0{#19:#8}
	move.w d0,16(a4)				*	move.w %d0,16(%a4)
	move.l a5,d4					*	move.l %a5,%d4
	pea 36(sp)					*	pea 36(%sp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	add.w #16,sp					*	add.w #16,%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbne _?L152					*	jne .L152
	jbra _?L150					*	jra .L150
_?L173:							*.L173:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L142					*	jne .L142
_?L155:							*.L155:
	clr.l d5					*	clr.l %d5
	jbra _?L140					*	jra .L140
_?L139:							*.L139:
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
	jbra _?L140					*	jra .L140
_?L172:							*.L172:
	moveq #-1,d6					*	moveq #-1,%d6
	move.l d6,d0					*	move.l %d6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
_?L153:							*.L153:
	clr.l d6					*	clr.l %d6
	move.l d6,d0					*	move.l %d6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	classify_object_over_fdes.constprop.0, .-classify_object_over_fdes.constprop.0
	.align	2					*	.align	2
							*	.type	fde_single_encoding_extract, @function
_fde_single_encoding_extract:				*fde_single_encoding_extract:
	movem.l d3/d4/d5/d6/d7/a3/a4,-(sp)		*	movem.l #7960,-(%sp)
	move.l 32(sp),a0				*	move.l 32(%sp),%a0
	move.l 44(sp),d6				*	move.l 44(%sp),%d6
	move.w 16(a0),d5				*	move.w 16(%a0),%d5
	bfextu d5{#19:#8},d0				*	bfextu %d5{#19:#8},%d0
	move.l d0,d5					*	move.l %d0,%d5
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L183					*	jeq .L183
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L177					*	jeq .L177
	jbls _?L183					*	jls .L183
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L190					*	jne .L190
	move.l 8(a0),d7					*	move.l 8(%a0),%d7
_?L176:							*.L176:
	tst.l d6					*	tst.l %d6
	jble _?L175					*	jle .L175
	move.l 40(sp),a3				*	move.l 40(%sp),%a3
	move.l 36(sp),d4				*	move.l 36(%sp),%d4
	clr.l d3					*	clr.l %d3
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
_?L181:							*.L181:
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l (a3)+,d0					*	move.l (%a3)+,%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	addq.l #1,d3					*	addq.l #1,%d3
	addq.l #4,d4					*	addq.l #4,%d4
	add.w #16,sp					*	add.w #16,%sp
	cmp.l d6,d3					*	cmp.l %d6,%d3
	jbne _?L181					*	jne .L181
_?L175:							*.L175:
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4		*	movem.l (%sp)+,#6392
	rts						*	rts
_?L183:							*.L183:
	clr.l d7					*	clr.l %d7
	jbra _?L176					*	jra .L176
_?L177:							*.L177:
	move.l 4(a0),d7					*	move.l 4(%a0),%d7
	jbra _?L176					*	jra .L176
_?L190:							*.L190:
	clr.l d7					*	clr.l %d7
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L176					*	jeq .L176
	trap #7						*	trap #7
							*	.size	fde_single_encoding_extract, .-fde_single_encoding_extract
	.align	2					*	.align	2
							*	.type	fde_single_encoding_compare, @function
_fde_single_encoding_compare:				*fde_single_encoding_compare:
	link.w a6,#-8					*	link.w %fp,#-8
	movem.l d3/d4/a3,-(sp)				*	movem.l #6160,-(%sp)
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.w 16(a0),d3				*	move.w 16(%a0),%d3
	bfextu d3{#19:#8},d0				*	bfextu %d3{#19:#8},%d0
	move.l d0,d3					*	move.l %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L198					*	jeq .L198
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L193					*	jeq .L193
	jbls _?L198					*	jls .L198
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L205					*	jne .L205
	move.l 8(a0),d4					*	move.l 8(%a0),%d4
_?L192:							*.L192:
	pea -8(a6)					*	pea -8(%fp)
	move.l 12(a6),d0				*	move.l 12(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	lea _read_encoded_value_with_base,a3		*	lea read_encoded_value_with_base,%a3
	jbsr (a3)					*	jsr (%a3)
	pea -4(a6)					*	pea -4(%fp)
	move.l 16(a6),d0				*	move.l 16(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	add.w #32,sp					*	add.w #32,%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L200					*	jcs .L200
_?L206:							*.L206:
	cmp.l d0,d1					*	cmp.l %d0,%d1
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	movem.l -20(a6),d3/d4/a3			*	movem.l -20(%fp),#2072
	unlk a6						*	unlk %fp
	rts						*	rts
_?L198:							*.L198:
	clr.l d4					*	clr.l %d4
	pea -8(a6)					*	pea -8(%fp)
	move.l 12(a6),d0				*	move.l 12(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	lea _read_encoded_value_with_base,a3		*	lea read_encoded_value_with_base,%a3
	jbsr (a3)					*	jsr (%a3)
	pea -4(a6)					*	pea -4(%fp)
	move.l 16(a6),d0				*	move.l 16(%fp),%d0
	addq.l #8,d0					*	addq.l #8,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	add.w #32,sp					*	add.w #32,%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L206					*	jcc .L206
_?L200:							*.L200:
	moveq #1,d0					*	moveq #1,%d0
	movem.l -20(a6),d3/d4/a3			*	movem.l -20(%fp),#2072
	unlk a6						*	unlk %fp
	rts						*	rts
_?L193:							*.L193:
	move.l 4(a0),d4					*	move.l 4(%a0),%d4
	jbra _?L192					*	jra .L192
_?L205:							*.L205:
	clr.l d4					*	clr.l %d4
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L192					*	jeq .L192
	trap #7						*	trap #7
							*	.size	fde_single_encoding_compare, .-fde_single_encoding_compare
	.align	2					*	.align	2
							*	.type	fde_mixed_encoding_compare, @function
_fde_mixed_encoding_compare:				*fde_mixed_encoding_compare:
	link.w a6,#-8					*	link.w %fp,#-8
	movem.l a3/a4/a5,-(sp)				*	movem.l #28,-(%sp)
	move.l 8(a6),a3					*	move.l 8(%fp),%a3
	move.l 12(a6),a5				*	move.l 12(%fp),%a5
	move.l 16(a6),a4				*	move.l 16(%fp),%a4
	move.l a5,d0					*	move.l %a5,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a5),d0					*	sub.l 4(%a5),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	addq.l #8,a5					*	addq.l #8,%a5
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L217					*	jeq .L217
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L209					*	jeq .L209
	jbls _?L217					*	jls .L217
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L227					*	jne .L227
	move.l 8(a3),a0					*	move.l 8(%a3),%a0
_?L208:							*.L208:
	pea -8(a6)					*	pea -8(%fp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	lea _read_encoded_value_with_base,a5		*	lea read_encoded_value_with_base,%a5
	jbsr (a5)					*	jsr (%a5)
	move.l a4,d0					*	move.l %a4,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a4),d0					*	sub.l 4(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #8,a4					*	addq.l #8,%a4
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	add.w #20,sp					*	add.w #20,%sp
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L220					*	jeq .L220
_?L229:							*.L229:
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L213					*	jeq .L213
	jbls _?L220					*	jls .L220
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L228					*	jne .L228
	move.l 8(a3),a0					*	move.l 8(%a3),%a0
_?L212:							*.L212:
	pea -4(a6)					*	pea -4(%fp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	add.w #16,sp					*	add.w #16,%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcs _?L222					*	jcs .L222
_?L230:							*.L230:
	cmp.l d0,d1					*	cmp.l %d0,%d1
	shi d0						*	shi %d0
	extb.l d0					*	extb.l %d0
	movem.l -20(a6),a3/a4/a5			*	movem.l -20(%fp),#14336
	unlk a6						*	unlk %fp
	rts						*	rts
_?L217:							*.L217:
	lea 0.w,a0					*	lea 0.w,%a0
	pea -8(a6)					*	pea -8(%fp)
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	lea _read_encoded_value_with_base,a5		*	lea read_encoded_value_with_base,%a5
	jbsr (a5)					*	jsr (%a5)
	move.l a4,d0					*	move.l %a4,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a4),d0					*	sub.l 4(%a4),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #8,a4					*	addq.l #8,%a4
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d0,d1					*	and.l %d0,%d1
	add.w #20,sp					*	add.w #20,%sp
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L229					*	jne .L229
_?L220:							*.L220:
	lea 0.w,a0					*	lea 0.w,%a0
	pea -4(a6)					*	pea -4(%fp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	add.w #16,sp					*	add.w #16,%sp
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbcc _?L230					*	jcc .L230
_?L222:							*.L222:
	moveq #1,d0					*	moveq #1,%d0
	movem.l -20(a6),a3/a4/a5			*	movem.l -20(%fp),#14336
	unlk a6						*	unlk %fp
	rts						*	rts
_?L213:							*.L213:
	move.l 4(a3),a0					*	move.l 4(%a3),%a0
	jbra _?L212					*	jra .L212
_?L209:							*.L209:
	move.l 4(a3),a0					*	move.l 4(%a3),%a0
	jbra _?L208					*	jra .L208
_?L227:							*.L227:
	lea 0.w,a0					*	lea 0.w,%a0
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L208					*	jeq .L208
	trap #7						*	trap #7
_?L228:							*.L228:
	lea 0.w,a0					*	lea 0.w,%a0
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L212					*	jeq .L212
	trap #7						*	trap #7
							*	.size	fde_mixed_encoding_compare, .-fde_mixed_encoding_compare
	.align	2					*	.align	2
							*	.type	add_fdes.isra.0, @function
_add_fdes?isra?0:					*add_fdes.isra.0:
	link.w a6,#-4					*	link.w %fp,#-4
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 8(a6),a4					*	move.l 8(%fp),%a4
	move.l 12(a6),a5				*	move.l 12(%fp),%a5
	move.l 16(a6),a3				*	move.l 16(%fp),%a3
	move.w 16(a4),d3				*	move.w 16(%a4),%d3
	bfextu d3{#19:#8},d0				*	bfextu %d3{#19:#8},%d0
	move.l d0,d3					*	move.l %d0,%d3
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L259					*	jeq .L259
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L233					*	jeq .L233
	jbls _?L260					*	jls .L260
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L288					*	jne .L288
	move.l 8(a4),d5					*	move.l 8(%a4),%d5
	clr.l d7					*	clr.l %d7
	tst.l (a3)					*	tst.l (%a3)
	jbeq _?L231					*	jeq .L231
_?L236:							*.L236:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbeq _?L237					*	jeq .L237
	btst #5,16(a4)					*	btst #5,16(%a4)
	jbeq _?L238					*	jeq .L238
	move.l a3,d6					*	move.l %a3,%d6
	addq.l #4,d6					*	addq.l #4,%d6
	sub.l d0,d6					*	sub.l %d0,%d6
	cmp.l d6,d7					*	cmp.l %d6,%d7
	jbeq _?L238					*	jeq .L238
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d3					*	move.l %d0,%d3
	move.b d0,d4					*	move.b %d0,%d4
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L239					*	jeq .L239
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L240					*	jeq .L240
	jbls _?L241					*	jls .L241
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L289					*	jne .L289
	move.l 8(a4),d5					*	move.l 8(%a4),%d5
	tst.l d3					*	tst.l %d3
	jbne _?L290					*	jne .L290
_?L265:							*.L265:
	move.l d6,d7					*	move.l %d6,%d7
_?L256:							*.L256:
	move.b 8(a3),-4(a6)				*	move.b 8(%a3),-4(%fp)
	move.b 9(a3),-3(a6)				*	move.b 9(%a3),-3(%fp)
	move.b 10(a3),-2(a6)				*	move.b 10(%a3),-2(%fp)
	move.b 11(a3),-1(a6)				*	move.b 11(%a3),-1(%fp)
	clr.l d3					*	clr.l %d3
	tst.l -4(a6)					*	tst.l -4(%fp)
	jbeq _?L237					*	jeq .L237
_?L246:							*.L246:
	tst.l a5					*	tst.l %a5
	jbeq _?L237					*	jeq .L237
	move.l 4(a5),d0					*	move.l 4(%a5),%d0
	move.l d0,d1					*	move.l %d0,%d1
	addq.l #1,d1					*	addq.l #1,%d1
	move.l d1,4(a5)					*	move.l %d1,4(%a5)
	move.l a3,8(a5,d0.l*4)				*	move.l %a3,8(%a5,%d0.l*4)
_?L237:							*.L237:
	move.l (a3),d0					*	move.l (%a3),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a3					*	add.l %d0,%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
_?L231:							*.L231:
	movem.l -36(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -36(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L238:							*.L238:
	tst.l d3					*	tst.l %d3
	jbeq _?L256					*	jeq .L256
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.b d3,d4					*	move.b %d3,%d4
	add.w #16,sp					*	add.w #16,%sp
	cmp.b #-1,d3					*	cmp.b #-1,%d3
	jbeq _?L237					*	jeq .L237
_?L255:							*.L255:
	and.b #7,d4					*	and.b #7,%d4
	cmp.b #2,d4					*	cmp.b #2,%d4
	jbeq _?L263					*	jeq .L263
	jbhi _?L249					*	jhi .L249
	tst.b d4					*	tst.b %d4
	jbne _?L235					*	jne .L235
_?L264:							*.L264:
	moveq #-1,d0					*	moveq #-1,%d0
	and.l -4(a6),d0					*	and.l -4(%fp),%d0
	jbne _?L246					*	jne .L246
_?L286:							*.L286:
	move.l (a3),d0					*	move.l (%a3),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a3					*	add.l %d0,%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
	jbra _?L231					*	jra .L231
_?L249:							*.L249:
	subq.b #3,d4					*	subq.b #3,%d4
	cmp.b #1,d4					*	cmp.b #1,%d4
	jbls _?L264					*	jls .L264
_?L235:							*.L235:
	trap #7						*	trap #7
_?L263:							*.L263:
	moveq #0,d0					*	moveq #0,%d0
	not.w d0					*	not.w %d0
	and.l -4(a6),d0					*	and.l -4(%fp),%d0
	jbne _?L246					*	jne .L246
	jbra _?L286					*	jra .L286
_?L289:							*.L289:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L235					*	jne .L235
_?L241:							*.L241:
	tst.l d3					*	tst.l %d3
	jbne _?L291					*	jne .L291
	move.l d6,d7					*	move.l %d6,%d7
	clr.l d5					*	clr.l %d5
	move.b 8(a3),-4(a6)				*	move.b 8(%a3),-4(%fp)
	move.b 9(a3),-3(a6)				*	move.b 9(%a3),-3(%fp)
	move.b 10(a3),-2(a6)				*	move.b 10(%a3),-2(%fp)
	move.b 11(a3),-1(a6)				*	move.b 11(%a3),-1(%fp)
	clr.l d3					*	clr.l %d3
	tst.l -4(a6)					*	tst.l -4(%fp)
	jbne _?L246					*	jne .L246
	jbra _?L237					*	jra .L237
_?L240:							*.L240:
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
	tst.l d3					*	tst.l %d3
	jbeq _?L265					*	jeq .L265
_?L290:							*.L290:
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	moveq #0,d1					*	moveq #0,%d1
	not.b d1					*	not.b %d1
	and.l d3,d1					*	and.l %d3,%d1
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	add.w #16,sp					*	add.w #16,%sp
	move.l d6,d7					*	move.l %d6,%d7
	jbra _?L255					*	jra .L255
_?L239:							*.L239:
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	add.w #16,sp					*	add.w #16,%sp
	move.l d6,d7					*	move.l %d6,%d7
	clr.l d5					*	clr.l %d5
	move.l (a3),d0					*	move.l (%a3),%d0
	addq.l #4,d0					*	addq.l #4,%d0
	add.l d0,a3					*	add.l %d0,%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
	jbra _?L231					*	jra .L231
_?L233:							*.L233:
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
	clr.l d7					*	clr.l %d7
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
	jbra _?L231					*	jra .L231
_?L259:							*.L259:
	clr.l d5					*	clr.l %d5
	moveq #0,d3					*	moveq #0,%d3
	not.b d3					*	not.b %d3
	clr.l d7					*	clr.l %d7
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
	jbra _?L231					*	jra .L231
_?L260:							*.L260:
	clr.l d5					*	clr.l %d5
	clr.l d7					*	clr.l %d7
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
	jbra _?L231					*	jra .L231
_?L291:							*.L291:
	pea -4(a6)					*	pea -4(%fp)
	pea 8(a3)					*	pea 8(%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d3,d0					*	and.l %d3,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.b d3,d4					*	move.b %d3,%d4
	add.w #16,sp					*	add.w #16,%sp
	move.l d6,d7					*	move.l %d6,%d7
	clr.l d5					*	clr.l %d5
	jbra _?L255					*	jra .L255
_?L288:							*.L288:
	clr.l d5					*	clr.l %d5
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L235					*	jne .L235
	clr.l d7					*	clr.l %d7
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L236					*	jne .L236
	jbra _?L231					*	jra .L231
							*	.size	add_fdes.isra.0, .-add_fdes.isra.0
	.align	2					*	.align	2
							*	.type	linear_search_fdes, @function
_linear_search_fdes:					*linear_search_fdes:
	link.w a6,#-12					*	link.w %fp,#-12
	movem.l d3/d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #7964,-(%sp)
	move.l 12(a6),a3				*	move.l 12(%fp),%a3
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.w 16(a0),d4				*	move.w 16(%a0),%d4
	bfextu d4{#19:#8},d0				*	bfextu %d4{#19:#8},%d0
	move.l d0,d4					*	move.l %d0,%d4
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L315					*	jeq .L315
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L294					*	jeq .L294
	jbls _?L316					*	jls .L316
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L344					*	jne .L344
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 8(a0),d6					*	move.l 8(%a0),%d6
_?L293:							*.L293:
	move.l (a3),d3					*	move.l (%a3),%d3
	clr.l d5					*	clr.l %d5
	tst.l d3					*	tst.l %d3
	jbeq _?L311					*	jeq .L311
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
	lea _get_cie_encoding,a5			*	lea get_cie_encoding,%a5
_?L297:							*.L297:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbeq _?L310					*	jeq .L310
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	btst #5,16(a0)					*	btst #5,16(%a0)
	jbeq _?L300					*	jeq .L300
	move.l a3,d7					*	move.l %a3,%d7
	addq.l #4,d7					*	addq.l #4,%d7
	sub.l d0,d7					*	sub.l %d0,%d7
	cmp.l d5,d7					*	cmp.l %d5,%d7
	jbeq _?L300					*	jeq .L300
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d4					*	move.l %d0,%d4
	move.b d0,d1					*	move.b %d0,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L301					*	jeq .L301
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L302					*	jeq .L302
	jbls _?L321					*	jls .L321
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L345					*	jne .L345
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 8(a0),d6					*	move.l 8(%a0),%d6
	tst.l d4					*	tst.l %d4
	jbne _?L346					*	jne .L346
_?L325:							*.L325:
	move.l d7,d5					*	move.l %d7,%d5
_?L313:							*.L313:
	move.l 8(a3),d0					*	move.l 8(%a3),%d0
	move.l d0,-8(a6)				*	move.l %d0,-8(%fp)
	move.l 12(a3),d1				*	move.l 12(%a3),%d1
	move.l d1,-4(a6)				*	move.l %d1,-4(%fp)
	clr.l d4					*	clr.l %d4
	tst.l d0					*	tst.l %d0
	jbeq _?L310					*	jeq .L310
	move.l 16(a6),a1				*	move.l 16(%fp),%a1
	sub.l d0,a1					*	sub.l %d0,%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbhi _?L347					*	jhi .L347
_?L310:							*.L310:
	lea 4(a3,d3.l),a3				*	lea 4(%a3,%d3.l),%a3
	move.l (a3),d3					*	move.l (%a3),%d3
	jbne _?L297					*	jne .L297
_?L311:							*.L311:
	clr.l d0					*	clr.l %d0
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L347:							*.L347:
	move.l a3,d0					*	move.l %a3,%d0
	movem.l -44(a6),d3/d4/d5/d6/d7/a3/a4/a5		*	movem.l -44(%fp),#14584
	unlk a6						*	unlk %fp
	rts						*	rts
_?L345:							*.L345:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbne _?L296					*	jne .L296
_?L321:							*.L321:
	move.l d7,d5					*	move.l %d7,%d5
	clr.l d6					*	clr.l %d6
_?L300:							*.L300:
	tst.l d4					*	tst.l %d4
	jbeq _?L313					*	jeq .L313
	pea -8(a6)					*	pea -8(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	pea -4(a6)					*	pea -4(%fp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.b d4,d1					*	move.b %d4,%d1
	add.w #32,sp					*	add.w #32,%sp
	cmp.b #-1,d4					*	cmp.b #-1,%d4
	jbeq _?L310					*	jeq .L310
_?L312:							*.L312:
	and.b #7,d1					*	and.b #7,%d1
	cmp.b #2,d1					*	cmp.b #2,%d1
	jbeq _?L323					*	jeq .L323
	jbhi _?L309					*	jhi .L309
	tst.b d1					*	tst.b %d1
	jbne _?L296					*	jne .L296
_?L324:							*.L324:
	moveq #-1,d1					*	moveq #-1,%d1
_?L308:							*.L308:
	move.l -8(a6),d0				*	move.l -8(%fp),%d0
	and.l d0,d1					*	and.l %d0,%d1
	jbeq _?L310					*	jeq .L310
	move.l -4(a6),d1				*	move.l -4(%fp),%d1
	move.l 16(a6),a1				*	move.l 16(%fp),%a1
	sub.l d0,a1					*	sub.l %d0,%a1
	cmp.l a1,d1					*	cmp.l %a1,%d1
	jbls _?L310					*	jls .L310
	jbra _?L347					*	jra .L347
_?L309:							*.L309:
	subq.b #3,d1					*	subq.b #3,%d1
	cmp.b #1,d1					*	cmp.b #1,%d1
	jbls _?L324					*	jls .L324
_?L296:							*.L296:
	trap #7						*	trap #7
_?L323:							*.L323:
	moveq #0,d1					*	moveq #0,%d1
	not.w d1					*	not.w %d1
	jbra _?L308					*	jra .L308
_?L302:							*.L302:
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 4(a0),d6					*	move.l 4(%a0),%d6
	tst.l d4					*	tst.l %d4
	jbeq _?L325					*	jeq .L325
_?L346:							*.L346:
	pea -8(a6)					*	pea -8(%fp)
	pea 8(a3)					*	pea 8(%a3)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l #_read_encoded_value_with_base,d5	*	move.l #read_encoded_value_with_base,%d5
	move.l d1,-12(a6)				*	move.l %d1,-12(%fp)
	move.l d5,a0					*	move.l %d5,%a0
	jbsr (a0)					*	jsr (%a0)
	pea -4(a6)					*	pea -4(%fp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d5,a0					*	move.l %d5,%a0
	jbsr (a0)					*	jsr (%a0)
	add.w #32,sp					*	add.w #32,%sp
	move.l d7,d5					*	move.l %d7,%d5
	move.l -12(a6),d1				*	move.l -12(%fp),%d1
	jbra _?L312					*	jra .L312
_?L301:							*.L301:
	pea -8(a6)					*	pea -8(%fp)
	pea 8(a3)					*	pea 8(%a3)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #0,d0					*	moveq #0,%d0
	not.b d0					*	not.b %d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l #_read_encoded_value_with_base,d6	*	move.l #read_encoded_value_with_base,%d6
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	pea -4(a6)					*	pea -4(%fp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d4,d0					*	and.l %d4,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d6,a0					*	move.l %d6,%a0
	jbsr (a0)					*	jsr (%a0)
	add.w #32,sp					*	add.w #32,%sp
	move.l d7,d5					*	move.l %d7,%d5
	clr.l d6					*	clr.l %d6
	lea 4(a3,d3.l),a3				*	lea 4(%a3,%d3.l),%a3
	move.l (a3),d3					*	move.l (%a3),%d3
	jbne _?L297					*	jne .L297
	jbra _?L311					*	jra .L311
_?L294:							*.L294:
	move.l 8(a6),a0					*	move.l 8(%fp),%a0
	move.l 4(a0),d6					*	move.l 4(%a0),%d6
	jbra _?L293					*	jra .L293
_?L315:							*.L315:
	clr.l d6					*	clr.l %d6
	moveq #0,d4					*	moveq #0,%d4
	not.b d4					*	not.b %d4
	jbra _?L293					*	jra .L293
_?L316:							*.L316:
	clr.l d6					*	clr.l %d6
	jbra _?L293					*	jra .L293
_?L344:							*.L344:
	clr.l d6					*	clr.l %d6
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L293					*	jeq .L293
	trap #7						*	trap #7
							*	.size	linear_search_fdes, .-linear_search_fdes
	.align	2					*	.align	2
							*	.type	search_object, @function
_search_object:						*search_object:
	add.w #-20,sp					*	add.w #-20,%sp
	movem.l d3/d4/d5/d6/d7/a3/a4/a5/a6,-(sp)	*	movem.l #7966,-(%sp)
	move.l 60(sp),a3				*	move.l 60(%sp),%a3
	move.l 64(sp),d3				*	move.l 64(%sp),%d3
	move.b 16(a3),d0				*	move.b 16(%a3),%d0
	jbpl _?L457					*	jpl .L457
_?L349:							*.L349:
	btst #5,d0					*	btst #5,%d0
	jbne _?L458					*	jne .L458
	move.w 16(a3),d0				*	move.w 16(%a3),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	jbeq _?L459					*	jeq .L459
	move.l 12(a3),36(sp)				*	move.l 12(%a3),36(%sp)
	move.w 16(a3),d7				*	move.w 16(%a3),%d7
	bfextu d7{#19:#8},d6				*	bfextu %d7{#19:#8},%d6
	move.l d6,40(sp)				*	move.l %d6,40(%sp)
	cmp.b #-1,d6					*	cmp.b #-1,%d6
	jbeq _?L409					*	jeq .L409
	move.b d6,d0					*	move.b %d6,%d0
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L392					*	jeq .L392
	jbls _?L409					*	jls .L409
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L460					*	jne .L460
	move.l 8(a3),44(sp)				*	move.l 8(%a3),44(%sp)
_?L391:							*.L391:
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 4(a0),d4					*	move.l 4(%a0),%d4
	jbeq _?L379					*	jeq .L379
	moveq #15,d0					*	moveq #15,%d0
	and.l d0,d6					*	and.l %d0,%d6
	clr.l d5					*	clr.l %d5
	lea (48,sp),a4					*	lea (48,%sp),%a4
	lea _read_encoded_value_with_base,a5		*	lea read_encoded_value_with_base,%a5
	lea (52,sp),a3					*	lea (52,%sp),%a3
_?L396:							*.L396:
	move.l d5,d7					*	move.l %d5,%d7
	add.l d4,d7					*	add.l %d4,%d7
	lsr.l #1,d7					*	lsr.l #1,%d7
	move.l 36(sp),a0				*	move.l 36(%sp),%a0
	move.l 8(a0,d7.l*4),a6				*	move.l 8(%a0,%d7.l*4),%a6
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	pea 8(a6)					*	pea 8(%a6)
	move.l 52(sp),-(sp)				*	move.l 52(%sp),-(%sp)
	move.l 52(sp),-(sp)				*	move.l 52(%sp),-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	add.w #32,sp					*	add.w #32,%sp
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L411					*	jhi .L411
	add.l 52(sp),d0					*	add.l 52(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L348					*	jhi .L348
	move.l d7,d5					*	move.l %d7,%d5
	addq.l #1,d5					*	addq.l #1,%d5
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbhi _?L396					*	jhi .L396
_?L379:							*.L379:
	lea 0.w,a6					*	lea 0.w,%a6
_?L348:							*.L348:
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	add.w #20,sp					*	add.w #20,%sp
	rts						*	rts
_?L457:							*.L457:
	move.l 16(a3),d1				*	move.l 16(%a3),%d1
	bfextu d1{#11:#21},d4				*	bfextu %d1{#11:#21},%d4
	bftst d1{#11:#21}				*	bftst %d1{#11:#21}
	jbne _?L350					*	jne .L350
	move.l 12(a3),a4				*	move.l 12(%a3),%a4
	btst #6,d0					*	btst #6,%d0
	jbeq _?L351					*	jeq .L351
	move.l (a4),d1					*	move.l (%a4),%d1
	jbeq _?L374					*	jeq .L374
	lea (_classify_object_over_fdes?constprop?0),a5	*	lea (classify_object_over_fdes.constprop.0),%a5
_?L355:							*.L355:
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #-1,d1					*	moveq #-1,%d1
	cmp.l d0,d1					*	cmp.l %d0,%d1
	jbeq _?L357					*	jeq .L357
	add.l d0,d4					*	add.l %d0,%d4
	addq.l #4,a4					*	addq.l #4,%a4
	move.l (a4),d1					*	move.l (%a4),%d1
	jbne _?L355					*	jne .L355
_?L356:							*.L356:
	move.l 16(a3),d0				*	move.l 16(%a3),%d0
	bfins d4,d0{#11:#21}				*	bfins %d4,%d0{#11:#21}
	move.l d0,16(a3)				*	move.l %d0,16(%a3)
	cmp.l #2097152,d4				*	cmp.l #2097152,%d4
	jbcs _?L358					*	jcs .L358
	and.l #-2097152,d0				*	and.l #-2097152,%d0
	move.l d0,16(a3)				*	move.l %d0,16(%a3)
_?L350:							*.L350:
	move.l d4,d5					*	move.l %d4,%d5
	addq.l #2,d5					*	addq.l #2,%d5
	lsl.l #2,d5					*	lsl.l #2,%d5
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	lea _malloc,a5					*	lea malloc,%a5
	jbsr (a5)					*	jsr (%a5)
	move.l d0,a4					*	move.l %d0,%a4
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L374					*	jeq .L374
	clr.l 4(a4)					*	clr.l 4(%a4)
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	move.l d0,a6					*	move.l %d0,%a6
	addq.l #4,sp					*	addq.l #4,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L360					*	jeq .L360
	clr.l 4(a6)					*	clr.l 4(%a6)
_?L360:							*.L360:
	move.b 16(a3),d6				*	move.b 16(%a3),%d6
	move.l 12(a3),a5				*	move.l 12(%a3),%a5
	btst #6,d6					*	btst #6,%d6
	jbeq _?L361					*	jeq .L361
	move.l (a5),d1					*	move.l (%a5),%d1
	jbeq _?L383					*	jeq .L383
	move.l #_add_fdes?isra?0,d5			*	move.l #add_fdes.isra.0,%d5
_?L363:							*.L363:
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l d5,a0					*	move.l %d5,%a0
	jbsr (a0)					*	jsr (%a0)
	addq.l #4,a5					*	addq.l #4,%a5
	move.l (a5),d1					*	move.l (%a5),%d1
	add.w #12,sp					*	add.w #12,%sp
	jbne _?L363					*	jne .L363
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
_?L364:							*.L364:
	cmp.l d4,d5					*	cmp.l %d4,%d5
	jbne _?L383					*	jne .L383
	and.b #32,d6					*	and.b #32,%d6
	tst.l a6					*	tst.l %a6
	jbeq _?L366					*	jeq .L366
	tst.b d6					*	tst.b %d6
	jbne _?L399					*	jne .L399
	move.w 16(a3),d0				*	move.w 16(%a3),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	jbne _?L400					*	jne .L400
	move.l #_fde_unencoded_extract,d0		*	move.l #fde_unencoded_extract,%d0
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _fde_radixsort				*	jsr fde_radixsort
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr _free					*	jsr free
	add.w #20,sp					*	add.w #20,%sp
_?L368:							*.L368:
	move.l 12(a3),(a4)				*	move.l 12(%a3),(%a4)
	move.l a4,12(a3)				*	move.l %a4,12(%a3)
	or.b #-128,16(a3)				*	or.b #-128,16(%a3)
_?L374:							*.L374:
	cmp.l (a3),d3					*	cmp.l (%a3),%d3
	jbcs _?L379					*	jcs .L379
	move.b 16(a3),d0				*	move.b 16(%a3),%d0
	jbmi _?L349					*	jmi .L349
	move.l 12(a3),a4				*	move.l 12(%a3),%a4
	btst #6,d0					*	btst #6,%d0
	jbeq _?L397					*	jeq .L397
	move.l (a4),d0					*	move.l (%a4),%d0
	jbeq _?L379					*	jeq .L379
	lea _linear_search_fdes,a5			*	lea linear_search_fdes,%a5
_?L398:							*.L398:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a5)					*	jsr (%a5)
	add.w #12,sp					*	add.w #12,%sp
	move.l d0,a6					*	move.l %d0,%a6
	tst.l d0					*	tst.l %d0
	jbne _?L348					*	jne .L348
	addq.l #4,a4					*	addq.l #4,%a4
	move.l (a4),d0					*	move.l (%a4),%d0
	jbne _?L398					*	jne .L398
	lea 0.w,a6					*	lea 0.w,%a6
	jbra _?L348					*	jra .L348
_?L459:							*.L459:
	move.l 12(a3),a2				*	move.l 12(%a3),%a2
	move.l 4(a2),a1					*	move.l 4(%a2),%a1
	tst.l a1					*	tst.l %a1
	jbeq _?L379					*	jeq .L379
	clr.l d2					*	clr.l %d2
	lea (48,sp),a4					*	lea (48,%sp),%a4
	lea (52,sp),a3					*	lea (52,%sp),%a3
	move.l a1,d0					*	move.l %a1,%d0
	add.l d2,d0					*	add.l %d2,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l 8(a2,d0.l*4),a6				*	move.l 8(%a2,%d0.l*4),%a6
	move.b 8(a6),(a4)				*	move.b 8(%a6),(%a4)
	move.b 9(a6),49(sp)				*	move.b 9(%a6),49(%sp)
	move.b 10(a6),50(sp)				*	move.b 10(%a6),50(%sp)
	move.b 11(a6),51(sp)				*	move.b 11(%a6),51(%sp)
	move.b 12(a6),(a3)				*	move.b 12(%a6),(%a3)
	move.b 13(a6),53(sp)				*	move.b 13(%a6),53(%sp)
	move.b 14(a6),54(sp)				*	move.b 14(%a6),54(%sp)
	move.b 15(a6),55(sp)				*	move.b 15(%a6),55(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbhi _?L407					*	jhi .L407
_?L461:							*.L461:
	add.l 52(sp),d1					*	add.l 52(%sp),%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbhi _?L348					*	jhi .L348
	move.l d0,d2					*	move.l %d0,%d2
	addq.l #1,d2					*	addq.l #1,%d2
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbls _?L379					*	jls .L379
_?L454:							*.L454:
	move.l a1,d0					*	move.l %a1,%d0
	add.l d2,d0					*	add.l %d2,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l 8(a2,d0.l*4),a6				*	move.l 8(%a2,%d0.l*4),%a6
	move.b 8(a6),(a4)				*	move.b 8(%a6),(%a4)
	move.b 9(a6),49(sp)				*	move.b 9(%a6),49(%sp)
	move.b 10(a6),50(sp)				*	move.b 10(%a6),50(%sp)
	move.b 11(a6),51(sp)				*	move.b 11(%a6),51(%sp)
	move.b 12(a6),(a3)				*	move.b 12(%a6),(%a3)
	move.b 13(a6),53(sp)				*	move.b 13(%a6),53(%sp)
	move.b 14(a6),54(sp)				*	move.b 14(%a6),54(%sp)
	move.b 15(a6),55(sp)				*	move.b 15(%a6),55(%sp)
	move.l 48(sp),d1				*	move.l 48(%sp),%d1
	cmp.l d3,d1					*	cmp.l %d3,%d1
	jbls _?L461					*	jls .L461
_?L407:							*.L407:
	move.l d0,a1					*	move.l %d0,%a1
	cmp.l d2,a1					*	cmp.l %d2,%a1
	jbhi _?L454					*	jhi .L454
	jbra _?L379					*	jra .L379
_?L351:							*.L351:
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (_classify_object_over_fdes?constprop?0)	*	jsr (classify_object_over_fdes.constprop.0)
	move.l d0,d4					*	move.l %d0,%d4
	addq.l #8,sp					*	addq.l #8,%sp
	moveq #-1,d0					*	moveq #-1,%d0
	cmp.l d4,d0					*	cmp.l %d4,%d0
	jbne _?L356					*	jne .L356
_?L357:							*.L357:
	clr.l 16(a3)					*	clr.l 16(%a3)
	move.w #8160,16(a3)				*	move.w #8160,16(%a3)
	move.l #_terminator?0,12(a3)			*	move.l #terminator.0,12(%a3)
	jbra _?L374					*	jra .L374
_?L397:							*.L397:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _linear_search_fdes			*	jsr linear_search_fdes
	add.w #12,sp					*	add.w #12,%sp
	move.l d0,a6					*	move.l %d0,%a6
	move.l a6,d0					*	move.l %a6,%d0
	movem.l (sp)+,d3/d4/d5/d6/d7/a3/a4/a5/a6	*	movem.l (%sp)+,#30968
	add.w #20,sp					*	add.w #20,%sp
	rts						*	rts
_?L458:							*.L458:
	move.l 12(a3),a5				*	move.l 12(%a3),%a5
	move.l 4(a5),d5					*	move.l 4(%a5),%d5
	jbeq _?L379					*	jeq .L379
	clr.l d6					*	clr.l %d6
	lea _read_encoded_value_with_base,a4		*	lea read_encoded_value_with_base,%a4
	move.l d6,d4					*	move.l %d6,%d4
	add.l d5,d4					*	add.l %d5,%d4
	lsr.l #1,d4					*	lsr.l #1,%d4
	move.l 8(a5,d4.l*4),a6				*	move.l 8(%a5,%d4.l*4),%a6
	move.l a6,d0					*	move.l %a6,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a6),d0					*	sub.l 4(%a6),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d7					*	move.l %d0,%d7
	lea (8,a6),a1					*	lea (8,%a6),%a1
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d0,d2					*	and.l %d0,%d2
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L405					*	jeq .L405
_?L463:							*.L463:
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L381					*	jeq .L381
	jbls _?L405					*	jls .L405
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L462					*	jne .L462
	move.l 8(a3),d0					*	move.l 8(%a3),%d0
_?L380:							*.L380:
	pea 48(sp)					*	pea 48(%sp)
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	pea 68(sp)					*	pea 68(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	add.w #32,sp					*	add.w #32,%sp
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L406					*	jhi .L406
_?L464:							*.L464:
	add.l 52(sp),d0					*	add.l 52(%sp),%d0
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbhi _?L348					*	jhi .L348
	move.l d4,d6					*	move.l %d4,%d6
	addq.l #1,d6					*	addq.l #1,%d6
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbls _?L379					*	jls .L379
_?L455:							*.L455:
	move.l d6,d4					*	move.l %d6,%d4
	add.l d5,d4					*	add.l %d5,%d4
	lsr.l #1,d4					*	lsr.l #1,%d4
	move.l 8(a5,d4.l*4),a6				*	move.l 8(%a5,%d4.l*4),%a6
	move.l a6,d0					*	move.l %a6,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a6),d0					*	sub.l 4(%a6),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,d7					*	move.l %d0,%d7
	lea (8,a6),a1					*	lea (8,%a6),%a1
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d0,d2					*	and.l %d0,%d2
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L463					*	jne .L463
_?L405:							*.L405:
	clr.l d0					*	clr.l %d0
	pea 48(sp)					*	pea 48(%sp)
	move.l a1,-(sp)					*	move.l %a1,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	pea 68(sp)					*	pea 68(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	moveq #15,d0					*	moveq #15,%d0
	and.l d7,d0					*	and.l %d7,%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l 80(sp),d0				*	move.l 80(%sp),%d0
	add.w #32,sp					*	add.w #32,%sp
	cmp.l d3,d0					*	cmp.l %d3,%d0
	jbls _?L464					*	jls .L464
_?L406:							*.L406:
	move.l d4,d5					*	move.l %d4,%d5
	cmp.l d6,d5					*	cmp.l %d6,%d5
	jbhi _?L455					*	jhi .L455
	jbra _?L379					*	jra .L379
_?L381:							*.L381:
	move.l 4(a3),d0					*	move.l 4(%a3),%d0
	jbra _?L380					*	jra .L380
_?L462:							*.L462:
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L405					*	jeq .L405
_?L383:							*.L383:
	trap #7						*	trap #7
_?L399:							*.L399:
	move.l #_fde_mixed_encoding_extract,d0		*	move.l #fde_mixed_encoding_extract,%d0
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _fde_radixsort				*	jsr fde_radixsort
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr _free					*	jsr free
	add.w #20,sp					*	add.w #20,%sp
	jbra _?L368					*	jra .L368
_?L361:							*.L361:
	move.l a5,-(sp)					*	move.l %a5,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (_add_fdes?isra?0)				*	jsr (add_fdes.isra.0)
	move.l 4(a4),d5					*	move.l 4(%a4),%d5
	add.w #12,sp					*	add.w #12,%sp
	jbra _?L364					*	jra .L364
_?L366:							*.L366:
	tst.b d6					*	tst.b %d6
	jbne _?L401					*	jne .L401
	move.w 16(a3),d0				*	move.w 16(%a3),%d0
	and.w #8160,d0					*	and.w #8160,%d0
	jbne _?L402					*	jne .L402
	move.l #_fde_unencoded_compare,d6		*	move.l #fde_unencoded_compare,%d6
	move.l a4,d4					*	move.l %a4,%d4
	addq.l #8,d4					*	addq.l #8,%d4
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l d0,d7					*	move.l %d0,%d7
	subq.l #1,d7					*	subq.l #1,%d7
	lea _frame_downheap,a6				*	lea frame_downheap,%a6
	tst.l d0					*	tst.l %d0
	jbeq _?L368					*	jeq .L368
_?L371:							*.L371:
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a6)					*	jsr (%a6)
	add.w #20,sp					*	add.w #20,%sp
	dbra d7,_?L371					*	dbra %d7,.L371
	clr.w d7					*	clr.w %d7
	subq.l #1,d7					*	subq.l #1,%d7
	jbcc _?L371					*	jcc .L371
	move.l d5,d7					*	move.l %d5,%d7
	subq.l #1,d7					*	subq.l #1,%d7
	tst.l d7					*	tst.l %d7
	jble _?L368					*	jle .L368
	addq.l #1,d5					*	addq.l #1,%d5
	lsl.l #2,d5					*	lsl.l #2,%d5
	lea (a4,d5.l),a5				*	lea (%a4,%d5.l),%a5
_?L373:							*.L373:
	move.l 8(a4),d0					*	move.l 8(%a4),%d0
	move.l (a5),8(a4)				*	move.l (%a5),8(%a4)
	move.l d0,(a5)					*	move.l %d0,(%a5)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a6)					*	jsr (%a6)
	subq.l #1,d7					*	subq.l #1,%d7
	subq.l #4,a5					*	subq.l #4,%a5
	add.w #20,sp					*	add.w #20,%sp
	jbeq _?L368					*	jeq .L368
	move.l 8(a4),d0					*	move.l 8(%a4),%d0
	move.l (a5),8(a4)				*	move.l (%a5),8(%a4)
	move.l d0,(a5)					*	move.l %d0,(%a5)
	move.l d7,-(sp)					*	move.l %d7,-(%sp)
	clr.l -(sp)					*	clr.l -(%sp)
	move.l d4,-(sp)					*	move.l %d4,-(%sp)
	move.l d6,-(sp)					*	move.l %d6,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a6)					*	jsr (%a6)
	subq.l #1,d7					*	subq.l #1,%d7
	subq.l #4,a5					*	subq.l #4,%a5
	add.w #20,sp					*	add.w #20,%sp
	jbne _?L373					*	jne .L373
	jbra _?L368					*	jra .L368
_?L409:							*.L409:
	clr.l 44(sp)					*	clr.l 44(%sp)
	jbra _?L391					*	jra .L391
_?L411:							*.L411:
	move.l d7,d4					*	move.l %d7,%d4
	cmp.l d5,d4					*	cmp.l %d5,%d4
	jbhi _?L396					*	jhi .L396
	jbra _?L379					*	jra .L379
_?L400:							*.L400:
	move.l #_fde_single_encoding_extract,d0		*	move.l #fde_single_encoding_extract,%d0
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr _fde_radixsort				*	jsr fde_radixsort
	move.l a6,-(sp)					*	move.l %a6,-(%sp)
	jbsr _free					*	jsr free
	add.w #20,sp					*	add.w #20,%sp
	jbra _?L368					*	jra .L368
_?L401:							*.L401:
	move.l #_fde_mixed_encoding_compare,d6		*	move.l #fde_mixed_encoding_compare,%d6
	move.l a4,d4					*	move.l %a4,%d4
	addq.l #8,d4					*	addq.l #8,%d4
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l d0,d7					*	move.l %d0,%d7
	subq.l #1,d7					*	subq.l #1,%d7
	lea _frame_downheap,a6				*	lea frame_downheap,%a6
	tst.l d0					*	tst.l %d0
	jbne _?L371					*	jne .L371
	jbra _?L368					*	jra .L368
_?L460:							*.L460:
	clr.l 44(sp)					*	clr.l 44(%sp)
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L391					*	jeq .L391
	trap #7						*	trap #7
_?L358:							*.L358:
	tst.l d4					*	tst.l %d4
	jbeq _?L374					*	jeq .L374
	jbra _?L350					*	jra .L350
_?L392:							*.L392:
	move.l 4(a3),44(sp)				*	move.l 4(%a3),44(%sp)
	jbra _?L391					*	jra .L391
_?L402:							*.L402:
	move.l #_fde_single_encoding_compare,d6		*	move.l #fde_single_encoding_compare,%d6
	move.l a4,d4					*	move.l %a4,%d4
	addq.l #8,d4					*	addq.l #8,%d4
	move.l d5,d0					*	move.l %d5,%d0
	lsr.l #1,d0					*	lsr.l #1,%d0
	move.l d0,d7					*	move.l %d0,%d7
	subq.l #1,d7					*	subq.l #1,%d7
	lea _frame_downheap,a6				*	lea frame_downheap,%a6
	tst.l d0					*	tst.l %d0
	jbne _?L371					*	jne .L371
	jbra _?L368					*	jra .L368
							*	.size	search_object, .-search_object
	.align	2					*	.align	2
	.globl	___register_frame_info_bases		*	.globl	__register_frame_info_bases
							*	.hidden	__register_frame_info_bases
							*	.type	__register_frame_info_bases, @function
___register_frame_info_bases:				*__register_frame_info_bases:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	tst.l a1					*	tst.l %a1
	jbeq _?L465					*	jeq .L465
	tst.l (a1)					*	tst.l (%a1)
	jbeq _?L465					*	jeq .L465
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l 12(sp),4(a0)				*	move.l 12(%sp),4(%a0)
	move.l 16(sp),8(a0)				*	move.l 16(%sp),8(%a0)
	move.l a1,12(a0)				*	move.l %a1,12(%a0)
	clr.l 16(a0)					*	clr.l 16(%a0)
	move.w #8160,16(a0)				*	move.w #8160,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
_?L465:							*.L465:
	rts						*	rts
							*	.size	__register_frame_info_bases, .-__register_frame_info_bases
	.align	2					*	.align	2
	.globl	___register_frame_info			*	.globl	__register_frame_info
							*	.hidden	__register_frame_info
							*	.type	__register_frame_info, @function
___register_frame_info:					*__register_frame_info:
	move.l 4(sp),a1					*	move.l 4(%sp),%a1
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	tst.l a1					*	tst.l %a1
	jbeq _?L472					*	jeq .L472
	tst.l (a1)					*	tst.l (%a1)
	jbeq _?L472					*	jeq .L472
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l a1,12(a0)				*	move.l %a1,12(%a0)
	clr.l 16(a0)					*	clr.l 16(%a0)
	move.w #8160,16(a0)				*	move.w #8160,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
_?L472:							*.L472:
	rts						*	rts
							*	.size	__register_frame_info, .-__register_frame_info
	.align	2					*	.align	2
	.globl	___register_frame			*	.globl	__register_frame
							*	.hidden	__register_frame
							*	.type	__register_frame, @function
___register_frame:					*__register_frame:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 8(sp),a3					*	move.l 8(%sp),%a3
	tst.l (a3)					*	tst.l (%a3)
	jbne _?L483					*	jne .L483
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
_?L483:							*.L483:
	pea 24.w					*	pea 24.w
	jbsr _malloc					*	jsr malloc
	move.l d0,a0					*	move.l %d0,%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l a3,12(a0)				*	move.l %a3,12(%a0)
	move.l #534773760,16(a0)			*	move.l #534773760,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	addq.l #4,sp					*	addq.l #4,%sp
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
							*	.size	__register_frame, .-__register_frame
	.align	2					*	.align	2
	.globl	___register_frame_info_table_bases	*	.globl	__register_frame_info_table_bases
							*	.hidden	__register_frame_info_table_bases
							*	.type	__register_frame_info_table_bases, @function
___register_frame_info_table_bases:			*__register_frame_info_table_bases:
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	move.l 12(sp),4(a0)				*	move.l 12(%sp),4(%a0)
	move.l 16(sp),8(a0)				*	move.l 16(%sp),8(%a0)
	move.l 4(sp),12(a0)				*	move.l 4(%sp),12(%a0)
	move.w #24544,16(a0)				*	move.w #24544,16(%a0)
	clr.w 18(a0)					*	clr.w 18(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	rts						*	rts
							*	.size	__register_frame_info_table_bases, .-__register_frame_info_table_bases
	.align	2					*	.align	2
	.globl	___register_frame_info_table		*	.globl	__register_frame_info_table
							*	.hidden	__register_frame_info_table
							*	.type	__register_frame_info_table, @function
___register_frame_info_table:				*__register_frame_info_table:
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l 4(sp),12(a0)				*	move.l 4(%sp),12(%a0)
	move.w #24544,16(a0)				*	move.w #24544,16(%a0)
	clr.w 18(a0)					*	clr.w 18(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	rts						*	rts
							*	.size	__register_frame_info_table, .-__register_frame_info_table
	.align	2					*	.align	2
	.globl	___register_frame_table			*	.globl	__register_frame_table
							*	.hidden	__register_frame_table
							*	.type	__register_frame_table, @function
___register_frame_table:				*__register_frame_table:
	pea 24.w					*	pea 24.w
	jbsr _malloc					*	jsr malloc
	move.l d0,a0					*	move.l %d0,%a0
	moveq #-1,d0					*	moveq #-1,%d0
	move.l d0,(a0)					*	move.l %d0,(%a0)
	clr.l 4(a0)					*	clr.l 4(%a0)
	clr.l 8(a0)					*	clr.l 8(%a0)
	move.l 8(sp),12(a0)				*	move.l 8(%sp),12(%a0)
	move.l #1608515584,16(a0)			*	move.l #1608515584,16(%a0)
	move.l _unseen_objects,20(a0)			*	move.l unseen_objects,20(%a0)
	move.l a0,_unseen_objects			*	move.l %a0,unseen_objects
	addq.l #4,sp					*	addq.l #4,%sp
	rts						*	rts
							*	.size	__register_frame_table, .-__register_frame_table
	.align	2					*	.align	2
	.globl	___deregister_frame_info_bases		*	.globl	__deregister_frame_info_bases
							*	.hidden	__deregister_frame_info_bases
							*	.type	__deregister_frame_info_bases, @function
___deregister_frame_info_bases:				*__deregister_frame_info_bases:
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	move.l 8(sp),a0					*	move.l 8(%sp),%a0
	tst.l a0					*	tst.l %a0
	jbeq _?L501					*	jeq .L501
	tst.l (a0)					*	tst.l (%a0)
	jbeq _?L501					*	jeq .L501
	move.l _unseen_objects,a3			*	move.l unseen_objects,%a3
	tst.l a3					*	tst.l %a3
	jbeq _?L492					*	jeq .L492
	lea _unseen_objects,a1				*	lea unseen_objects,%a1
_?L494:							*.L494:
	cmp.l 12(a3),a0					*	cmp.l 12(%a3),%a0
	jbeq _?L510					*	jeq .L510
	lea (20,a3),a1					*	lea (20,%a3),%a1
	move.l 20(a3),a3				*	move.l 20(%a3),%a3
	tst.l a3					*	tst.l %a3
	jbne _?L494					*	jne .L494
_?L492:							*.L492:
	move.l _seen_objects,a3				*	move.l seen_objects,%a3
	tst.l a3					*	tst.l %a3
	jbeq _?L495					*	jeq .L495
	lea _seen_objects,a1				*	lea seen_objects,%a1
_?L499:							*.L499:
	tst.b 16(a3)					*	tst.b 16(%a3)
	jblt _?L513					*	jlt .L513
	cmp.l 12(a3),a0					*	cmp.l 12(%a3),%a0
	jbeq _?L510					*	jeq .L510
_?L497:							*.L497:
	lea (20,a3),a1					*	lea (20,%a3),%a1
	move.l 20(a3),a3				*	move.l 20(%a3),%a3
	tst.l a3					*	tst.l %a3
	jbne _?L499					*	jne .L499
_?L495:							*.L495:
	trap #7						*	trap #7
_?L510:							*.L510:
	move.l 20(a3),(a1)				*	move.l 20(%a3),(%a1)
	move.l a3,d0					*	move.l %a3,%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
_?L513:							*.L513:
	move.l 12(a3),a2				*	move.l 12(%a3),%a2
	cmp.l (a2),a0					*	cmp.l (%a2),%a0
	jbne _?L497					*	jne .L497
	move.l 20(a3),(a1)				*	move.l 20(%a3),(%a1)
	move.l a2,-(sp)					*	move.l %a2,-(%sp)
	jbsr _free					*	jsr free
	addq.l #4,sp					*	addq.l #4,%sp
	move.l a3,d0					*	move.l %a3,%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
_?L501:							*.L501:
	lea 0.w,a3					*	lea 0.w,%a3
	move.l a3,d0					*	move.l %a3,%d0
	move.l (sp)+,a3					*	move.l (%sp)+,%a3
	rts						*	rts
							*	.size	__deregister_frame_info_bases, .-__deregister_frame_info_bases
	.align	2					*	.align	2
	.globl	___deregister_frame_info		*	.globl	__deregister_frame_info
							*	.hidden	__deregister_frame_info
							*	.type	__deregister_frame_info, @function
___deregister_frame_info:				*__deregister_frame_info:
	jbra ___deregister_frame_info_bases		*	jra __deregister_frame_info_bases
							*	.size	__deregister_frame_info, .-__deregister_frame_info
	.align	2					*	.align	2
	.globl	___deregister_frame			*	.globl	__deregister_frame
							*	.hidden	__deregister_frame
							*	.type	__deregister_frame, @function
___deregister_frame:					*__deregister_frame:
	move.l 4(sp),a0					*	move.l 4(%sp),%a0
	tst.l (a0)					*	tst.l (%a0)
	jbne _?L520					*	jne .L520
	rts						*	rts
_?L520:							*.L520:
	move.l a0,-(sp)					*	move.l %a0,-(%sp)
	jbsr ___deregister_frame_info_bases		*	jsr __deregister_frame_info_bases
	addq.l #4,sp					*	addq.l #4,%sp
	move.l d0,4(sp)					*	move.l %d0,4(%sp)
	jbra _free					*	jra free
							*	.size	__deregister_frame, .-__deregister_frame
	.align	2					*	.align	2
	.globl	__Unwind_Find_FDE			*	.globl	_Unwind_Find_FDE
							*	.hidden	_Unwind_Find_FDE
							*	.type	_Unwind_Find_FDE, @function
__Unwind_Find_FDE:					*_Unwind_Find_FDE:
	link.w a6,#-4					*	link.w %fp,#-4
	movem.l d3/d4/a3/a4/a5,-(sp)			*	movem.l #6172,-(%sp)
	move.l 8(a6),d3					*	move.l 8(%fp),%d3
	move.l 12(a6),a5				*	move.l 12(%fp),%a5
	move.l _seen_objects,a4				*	move.l seen_objects,%a4
	tst.l a4					*	tst.l %a4
	jbeq _?L522					*	jeq .L522
_?L525:							*.L525:
	cmp.l (a4),d3					*	cmp.l (%a4),%d3
	jbcc _?L552					*	jcc .L552
	move.l 20(a4),a4				*	move.l 20(%a4),%a4
	tst.l a4					*	tst.l %a4
	jbne _?L525					*	jne .L525
_?L522:							*.L522:
	lea _search_object,a4				*	lea search_object,%a4
	move.l #_seen_objects,d4			*	move.l #seen_objects,%d4
_?L528:							*.L528:
	move.l _unseen_objects,a3			*	move.l unseen_objects,%a3
	tst.l a3					*	tst.l %a3
	jbeq _?L521					*	jeq .L521
	move.l 20(a3),_unseen_objects			*	move.l 20(%a3),unseen_objects
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a3,-(sp)					*	move.l %a3,-(%sp)
	jbsr (a4)					*	jsr (%a4)
	move.l _seen_objects,a0				*	move.l seen_objects,%a0
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l a0					*	tst.l %a0
	jbeq _?L537					*	jeq .L537
	move.l (a3),d1					*	move.l (%a3),%d1
	move.l d4,a1					*	move.l %d4,%a1
_?L527:							*.L527:
	cmp.l (a0),d1					*	cmp.l (%a0),%d1
	jbhi _?L526					*	jhi .L526
	lea (20,a0),a1					*	lea (20,%a0),%a1
	move.l 20(a0),a0				*	move.l 20(%a0),%a0
	tst.l a0					*	tst.l %a0
	jbne _?L527					*	jne .L527
_?L526:							*.L526:
	move.l a0,20(a3)				*	move.l %a0,20(%a3)
	move.l a3,(a1)					*	move.l %a3,(%a1)
	tst.l d0					*	tst.l %d0
	jbeq _?L528					*	jeq .L528
_?L556:							*.L556:
	move.l a3,a4					*	move.l %a3,%a4
	move.l d0,a3					*	move.l %d0,%a3
	move.l 4(a4),d4					*	move.l 4(%a4),%d4
	move.l d4,(a5)					*	move.l %d4,(%a5)
	move.l 8(a4),d3					*	move.l 8(%a4),%d3
	move.l d3,4(a5)					*	move.l %d3,4(%a5)
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	bfextu d0{#19:#8},d0				*	bfextu %d0{#19:#8},%d0
	btst #5,16(a4)					*	btst #5,16(%a4)
	jbne _?L531					*	jne .L531
_?L554:							*.L554:
	clr.l d2					*	clr.l %d2
	move.b d0,d2					*	move.b %d0,%d2
	move.l a3,d1					*	move.l %a3,%d1
	addq.l #8,d1					*	addq.l #8,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbeq _?L540					*	jeq .L540
_?L555:							*.L555:
	and.b #112,d0					*	and.b #112,%d0
	cmp.b #32,d0					*	cmp.b #32,%d0
	jbeq _?L534					*	jeq .L534
	jbls _?L540					*	jls .L540
	cmp.b #48,d0					*	cmp.b #48,%d0
	jbne _?L553					*	jne .L553
_?L533:							*.L533:
	pea -4(a6)					*	pea -4(%fp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l -4(a6),8(a5)				*	move.l -4(%fp),8(%a5)
	add.w #16,sp					*	add.w #16,%sp
_?L521:							*.L521:
	move.l a3,d0					*	move.l %a3,%d0
	movem.l -24(a6),d3/d4/a3/a4/a5			*	movem.l -24(%fp),#14360
	unlk a6						*	unlk %fp
	rts						*	rts
_?L552:							*.L552:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l a4,-(sp)					*	move.l %a4,-(%sp)
	jbsr _search_object				*	jsr search_object
	move.l d0,a3					*	move.l %d0,%a3
	addq.l #8,sp					*	addq.l #8,%sp
	tst.l d0					*	tst.l %d0
	jbeq _?L522					*	jeq .L522
	move.l 4(a4),d4					*	move.l 4(%a4),%d4
	move.l d4,(a5)					*	move.l %d4,(%a5)
	move.l 8(a4),d3					*	move.l 8(%a4),%d3
	move.l d3,4(a5)					*	move.l %d3,4(%a5)
	move.w 16(a4),d0				*	move.w 16(%a4),%d0
	bfextu d0{#19:#8},d0				*	bfextu %d0{#19:#8},%d0
	btst #5,16(a4)					*	btst #5,16(%a4)
	jbeq _?L554					*	jeq .L554
_?L531:							*.L531:
	move.l a3,d0					*	move.l %a3,%d0
	addq.l #4,d0					*	addq.l #4,%d0
	sub.l 4(a3),d0					*	sub.l 4(%a3),%d0
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr _get_cie_encoding				*	jsr get_cie_encoding
	addq.l #4,sp					*	addq.l #4,%sp
	moveq #0,d2					*	moveq #0,%d2
	not.b d2					*	not.b %d2
	and.l d0,d2					*	and.l %d0,%d2
	move.l a3,d1					*	move.l %a3,%d1
	addq.l #8,d1					*	addq.l #8,%d1
	cmp.b #-1,d0					*	cmp.b #-1,%d0
	jbne _?L555					*	jne .L555
_?L540:							*.L540:
	clr.l d3					*	clr.l %d3
	pea -4(a6)					*	pea -4(%fp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l -4(a6),8(a5)				*	move.l -4(%fp),8(%a5)
	add.w #16,sp					*	add.w #16,%sp
	jbra _?L521					*	jra .L521
_?L537:							*.L537:
	lea _seen_objects,a1				*	lea seen_objects,%a1
	move.l a0,20(a3)				*	move.l %a0,20(%a3)
	move.l a3,(a1)					*	move.l %a3,(%a1)
	tst.l d0					*	tst.l %d0
	jbeq _?L528					*	jeq .L528
	jbra _?L556					*	jra .L556
_?L534:							*.L534:
	move.l d4,d3					*	move.l %d4,%d3
	pea -4(a6)					*	pea -4(%fp)
	move.l d1,-(sp)					*	move.l %d1,-(%sp)
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l d2,-(sp)					*	move.l %d2,-(%sp)
	jbsr _read_encoded_value_with_base		*	jsr read_encoded_value_with_base
	move.l -4(a6),8(a5)				*	move.l -4(%fp),8(%a5)
	add.w #16,sp					*	add.w #16,%sp
	jbra _?L521					*	jra .L521
_?L553:							*.L553:
	clr.l d3					*	clr.l %d3
	cmp.b #80,d0					*	cmp.b #80,%d0
	jbeq _?L533					*	jeq .L533
	trap #7						*	trap #7
							*	.size	_Unwind_Find_FDE, .-_Unwind_Find_FDE
	.data						*	.section	.rodata
	.align	2					*	.align	2
							*	.type	terminator.0, @object
							*	.size	terminator.0, 8
_terminator?0:						*terminator.0:
	.ds.b	8					*	.zero	8
							*	.local	seen_objects
	.align 2	* workaround for 3 args .comm directive.
	.comm	_seen_objects,4				*	.comm	seen_objects,4,2
							*	.local	unseen_objects
	.align 2	* workaround for 3 args .comm directive.
	.comm	_unseen_objects,4			*	.comm	unseen_objects,4,2
							*	.ident	"GCC: (GNU) 13.4.0"
