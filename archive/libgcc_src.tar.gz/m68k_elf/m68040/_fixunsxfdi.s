* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.globl	___fixunsxfsi				*	.globl	__fixunsxfsi
	.globl	___floatundixf				*	.globl	__floatundixf
	.data						*	.section	.rodata
	.align	2					*	.align	2
_?LC0:							*.LC0:
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.dc.l	0					*	.long	0
	.align	2					*	.align	2
_?LC1:							*.LC1:
	.dc.l	1071579136				*	.long	1071579136
	.dc.l	-2147483648				*	.long	-2147483648
	.dc.l	0					*	.long	0
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixunsxfdi				*	.globl	__fixunsxfdi
							*	.hidden	__fixunsxfdi
							*	.type	__fixunsxfdi, @function
___fixunsxfdi:						*__fixunsxfdi:
	fmovem fp2/fp5,-(sp)				*	fmovem #36,-(%sp)
	movem.l d4/d5/d6/d7/a3/a4/a5,-(sp)		*	movem.l #3868,-(%sp)
	fmove.x 56(sp),fp2				*	fmove.x 56(%sp),%fp2
	fmove.x _?LC0,fp5				*	fmove.x .LC0,%fp5
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fblt _?L5					*	fjlt .L5
	lea ___fixunsxfsi,a3				*	lea __fixunsxfsi,%a3
	fmove.x fp2,fp0					*	fmove.x %fp2,%fp0
	fmul.x _?LC1,fp0				*	fmul.x .LC1,%fp0
	fmove.x fp0,-(sp)				*	fmove.x %fp0,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	add.w #12,sp					*	add.w #12,%sp
	move.l d0,d4					*	move.l %d0,%d4
	clr.l d5					*	clr.l %d5
	move.l d5,-(sp)					*	move.l %d5,-(%sp)
	move.l d0,-(sp)					*	move.l %d0,-(%sp)
	jbsr ___floatundixf				*	jsr __floatundixf
	addq.l #8,sp					*	addq.l #8,%sp
	fsub.x fp0,fp2					*	fsub.x %fp0,%fp2
	fcmp.x fp5,fp2					*	fcmp.x %fp5,%fp2
	fblt _?L10					*	fjlt .L10
	fmove.x fp2,-(sp)				*	fmove.x %fp2,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	add.w #12,sp					*	add.w #12,%sp
	move.l d0,a5					*	move.l %d0,%a5
	lea 0.w,a4					*	lea 0.w,%a4
	move.l a4,d0					*	move.l %a4,%d0
	move.l a5,d1					*	move.l %a5,%d1
	add.l d5,d1					*	add.l %d5,%d1
	addx.l d4,d0					*	addx.l %d4,%d0
	movem.l (sp)+,d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14576
	fmovem (sp)+,fp2/fp5				*	fmovem (%sp)+,#36
	rts						*	rts
_?L10:							*.L10:
	fneg.x fp2,fp2					*	fneg.x %fp2,%fp2
	fmove.x fp2,-(sp)				*	fmove.x %fp2,-(%sp)
	jbsr (a3)					*	jsr (%a3)
	add.w #12,sp					*	add.w #12,%sp
	move.l d0,d7					*	move.l %d0,%d7
	clr.l d6					*	clr.l %d6
	move.l d4,d0					*	move.l %d4,%d0
	move.l d5,d1					*	move.l %d5,%d1
	sub.l d7,d1					*	sub.l %d7,%d1
	subx.l d6,d0					*	subx.l %d6,%d0
	movem.l (sp)+,d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14576
	fmovem (sp)+,fp2/fp5				*	fmovem (%sp)+,#36
	rts						*	rts
_?L5:							*.L5:
	clr.l d0					*	clr.l %d0
	clr.l d1					*	clr.l %d1
	movem.l (sp)+,d4/d5/d6/d7/a3/a4/a5		*	movem.l (%sp)+,#14576
	fmovem (sp)+,fp2/fp5				*	fmovem (%sp)+,#36
	rts						*	rts
							*	.size	__fixunsxfdi, .-__fixunsxfdi
							*	.ident	"GCC: (GNU) 13.4.0"
