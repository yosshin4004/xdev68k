* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___ctzdi2				*	.globl	__ctzdi2
							*	.hidden	__ctzdi2
							*	.type	__ctzdi2, @function
___ctzdi2:						*__ctzdi2:
	move.l 4(sp),d2					*	move.l 4(%sp),%d2
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	jbeq _?L2					*	jeq .L2
	move.l d0,d2					*	move.l %d0,%d2
	lea 0.w,a0					*	lea 0.w,%a0
_?L3:							*.L3:
	move.l d2,d1					*	move.l %d2,%d1
	neg.l d1					*	neg.l %d1
	and.l d2,d1					*	and.l %d2,%d1
	cmp.l #65535,d1					*	cmp.l #65535,%d1
	jbhi _?L4					*	jhi .L4
	cmp.l #255,d1					*	cmp.l #255,%d1
	shi d2						*	shi %d2
	extb.l d2					*	extb.l %d2
	neg.l d2					*	neg.l %d2
	lsl.l #3,d2					*	lsl.l #3,%d2
	move.l d2,a1					*	move.l %d2,%a1
	subq.l #1,a1					*	subq.l #1,%a1
	lsr.l d2,d1					*	lsr.l %d2,%d1
	clr.l d0					*	clr.l %d0
	move.b ___clz_tab(d1.l),d0			*	move.b __clz_tab(%d1.l),%d0
	add.l a1,d0					*	add.l %a1,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L4:							*.L4:
	cmp.l #16777215,d1				*	cmp.l #16777215,%d1
	jbhi _?L6					*	jhi .L6
	move.w #15,a1					*	move.w #15,%a1
	moveq #16,d2					*	moveq #16,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	clr.l d0					*	clr.l %d0
	move.b ___clz_tab(d1.l),d0			*	move.b __clz_tab(%d1.l),%d0
	add.l a1,d0					*	add.l %a1,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
_?L2:							*.L2:
	move.w #32,a0					*	move.w #32,%a0
	jbra _?L3					*	jra .L3
_?L6:							*.L6:
	move.w #23,a1					*	move.w #23,%a1
	moveq #24,d2					*	moveq #24,%d2
	lsr.l d2,d1					*	lsr.l %d2,%d1
	clr.l d0					*	clr.l %d0
	move.b ___clz_tab(d1.l),d0			*	move.b __clz_tab(%d1.l),%d0
	add.l a1,d0					*	add.l %a1,%d0
	add.l a0,d0					*	add.l %a0,%d0
	rts						*	rts
							*	.size	__ctzdi2, .-__ctzdi2
							*	.ident	"GCC: (GNU) 13.4.0"
