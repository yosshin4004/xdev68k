* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___fixdfdi				*	.globl	__fixdfdi
							*	.hidden	__fixdfdi
							*	.type	__fixdfdi, @function
___fixdfdi:						*__fixdfdi:
	fdmove.d 4(sp),fp0				*	fdmove.d 4(%sp),%fp0
	fblt _?L8					*	fjlt .L8
	fmove.d fp0,4(sp)				*	fmove.d %fp0,4(%sp)
	jbra ___fixunsdfdi				*	jra __fixunsdfdi
_?L8:							*.L8:
	fdneg.x fp0,fp0					*	fdneg.x %fp0,%fp0
	fmove.d fp0,-(sp)				*	fmove.d %fp0,-(%sp)
	jbsr ___fixunsdfdi				*	jsr __fixunsdfdi
	neg.l d1					*	neg.l %d1
	negx.l d0					*	negx.l %d0
	addq.l #8,sp					*	addq.l #8,%sp
	rts						*	rts
							*	.size	__fixdfdi, .-__fixdfdi
							*	.ident	"GCC: (GNU) 13.4.0"
