* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___absvsi2				*	.globl	__absvsi2
							*	.hidden	__absvsi2
							*	.type	__absvsi2, @function
___absvsi2:						*__absvsi2:
	move.l 4(sp),d1					*	move.l 4(%sp),%d1
	move.l d1,d2					*	move.l %d1,%d2
	add.l d2,d2					*	add.l %d2,%d2
	subx.l d2,d2					*	subx.l %d2,%d2
	move.l d1,d0					*	move.l %d1,%d0
	add.l d2,d0					*	add.l %d2,%d0
	eor.l d2,d1					*	eor.l %d2,%d1
	eor.l d2,d0					*	eor.l %d2,%d0
	not.l d1					*	not.l %d1
	and.l d0,d1					*	and.l %d0,%d1
	jbmi _?L7					*	jmi .L7
	rts						*	rts
_?L7:							*.L7:
	trap #7						*	trap #7
							*	.size	__absvsi2, .-__absvsi2
							*	.ident	"GCC: (GNU) 13.4.0"
