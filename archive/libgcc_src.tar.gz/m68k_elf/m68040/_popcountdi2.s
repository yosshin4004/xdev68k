* NO_APP
RUNS_HUMAN_VERSION	equ	3
	.cpu 68040
* X68 GCC Develop
* APP OFF (NO_APP) asm_mode=gas				*#NO_APP
	.file	"libgcc2.c"				*	.file	"libgcc2.c"
	.text						*	.text
	.align	2					*	.align	2
	.globl	___popcountdi2				*	.globl	__popcountdi2
							*	.hidden	__popcountdi2
							*	.type	__popcountdi2, @function
___popcountdi2:						*__popcountdi2:
	move.l d3,-(sp)					*	move.l %d3,-(%sp)
	move.l 8(sp),d0					*	move.l 8(%sp),%d0
	move.l 12(sp),d1				*	move.l 12(%sp),%d1
	move.l d1,d2					*	move.l %d1,%d2
	lsr.l #1,d2					*	lsr.l #1,%d2
	and.l #1431655765,d2				*	and.l #1431655765,%d2
	sub.l d2,d1					*	sub.l %d2,%d1
	move.l d0,d2					*	move.l %d0,%d2
	lsr.l #1,d2					*	lsr.l #1,%d2
	and.l #1431655765,d2				*	and.l #1431655765,%d2
	sub.l d2,d0					*	sub.l %d2,%d0
	move.l d1,d3					*	move.l %d1,%d3
	and.l #858993459,d3				*	and.l #858993459,%d3
	lsr.l #2,d1					*	lsr.l #2,%d1
	and.l #858993459,d1				*	and.l #858993459,%d1
	add.l d1,d3					*	add.l %d1,%d3
	move.l d0,d2					*	move.l %d0,%d2
	and.l #858993459,d2				*	and.l #858993459,%d2
	lsr.l #2,d0					*	lsr.l #2,%d0
	and.l #858993459,d0				*	and.l #858993459,%d0
	add.l d0,d2					*	add.l %d0,%d2
	move.l d3,d1					*	move.l %d3,%d1
	lsr.l #4,d1					*	lsr.l #4,%d1
	add.l d3,d1					*	add.l %d3,%d1
	and.l #252645135,d1				*	and.l #252645135,%d1
	move.l d2,d0					*	move.l %d2,%d0
	lsr.l #4,d0					*	lsr.l #4,%d0
	add.l d2,d0					*	add.l %d2,%d0
	and.l #252645135,d0				*	and.l #252645135,%d0
	add.l d1,d0					*	add.l %d1,%d0
	muls.l #16843009,d0				*	muls.l #16843009,%d0
	moveq #24,d1					*	moveq #24,%d1
	lsr.l d1,d0					*	lsr.l %d1,%d0
	move.l (sp)+,d3					*	move.l (%sp)+,%d3
	rts						*	rts
							*	.size	__popcountdi2, .-__popcountdi2
							*	.ident	"GCC: (GNU) 13.4.0"
